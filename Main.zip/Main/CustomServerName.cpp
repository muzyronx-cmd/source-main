#include "stdafx.h"
#include "CustomServerName.h"
#include "Util.h"
#include "LuaStack.hpp"

using namespace luaaa;

CCustomServerName gCustomServerName;

CCustomServerName::CCustomServerName() : m_Lua(false)
{
	this->m_ServerNameInfo.clear();
}

CCustomServerName::~CCustomServerName()
{
	this->m_ServerNameInfo.clear();
}

int ChangeServerName(DWORD Struct) {
	auto serverInfo = gCustomServerName.GetServer(*(DWORD *)(Struct + 8));

	if (serverInfo) {
		if (*(DWORD *)(Struct + 8) == serverInfo->ServerID) {
			std::memcpy((char*)(Struct + 21), serverInfo->ServerName, 50);
			return 1;
		}
	}

	return 0;
}

void __declspec(naked) ChangeSubServerName() {
	static DWORD ExitFunc = 0x0095415C;
	static DWORD ReturnFunc = 0x00954078;

	static DWORD m_OldEax = 0;
	static DWORD m_OldEcx = 0;
	static DWORD m_OldEbx = 0;
	static DWORD m_OldEbp = 0;

	_asm {
		MOV m_OldEax, EAX;
		MOV m_OldEcx, Ecx;
		MOV m_OldEbx, Ebx;
		MOV m_OldEbp, Ebp;

		MOV ECX, DWORD PTR SS : [EBP - 0x14];
		MOVZX EDX, BYTE PTR DS : [ECX + 0x14];
		PUSH ECX;
		CALL[ChangeServerName];
		Test Eax, Eax
		Je RETURN

		JMP[ExitFunc];

	RETURN:
		MOV EAX, m_OldEax;
		MOV Ecx, m_OldEcx;
		MOV Ebx, m_OldEbx;
		MOV Ebp, m_OldEbp;

		MOV ECX, DWORD PTR SS : [EBP - 0x14];
		MOVZX EDX, BYTE PTR DS : [ECX + 0x14];
		JMP[ReturnFunc];
	}
}

void SetServerName(int ServerID, char* ServerName) {
	CUSTOM_SERVER_NAME_INFO info;

	info.ServerID = ServerID;

	strcpy_s(info.ServerName, ServerName);

	gCustomServerName.m_ServerNameInfo.insert(std::make_pair(info.ServerID, info));
}

CUSTOM_SERVER_NAME_INFO * CCustomServerName::GetServer(int ServerID)
{
	std::map<int, CUSTOM_SERVER_NAME_INFO>::iterator it = this->m_ServerNameInfo.find(ServerID);

	if (it == this->m_ServerNameInfo.end()) {
		return 0;
	}

	return &it->second;
}

void CCustomServerName::Init()
{
	SetCompleteHook(0xE9, 0x00954071, &ChangeSubServerName);

	LuaModule(this->m_Lua.GetState()).fun("SetServerName", &SetServerName);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomServerName.lua");

	this->m_Lua.Generic_Call("StartLoadCustomServerName", "");
}
