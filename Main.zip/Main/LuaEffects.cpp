#include "stdafx.h"
#include "LuaEffects.h"
#include "LuaStack.hpp"
#include "Item.h"
#include "Console.h"

using namespace luaaa;

vec34_t* BoneTransform = (vec34_t*)(0x7BC08A0);

void FuncCreateParticle(DWORD BMDStruct, int Bitmap, int SubType, int Link, float Scale, vec3_t Light, DWORD ObjectStruct) {
	if (BMDStruct == 0 || ObjectStruct == 0) {
		return;
	}

	vec3_t Position, p;
	p[0] = 0.f; p[1] = 0.f; p[2] = 0.f;
	auto Object = &*(ObjectModel*)ObjectStruct;

	if (Object != nullptr) {
		if (Object->Type >= GET_ITEM_MODEL(13, 150) && Object->Type <= GET_ITEM_MODEL(13, 500)
			|| Object->Type >= GET_ITEM_MODEL(14, 150) && Object->Type <= GET_ITEM_MODEL(16, 0)) {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 0);
		}
		else if (Object->Type >= GET_ITEM_MODEL(18, 0) && Object->Type <= GET_ITEM_MODEL(20, 0)) {
			((void(__thiscall*)(void*, vec34_t, vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, Object->BoneTransform[Link], p, Position, 0);
		}
		else {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 1);
		}
	}
	else {
		((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 1);
	}

	((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(Bitmap, Position, Object->Angle, Light, SubType, Scale, ObjectStruct);
}

void FuncCreateSprite(DWORD BMDStruct, int Bitmap, int Link, float Scale, vec3_t Light, DWORD ObjectStruct) {
	if (BMDStruct == 0 || ObjectStruct == 0) {
		return;
	}

	vec3_t Position, p;
	p[0] = 0.f; p[1] = 0.f; p[2] = 0.f;

	auto Object = &*(ObjectModel*)ObjectStruct;

	if (Object != nullptr) {
		if (Object->Type >= GET_ITEM_MODEL(13, 150) && Object->Type <= GET_ITEM_MODEL(13, 500)
			|| Object->Type >= GET_ITEM_MODEL(14, 150) && Object->Type <= GET_ITEM_MODEL(16, 0)) {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 0);
		}
		else if (Object->Type >= GET_ITEM_MODEL(18, 0) && Object->Type <= GET_ITEM_MODEL(20, 0)) {
			((void(__thiscall*)(void*, vec34_t, vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, Object->BoneTransform[Link], p, Position, 0);
		}
		else {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 1);
		}
	}
	else {
		((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 1);
	}

	((void(*)(int, vec3_t, float, vec3_t, DWORD, float, int))0x771310)(Bitmap, Position, Scale, Light, ObjectStruct, 0.0, 0);
}

void CreateSprite(DWORD BMDStruct, int Bitmap, int Link, float Scale, float LightR, float LightG, float LightB, DWORD ObjectStruct) {
	vec3_t Light;

	Vector(LightR, LightG, LightB, Light);

	FuncCreateSprite(BMDStruct, Bitmap, Link, Scale, Light, ObjectStruct);
}

void CreateParticle(DWORD BMDStruct, int Bitmap, int SubType, int Link, float Scale, float LightR, float LightG, float LightB, DWORD ObjectStruct) {
	vec3_t Light;

	Vector(LightR, LightG, LightB, Light);

	FuncCreateParticle(BMDStruct, Bitmap, SubType, Link, Scale, Light, ObjectStruct);
}

CLuaEffects::CLuaEffects()
{
}

CLuaEffects::~CLuaEffects()
{
}

void CLuaEffects::RegisterLuaClass(lua_State * lua)
{
	LuaModule(lua).fun("CreateSprite", &CreateSprite);
	LuaModule(lua).fun("CreateParticle", &CreateParticle);
}
