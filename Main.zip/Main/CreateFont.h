#pragma once

#include "Lua.h"

struct FONT_INFO {
	int Bold;
	int AddSize;
	int CharSet;
	std::string Name;
};

class CCreateFont {
public:
	CCreateFont();
	~CCreateFont();

	void Init();

public:
	Lua m_Lua;

	FONT_INFO m_fontInfo[4];
};

extern CCreateFont gCreateFont;