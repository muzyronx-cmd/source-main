#include "stdafx.h"
#include "LoginRemake.h"
#include "AutoLoginWin.h"
#include "CompactLogin.h"
#include "Util.h"
#include "Offset.h"

int PointSY1 = 0; // retained for source compatibility; compact panel does not slide
namespace {
bool installed = false;
DWORD lastClick = 0;
// Derived CUITextInputBox::SetSize, also used by the native Init virtual call.
// 0x417EE0 is the BASE setter and leaves the DIB stride stale.
const auto ResizeInputSurface = (void(__thiscall*)(int,int,int))0x00421910;
const auto SetInputFont = (void(__thiscall*)(int,HFONT))0x00423060;
CompactLogin::InputSurfaceState userSurface, passwordSurface;
struct NativeInput {
    int field;
    const void* Identity() const { return (const void*)field; }
    int Width() const { return *(int*)(field+0x48); }
    int Height() const { return *(int*)(field+0x4C); }
    void RebuildSurface(int width,int height) {
        // The derived setter skips equal dimensions. Invalidate that comparison
        // so a changed screen scale rebuilds the DIB even at equal logical size.
        // No rendering occurs between invalidation and the native resize.
        *(int*)(field+0x48)=0;
        ResizeInputSurface(field,width,height);
    }
    void RestoreFont() {
        SetInputFont(field,(HFONT)pFontNormal2);
        *(float*)(field+0x9C)=0; // renderer remeasures glyph height after rebuilding
    }
    void Position(int x,int y) { SetBoundInputField(field,x,y); }
};

bool IsLoginVisible() {
    return *(int*)0x087935A4 == 2 && *(int*)0x00E60960 == 1;
}
bool OriginalCall(DWORD address, DWORD target) {
    return *(BYTE*)address == 0xE8 &&
        address + 5 + *(DWORD*)(address + 1) == target;
}
void Text(int x,int y,const char* value,int width=0,int align=CompactLogin::TextLeft) {
    pDrawText(pTextThis(),x,y,value,width,0,align,0);
}
void Image(int id,const CompactLogin::Rect& r,float u,float v) {
    RenderBitmap(id,(float)r.x,(float)r.y,(float)r.w,(float)r.h,0,0,u,v,1,1,0);
}
void PositionFields() {
    const CompactLogin::Layout ui = CompactLogin::GetLayout();
    const int login = _Instance() + 16968;
    const int user = *(DWORD*)(login + 848);
    const int password = *(DWORD*)(login + 852);
    if (!user || !password) return;
    NativeInput userInput={user}, passwordInput={password};
    const CompactLogin::Rect userBounds={ui.user.x+5,ui.user.y+2,ui.user.w-24,ui.user.h-4};
    const CompactLogin::Rect passwordBounds={ui.password.x+5,ui.password.y+2,ui.password.w-10,ui.password.h-4};
    CompactLogin::FitInput(userInput,userSurface,userBounds,g_fScreenRate_x,g_fScreenRate_y);
    CompactLogin::FitInput(passwordInput,passwordSurface,passwordBounds,g_fScreenRate_x,g_fScreenRate_y);
}
// The original site calls a thiscall color setter with four stack arguments.
// Fastcall's unused EDX slot preserves that ABI and the 16-byte stack cleanup.
void __fastcall LoginScene(int text,int,int red,int green,int blue,int alpha) {
    pSetTextColor((LPVOID)text,red,green,blue,alpha);
    if (!IsLoginVisible()) {
        AutoLogin.SetShowListAccount(false);
        return;
    }
    PositionFields();
    ((void(*)())0x00637770)();
    EnableAlphaTest(true);
    glColor4f(1,1,1,1);
    Image(531020,CompactLogin::GetLayout().panel,250.0f/256.0f,216.0f/256.0f);
    ((void(*)())0x006366F0)();
}
// Suppress the old field backgrounds only; the native text inputs still render.
void __fastcall HideFieldBar(int,int) { PositionFields(); }
// Keep the native keyboard shortcuts, but retire the old mouse buttons.
void __fastcall HideNativeButton(int button,int,int,int,int) {
    Sprite_SetPosition((BYTE*)button,-10000,-10000,3);
}
void __fastcall HideNativeButtonState(int button,int,int) {
    ((void(__thiscall*)(int,int))0x00401520)(button,0);
}
// Native text drawing is thiscall with seven stack arguments (28 bytes).
int __fastcall HideLabel(int,int,int,int,const char*,int,int,int,SIZE* size) {
    if (size) { size->cx=0; size->cy=0; }
    return 0;
}
int SavedCount() {
    int count=AutoLogin.totalSavedAcc;
    if (count<0) return 0;
    return count>MAX_ACCOUNT_SAVE ? MAX_ACCOUNT_SAVE : count;
}
void AccountName(int index,char* name) {
    memcpy(name,AutoLogin.saved_acc[index].ID,10);
    name[10]=0;
}
}
namespace CompactLogin {
bool Installed() { return installed; }
void Overlay() {
    if (!installed || !IsLoginVisible()) return;
    const Layout ui = GetLayout();
    const int count = SavedCount();
    bool list = AutoLogin.GetShowListAccount(false) && count>0;
    if (pIsKeyRelease(VK_LBUTTON) && (DWORD)(GetTickCount()-lastClick)>=150) {
        const Hit hit = HitTest(pCursorX,pCursorY,list,count);
        if (hit.action!=None) lastClick=GetTickCount();
        switch (hit.action) {
        case ToggleAccounts:
            AutoLogin.SetShowListAccount(!list && count>0);
            break;
        case SelectAccount:
            if (hit.account>=0 && hit.account<count) {
                AutoLogin.SetSelectedAccount(hit.account);
                AutoLogin.Login(hit.account,false);
            }
            AutoLogin.SetShowListAccount(false);
            break;
        case CloseAccounts:
            AutoLogin.SetShowListAccount(false);
            break;
        case ToggleSave:
            AutoLogin.savePass=!AutoLogin.savePass;
            PlayBuffer(25,0,0);
            break;
        case Submit:
            AutoLogin.SetShowListAccount(false);
            cAutoLogin::DoRequestLogin(); // same route as native Enter key hooks
            return;
        case Back:
            AutoLogin.SetShowListAccount(false);
            CancelLogin(_Instance()+16968);
            return;
        default: break;
        }
        list=AutoLogin.GetShowListAccount(false) && count>0;
    }
    ((void(*)())0x00637770)();
    EnableAlphaTest(true);
    glColor4f(1,1,1,1);
    if (!list && ui.enter.Contains(pCursorX,pCursorY))
        Image(531021,ui.enter,70.0f/128.0f,19.0f/32.0f);
    if (!list && ui.back.Contains(pCursorX,pCursorY))
        Image(531022,ui.back,70.0f/128.0f,20.0f/32.0f);
    RenderBitmap(0x7B69,(float)ui.save.x,(float)ui.save.y,10,10,
        0,AutoLogin.savePass?0:15.0f/32.0f,15.0f/16.0f,15.0f/32.0f,1,1,0);
    ((void(*)())0x006366F0)();
    pSetBackgroundTextColor(pTextThis(),0,0,0,0);
    pSetFont(pTextThis(),(int)pFontNormal2);
    pSetTextColor(pTextThis(),235,227,205,255);
    Text(ui.panel.x+13,ui.user.y+4,"Login:");
    Text(ui.panel.x+13,ui.password.y+4,"Senha:");
    Text(ui.save.x+14,ui.save.y+1,"Salvar Senha");
    Text(ui.enter.x,ui.enter.y+4,"Entrar",ui.enter.w,TextCenter);
    Text(ui.back.x,ui.back.y+4,"Voltar",ui.back.w,TextCenter);
    Text(ui.arrow.x,ui.arrow.y+2,">",ui.arrow.w,TextCenter);
    if (list) {
        // Paint the popup LAST, over both native fields and the form captions.
        // Its JPEG row backgrounds are opaque, so covered labels cannot bleed through.
        ((void(*)())0x00637770)();
        EnableAlphaTest(true);
        glColor4f(1,1,1,1);
        for (int i=0;i<count;++i) Image(531021,ui.AccountRow(i),70.0f/128.0f,19.0f/32.0f);
        ((void(*)())0x006366F0)();
        for (int i=0;i<count;++i) {
            char name[11]; AccountName(i,name);
            const Rect row=ui.AccountRow(i);
            Text(row.x+5,row.y+4,name);
        }
    }
    pSetTextColor(pTextThis(),255,255,255,255);
}
}
void RemakeLoginLoad() {
    if (installed) return;
    // Refuse to patch a different native executable build.
    if (*(DWORD*)(0x00D23AD4+8)!=0x00421910) {
        OutputDebugStringA("[CompactLogin] Input vtable mismatch; layout not installed.\n");
        return;
    }
    const DWORD sites[][2] = {
        {0x004D7D13,0x00420040}, {0x0040B554,0x00416C40},
        {0x0040B635,0x00420150}, {0x0040B6A7,0x00420150},
        {0x0040B7A2,0x00420150}, {0x0040B2E2,0x00416640},
        {0x0040B306,0x00416640}, {0x0040B380,0x00401520},
        {0x00401F56,0x00420150}
    };
    for (unsigned i=0;i<sizeof(sites)/sizeof(sites[0]);++i) {
        if (!OriginalCall(sites[i][0],sites[i][1])) {
            OutputDebugStringA("[CompactLogin] Native build mismatch; layout not installed.\n");
            return;
        }
    }
    SetDword(0x006311B6+1,(DWORD)"Logo\\none.tga");
    SetDword(0x006311D6+1,(DWORD)"Logo\\none.tga");
    SetCompleteHook(0xE8,0x004D7D13,&LoginScene);
    SetCompleteHook(0xE8,0x0040B554,&HideFieldBar);
    SetCompleteHook(0xE8,0x0040B635,&HideLabel);
    SetCompleteHook(0xE8,0x0040B6A7,&HideLabel);
    SetCompleteHook(0xE8,0x0040B7A2,&HideLabel);
    SetCompleteHook(0xE8,0x0040B2E2,&HideNativeButton);
    SetCompleteHook(0xE8,0x0040B306,&HideNativeButton);
    SetCompleteHook(0xE8,0x0040B380,&HideNativeButtonState);
    SetCompleteHook(0xE8,0x00401F56,&HideLabel);
    installed=true;
}
