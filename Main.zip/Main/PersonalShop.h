#pragma once

#include "Protocol.h"

class PERSONAL_SHOP_ITENS_VALUE {
public:
	PERSONAL_SHOP_ITENS_VALUE() {
		this->slot = -1;
		this->ItemIndex = -1;
	};

	~PERSONAL_SHOP_ITENS_VALUE() {

	};

	unsigned char slot;
	int ItemIndex;
	int Coin1;
	int Coin2;
	int Coin3;
	int Coin4;
};

struct PMSG_PSHOP_ITEM_LIST_RECV
{
	PSWMSG_HEAD header; // C2:3F:[05:13]
	BYTE result;
	BYTE index[2];
	char name[10];
	char text[36];
	BYTE count;
};

struct PMSG_PSHOP_ITEM_LIST_CUSTOM
{
	BYTE slot;
	int m_Values[4];
	int ItemIndex;
};

struct PMSG_PSHOP_SET_ITEM_PRICE_SEND
{
	PSBMSG_HEAD header; // C1:3F:01
	BYTE slot;
	BYTE price[4];
	int coins[4];
};

struct PMSG_PSHOP_SET_CLOSE_SEND
{
	PSBMSG_HEAD header; // C1:3F:01
};

class CPersonalShop {
public:
	CPersonalShop();
	~CPersonalShop();

	PERSONAL_SHOP_ITENS_VALUE* getItem(int slot);
	PERSONAL_SHOP_ITENS_VALUE* getItemTarget(int slot);
	void Init();
	void InsertItemValue(int ItemIndex, BYTE slot, int Coin1, int Coin2, int Coin3, int Coin4);
	void InsertItemValueTarget(int ItemIndex, BYTE slot, int Coin1, int Coin2, int Coin3, int Coin4);
	void GCPShopItemPrinceListRecv(PMSG_PSHOP_ITEM_LIST_RECV * lpMsg);

	bool UpdateMouseChangeValue();
	bool UpdateChangeValue();
	void RenderWindowChangeValue();

	void PersonalShopValueItemChangeSend(unsigned char slot, int coin1, int coin2, int coin3, int coin4);

	void InsertKeyInInput(int Param);
	void RemoveKeyInInput();

public:
	bool WindowValueVisible;

	int m_x;
	int m_y;
	int m_width;
	int m_height;

	int m_EventKey;
	int m_EventKey2;

	std::string m_TextInput;
	std::string m_TextInput2;
	std::string m_TextInput3;
	std::string m_TextInput4;

	bool m_Input01Open;
	bool m_Input02Open;
	bool m_Input03Open;
	bool m_Input04Open;

private:
	std::map<int, PERSONAL_SHOP_ITENS_VALUE> m_PersonalShopInfo;
	std::map<int, PERSONAL_SHOP_ITENS_VALUE> m_PersonalShopInfoTarget;
};

extern CPersonalShop gPersonalShop;