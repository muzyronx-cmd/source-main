// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define USE_CONSOLE false

#define _WINSOCK_DEPRECATED_NO_WARNINGS

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#define _CRT_SECURE_NO_WARNINGS


// Windows Header Files:
#include <windows.h>
#include <iostream>
#include <string.h>
#include <mbstring.h>
#include <memory>
#include <vector>
#include <map>
#include <Mmsystem.h>
#include <gl\GL.h>
#include <winsock2.h>
#include <map>

// TODO: reference additional headers your program requires here
#include "zzzmathlib.h"
#include "Defines.h"
#include "Structs.h"
#include "Offset.h"

//ATIVAR OU DESATIVAR 

#define WIDESCREEN 0
#define DOWNGRADE  1
#define pPartyMemberCount			*(DWORD*)0x81F6B6C


typedef unsigned __int64 QWORD;

#define CRASH_APPLICATION_MACRO _asm _emit 0xFF _asm _emit 0x25 _asm _emit 0x00 _asm _emit 0x00 _asm _emit 0x00 _asm _emit 0x00

#define BoostSmart_Ptr(classname)  std::shared_ptr<classname>
#define BoostWeak_Ptr(classname)   std::weak_ptr<classname>

#define BoostSmartPointer(classname) \
    class classname; \
    typedef BoostSmart_Ptr(classname) classname##Ptr

#define BoostRest(p) { if(p) { p.reset(); } }