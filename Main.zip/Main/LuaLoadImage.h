#pragma once

#include "Lua.h"

class LuaLoadImage {
public:
	LuaLoadImage();
	~LuaLoadImage();

	void SetFunctions(lua_State* lua);
};