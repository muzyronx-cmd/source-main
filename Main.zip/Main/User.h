#pragma once

#pragma pack(push, 1)

#define sub_558630					((void(__cdecl*)(int a1, int a2, int a3)) 0x558630)

class User
{
public:	
	int CoordenadaX;
	int CoordenadaY;
	int getLevel;
	int getReset;
	char getName[11];
	void		Load();
	void		Refresh();	
	lpCharObj	lpPlayer;
	lpViewObj	lpViewPlayer;
	lpViewObj	lpViewTarget;
	BYTE		m_TargetType;	//1 - npc, 2 - attack
	int			m_MapNumber;
	int			m_CursorX;
	int			MagickAttack;
	int			m_CursorY;
	DWORD		m_TargetUpdateTick;
};
extern User gObjUser;