#pragma once

#include "Lua.h"
#include "LuaLoadImage.h"
#include "LuaBMD.h"

class CapeClass {
public:
	CapeClass() {

	};

	CapeClass(int StackCount) {
		this->m_StackCount = StackCount;

		DWORD CreateStruct = (DWORD)((void*(*)(int)) 0x009CDB52)((this->m_StackCount + 1) * 100);
		this->m_ClockClass = 0;

		if (CreateStruct)
		{
			*(DWORD*)CreateStruct = this->m_StackCount+1;
			((void(__stdcall*)(void*, int, int, void(__thiscall *)(void*), void(__thiscall *)(void*))) 0x009CFA13)
				((void *)(CreateStruct + 4), 96, this->m_StackCount+1, (void(__thiscall*)(void *))((void*)0x51D320), (void(__thiscall*)(void*))((void*)0x51D380));

			this->m_ClockClass = (CreateStruct + 4);
		}
		else
		{
			this->m_ClockClass = 0;
		}
	};

	~CapeClass() {
	};

	void Create(int stack, DWORD o, int iBone, float fxPos, float fyPos, float fzPos, int iNumHor, int iNumVer, float fWidth, float fHeight, int iTexFront, int TexBack, int dwType) const {
		if (this->m_ClockClass == 0 || o == 0) {
			return;
		}

		if (stack <= 1) {
			(*(void(__thiscall **)(int, DWORD, int, float, float, float, int, int, float, float, int, int, int))
				(*(DWORD *)this->m_ClockClass + 4))(this->m_ClockClass, o, iBone, fxPos, fyPos, fzPos, iNumHor, iNumVer, fWidth, fHeight, iTexFront, TexBack, dwType);
		}
		else {
			int stackValue = stack - 1;

			(*(void(__thiscall **)(int, DWORD, int, float, float, float, int, int, float, float, int, int, int))
				(*(DWORD *)(this->m_ClockClass + (96 * stackValue)) + 4))(this->m_ClockClass + (96 * stackValue), o, iBone, fxPos, fyPos, fzPos, iNumHor, iNumVer, fWidth, fHeight, iTexFront, TexBack, dwType);
		}
	};

	void Collision(int stack, float fXPos, float fYPos, float fZPos, float fRadius, int iBone) const {
		if (this->m_ClockClass == 0) {
			return;
		}

		if (stack <= 1) {
			((void(__thiscall*)(DWORD*, float, float, float, float, int)) 0x51EEF0)
				((DWORD*)this->m_ClockClass, fXPos, fYPos, fZPos, fRadius, iBone);
		}
		else {
			int stackValue = stack - 1;

			((void(__thiscall*)(DWORD*, float, float, float, float, int)) 0x51EEF0)
				((DWORD*)(this->m_ClockClass + (96 * stackValue)), fXPos, fYPos, fZPos, fRadius, iBone);
		}
	};

	void SetWindMinMax(int stack, int min, int max) const {
		if (stack <= 1) {
			((void(__thiscall*)(DWORD*, BYTE, BYTE)) 0x588B70)
				((DWORD*)this->m_ClockClass, (BYTE)min, (BYTE)max);
		}
		else {
			int stackValue = stack - 1;

			((void(__thiscall*)(DWORD*, BYTE, BYTE)) 0x588B70)
				((DWORD*)(this->m_ClockClass + (96 * stackValue)), (BYTE)min, (BYTE)max);
		}
	}

	void SetCapePlayer(DWORD o) const {
		if (this->m_ClockClass == 0) {
			return;
		}

		*(DWORD *)(o + 36) = m_ClockClass;
		*(BYTE *)(o + 28) = this->m_StackCount;
	};

private:
	int m_StackCount;
	DWORD m_ClockClass;
};


class CCustomCape {
public:
	CCustomCape();
	~CCustomCape();

	void RestartLua();
	void Init();
	void RegisterCapeClass(lua_State* lua);
	void LoadImageCape();
	void CreateCape(ObjectPreview* character, WORD ItemIndex, BYTE Class);

public:
	Lua m_Lua;

private:
	LuaLoadImage m_LuaLoadImage;
	LuaBMD m_LuaBMD;
};

extern CCustomCape gCustomCape;