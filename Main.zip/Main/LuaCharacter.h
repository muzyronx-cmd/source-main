#pragma once

#include "Lua.h"
#include "Protocol.h"

class CLuaCharacter {
public:
	CLuaCharacter();
	~CLuaCharacter();

	void RegisterLuaCharacter(lua_State* lua);

private:
	static BOOL LuaCharacterGetName(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushstring(lua, lpObj->Name);
		}
		return true;
	};

	static BOOL LuaCharacterGetKey(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, lpObj->aIndex);
		}
		return true;
	};

	static BOOL LuaCharacterGetIsLive(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, lpObj->Object.Live);
		}
		return true;
	};

	static BOOL LuaCharacterGetType(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, lpObj->Object.Kind);
		}
		return true;
	};

	static BOOL LuaCharacterX(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			DWORD PosX = (DWORD)(lpObj->Object.Position[0] / 100.f);
			lua_pushnumber(lua, (DWORD)(PosX > 0 ? PosX : 0));
		}
		return true;
	};

	static BOOL LuaCharacterY(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			DWORD PosY = (DWORD)(lpObj->Object.Position[1] / 100.f);
			lua_pushnumber(lua, (DWORD)(PosY > 0 ? PosY : 0));
		}
		return true;
	};

	static BOOL LuaCharacterPositionX(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (float)lpObj->Object.Position[0]);
		}
		return true;
	};

	static BOOL LuaCharacterPositionY(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (float)lpObj->Object.Position[1]);
		}
		return true;
	};

	static BOOL LuaCharacterPositionZ(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (float)lpObj->Object.Position[2]);
		}
		return true;
	};

	static BOOL LuaCharacterGetHelper(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

			lua_pushnumber(lua, (lpObj->PetSlot != (WORD)-1 ? (lpObj->PetSlot - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetWing(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

			lua_pushnumber(lua, (lpObj->WingsSlot != (WORD)-1 ? (lpObj->WingsSlot - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetSword(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

			lua_pushnumber(lua, (lpObj->WeaponFirstSlot != (WORD)-1 ? (lpObj->WeaponFirstSlot - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetShield(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

			lua_pushnumber(lua, (lpObj->WeaponSecondSlot != (WORD)-1 ? (lpObj->WeaponSecondSlot - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetHelm(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->BodyPart[BODYPART_HELM].Type != (WORD)-1 ? (lpObj->BodyPart[BODYPART_HELM].Type - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetArmor(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->BodyPart[BODYPART_ARMOR].Type != (WORD)-1 ? (lpObj->BodyPart[BODYPART_ARMOR].Type - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetPants(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->BodyPart[BODYPART_PANTS].Type != (WORD)-1 ? (lpObj->BodyPart[BODYPART_PANTS].Type - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetGloves(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->BodyPart[BODYPART_GLOVES].Type != (WORD)-1 ? (lpObj->BodyPart[BODYPART_GLOVES].Type - 1171) : -1));
		}

		return true;
	};

	static BOOL LuaCharacterGetBoots(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->BodyPart[BODYPART_BOOTS].Type != (WORD)-1 ? (lpObj->BodyPart[BODYPART_BOOTS].Type - 1171) : -1));
		}
		return true;
	};

	static BOOL LuaCharacterGetLevel(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, lpObj->Level);
		}
		return true;
	};

	static BOOL LuaCharacterGetClass(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			lua_pushnumber(lua, (lpObj->Class & 7));
		}
		return true;
	};

	static BOOL LuaCharacterGetGuild(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);
			if (lpObj->GuildMarkIndex != (WORD)-1) {
				lua_pushnumber(lua, lpObj->GuildMarkIndex);
			}
			else {
				lua_pushnumber(lua, -1);
			}
		}
		return true;
	};

	static BOOL LuaCharacterGuildGetName(lua_State* lua)
	{
		int arrayIndex = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		if (arrayIndex >= 0 && arrayIndex < MAX_MAIN_VIEWPORT) {
			lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

			if (lpObj->GuildMarkIndex != (WORD)-1) {
				char * gname = (char*)&*(BYTE*)(0x81CB595 + 88 * lpObj->GuildMarkIndex);

				lua_pushstring(lua, strlen(gname) <= 0 ? " " : gname);
			}
			else {
				lua_pushstring(lua, " ");
			}
		}
		return true;
	};

	static BOOL LuaGetPosFromPlayer(lua_State* lua)
	{
		vec3_t Position;

		int arrayIndex = (int)lua_tointeger(lua, 1);
		float Height = (float)lua_tonumber(lua, 2);

		lua_pop(lua, 2);

		if (arrayIndex < 0 || arrayIndex > 400) {

			return true;
		}

		lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayIndex);

		Position[0] = lpObj->Object.Position[0];
		Position[1] = lpObj->Object.Position[1];
		Position[2] = lpObj->Object.Position[2] + lpObj->Object.BoundingBoxMax[2] + Height;

		int GetPosX, GetPosY;

		pGetPosFromAngle(&Position, &GetPosX, &GetPosY);

		lua_pushnumber(lua, GetPosX);
		lua_pushnumber(lua, GetPosY);
		return 2;
	};

	static BOOL LuaSendPlayerChat(lua_State* lua)
	{
		lpCharObj lpPlayer = pUserObjectStruct;
		GCChatSend(lpPlayer->Name, (char*)lua_tostring(lua, 1));
		return true;
	};

	static BOOL LuaGetFindCharacterIndex(lua_State* lua)
	{
		int index = (int)lua_tointeger(lua, 1);

		lua_pop(lua, 1);

		lua_pushnumber(lua, ((int(*)(int))0x57D9A0)(index));
		return true;
	};

	static BOOL LuaGetTargetCharacter(lua_State* lua)
	{
		lua_pushnumber(lua, (*(int*)0xE61730 == -1 ? -1 : *(int*)0xE61730));
		return true;
	};

	static BOOL LuaSendTradePlayer(lua_State* lua)
	{
		SendRequestTrade((int)lua_tointeger(lua, 1));
		lua_pop(lua, 1);
		return true;
	};

	static BOOL LuaSendPartyPlayer(lua_State* lua)
	{
		SendRequestParty((int)lua_tointeger(lua, 1));
		lua_pop(lua, 1);
		return true;
	};

	static BOOL LuaSendGuildPlayer(lua_State* lua)
	{
		SendRequestGuild((int)lua_tointeger(lua, 1));
		lua_pop(lua, 1);
		return true;
	};

	static BOOL LuaSendLojaPlayer(lua_State* lua)
	{
		SendRequestOpenPersonalShop((int)lua_tointeger(lua, 1), (char*)lua_tostring(lua, 1));
		lua_pop(lua, 1);
		return true;
	};
};