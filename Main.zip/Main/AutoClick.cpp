#include "stdafx.h"
#include "AutoClick.h"
#include "WindowMode.h"

CAutoClick gAutoClick;

CAutoClick::CAutoClick()
{
	this->m_Theread = NULL;

	//this->CreateAutoClick();
}

CAutoClick::~CAutoClick()
{
	if (this->m_Theread != NULL)
	{
		TerminateThread(this->m_Theread, 0);
		CloseHandle(this->m_Theread);
		this->m_Theread = NULL;
	}
}

void CAutoClick::CreateAutoClick()
{
	if (gLoadFiles.m_LoadFiles.m_AutoClick == 0)
	{
		return;
	}

	GetCursorPos(&this->CursorCoords);

	if (this->m_Theread == NULL)
	{
		this->m_Theread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)this->AutoClickWorker, this, 0, 0);
	}
}

DWORD WINAPI CAutoClick::AutoClickWorker(CAutoClick* AutoClick)
{
	while (1)
	{
		Sleep(20);

		if (AutoClick->m_ClickRight == 1 || AutoClick->m_ClickLeft == 1)
		{
			if (AutoClick->m_ClickRight == 1)
			{
				SendMessage(m_hWnd, WM_RBUTTONDOWN, MK_RBUTTON, MAKELPARAM(AutoClick->CursorCoords.x, AutoClick->CursorCoords.y));
				Sleep(30);
				SendMessage(m_hWnd, WM_RBUTTONUP, MK_RBUTTON, MAKELPARAM(AutoClick->CursorCoords.x, AutoClick->CursorCoords.y));
				Sleep(30);
			}

			if (AutoClick->m_ClickLeft == 1)
			{
				SendMessage(m_hWnd, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(AutoClick->CursorCoords.x, AutoClick->CursorCoords.y));
				Sleep(30);
				SendMessage(m_hWnd, WM_LBUTTONUP, MK_LBUTTON, MAKELPARAM(AutoClick->CursorCoords.x, AutoClick->CursorCoords.y));
				Sleep(30);
			}
		}
	}

	return 1;
}