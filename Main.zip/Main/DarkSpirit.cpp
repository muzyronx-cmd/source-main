#include "stdafx.h"
#include "DarkSpirit.h"
#include "Util.h"
#include "Item.h"
#include "LuaStack.hpp"
#include "Console.h"
#include "ElementSlots.h"
#include "LuaObject.h"
#include "Protocol.h"
#include "HelperManager.h"

CDarkSpirit gDarkSpirit;

CDarkSpirit::CDarkSpirit() : m_Lua(false)
{
	this->m_DarkSpiritInfo.clear();
	this->m_DarkSpirit.clear();
	this->m_DarkSpiritModels.clear();
}

CDarkSpirit::~CDarkSpirit()
{

}

int CheckNewRaven(ObjectPreview* Struct) {
	auto Raven = gDarkSpirit.getDarkSpirit(Struct->WeaponSecondSlot - ITEM_BASE_MODEL);

	if (Raven != nullptr) {
		return Raven->ItemModel;
	}

	int GetRavenExist = gDarkSpirit.GetItemDarkSpirit(Hero);

	if (GetRavenExist != 0) {
		auto Raven = gDarkSpirit.getDarkSpirit(GetRavenExist - ITEM_BASE_MODEL);

		if (Raven != nullptr) {
			return Raven->ItemModel;
		}
	}

	return 0;
}

int CheckCreateDarkSpiritNow(int Index) {
	if (gDarkSpirit.CheckExistDarkSpirit(Hero)) {
		return 1;
	}

	if (gDarkSpirit.checkIsDarkSpirit(Index - ITEM_BASE_MODEL)) {
		return 1;
	}

	return 0;
}

int CheckDarkSpiritCustomModel(int Index) {
	if (gDarkSpirit.checkIsDarkSpirit(Index - ITEM_BASE_MODEL)) {
		return 1;
	}

	return 0;
}

int CheckDarkSpiritCustom(int Index) {
	if (gDarkSpirit.checkIsDarkSpirit(Index)) {
		return 1;
	}

	return 0;
}

__declspec(naked) void SetDarkRavenNew() {
	static DWORD m_ReturnFunc = 0x004F12FA;
	static DWORD m_CallFunc = 0x004F0A40;
	static DWORD m_HookFunc = 0x004F1323;

	static DWORD m_OldEdx = 0;
	static DWORD m_OldEcx = 0;

	static DWORD m_Index = 0;

	_asm {
		MOV m_OldEdx, Edx;
		MOV m_OldEcx, Ecx;

		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		PUSH EAX;
		CALL[CheckNewRaven];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		MOV m_Index, EAX;

		MOV Edx, m_OldEdx;
		MOV Ecx, m_OldEcx;

		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		MOV DWORD PTR DS : [EDX + 0x4], EAX;
		PUSH ECX;
		FLDZ;
		FSTP DWORD PTR SS : [ESP];
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOVZX EDX, BYTE PTR DS : [ECX + 0xB0];
		PUSH EDX;
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		MOVZX ECX, BYTE PTR DS : [EAX + 0xAC];
		PUSH ECX;
		PUSH m_Index;
		MOV ECX, DWORD PTR SS : [EBP - 0x10];
		CALL[m_CallFunc];

		JMP[m_HookFunc];

	RETURN:
		MOV Edx, m_OldEdx;
		MOV Ecx, m_OldEcx;
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		MOV DWORD PTR DS : [EDX + 0x4], EAX;
		JMP[m_ReturnFunc];
	}
}

int CheckBackupPickedItem(int Index) {
	if (gDarkSpirit.checkIsDarkSpirit(Index)) {
		auto hero = Hero;
		auto backupWeapon = hero->WeaponSecondSlot;
		hero->WeaponSecondSlot = Index + ITEM_BASE_MODEL;
		((void(*)(ObjectPreview*))0x4F8B80)(Hero);
		hero->WeaponSecondSlot = backupWeapon;
		return 1;
	}
	else if (Index == 6661) {
		auto hero = Hero;
		auto backupWeapon = hero->WeaponSecondSlot;
		hero->WeaponSecondSlot = Index + ITEM_BASE_MODEL;
		((void(*)(ObjectPreview*))0x4F8B80)(Hero);
		hero->WeaponSecondSlot = backupWeapon;
		return 1;
	}

	return 0;
}

__declspec(naked) void InventoryEquipItem() {
	static DWORD m_ReturnFunc = 0x00833A39;
	static DWORD m_HookFunc = 0x00833AC5;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x14];
		MOVSX EDX, WORD PTR DS : [ECX];
		PUSH EDX;
		CALL[CheckBackupPickedItem];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_HookFunc];


	RETURN:
		MOV ECX, DWORD PTR SS : [EBP - 0x14];
		MOVSX EDX, WORD PTR DS : [ECX];
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void InventoryUneEquipItem() {
	static DWORD m_ReturnFunc = 0x00833BAF;
	static DWORD m_HookFunc = 0x00833BB7;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x4];
		MOVSX EDX, WORD PTR DS : [ECX];
		PUSH EDX;
		CALL[CheckDarkSpiritCustom];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_HookFunc];

	RETURN:
		MOV ECX, DWORD PTR SS : [EBP - 0x4];
		MOVSX EDX, WORD PTR DS : [ECX];
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void BlockRenderDarkSpirit() {
	static DWORD m_ReturnFunc = 0x005769F3;
	static DWORD m_HookFunc = 0x005769F9;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x330];
		MOVSX EDX, WORD PTR DS : [ECX];
		PUSH EDX;
		CALL[CheckDarkSpiritCustomModel];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		MOV EDX, 0x1E98;
		CMP EDX, 0x1E98;
		JMP[m_ReturnFunc];

	RETURN:
		MOV ECX, DWORD PTR SS : [EBP - 0x330];
		MOVSX EDX, WORD PTR DS : [ECX];
		CMP EDX, 0x1E98;
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void RenderBackDarkSpirit() {
	static DWORD m_ReturnFunc = 0x0588228;
	static DWORD m_HookFunc = 0x00588239;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x1C];
		PUSH EAX;
		CALL[CheckDarkSpiritCustomModel];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		MOV BYTE PTR SS : [EBP - 0x9], 0x0;
		JMP[m_HookFunc];

	RETURN:
		CMP DWORD PTR SS : [EBP - 0x1C], 0x0C9A;
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void CreateDarkSpiritNow() {
	static DWORD m_ReturnFunc = 0x004F8C5B;
	static DWORD m_HookFunc = 0x004F8C5D;

	static DWORD m_OldEax = 0x0;

	_asm {
		MOV m_OldEax, EAX;
		MOVSX ECX, WORD PTR DS : [EAX + 0x1E4];
		PUSH ECX;
		CALL[CheckCreateDarkSpiritNow];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		MOV EAX, m_OldEax;
		JMP[m_HookFunc];

	RETURN:
		MOV EAX, m_OldEax;
		MOVSX ECX, WORD PTR DS : [EAX + 0x1E4];
		CMP ECX, 0x1E98;
		JMP[m_ReturnFunc];
	}
}

int CheckUsingDarkSpirit() {
	if (GetBaseClass((Hero)->Class) == 4) {
		if ((Hero)->m_pPet != 0) {
			return 0;
		}
		else {
			return 1;
		}
	}
	else {
		if ((Hero)->m_pPet != 0) {
			return 0;
		}
	}

	return 1;
}

__declspec(naked) void FixSwitchDarkSpiritSkill() {
	static DWORD m_HookFunc = 0x008133AC;
	static DWORD m_ExitFunc = 0x008133EA;

	_asm {
		CALL[CheckUsingDarkSpirit];
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV DWORD PTR SS : [EBP - 0xC], 0;
		JMP[m_HookFunc];
	}
}

void GCSkillRecv(DWORD lpMsg) {
	((void(*)(DWORD))0x63EF10)(lpMsg);

	auto elementFirst = gElementSlots.getItemElement(236);

	if (elementFirst) {
		if (gDarkSpirit.checkIsDarkSpirit(elementFirst->Type)) {
			for (int k = 0; k < 4; ++k) {
				*(WORD *)(*(DWORD*)0x8128AC8 + 2 * k + 420) = k + 120;
			}
		}
	}
}

void SetDarkSpirit(int ItemIndex, std::string modelName, std::string objectName) {
	DARK_SPIRIT_INFO info;

	info.ItemIndex = ItemIndex;

	info.ModelName = modelName;

	info.ObjectName = objectName;

	gDarkSpirit.m_DarkSpiritInfo.insert(std::make_pair(ItemIndex, info));
}

void CDarkSpirit::Init()
{
	MemorySet(0x004F12F4, 0x90, 6);
	SetCompleteHook(0xE9, 0x004F12F4, &SetDarkRavenNew);

	MemorySet(0x00833A33, 0x90, 6);
	SetCompleteHook(0xE9, 0x00833A33, &InventoryEquipItem);

	MemorySet(0x00833BA9, 0x90, 6);
	SetCompleteHook(0xE9, 0x00833BA9, &InventoryUneEquipItem);

	MemorySet(0x005769EA, 0x90, 9);
	SetCompleteHook(0xE9, 0x005769EA, &BlockRenderDarkSpirit);

	MemorySet(0x00588221, 0x90, 9);
	SetCompleteHook(0xE9, 0x00588221, &RenderBackDarkSpirit);

	MemorySet(0x004F8C4E, 0x90, 7);
	SetCompleteHook(0xE9, 0x004F8C4E, &CreateDarkSpiritNow);

	MemorySet(0x008133A5, 0x90, 7);
	SetCompleteHook(0xE9, 0x008133A5, &FixSwitchDarkSpiritSkill);


	SetByte(0x004F921D, 0xEB);
	SetByte(0x004F921D+1, 0x19);
	SetByte(0x004F921F, 0x90);
	SetByte(0x004F9220, 0x90);
	SetByte(0x004F9221, 0x90);

	SetCompleteHook(0xE8, 0x00663F54, &GCSkillRecv);

	luaaa::LuaModule(this->m_Lua.GetState()).fun("SetDarkSpirit", &SetDarkSpirit);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//DarkSpirit.lua");

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());

}

void CDarkSpirit::RestartLua()
{

luaaa::LuaModule(this->m_Lua.GetState()).fun("SetDarkSpirit", &SetDarkSpirit);

this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//DarkSpirit.lua");

this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

RegisterClassObject(this->m_Lua.GetState());

this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());
}

void CDarkSpirit::CreateDarkSpirit(ObjectPreview * m_Owner, int ModelIndex)
{
	if (m_Owner == nullptr) {
		return;
	}

	if (this->CheckExistDarkSpirit(m_Owner)) {
		return;
	}

	DARK_SPIRIT_HELPER_VIEWPtr darkspirit = DARK_SPIRIT_HELPER_VIEW::Make();

	if (darkspirit == nullptr) {
		return;
	}

	if (darkspirit->Create(m_Owner, ModelIndex)) {
		this->Register(darkspirit);
	}
}

bool CDarkSpirit::CheckExistDarkSpirit(ObjectPreview * Owner)
{
	if (Owner == nullptr) {
		return 0;
	}

	for (std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator it = this->m_DarkSpirit.begin(); it != this->m_DarkSpirit.end();) {

		std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(DARK_SPIRIT_HELPER_VIEW) darkspirit = *tempIT;

		if (darkspirit.expired() == false) {
			if (darkspirit.lock()->IsSameOwner(Owner)) {
				return 1;
			}
		}
	}

	return 0;
}

int CDarkSpirit::GetItemDarkSpirit(ObjectPreview * Owner)
{
	if (Owner == nullptr) {
		return 0;
	}

	for (std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator it = this->m_DarkSpirit.begin(); it != this->m_DarkSpirit.end();) {

		std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(DARK_SPIRIT_HELPER_VIEW) darkspirit = *tempIT;

		if (darkspirit.expired() == false) {
			if (darkspirit.lock()->IsSameOwner(Owner)) {
				return darkspirit.lock()->ModelIndex;
			}
		}
	}

	return 0;
}

void CDarkSpirit::Register(BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW) info)
{
	this->m_DarkSpirit.push_back(info);
}

void CDarkSpirit::DeleteDarkSpirit(ObjectPreview * Owner, int itemType, bool allDelete)
{
	if (Owner == nullptr) {
		return;
	}

	this->UnRegister(Owner, itemType, allDelete);
}

void CDarkSpirit::UnRegister(ObjectPreview * Owner, int itemType, bool isUnregistAll)
{
	if (Owner == nullptr) {
		return;
	}

	for (std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator it = this->m_DarkSpirit.begin(); it != this->m_DarkSpirit.end();) {
		std::vector<BoostSmart_Ptr(DARK_SPIRIT_HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(DARK_SPIRIT_HELPER_VIEW) element = *tempIT;

		if (Hero == Owner) {
			if (element.lock()->IsSameOwner(Owner)) {
				element.lock()->Relese();
				this->m_DarkSpirit.erase(tempIT);
				break;
			}
		}
		else {
			if (-1 == itemType && element.lock()->IsSameOwner(Owner))
			{
				element.lock()->Relese();

				this->m_DarkSpirit.erase(tempIT);

				if (-1 == itemType || !isUnregistAll) {
					return;
				}
			}
		}
	}
}

DARK_SPIRIT_INFO * CDarkSpirit::getDarkSpirit(int ItemIndex)
{
	std::map<int, DARK_SPIRIT_INFO>::iterator it = this->m_DarkSpiritInfo.find(ItemIndex);

	if (it == this->m_DarkSpiritInfo.end()) {
		return nullptr;
	}

	return &it->second;
}

bool CDarkSpirit::checkIsDarkSpirit(int ItemIndex)
{
	std::map<int, DARK_SPIRIT_INFO>::iterator it = this->m_DarkSpiritInfo.find(ItemIndex);

	if (it == this->m_DarkSpiritInfo.end()) {
		return 0;
	}

	return 1;
}

int CDarkSpirit::GetItemModelDarkSpirit(int ItemIndex)
{
	return this->m_DarkSpiritModels[ItemIndex];
}

void CDarkSpirit::RenderModel(DWORD BMDStruct, DWORD ObjectStruct, DWORD ItemIndex)
{
	int ModelIndex = this->GetItemModelDarkSpirit(ItemIndex);

	this->m_Lua.Generic_Call("RenderModel", "iii>", BMDStruct, ObjectStruct, ModelIndex);
}
