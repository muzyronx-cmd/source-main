#pragma once

#define CGetScreenWidth2						((signed int(*)()) 0x005C6E80)
#define glViewport2								((void(__cdecl*)(GLint x, int a2, GLsizei width, GLsizei height)) 0x006363D0)
#define CameraMatrix							*(char*)0x87933A0
#define GetOpenGLMatrix							((void(__cdecl*)(int a1)) 0x00635830)
#define gluPerspective2							((int(__cdecl*)(float a1, float a2, float a3, float a4)) 0x006358A0)
#define OpenglWindowHeight						*(int*)0x87933E8
#define OpenglWindowWidth						*(int*)0x87933EC
#define OpenglWindowY							*(int*)0x87933F0
#define OpenglWindowX							*(int*)0x87933F4
#define gluPerspective							((void(__stdcall*)(GLdouble fovy, GLdouble aspect, GLdouble zNear, GLdouble zFar)) 0x00995FB2)
#define gluOrtho2D								((void(__stdcall*)(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top)) 0x00995FB8)
#define CameraFOV								*(float*)0xE61E40
#define CameraViewNear							*(float*)0xE61E38
#define CameraViewFar							*(float*)0xE61E3C
#define DisableDepthTest						((void(*)()) 0x00635E10)
#define JCBaulExtShow							((void (__thiscall*)(int This)) 0x008567B0)
#define JCBaulExtMove							((BYTE *(__thiscall*)(int This, int a2, int a3)) 0x008564F0)
#define JCStoreMove								((int(__thiscall*)(int This, int a2, int a3, int a4)) 0x00840D80)
#define JCChaosMove								((int(__thiscall*)(void *This, int a2, int a3, int a4)) 0x0082C340)
#define JCShopMove								((BYTE *(__thiscall*)(int This, int a2, int a3, int a4)) 0x00846B90)
#define JCOtherStoreMove						((int (__thiscall*)(void *This, int a2, int a3, int a4)) 0x0084FA90)
#define JCBaulMove								((int (__thiscall*)(void *This, int a2, int a3, int a4)) 0x00857200)
#define JCInvExtMove							((signed int (__thiscall*)(int This, int a2, int a3)) 0x007D4E70)
#define JCTradeMove								((int (__thiscall*)(void *This, int a2, int a3, int a4)) 0x00863F10)
#define JCLuckyMove								((int (__thiscall*)(void *This, int a2, int a3, int a4)) 0x007F0460)
#define sub_860B50								((int(__thiscall*)(void * _this)) 0x00860B50)
#define sub_815F50								((int(__thiscall*)(int a1, char a5, char a6)) 0x00815F50)
#define GetInstance								((int(__cdecl*)()) 0x00861110)
#define sub_7D6270								((int(__thiscall*)(int This, int a5))0x007D6270)
#define ChangeButtonInfo						((int(__thiscall*)(char *This, int X, int Y, int Width, int Height)) 0x00779410)
#define RenderBitmapUV							((void(__cdecl*)(int a4, float a5, float a6, float a7, float a8, float a9, float a10, float a11, float a12)) 0x00638E90)
#define CNewPictureFont							((int(__thiscall*)(int thisa, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, int nTabOrigin)) 0x00420150)
#define CNewUIMainFrameHelper					((BYTE(__thiscall*)(int thisa, int a5, int x, int y)) 0x007F0C80)
#define InitCashShop							((BYTE(__thiscall*)(int thisa, int a5, int x, int y)) 0x00942E80)

enum JCObjWindow // -> Season 6.3
{
	JCWinStore = 84,
	JCWinChaosBox = 52,
	JCWinShop = 44,
	JCWinLuckyMix = 296,
	JCWinOtherStore = 88,
	JCWinInvExt = 300,
	JCWinBaul = 72,
	JCWinTrade = 124,
};

class JCWideScreem
{
public:
	int JCWinWidth;
	int JCWinWidthAdd;
	int DisplayWinCDepthBox; // eax@4
	void Load(); 
	static int __thiscall CNewUIMainPaintFont(int thisa, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, int nTabOrigin);
	static BYTE __thiscall FrameHelperDisplay(int thisa, int a2, int x, int y);
	static BYTE __thiscall FrameShopDisplay(int thisa, int a2, int x, int y);
	static char __thiscall sub_791480(int This, int a2, float a3, float a4, float a5, float a6, int a7, char a8);
	static char __thiscall sub_7A9E80(int This, int a2, int a3, int a4, int a5, float a6);
	static int __thiscall MessageBoxButtonRenderText(int thisa, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, int nTabOrigin);
	static int __thiscall OpenMainWnd(int thisa, int a2, int a3);
};

extern JCWideScreem JCPWideScreem;