#include "stdafx.h"
#include "Item.h"
#include "CustomColorName.h"
#include "Util.h"
#include "Defines.h"
//--
DWORD DivineWeapon_Buff=0;
DWORD DivineWeapon_Pointer=0;
//--
__declspec(naked)void DivineWeapon()
{
	static DWORD DivineWeaponAdress1=0x007E785F;
	static DWORD DivineWeaponAdress2=0x007E7866;
	_asm
	{
		Mov DivineWeapon_Buff,Edx
		MOVSX EDX,WORD PTR SS:[EBP+0x8]
		mov DWORD PTR SS:[EBP+0x8],Edx
		mov DivineWeapon_Pointer,Edx
		Mov Edx,DivineWeapon_Buff
	}
	if(DivineWeapon_Pointer==0x13
		||DivineWeapon_Pointer==0x812
		||DivineWeapon_Pointer==0x0A0A
		||DivineWeapon_Pointer==0x40D
		||DivineWeapon_Pointer==0x0A24
		//--

		|| DivineWeapon_Pointer == GET_ITEM(13, 100)
		|| DivineWeapon_Pointer == GET_ITEM(13, 101)
		|| DivineWeapon_Pointer == GET_ITEM(13, 102)
		|| DivineWeapon_Pointer == GET_ITEM(13, 103)
		|| DivineWeapon_Pointer == GET_ITEM(13, 104)
		|| DivineWeapon_Pointer == GET_ITEM(13, 105)
		|| DivineWeapon_Pointer == GET_ITEM(13, 106)

		||DivineWeapon_Pointer== GET_ITEM(15, 462)	
		||DivineWeapon_Pointer == GET_ITEM(15, 463)	
		||DivineWeapon_Pointer == GET_ITEM(13, 177)	
		||DivineWeapon_Pointer == GET_ITEM(13, 163)	
		||DivineWeapon_Pointer == GET_ITEM(13, 231)	
		||DivineWeapon_Pointer == GET_ITEM(15, 455)	
		||DivineWeapon_Pointer == GET_ITEM(15, 458)	
		||DivineWeapon_Pointer == GET_ITEM(15, 459)	
		||DivineWeapon_Pointer == GET_ITEM(15, 460)	
		||DivineWeapon_Pointer == GET_ITEM(15, 461)	

		||DivineWeapon_Pointer == GET_ITEM(15, 467)	
		||DivineWeapon_Pointer == GET_ITEM(15, 468)	
		||DivineWeapon_Pointer == GET_ITEM(15, 469)	
		||DivineWeapon_Pointer == GET_ITEM(15, 470)	
		||DivineWeapon_Pointer == GET_ITEM(15, 471)	
		||DivineWeapon_Pointer == GET_ITEM(15, 472)	
		||DivineWeapon_Pointer == GET_ITEM(15, 473)	
		||DivineWeapon_Pointer == GET_ITEM(15, 474)	
		||DivineWeapon_Pointer == GET_ITEM(15, 475)	

		||DivineWeapon_Pointer == GET_ITEM(13, 293)	
		||DivineWeapon_Pointer == GET_ITEM(13, 294)	

		||DivineWeapon_Pointer == GET_ITEM(13, 296)	
		||DivineWeapon_Pointer == GET_ITEM(15, 476)	
		||DivineWeapon_Pointer == GET_ITEM(15, 477)	
		||DivineWeapon_Pointer == GET_ITEM(15, 478)	
		||DivineWeapon_Pointer == GET_ITEM(15, 479)	
		||DivineWeapon_Pointer == GET_ITEM(15, 480)	
		||DivineWeapon_Pointer == GET_ITEM(15, 481)	
		||DivineWeapon_Pointer == GET_ITEM(15, 482)	
		||DivineWeapon_Pointer == GET_ITEM(15, 483)	
		||DivineWeapon_Pointer == GET_ITEM(15, 484)	
		||DivineWeapon_Pointer == GET_ITEM(15, 485)	
		||DivineWeapon_Pointer == GET_ITEM(15, 486)	
		||DivineWeapon_Pointer == GET_ITEM(15, 487)	
		||DivineWeapon_Pointer == GET_ITEM(15, 488)	
		||DivineWeapon_Pointer == GET_ITEM(15, 489)	
		||DivineWeapon_Pointer == GET_ITEM(15, 490)	
		||DivineWeapon_Pointer == GET_ITEM(15, 491)	
		||DivineWeapon_Pointer == GET_ITEM(15, 492)	
		||DivineWeapon_Pointer == GET_ITEM(15, 493)	
		||DivineWeapon_Pointer == GET_ITEM(15, 494)	
		||DivineWeapon_Pointer == GET_ITEM(15, 495)	
		||DivineWeapon_Pointer == GET_ITEM(15, 496)	
		||DivineWeapon_Pointer == GET_ITEM(15, 497)	
		||DivineWeapon_Pointer == GET_ITEM(15, 498)	
		||DivineWeapon_Pointer == GET_ITEM(15, 499)	
		||DivineWeapon_Pointer == GET_ITEM(15, 500)	

		||DivineWeapon_Pointer == GET_ITEM(13, 285)	
		||DivineWeapon_Pointer == GET_ITEM(13, 287)	
		||DivineWeapon_Pointer == GET_ITEM(15, 448)	
		||DivineWeapon_Pointer == GET_ITEM(15, 449)	
		||DivineWeapon_Pointer == GET_ITEM(15, 450)	
		||DivineWeapon_Pointer == GET_ITEM(15, 451)	
		||DivineWeapon_Pointer == GET_ITEM(15, 452)	

		||DivineWeapon_Pointer == GET_ITEM(13, 280)	
		||DivineWeapon_Pointer == GET_ITEM(15, 435)	
		||DivineWeapon_Pointer == GET_ITEM(15, 436)	
		||DivineWeapon_Pointer == GET_ITEM(15, 437)	
		||DivineWeapon_Pointer == GET_ITEM(15, 438)	
		||DivineWeapon_Pointer == GET_ITEM(15, 439)	
		||DivineWeapon_Pointer == GET_ITEM(13, 281)	
		||DivineWeapon_Pointer == GET_ITEM(13, 288)	
		||DivineWeapon_Pointer == GET_ITEM(13, 289)	

		||DivineWeapon_Pointer == GET_ITEM(13, 283)	
		||DivineWeapon_Pointer == GET_ITEM(15, 440)	
		||DivineWeapon_Pointer == GET_ITEM(15, 441)	
		||DivineWeapon_Pointer == GET_ITEM(15, 442)	
		||DivineWeapon_Pointer == GET_ITEM(15, 443)	

		||DivineWeapon_Pointer == GET_ITEM(15, 453)	
		||DivineWeapon_Pointer == GET_ITEM(15, 454)	

		||DivineWeapon_Pointer == GET_ITEM(13, 269)	
		||DivineWeapon_Pointer == GET_ITEM(13, 278)	
		||DivineWeapon_Pointer == GET_ITEM(15, 424)	
		||DivineWeapon_Pointer == GET_ITEM(15, 427)	
		||DivineWeapon_Pointer == GET_ITEM(15, 428)	
		||DivineWeapon_Pointer == GET_ITEM(15, 429)	
		||DivineWeapon_Pointer == GET_ITEM(15, 430)	
		||DivineWeapon_Pointer == GET_ITEM(15, 422)	
		||DivineWeapon_Pointer == GET_ITEM(15, 423)	
		||DivineWeapon_Pointer == GET_ITEM(15, 421)	
		||DivineWeapon_Pointer == GET_ITEM(15, 425)	
		||DivineWeapon_Pointer == GET_ITEM(15, 426)	

		||DivineWeapon_Pointer == GET_ITEM(15, 419)	
		||DivineWeapon_Pointer == GET_ITEM(15, 420)	
		||DivineWeapon_Pointer == GET_ITEM(13, 266)	
		||DivineWeapon_Pointer == GET_ITEM(13, 267)	

		||DivineWeapon_Pointer == GET_ITEM(13, 271)	
		||DivineWeapon_Pointer == GET_ITEM(13, 272)	
		||DivineWeapon_Pointer == GET_ITEM(15, 431)	
		||DivineWeapon_Pointer == GET_ITEM(15, 432)	
		||DivineWeapon_Pointer == GET_ITEM(13, 274)	
		||DivineWeapon_Pointer == GET_ITEM(15, 433)	
		||DivineWeapon_Pointer == GET_ITEM(15, 434)	
		||DivineWeapon_Pointer == GET_ITEM(13, 273)	
		||DivineWeapon_Pointer == GET_ITEM(15, 411)	
		||DivineWeapon_Pointer == GET_ITEM(15, 412)	
		||DivineWeapon_Pointer == GET_ITEM(15, 417)	
		||DivineWeapon_Pointer == GET_ITEM(15, 418)	

		||DivineWeapon_Pointer == GET_ITEM(15, 413)	
		||DivineWeapon_Pointer == GET_ITEM(15, 414)	
		||DivineWeapon_Pointer == GET_ITEM(15, 415)	
		||DivineWeapon_Pointer == GET_ITEM(15, 416)	
		||DivineWeapon_Pointer == GET_ITEM(13, 262)	
		||DivineWeapon_Pointer == GET_ITEM(13, 263)	
		||DivineWeapon_Pointer == GET_ITEM(13, 264)	
		||DivineWeapon_Pointer == GET_ITEM(13, 265)	
		||DivineWeapon_Pointer == GET_ITEM(13, 278)	
		||DivineWeapon_Pointer == GET_ITEM(13, 279)	
		||DivineWeapon_Pointer == GET_ITEM(15, 409)	
		||DivineWeapon_Pointer == GET_ITEM(15, 410)	
		||DivineWeapon_Pointer == GET_ITEM(13, 259)	
		||DivineWeapon_Pointer == GET_ITEM(15, 465)	
		||DivineWeapon_Pointer == GET_ITEM(15, 466)	

		||DivineWeapon_Pointer == GET_ITEM(13, 255)	
		||DivineWeapon_Pointer == GET_ITEM(13, 256)	
		||DivineWeapon_Pointer == GET_ITEM(15, 407)	
		||DivineWeapon_Pointer == GET_ITEM(15, 408)	
		||DivineWeapon_Pointer == GET_ITEM(15, 405)	
		||DivineWeapon_Pointer == GET_ITEM(15, 406)	
		||DivineWeapon_Pointer == GET_ITEM(13, 253)	
		||DivineWeapon_Pointer == GET_ITEM(13, 257)	
		||DivineWeapon_Pointer == GET_ITEM(13, 258)	

		||DivineWeapon_Pointer == GET_ITEM(15, 402)	
		||DivineWeapon_Pointer == GET_ITEM(15, 403)	
		||DivineWeapon_Pointer == GET_ITEM(15, 404)	
		||DivineWeapon_Pointer == GET_ITEM(12, 256)	
		||DivineWeapon_Pointer == GET_ITEM(12, 257)	
		||DivineWeapon_Pointer == GET_ITEM(13, 254)	

		||DivineWeapon_Pointer == GET_ITEM(13, 251)	
		||DivineWeapon_Pointer == GET_ITEM(13, 252)	

		||DivineWeapon_Pointer == GET_ITEM(13, 248)	
		||DivineWeapon_Pointer == GET_ITEM(13, 247)	
		||DivineWeapon_Pointer == GET_ITEM(13, 179)	
		||DivineWeapon_Pointer == GET_ITEM(13, 180)	

		||DivineWeapon_Pointer == GET_ITEM(13, 244)	
		||DivineWeapon_Pointer == GET_ITEM(13, 175)	
		||DivineWeapon_Pointer == GET_ITEM(13, 176)	
		||DivineWeapon_Pointer == GET_ITEM(13, 240)	
		||DivineWeapon_Pointer == GET_ITEM(13, 162)	
		||DivineWeapon_Pointer == GET_ITEM(13, 161)	

		|| DivineWeapon_Pointer == GET_ITEM(13, 245)
		|| DivineWeapon_Pointer == GET_ITEM(13, 246)
		|| DivineWeapon_Pointer == GET_ITEM(13, 247)
		|| DivineWeapon_Pointer == GET_ITEM(13, 248)
		|| DivineWeapon_Pointer == GET_ITEM(13, 249)
		|| DivineWeapon_Pointer == GET_ITEM(13, 250)
		|| DivineWeapon_Pointer == GET_ITEM(13, 251)
		|| DivineWeapon_Pointer == GET_ITEM(13, 252)
		|| DivineWeapon_Pointer == GET_ITEM(13, 253)
		|| DivineWeapon_Pointer == GET_ITEM(13, 254)
		|| DivineWeapon_Pointer == GET_ITEM(13, 255)
		|| DivineWeapon_Pointer == GET_ITEM(13, 256)
		|| DivineWeapon_Pointer == GET_ITEM(13, 257)
		|| DivineWeapon_Pointer == GET_ITEM(13, 258)
		|| DivineWeapon_Pointer == GET_ITEM(13, 259)
		|| DivineWeapon_Pointer == GET_ITEM(13, 260)
		|| DivineWeapon_Pointer == GET_ITEM(13, 261)
		|| DivineWeapon_Pointer == GET_ITEM(13, 262)
		|| DivineWeapon_Pointer == GET_ITEM(13, 263)
		|| DivineWeapon_Pointer == GET_ITEM(13, 264)
		|| DivineWeapon_Pointer == GET_ITEM(13, 265)
		|| DivineWeapon_Pointer == GET_ITEM(13, 266)
		|| DivineWeapon_Pointer == GET_ITEM(13, 267)
		|| DivineWeapon_Pointer == GET_ITEM(13, 268)
		|| DivineWeapon_Pointer == GET_ITEM(13, 269)
		|| DivineWeapon_Pointer == GET_ITEM(13, 270)
		|| DivineWeapon_Pointer == GET_ITEM(13, 271)
		|| DivineWeapon_Pointer == GET_ITEM(13, 272)
		|| DivineWeapon_Pointer == GET_ITEM(13, 273)
		|| DivineWeapon_Pointer == GET_ITEM(13, 274)
		|| DivineWeapon_Pointer == GET_ITEM(13, 275)
		|| DivineWeapon_Pointer == GET_ITEM(13, 276)
		|| DivineWeapon_Pointer == GET_ITEM(13, 277)
		|| DivineWeapon_Pointer == GET_ITEM(13, 278)
		|| DivineWeapon_Pointer == GET_ITEM(13, 279)
		|| DivineWeapon_Pointer == GET_ITEM(13, 280)
		|| DivineWeapon_Pointer == GET_ITEM(13, 281)
		|| DivineWeapon_Pointer == GET_ITEM(13, 282)
		|| DivineWeapon_Pointer == GET_ITEM(13, 283)
		|| DivineWeapon_Pointer == GET_ITEM(13, 284)
		|| DivineWeapon_Pointer == GET_ITEM(13, 285)
		|| DivineWeapon_Pointer == GET_ITEM(13, 286)
		|| DivineWeapon_Pointer == GET_ITEM(13, 287)
		|| DivineWeapon_Pointer == GET_ITEM(13, 288)
		|| DivineWeapon_Pointer == GET_ITEM(13, 289)
		|| DivineWeapon_Pointer == GET_ITEM(13, 290)
		|| DivineWeapon_Pointer == GET_ITEM(13, 291)
		|| DivineWeapon_Pointer == GET_ITEM(13, 292)
		|| DivineWeapon_Pointer == GET_ITEM(13, 293)
		|| DivineWeapon_Pointer == GET_ITEM(13, 294)
		|| DivineWeapon_Pointer == GET_ITEM(13, 295)
		|| DivineWeapon_Pointer == GET_ITEM(13, 296)
		|| DivineWeapon_Pointer == GET_ITEM(13, 297)
		|| DivineWeapon_Pointer == GET_ITEM(13, 298)
		|| DivineWeapon_Pointer == GET_ITEM(13, 299)
		|| DivineWeapon_Pointer == GET_ITEM(13, 300)
		|| DivineWeapon_Pointer == GET_ITEM(13, 301)
		|| DivineWeapon_Pointer == GET_ITEM(13, 302)
		|| DivineWeapon_Pointer == GET_ITEM(13, 303)
		|| DivineWeapon_Pointer == GET_ITEM(13, 304)
		|| DivineWeapon_Pointer == GET_ITEM(13, 305)
		|| DivineWeapon_Pointer == GET_ITEM(13, 306)
		|| DivineWeapon_Pointer == GET_ITEM(13, 307)
		|| DivineWeapon_Pointer == GET_ITEM(13, 308)
		|| DivineWeapon_Pointer == GET_ITEM(13, 309)
		|| DivineWeapon_Pointer == GET_ITEM(13, 310)
		|| DivineWeapon_Pointer == GET_ITEM(13, 311)
		|| DivineWeapon_Pointer == GET_ITEM(13, 312)
		|| DivineWeapon_Pointer == GET_ITEM(13, 313)

		||DivineWeapon_Pointer == GET_ITEM(13, 160)	
		||DivineWeapon_Pointer == GET_ITEM(13, 159)	
		||DivineWeapon_Pointer == GET_ITEM(13, 224)	
		||DivineWeapon_Pointer == GET_ITEM(13, 225)	
		||DivineWeapon_Pointer == GET_ITEM(13, 226)	
		||DivineWeapon_Pointer == GET_ITEM(13, 227)	
		||DivineWeapon_Pointer == GET_ITEM(13, 249)	
		||DivineWeapon_Pointer == GET_ITEM(13, 250)	
		||DivineWeapon_Pointer == GET_ITEM(13, 229)	
		||DivineWeapon_Pointer == GET_ITEM(13, 230)	

		||DivineWeapon_Pointer == GET_ITEM(13, 146)	
		||DivineWeapon_Pointer == GET_ITEM(13, 148)	
		||DivineWeapon_Pointer == GET_ITEM(13, 210)	
		||DivineWeapon_Pointer == GET_ITEM(13, 221)	
		||DivineWeapon_Pointer == GET_ITEM(13, 222)	
		||DivineWeapon_Pointer == GET_ITEM(13, 223)	
		||DivineWeapon_Pointer == GET_ITEM(13, 202)
		||DivineWeapon_Pointer == GET_ITEM(13, 149)
		||DivineWeapon_Pointer == GET_ITEM(13, 150)
		||DivineWeapon_Pointer == GET_ITEM(13, 153)
		||DivineWeapon_Pointer == GET_ITEM(13, 154)
		||DivineWeapon_Pointer == GET_ITEM(13, 205)
		||DivineWeapon_Pointer == GET_ITEM(13, 207)
		||DivineWeapon_Pointer == GET_ITEM(13, 157)
		||DivineWeapon_Pointer == GET_ITEM(13, 158)
		||DivineWeapon_Pointer == GET_ITEM(13, 234)
		||DivineWeapon_Pointer == GET_ITEM(13, 235)
		||DivineWeapon_Pointer == GET_ITEM(13, 236)
		||DivineWeapon_Pointer == GET_ITEM(13, 220)

		||DivineWeapon_Pointer == GET_ITEM(13, 261)
		||DivineWeapon_Pointer == GET_ITEM(13, 203)
		||DivineWeapon_Pointer == GET_ITEM(13, 204)
		||DivineWeapon_Pointer == GET_ITEM(13, 228)
		||DivineWeapon_Pointer == GET_ITEM(13, 208)
		||DivineWeapon_Pointer == GET_ITEM(13, 211)
		||DivineWeapon_Pointer == GET_ITEM(13, 212)
		||DivineWeapon_Pointer == GET_ITEM(13, 213)
		||DivineWeapon_Pointer == GET_ITEM(13, 214)
		||DivineWeapon_Pointer == GET_ITEM(13, 215)
		||DivineWeapon_Pointer == GET_ITEM(13, 216)
		||DivineWeapon_Pointer == GET_ITEM(13, 217)
		||DivineWeapon_Pointer == GET_ITEM(13, 218)
		||DivineWeapon_Pointer == GET_ITEM(13, 219)
		||DivineWeapon_Pointer == GET_ITEM(13, 232)
		||DivineWeapon_Pointer == GET_ITEM(13, 233)
		||DivineWeapon_Pointer == GET_ITEM(13, 237)
		||DivineWeapon_Pointer == GET_ITEM(13, 151)
		||DivineWeapon_Pointer == GET_ITEM(13, 152)
		||DivineWeapon_Pointer == GET_ITEM(13, 156)
		||DivineWeapon_Pointer == GET_ITEM(13, 155)
		||DivineWeapon_Pointer == GET_ITEM(15, 444)
		||DivineWeapon_Pointer == GET_ITEM(15, 445)
		||DivineWeapon_Pointer == GET_ITEM(15, 446)
		||DivineWeapon_Pointer == GET_ITEM(15, 447)
		||DivineWeapon_Pointer == GET_ITEM(13, 238)
		||DivineWeapon_Pointer == GET_ITEM(13, 241)
		||DivineWeapon_Pointer == GET_ITEM(13, 242)
		||DivineWeapon_Pointer == GET_ITEM(13, 243)


		||DivineWeapon_Pointer == GET_ITEM(12, 200)
		||DivineWeapon_Pointer == GET_ITEM(12, 201)
		||DivineWeapon_Pointer == GET_ITEM(12, 202)
		||DivineWeapon_Pointer == GET_ITEM(12, 203)
		||DivineWeapon_Pointer == GET_ITEM(12, 204)
		||DivineWeapon_Pointer == GET_ITEM(12, 205)
		||DivineWeapon_Pointer == GET_ITEM(12, 206)
		||DivineWeapon_Pointer == GET_ITEM(12, 207)
		||DivineWeapon_Pointer == GET_ITEM(12, 208)
		||DivineWeapon_Pointer == GET_ITEM(12, 209)
		||DivineWeapon_Pointer == GET_ITEM(12, 210)
		||DivineWeapon_Pointer == GET_ITEM(12, 211)
		||DivineWeapon_Pointer == GET_ITEM(12, 212)
		||DivineWeapon_Pointer == GET_ITEM(12, 213)
		||DivineWeapon_Pointer == GET_ITEM(12, 214)
		||DivineWeapon_Pointer == GET_ITEM(12, 215)
		||DivineWeapon_Pointer == GET_ITEM(12, 216)
		||DivineWeapon_Pointer == GET_ITEM(12, 218)
		||DivineWeapon_Pointer == GET_ITEM(12, 219)
		||DivineWeapon_Pointer == GET_ITEM(12, 220)
		||DivineWeapon_Pointer == GET_ITEM(12, 221)
		||DivineWeapon_Pointer == GET_ITEM(12, 222)
		||DivineWeapon_Pointer == GET_ITEM(12, 223)
		||DivineWeapon_Pointer == GET_ITEM(12, 224)
		||DivineWeapon_Pointer == GET_ITEM(12, 225)
		||DivineWeapon_Pointer == GET_ITEM(12, 226)
		||DivineWeapon_Pointer == GET_ITEM(12, 227)
		||DivineWeapon_Pointer == GET_ITEM(12, 228)
		||DivineWeapon_Pointer == GET_ITEM(12, 229)
		||DivineWeapon_Pointer == GET_ITEM(12, 230)
		||DivineWeapon_Pointer == GET_ITEM(12, 231)
		||DivineWeapon_Pointer == GET_ITEM(12, 232)
		||DivineWeapon_Pointer == GET_ITEM(12, 233)
		||DivineWeapon_Pointer == GET_ITEM(12, 234)
		||DivineWeapon_Pointer == GET_ITEM(12, 235)
		||DivineWeapon_Pointer == GET_ITEM(12, 236)
		||DivineWeapon_Pointer == GET_ITEM(12, 237)
		||DivineWeapon_Pointer == GET_ITEM(12, 238)
		||DivineWeapon_Pointer == GET_ITEM(12, 239)
		||DivineWeapon_Pointer == GET_ITEM(12, 240)
		||DivineWeapon_Pointer == GET_ITEM(12, 241)
		||DivineWeapon_Pointer == GET_ITEM(12, 242)
		||DivineWeapon_Pointer == GET_ITEM(12, 243)
		||DivineWeapon_Pointer == GET_ITEM(12, 244)
		||DivineWeapon_Pointer == GET_ITEM(12, 245)
		||DivineWeapon_Pointer == GET_ITEM(12, 246)
		||DivineWeapon_Pointer == GET_ITEM(12, 247)
		||DivineWeapon_Pointer == GET_ITEM(12, 248)
		||DivineWeapon_Pointer == GET_ITEM(12, 249)
		||DivineWeapon_Pointer == GET_ITEM(12, 250)
		||DivineWeapon_Pointer == GET_ITEM(12, 251)
		||DivineWeapon_Pointer == GET_ITEM(12, 252)
		||DivineWeapon_Pointer == GET_ITEM(12, 253)
		||DivineWeapon_Pointer == GET_ITEM(12, 254)
		||DivineWeapon_Pointer == GET_ITEM(12, 255)
		||DivineWeapon_Pointer == GET_ITEM(12, 256)
		||DivineWeapon_Pointer == GET_ITEM(12, 257)
		||DivineWeapon_Pointer == GET_ITEM(12, 260)
		||DivineWeapon_Pointer == GET_ITEM(12, 259)
		||DivineWeapon_Pointer == GET_ITEM(12, 261)
		||DivineWeapon_Pointer == GET_ITEM(12, 262)
		||DivineWeapon_Pointer == GET_ITEM(12, 263)
		||DivineWeapon_Pointer == GET_ITEM(12, 264)
		||DivineWeapon_Pointer == GET_ITEM(12, 265)
		||DivineWeapon_Pointer == GET_ITEM(12, 266)
		||DivineWeapon_Pointer == GET_ITEM(12, 267)
		||DivineWeapon_Pointer == GET_ITEM(12, 268)
		||DivineWeapon_Pointer == GET_ITEM(12, 269)
		||DivineWeapon_Pointer == GET_ITEM(12, 270)
		||DivineWeapon_Pointer == GET_ITEM(12, 271)
		||DivineWeapon_Pointer == GET_ITEM(12, 272)
		||DivineWeapon_Pointer == GET_ITEM(12, 273)
		||DivineWeapon_Pointer == GET_ITEM(12, 274)
		||DivineWeapon_Pointer == GET_ITEM(12, 275)
		||DivineWeapon_Pointer == GET_ITEM(12, 276)
		||DivineWeapon_Pointer == GET_ITEM(12, 277)
		||DivineWeapon_Pointer == GET_ITEM(12, 278)
		||DivineWeapon_Pointer == GET_ITEM(12, 279)
		||DivineWeapon_Pointer == GET_ITEM(12, 280)
		||DivineWeapon_Pointer == GET_ITEM(12, 281)
		||DivineWeapon_Pointer == GET_ITEM(12, 282)
		||DivineWeapon_Pointer == GET_ITEM(12, 283)
		||DivineWeapon_Pointer == GET_ITEM(12, 284)
		||DivineWeapon_Pointer == GET_ITEM(12, 285)
		||DivineWeapon_Pointer == GET_ITEM(12, 286)
		||DivineWeapon_Pointer == GET_ITEM(12, 287)
		||DivineWeapon_Pointer == GET_ITEM(12, 288)
		||DivineWeapon_Pointer == GET_ITEM(12, 289)
		||DivineWeapon_Pointer == GET_ITEM(12, 290)
		||DivineWeapon_Pointer == GET_ITEM(12, 291)
		||DivineWeapon_Pointer == GET_ITEM(12, 292)
		||DivineWeapon_Pointer == GET_ITEM(12, 293)
		||DivineWeapon_Pointer == GET_ITEM(12, 294)
		||DivineWeapon_Pointer == GET_ITEM(12, 295)
		||DivineWeapon_Pointer == GET_ITEM(12, 296)
		||DivineWeapon_Pointer == GET_ITEM(12, 297)
		||DivineWeapon_Pointer == GET_ITEM(12, 298)
		||DivineWeapon_Pointer == GET_ITEM(12, 299)
		||DivineWeapon_Pointer == GET_ITEM(12, 300)
		||DivineWeapon_Pointer == GET_ITEM(12, 301)
		||DivineWeapon_Pointer == GET_ITEM(12, 302)
		||DivineWeapon_Pointer == GET_ITEM(12, 303)
		||DivineWeapon_Pointer == GET_ITEM(12, 304)
		||DivineWeapon_Pointer == GET_ITEM(12, 305)
		||DivineWeapon_Pointer == GET_ITEM(12, 400)
		||DivineWeapon_Pointer == GET_ITEM(12, 307)
		||DivineWeapon_Pointer == GET_ITEM(12, 308)
		||DivineWeapon_Pointer == GET_ITEM(12, 309)
		||DivineWeapon_Pointer == GET_ITEM(12, 310)
		||DivineWeapon_Pointer == GET_ITEM(12, 311)
		||DivineWeapon_Pointer == GET_ITEM(12, 312)
		||DivineWeapon_Pointer == GET_ITEM(12, 313)
		||DivineWeapon_Pointer == GET_ITEM(12, 314)
		||DivineWeapon_Pointer == GET_ITEM(12, 315)
		||DivineWeapon_Pointer == GET_ITEM(12, 316)
		||DivineWeapon_Pointer == GET_ITEM(12, 317)
		||DivineWeapon_Pointer == GET_ITEM(12, 318)
		||DivineWeapon_Pointer == GET_ITEM(12, 319)
		||DivineWeapon_Pointer == GET_ITEM(12, 320)
		||DivineWeapon_Pointer == GET_ITEM(12, 321)
		||DivineWeapon_Pointer == GET_ITEM(12, 323)
		||DivineWeapon_Pointer == GET_ITEM(12, 325)
		||DivineWeapon_Pointer == GET_ITEM(12, 326)
		||DivineWeapon_Pointer == GET_ITEM(12, 327)
		||DivineWeapon_Pointer == GET_ITEM(12, 328)
		||DivineWeapon_Pointer == GET_ITEM(12, 329)
		||DivineWeapon_Pointer == GET_ITEM(12, 330)
		||DivineWeapon_Pointer == GET_ITEM(12, 331)
		||DivineWeapon_Pointer == GET_ITEM(12, 332)
		||DivineWeapon_Pointer == GET_ITEM(12, 333)
		||DivineWeapon_Pointer == GET_ITEM(12, 334)
		||DivineWeapon_Pointer == GET_ITEM(12, 335)
		||DivineWeapon_Pointer == GET_ITEM(12, 336)
		||DivineWeapon_Pointer == GET_ITEM(12, 337)



		)
	{
		_asm{Jmp DivineWeaponAdress1}
	}
	else
	{
		_asm{Jmp DivineWeaponAdress2}
	}
}
//--
DWORD DropColorProtect;
DWORD DropColorPointer;
//--
__declspec(naked)void DropColor()
{
	_asm
	{
		Mov DropColorProtect,Eax
		MOV EDX,DWORD PTR SS:[EBP-0x18]
		Mov Eax,DWORD PTR DS:[EDX+0x30]
		Mov DropColorPointer,Eax
		Mov Eax,DropColorProtect
	}
	if(DropColorPointer==0x253B)
	{
		_asm{
			Mov DropColorPointer,0x005F47AA // Orange
			Jmp DropColorPointer
		}
	}
	else if(DropColorPointer== GET_ITEM(0,51))
	{
		_asm
		{
			Mov DropColorPointer,0x005F4918 // Purple
			Jmp DropColorPointer
		}
	}
	else if
		(DropColorPointer== GET_ITEM(14,14))
	{
		_asm
		{
			mov DropColorPointer,0x005F439E//Yellow
			jmp DropColorPointer
		}
	}
	else
		{
		_asm{
			Mov DropColorPointer,0x005F47BC//Next
			Jmp DropColorPointer
		}
	}
}
//--
void InitCustomNameColor()
{
	SetRange((LPVOID)0x007E7827,4, 0x90);
	SetOp((DWORD)0x007E7827,(LPVOID)DivineWeapon, 0xE9);
	//--
	SetRange((LPVOID)0x005F479E,10, 0x90);
	SetOp((DWORD)0x005F479E,(LPVOID)DropColor, 0xE9);
}