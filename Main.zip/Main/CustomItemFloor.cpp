#include "stdafx.h"
#include "CustomItemFloor.h"
#include "LuaStack.hpp"
#include "Util.h"
#include "Item.h"

using namespace luaaa;

CCustomItemFloor gCustomItemFloor;

CCustomItemFloor::CCustomItemFloor() : m_Lua(true)
{
	this->m_CustomItemFloorInfo.clear();
}

CCustomItemFloor::~CCustomItemFloor()
{
	this->m_CustomItemFloorInfo.clear();
}

void SetItemFloor(int ItemIndex, float AngleX, float AngleY, float AngleZ, float Size) {
	CUSTOM_ITEM_FLOOR_INFO info;

	info.ItemIndex = ItemIndex + ITEM_BASE_MODEL;

	info.AngleX = AngleX;

	info.AngleY = AngleY;

	info.AngleZ = AngleZ;

	info.Size = Size;

	gCustomItemFloor.m_CustomItemFloorInfo.insert(std::make_pair(info.ItemIndex, info));
}

void CCustomItemFloor::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemFloor", &SetItemFloor);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomItemFloor.lua");

	this->m_Lua.Generic_Call("StartLoadItemFloor", ">");

	SetCompleteHook(0xE8, 0x005F820C, &this->ItemAngle);
	SetCompleteHook(0xE8, 0x005F847D, &this->ItemAngle);
}

CUSTOM_ITEM_FLOOR_INFO * CCustomItemFloor::getItem(int ItemIndex)
{
	std::map<int, CUSTOM_ITEM_FLOOR_INFO>::iterator it = this->m_CustomItemFloorInfo.find(ItemIndex);

	if (it == this->m_CustomItemFloorInfo.end()) {
		return 0;
	}

	return &it->second;
}

void CCustomItemFloor::ItemAngle(ObjectModel * object)
{
	auto CheckItem = gCustomItemFloor.getItem(object->Type);

	if (CheckItem) {
		Vector(CheckItem->AngleX, CheckItem->AngleY, CheckItem->AngleZ, object->Angle);

		object->Scale = CheckItem->Size;
	}
	else {
		((void(*)(ObjectModel*))0x5F61C0)(object);
	}
}
