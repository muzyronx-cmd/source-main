#pragma once

#include "Lua.h"

struct CUSTOM_MONSTER_GLOW_INFO {
	int Layer;
	int MeshType;
	int R;
	int G;
	int B;
};

class CUSTOM_MONSTER_GLOW {
public:
	CUSTOM_MONSTER_GLOW() {
		this->m_Glow.clear();
	};

	~CUSTOM_MONSTER_GLOW() {
		this->m_Glow.clear();
	};

	int MonsterID;
	std::vector<CUSTOM_MONSTER_GLOW_INFO> m_Glow;
};

class CCustomMonsterGlow {
public:
	CCustomMonsterGlow();
	~CCustomMonsterGlow();

	void Init();
	CUSTOM_MONSTER_GLOW* getMonsterGlow(int Type);
	static bool RenderAidaMonsterObjectMesh(DWORD obj, DWORD model);

public:
	std::map<int, CUSTOM_MONSTER_GLOW> m_CustomMonsterGlow;

private:
	Lua m_Lua;
};

extern CCustomMonsterGlow gCustomMonsterGlow;