#include "stdafx.h"
#include "LuaEffects.h"
#include "LuaEffectsNormal.h"
#include "LuaStack.hpp"
#include "Item.h"

using namespace luaaa;

void FuncCreateParticleNormal(DWORD BMDStruct, int Bitmap, int SubType, int Link, float Scale, vec3_t Light, DWORD ObjectStruct) {
	vec3_t Position, p;
	p[0] = 0.f; p[1] = 0.f; p[2] = 0.f;

	if (ObjectStruct == 0) {
		return;
	}

	((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[Link], p, Position, 1);
	((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(Bitmap, Position, *(vec3_t*)(ObjectStruct + 264), Light, SubType, Scale, ObjectStruct);
}

void CreateSpriteNormal(DWORD BMDStruct, int Bitmap, int Link, float Scale, float LightR, float LightG, float LightB, DWORD ObjectStruct) {
	vec3_t Light;
	Vector(LightR, LightG, LightB, Light);
	((void(*)(DWORD, int, int, float, vec3_t, DWORD))0x565560)(BMDStruct, Bitmap, Link, Scale, Light, ObjectStruct);
}

void CreateParticleNormal(DWORD BMDStruct, int Bitmap, int SubType, int Link, float Scale, float LightR, float LightG, float LightB, DWORD ObjectStruct) {
	vec3_t Light;
	Vector(LightR, LightG, LightB, Light);
	FuncCreateParticleNormal(BMDStruct, Bitmap, SubType, Link, Scale, Light, ObjectStruct);
}

CLuaEffectNormal::CLuaEffectNormal()
{
}

CLuaEffectNormal::~CLuaEffectNormal()
{
}

void CLuaEffectNormal::RegisterLuaClass(lua_State * lua)
{
	LuaModule(lua).fun("CreateSprite", &CreateSpriteNormal);
	LuaModule(lua).fun("CreateParticle", &CreateParticleNormal);
}
