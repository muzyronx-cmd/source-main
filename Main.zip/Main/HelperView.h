#pragma once

#include <list>

BoostSmartPointer(HELPER_VIEW);
class HELPER_VIEW
{
public:
	static HELPER_VIEWPtr Make();

	HELPER_VIEW() : m_pOwner(nullptr), m_itemType(-1), m_Obj(nullptr), m_HeightFloor(0.0f), m_Movement(0), m_Type(0) {
		this->Init();
	};

	virtual ~HELPER_VIEW() {
		this->Relese();
	};

	void Init() {
		if (m_Obj == nullptr) {

			DWORD* CreateClass = ((DWORD*(*)(int))0x9D00C5)(648);

			if (CreateClass) {
				m_Obj = ((ObjectModel*(__thiscall*)(DWORD*))0x4CD230)(CreateClass);
			}
			else {
				m_Obj = nullptr;
			}
		}
	};

	bool Create(int Index, int ModelIndex, vec3_t Position, ObjectPreview* m_Owner, int SubType);

	void Render();
	void Update();
	void UpdateModel(DWORD model);
	void UpdateMove(DWORD model);

	void WorkMoviment(ObjectModel* ObjectStruct, DWORD BMDStruct, float MaxPos, int type, int movement, int state);
	void WorkdMovimentMiniature(ObjectModel* ObjectStruct, DWORD BMDStruct, float MaxPos);

	bool IsLive() { return m_Obj->Live; };
	bool IsSameOwner(ObjectModel *Owner) { return (Owner == m_Obj->Owner) ? 1 : 0; };
	bool IsSameObject(ObjectModel *Owner, int itemType) { return (Owner == m_Obj->Owner && itemType == m_itemType) ? 1 : 0; };
	bool IsSameObject(ObjectModel *Owner) { return (Owner == m_Obj->Owner) ? 1 : 0; };
	void SetScale(float scale) {
		m_Obj->Scale = scale; 
		this->PetOriginalSize = scale;
	};

	void SetMiniature(int miniature, float sizeminiature, float velocity) {
		this->Miniature = miniature;
		this->SizeMiniature = sizeminiature;
		this->VelocityMiniature = velocity;
	}

	void Relese() {
		m_itemType = -1;
		ModelIndex = -1;

		if (m_pOwner) {
			m_pOwner = nullptr;
		}

		if (m_Obj) {
			m_Obj->Live = false;
			m_Obj->Owner = nullptr;

			DWORD ObjectStruct = (DWORD)m_Obj;

			/*if (ObjectStruct) {
				(**(void(__thiscall ***)(int, signed int))ObjectStruct)(ObjectStruct, 1);
			}*/

			m_Obj = nullptr;
		}
	}

	int m_itemType;
	int ModelIndex;
	ObjectModel* m_Obj;
	ObjectPreview* m_pOwner;

	DWORD m_startTick;

	int m_Type;
	int m_Movement;
	float m_HeightFloor;
	float PetOriginalSize;

	int Miniature;
	float SizeMiniature;
	float VelocityMiniature;
};