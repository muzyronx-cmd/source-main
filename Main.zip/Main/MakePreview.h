#pragma once

#include "Protocol.h"

class CMakePreview {
public:
	CMakePreview();
	~CMakePreview();

	void Init();
	static void ChangeCharacterExt(int Key, BYTE* Equipment, ObjectPreview* pCharacter, ObjectModel* pHelper);
	static void ReceiveChangePlayer(PMSG_ITEM_CHANGE_RECV * lpMsg);
	static void SetChangeClass(ObjectPreview* pCharacter);
};

extern CMakePreview gMakePreview;