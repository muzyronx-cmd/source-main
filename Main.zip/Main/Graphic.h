#pragma once

class CGraphic {
public:
	CGraphic();
	~CGraphic();

	void Init();
};

extern CGraphic gGraphic;