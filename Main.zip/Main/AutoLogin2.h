#pragma once

#include "Protocol.h"

class CAutoLogin
{
public:
	CAutoLogin();
	virtual ~CAutoLogin();

	void EncryptString(char* out_buff, char* in_buff, int size);
	void DecryptString(char* out_buff, char* in_buff, int size);
	void Load();
	void Save();
	void RegisterAutoLogin(char * account, char * password, char * character, char * serverip, WORD serverport);
	static void RenderMainScene(HDC hdc);
	void CGCharacterListRecv(PMSG_CHARACTER_LIST_RECV* lpMsg);
	static bool CharacterInfoRecv(DWORD lpMsg, int key);
	static void DestroyWindow();

private:
	char m_LoginAccount[11];
	char m_PassAccount[11];
	char m_CharAccount[11];
	char m_ServerIPAddress[17];
	WORD m_ServerPORT;

	char m_SaveLoginAccount[11];
	char m_SavePassAccount[11];
	char m_SaveCharAccount[11];
	char m_SaveServerIPAddress[17];
	WORD m_SaveServerPORT;

	DWORD m_AutoLogin;
	DWORD m_ThisAutoLogin;

	bool m_Load;
	bool m_FirstLogin;

public:
	bool m_ConnectingAutoLogin;
	bool m_AutoLoginConnected;
	bool m_CancelAutoLogin;
};

extern CAutoLogin gAutoLogin;