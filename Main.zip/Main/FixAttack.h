#pragma once

void InitAttackSpeed();