// CustomMessage.h: interface for the CCustomMessage class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Lua.h"

#define MAX_CUSTOM_MESSAGE 70

struct CUSTOM_MESSAGE_INFO
{
	int Index;
	char Message[128];
};

class CCustomMessage
{
public:
	CCustomMessage();
	virtual ~CCustomMessage();
	void Init();
	void LoadEng();
	void LoadPor();
	void LoadSpn();
	CUSTOM_MESSAGE_INFO* GetInfoEng(int index);
	CUSTOM_MESSAGE_INFO* GetInfoPor(int index);
	CUSTOM_MESSAGE_INFO* GetInfoSpn(int index);
	char* GetMessage(int index);
public:
	char m_DefaultMessage[128];
	CUSTOM_MESSAGE_INFO m_EngCustomMessageInfo[MAX_CUSTOM_MESSAGE];
	CUSTOM_MESSAGE_INFO m_PorCustomMessageInfo[MAX_CUSTOM_MESSAGE];
	CUSTOM_MESSAGE_INFO m_SpnCustomMessageInfo[MAX_CUSTOM_MESSAGE];

	Lua m_Lua;
};

extern CCustomMessage gCustomMessage;
