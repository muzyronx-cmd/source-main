#pragma once

#include "Lua.h"
#include "LuaEffectsNormal.h"

class CCustomEffects {
public:
	CCustomEffects();
	~CCustomEffects();

	void RestartLua();
	void Init();
	static void RenderLinkObject(float x, float y, float z, ObjectPreview *c, PART_t* f, int Type, int Level, int Option1, bool Link, bool Translate, int RenderType, bool bRightHandItem);
	static void RenderPartObjectEffect(ObjectModel *o, int Type, vec3_t Light, float_t Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType);

private:
	Lua m_Lua;
	CLuaEffectNormal m_LuaEffects;
};

extern CCustomEffects gCustomEffects;