#include "stdafx.h"
#include "CustomClaws.h"
#include "LuaStack.hpp"
#include "Item.h"

using namespace luaaa;

#define sub_50D810_Addr        ((int(__thiscall*)(int a1, int a2, int a3, int a4)) 0x50D810)
#define sub_512D50_Addr        ((void*(__thiscall*)(void* a1)) 0x512D50)
#define sub_513C60_Addr        ((char*(__thiscall*)(char *This, void *a2, int a3)) 0x513C60)
#define sub_5135F0_Addr        ((char*(__thiscall*)(DWORD *This, int a2, int a3)) 0x5135F0)
#define sub_512D60_Addr        ((void(*)()) 0x512D60)

CCustomClaws gCustomClaws;

CCustomClaws::CCustomClaws() : m_Lua(true)
{
	this->m_CustomClaws.clear();
}

CCustomClaws::~CCustomClaws()
{
	this->m_CustomClaws.clear();
}

void SetClaws(int ItemIndex, float ColorR, float ColorG, float ColorB, char* ModelName, int TextureLeftIndex, char* TextureLeftModel, int TextureRightIndex, char* TextureRightModel) {
	CUSTOM_CLAWS_INFO info;

	info.ItemIndex = ItemIndex;

	info.ColorR = ColorR;

	info.ColorG = ColorG;

	info.ColorB = ColorB;

	strcpy_s(info.ModelName, ModelName);

	info.TextureLeftIndex = TextureLeftIndex;

	strcpy_s(info.TextureLeftModel, TextureLeftModel);

	info.TextureRightIndex = TextureRightIndex;

	strcpy_s(info.TextureRightModel, TextureRightModel);

	gCustomClaws.m_CustomClaws.insert(std::make_pair(info.ItemIndex, info));
}

void GlovesAssoc(char *This)
{
	sub_50D810_Addr((int)(This + 92), 1203, 610, 611);
	void* v2 = sub_512D50_Addr(This + 92);
	char* v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
	sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
	sub_512D60_Addr();
	// ----
	sub_50D810_Addr((int)(This + 92), 1204, 612, 613);
	v2 = sub_512D50_Addr(This + 92);
	v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
	sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
	sub_512D60_Addr();
	// ----
	sub_50D810_Addr((int)(This + 92), 1205, 614, 615);
	v2 = sub_512D50_Addr(This + 92);
	v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
	sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
	sub_512D60_Addr();
	// ----
	sub_50D810_Addr((int)(This + 92), 1206, 616, 617);
	v2 = sub_512D50_Addr(This + 92);
	v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
	sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
	sub_512D60_Addr();
	// ----
	sub_50D810_Addr((int)(This + 92), 1211, 610, 611);
	v2 = sub_512D50_Addr(This + 92);
	v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
	sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
	sub_512D60_Addr();
	// ----
	for (std::map<int, CUSTOM_CLAWS_INFO>::iterator it = gCustomClaws.m_CustomClaws.begin(); it != gCustomClaws.m_CustomClaws.end(); it++)
	{
		sub_50D810_Addr((int)(This + 92), it->second.ItemIndex, it->second.TextureLeftIndex, it->second.TextureRightIndex);
		v2 = sub_512D50_Addr(This + 92);
		v3 = sub_513C60_Addr(This, v2, (int)(This + 92));
		sub_5135F0_Addr((DWORD *)This + 15, (int)This, (int)v3);
		sub_512D60_Addr();
	}
}

static BOOL bBattleGlovesGlow_Switcher;

void __declspec(naked) BattleGloveGlow()
{
	static DWORD dwBattleGlovesGlow_Pointer;
	static DWORD dwBattleGlovesGlow_Buffer;
	static DWORD dwBattleGlovesNewGlow_Buffer;
	static DWORD dwBattleGlovesGlow_Jump = 0x005F94E8;
	static bool item = false;
	// ----
	bBattleGlovesGlow_Switcher = FALSE;
	// ----
	_asm {
		MOV dwBattleGlovesGlow_Pointer, EAX
	}
	// ----
	item = gCustomClaws.CheckIsClaw(dwBattleGlovesGlow_Pointer);

	if (dwBattleGlovesGlow_Pointer == GET_ITEM_MODEL(0, 35))
	{
		bBattleGlovesGlow_Switcher = TRUE;
	}
	//--
	else if (item == true)
	{
		bBattleGlovesGlow_Switcher = FALSE;
		// ----
		_asm {
			MOV DWORD PTR SS : [EBP - 0x4], 0x2C
			JMP dwBattleGlovesGlow_Jump
		}
	}
	// ----
	if (bBattleGlovesGlow_Switcher == TRUE) {
		_asm {
			MOV dwBattleGlovesGlow_Buffer, 0x005F91C9
			JMP dwBattleGlovesGlow_Buffer
		}
	}
	else {
		_asm {
			MOV dwBattleGlovesGlow_Buffer, 0x005F91D5
			JMP dwBattleGlovesGlow_Buffer
		}
	}
}

bool CheckIsClaws(int ItemIndex) {
	if (gCustomClaws.CheckIsClaw(ItemIndex + ITEM_BASE_MODEL) || (ItemIndex >= 32 && ItemIndex <= 35)) {
		return 1;
	}

	return 0;
}

void __declspec(naked) RenderBattleGlove()
{
	static DWORD buffer_posicion = 0x005D01DA;
	static DWORD buffer_Next_posicion = 0x005D01FA;
	static DWORD RenderClaws = 0;
	static DWORD t;

	_asm
	{
		MOV ECX, DWORD PTR SS : [EBP + 0x18]
		MOV RenderClaws, ECX
	}

	if (CheckIsClaws(RenderClaws) == true)
	{
		_asm
		{
			JMP[buffer_posicion]
		}
	}
	else
	{
		_asm
		{
			JMP[buffer_Next_posicion]
		}
	}
}

void CCustomClaws::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetClaws", &SetClaws);

	//this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomClaws.lua");

	//this->m_Lua.Generic_Call("StartLoadClaws", "");

	SetCompleteHook(0xE9, 0x005D01D0, &RenderBattleGlove);

	SetCompleteHook(0xE8, 0x0050D905, &GlovesAssoc);

	SetCompleteHook(0xE9, 0x005F91C2, &BattleGloveGlow);
}

bool CCustomClaws::CheckIsClaw(int ItemIndex)
{
	std::map<int, CUSTOM_CLAWS_INFO>::iterator it = this->m_CustomClaws.find(ItemIndex);

	if (it == this->m_CustomClaws.end()) {
		return 0;
	}

	return 1;
}

CUSTOM_CLAWS_INFO * CCustomClaws::getInfo(int ItemIndex)
{
	for (std::map<int, CUSTOM_CLAWS_INFO>::iterator it = gCustomClaws.m_CustomClaws.begin(); it != gCustomClaws.m_CustomClaws.end(); it++)
	{
		if (it->second.ItemIndex == ItemIndex
			|| it->second.TextureLeftIndex == ItemIndex
			|| it->second.TextureRightIndex == ItemIndex) {
			return &it->second;
		}
	}

	return 0;
}
