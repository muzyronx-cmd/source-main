#include "stdafx.h"
#include "MuHelper.h"
#include "PrintPlayer.h"
#include "Offset.h"
#include "Util.h"
#include "Defines.h"

cMuOffHelper gMuHelper;

void cMuOffHelper::Load()
{
	this->m_Disconnect = false;
}

void cMuOffHelper::RunningOffHelper()
{
	this->m_Disconnect = true;

	PMSG_MUHELPER_OFFLINE_SEND pMsg;

	pMsg.header.set(0xFB, 0x3D, sizeof(pMsg));
	//-- Range Attack
	pMsg.HuntingRange = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+172);
	//-- Auto Heling, Drain and Potion
	pMsg.RecoveryPotionOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+176);
	pMsg.RecoveryPotionPercent = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+177);
	pMsg.RecoveryHealOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+178);
	pMsg.RecoveryHealPercent = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+179);
	pMsg.RecoveryDrainOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+180);
	pMsg.RecoveryDrainPercent = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+181);
	//-- Attack
	pMsg.DistanceLongOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+182);
	pMsg.DistanceReturnOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+183);
	pMsg.DistanceMin = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+184);
	pMsg.SkillBasicID = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+188);
	pMsg.SkillSecondID = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+192);
	pMsg.SkillThirdID = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+216);
	pMsg.ComboOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+240);
	//-- Party Settings
	pMsg.PartyModeOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+241);
	pMsg.PartyModeHealOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+242);
	pMsg.PartyModeHealPercent = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+243);
	pMsg.PartyModeBuffOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+244);
	//-- AutoBuffo
	pMsg.BuffOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+260);
	pMsg.BuffSkill[0] = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+264);
	pMsg.BuffSkill[1] = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+268);
	pMsg.BuffSkill[2] = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+272);
	//-- PickObtain
	pMsg.ObtainRange = *(WORD*)(*(DWORD*)(MAIN_HELPER_STRUCT)+288);
	pMsg.ObtainRepairOn = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+292);
	pMsg.ObtainPickNear = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+293);
	pMsg.ObtainPickSelected = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+294);
	pMsg.ObtainPickMoney = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+298);
	pMsg.ObtainPickJewels = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+295);
	pMsg.ObtainPickExcellent = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+297);
	pMsg.ObtainPickAncient = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+296);
	pMsg.ObtainPickExtra = *(BYTE*)(*(DWORD*)(MAIN_HELPER_STRUCT)+299);

	pMsg.ObtainPickExtraCount = 0;

	for (int i = 0; i < 12; i++)
	{
		ZeroMemory(pMsg.ObtainPickItemList[i], sizeof(pMsg.ObtainPickItemList[i]));
		wsprintf(pMsg.ObtainPickItemList[i], pGetItemList(i));

		if ((strcmp(pGetItemList(i), "") != 0))
		{
			pMsg.ObtainPickExtraCount++;
		}
	}

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

__declspec(naked) void CheckHelperMana()
{
	static DWORD main_addr;
	static DWORD SkillUsedMana;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP - 0xC]
		MOV SkillUsedMana, EDX
	}

	if (SkillUsedMana <= ViewCurMP)
		main_addr = 0x0095F9BD;
	else
		main_addr = 0x0095F9BF;

	_asm
	{
		JMP[main_addr]
	}
}

__declspec(naked) void CheckHelperBP()
{
	static DWORD main_addr;
	static DWORD SkillUsedBP;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP - 0x4]
		MOV SkillUsedBP, EDX
	}


	if (SkillUsedBP <= ViewCurBP)
		main_addr = 0x0095F9F7;
	else
		main_addr = 0x0095F9F0;

	_asm
	{
		JMP[main_addr]
	}
}

__declspec(naked) void CheckAttckBP()
{
	static DWORD main_addr;
	static DWORD SkillUsedBP;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP - 0x1C]
		MOV SkillUsedBP, EDX
	}

	if (SkillUsedBP > ViewCurBP)
		main_addr = 0x0059B9D2;
	else
		main_addr = 0x0059B9D9;

	_asm
	{
		JMP[main_addr]
	}
}

__declspec(naked) void CheckAutoPote()
{
	static DWORD Pointer;
	static DWORD main_addr = 0x0095E1C4;

	_asm
	{
		MOV ECX, DWORD PTR SS : [EBP - 0x1874]
		MOV Pointer, ECX
	}

	if (*(BYTE *)(Pointer + 176))
	{
		if (ViewCurHP < (ViewMaxHP * *(BYTE *)(Pointer + 177) / 100)
			&& *(BYTE *)(*(DWORD *)(Pointer + 4) + 780) == 1
			&& ViewCurHP > 0)
		{
			main_addr = 0x0095E1B9;
		}
	}

	_asm
	{
		JMP[main_addr]
	}
}

__declspec(naked) void CheckAutoHealing()
{
	static DWORD Pointer;
	static DWORD main_addr = 0x0095E970;

	_asm
	{
		MOV ECX, DWORD PTR SS : [EBP - 0x1874]
		MOV Pointer, ECX
	}

	if (!*(BYTE *)(Pointer + 178)
		|| (pGetSkillPos(26) < 0 && pGetSkillPos(413) < 0)
		|| (ViewCurHP >= (ViewMaxHP * *(BYTE *)(Pointer + 179) / 100) ||
			*(BYTE *)(*(DWORD *)(Pointer + 4) + 780) != 1 || ViewCurHP <= 0 ||
			!pHelperUseBuff((MUHelper*)Pointer, (ObjectPreview*) *(DWORD *)(Pointer + 4)))
		)
	{
		main_addr = 0x0095E2BA;
	}

	_asm
	{
		JMP[main_addr]
	}
}

void cMuOffHelper::Init()
{
	SetCompleteHook(0xE9, 0x0095E1AB, &CheckAutoPote);
	SetCompleteHook(0xE9, 0x0095E1C4, &CheckAutoHealing);
	SetCompleteHook(0xE9, 0x0095F9B0, &CheckHelperMana);
}