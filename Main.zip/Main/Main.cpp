// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "HotKey.h"
#include "LoadFiles.h"
#include "AntiHack.h"
#include "Common.h"
#include "Util.h"
#include "HackCheck.h"
#include "HealthBar.h"
#include "CustomMessage.h"
#include "WindowTray.h"
//#include "VBA.h"
#include "CustomWing.h"
#include "CustomItem.h"
#include "CustomEffects.h"
#include "MakePreview.h"
#include "PacketManager.h"
#include "RenderObject.h"
#include "Item.h"
#include "PrintPlayer.h"
#include "Reconnect.h"
#include "Resolution.h"
#include "LoadImages.h"
#include "Interface.h"
#include "HelperSystem.h"
#include "MenuWindow.h"
#include "Descriptions.h"
#include "TradeX.h"
#include "ChaosBoxGenesis.h"
#include "CustomMonster.h"
#include "CustomBow.h"
#include "CustomItemPosition.h"
#include "CustomItemSize.h"
#include "CustomItemFloor.h"
#include "ChatWindow.h"
#include "MuHelper.h"
#include "MuHelperInterface.h"
#include "RenderModel.h"
#include "CounterItem.h"
#include "CustomSetEffect.h"
#include "Patente.h"
//#include "CustomClaws.h"
#include "CustomItemValue.h"
#include "PersonalShop.h"
#include "CustomItemForce.h"
#include "CustomServerName.h"
#include "MessageColor.h"
#include "Console.h"
#include "CustomMap.h"
#include "CharacterList.h"
#include "Graphic.h"
#include "CustomJewelStack.h"
#include "resource.h"
#include "ElementSlots.h"
#include "ElementSystem.h"
#include "VisualInventory.h"
#include "AutoLoginWin.h"
#include "DisableExcellent.h"
#include "CustomMonsterName.h"
#include "DarkSpirit.h"
#include "CreateFont.h"
#include "CharacterLevel.h"
#include "CustomMonsterEffect.h"
#include "CustomMonsterGlow.h"
#include "RenderItem.h"
#include "CustomSkillEffect.h"
#include "ShowInfoItemDrop.h"
#include "InterWide.h"
#include "WideScreen.h"
#include "SelectScene.h"
#include "RemakeInterface.h"
#include "User.h"
#include "ChatSystem.h"
#include "LoginRemake.h"
#include "AutoLogin2.h"
#include "CustomColorName.h"
#include "UITextInputBox.h"
#include "ItemTooltip.h"
//#include "GLFont.h"


#define pMSendChatSay         ((int(__cdecl*)(char * Name, char * Text, int a1, int a4, int a5)) 0x5996A0)

static void NPCChat(int a1, int a2);



#define RenderBoolean									((void(__cdecl*)(int a1, int a2, char *a3)) 0x005985F0)
#define CreateGuildMark									((void(__cdecl*)(int a1, bool a2)) 0x005D30F0)
#define RenderBitmap									((void(__cdecl*)(int a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9, char a10, char a11, float a12)) 0x00637C60)

void CRenderBoolean(int a1, int a2, char* a3)
{
	int result = *(DWORD*)(a3 + 668);
	if (*(BYTE*)(result + 800) == 1)
	{
		CreateGuildMark(*(WORD*)(result + 124), 1);
		RenderBitmap(31740, a1 - 15, a2 + 2, 16.0, 16.0, 0.0, 0.0, 1.0, 1.0, 1, 1, 0.0);
	}
	RenderBoolean(a1, a2, a3);
}





HINSTANCE hins;
HHOOK HookKB;
bool g_Running = true;


//char IP_ADDRES_CONFIG[32] = "192.168.1.13";  // IP DA LICEN�A

bool m_Loaded = 0;


//-------------------------------------------------------------
                        // FIX CONSUMO
//-------------------------------------------------------------

DWORD WINAPI StartAddress(LPVOID lpThreadParameter)
{
	while (g_Running)
	{
		Sleep(5000);

		HANDLE process = GetCurrentProcess();
		SetProcessWorkingSetSize(process, -1, -1);

		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_LOWEST);
	}

	return 0;
}

DWORD WINAPI CheckMacroThread(LPVOID lpParam)
{
	while (g_Running)
	{
		Sleep(1000);

		if (VKF7_State != 0)
		{
			SendMessage(*(HWND*)(MAIN_WINDOW), WM_LBUTTONDOWN, VK_F7, MK_LBUTTON);
		}
	}

	return 0;
}

void StartMain() {

	if (m_Loaded) {
		return;
	}

	m_Loaded = true;

	if (gLoadFiles.ReadConfig("Data//Files//Configs.LORD-GAMING") == 0)
	{
		//gAntiHack.CloseApp();
		return;
	}

	if (gLoadFiles.m_LoadFiles.m_ItemTransparente == 1)
	{
		SetCompleteHook(0xE9, 0x0060EA3C, 0x0060EA58);
		SetCompleteHook(0xE9, 0x0060EA88, 0x0060EAE9);
	}

	//char m_path[256];
	//
	//wsprintf(m_path, "key.txt");
	//
	//HANDLE file = CreateFile(m_path, GENERIC_WRITE, FILE_SHARE_WRITE | FILE_SHARE_READ | FILE_SHARE_DELETE, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_SYSTEM, 0);
	//
	//if (file == INVALID_HANDLE_VALUE)
	//{
	//	return;
	//}
	//
	//DWORD OutSize = 0;
	//
	//char m_buff[256];
	//
	//wsprintf(m_buff, "%s", gLoadFiles.m_LoadFiles.m_PrivateCode);
	//
	//if (WriteFile(file, m_buff, sizeof(m_buff), &OutSize, 0) == 0)
	//{
	//	CloseHandle(file);
	//	return;
	//}

	//CloseHandle(file);


#if( USE_CONSOLE == TRUE)
	Console.InitCore();
#endif

	//if (strcmp(gLoadFiles.m_LoadFiles.m_IpServer, IP_ADDRES_CONFIG) != 0) {
	//	MessageBoxA(NULL, "Contate o administrador", "ERROR", MB_ICONSTOP);
	//	ExitProcess(0);
	//}


	if (pPlayerState == 5 && cName == NULL)
		ExitProcess(0);

	if (*(int*)0x0E609E8 == 5 && (char*)*(DWORD*)(0x8128AC4) == NULL)
		ExitProcess(0);

	//Load Dll Additional
	gLoadFiles.LoadDll();

	//Load Dll Additional2
	gLoadFiles.LoadDll2();

	gLoadFiles.LoadDll3();

	gLoadFiles.LoadDll4();

	gLoadFiles.LoadDll5();

	AutoLogin.Load();


	//gAntiHack.SetAdminPrivilege(SE_DEBUG_NAME);

	SetByte(0x00E61144, 0xA0); // Accent
	SetByte(0x004D1E69, 0xEB); // Crack (mu.exe)
	SetByte(0x004D228D, 0xE9); // Crack (GameGuard)
	SetByte(0x004D228E, 0x8B); // Crack (GameGuard)
	SetByte(0x004D228F, 0x00); // Crack (GameGuard)
	SetByte(0x004D2290, 0x00); // Crack (GameGuard)
	SetByte(0x004D2291, 0x00); // Crack (GameGuard)
	SetByte(0x004D559C, 0xEB); // Crack (ResourceGuard)
	SetByte(0x00633F7A, 0xEB); // Crack (ResourceGuard)
	SetByte(0x00634403, 0xEB); // Crack (ResourceGuard)
	SetByte(0x0063E6C4, 0xEB); // Crack (ResourceGuard)
	SetByte(0x004D2246, 0xEB); // Crack (ResourceGuard)
	SetByte(0x00501163, 0xEB); // Crack (ResourceGuard)
	SetByte(0x0040AF0A, 0x00); // Crack (ResourceGuard)
	SetByte(0x0040B4BC, 0x50); // Login Screen
	SetByte(0x0040B4C5, 0x50); // Login Screen
	SetByte(0x0040B4CF, 0x18); // Login Screen
	SetByte(0x0040AF0A, 0x00); // Login Screen
	SetByte(0x0040AFD5, 0xEB); // Login Screen
	SetByte(0x00777FD6, 0x70); // Item Text Limit
	SetByte(0x00777FD7, 0x17); // Item Text Limit
	SetByte(0x004EBEC7, 0x3C); // Item Text Limit
	SetByte(0x005C4004, 0x3C); // Item Text Limit
	SetByte(0x007E40BB, 0x3C); // Item Text Limit
	SetByte(0x0081B546, 0x3C); // Item Text Limit
	SetByte(0x0081B58D, 0x3C); // Item Text Limit
	SetByte(0x0086E284, 0x3C); // Item Text Limit
	SetByte(0x0086E44C, 0x3C); // Item Text Limit
	SetByte(0x0086E573, 0x3C); // Item Text Limit
	SetByte(0x0086F8FC, 0x3C); // Item Text Limit
	SetByte(0x007DA373, 0xB7); // Item Type Limit
	SetByte(0x007E1C44, 0xB7); // Item Type Limit
	SetByte(0x0052100D, 0xEB); // Ctrl Fix
	SetByte(0x009543C4, 0x00); // Move Vulcanus
	SetByte(0x0064CBD1, ((gLoadFiles.m_LoadFiles.HelperActiveAlert == 0) ? 0xEB : 0x75)); // Helper Message Box
	SetByte(0x0064CBD0, (BYTE)gLoadFiles.m_LoadFiles.HelperActiveLevel); // Helper Active Level
	SetByte(0x0095CEEF, (BYTE)gLoadFiles.m_LoadFiles.HelperActiveLevel); // Helper Active Level
	SetByte(0x0095CF14, (BYTE)gLoadFiles.m_LoadFiles.HelperActiveLevel); // Helper Active Level
	SetByte(0x00E61F68, (gLoadFiles.m_LoadFiles.ClientVersion[0] + 1)); // Version
	SetByte(0x00E61F69, (gLoadFiles.m_LoadFiles.ClientVersion[2] + 2)); // Version
	SetByte(0x00E61F6A, (gLoadFiles.m_LoadFiles.ClientVersion[3] + 3)); // Version
	SetByte(0x00E61F6B, (gLoadFiles.m_LoadFiles.ClientVersion[5] + 4)); // Version
	SetByte(0x00E61F6C, (gLoadFiles.m_LoadFiles.ClientVersion[6] + 5)); // Version
	SetWord(0x00E609E4, (gLoadFiles.m_LoadFiles.m_PortCS)); // IpAddressPort
	SetDword(0x004D0E09, (DWORD)gLoadFiles.m_LoadFiles.m_WindowName);
	SetDword(0x004D9F55, (DWORD)gLoadFiles.m_LoadFiles.m_ScreenDiretory);



	if (gLoadFiles.m_LoadFiles.ChineseSupport == 1) {

		SetByte((0x00958D4C + 3), 0xA8);	//1 Codepage utf China lang
		SetByte((0x00958D4C + 4), 0x03);	//2	Codepage utf China lang

		SetByte((0x00958D85 + 3), 0xA8);	//1 Codepage utf China lang
		SetByte((0x00958D85 + 4), 0x03);	//2	Codepage utf China lang

		SetByte((0x00958DBB + 3), 0xA8);	//1 Codepage utf China lang
		SetByte((0x00958DBB + 4), 0x03);	//2	Codepage utf China lang

		SetByte((0x00958DD7 + 3), 0xA8);	//1 Codepage utf China lang
		SetByte((0x00958DD7 + 4), 0x03);	//2	Codepage utf China lang

		SetByte(0x004215A7, 0xEB); //[0-9A-Za-z] Name
		SetByte(0x00507AFD, 0xEB); //[0-9A-Za-z] Guild
		SetByte((0x00507AEA + 1), 0x72); //[0-9A-Za-z] Name
		SetByte(0x004D6B49, 0xEB);

		SetCompleteHook(0xE8, 0x0059AFFA, 0x0059B00E);

		SetByte(0x004D6A84, 0xE9);
		SetByte(0x004D6A84 + 1, 0x8D);
		SetByte(0x004D6A84 + 2, 0x00);
		SetByte(0x004D6A89, 0x90);
	}

	/*SetDword(0x00954148 + 1, (DWORD)gLoadFiles.m_LoadFiles.m_ServerName1); //-> (Gold)
	SetDword(0x00954115 + 1, (DWORD)gLoadFiles.m_LoadFiles.m_ServerName2); //-> (Gold PVP)
	SetDword(0x009540E2 + 1, (DWORD)gLoadFiles.m_LoadFiles.m_ServerName3); //-> (Non-PVP)
	SetDword(0x009540AC + 1, (DWORD)gLoadFiles.m_LoadFiles.m_ServerName4); //-> Sem Nada*/

	MemorySet(0x0063E908, 0x90, 20); // C1:F3:04

	MemoryCpy(0x00E611B2, gLoadFiles.m_LoadFiles.m_IpServer, sizeof(gLoadFiles.m_LoadFiles.m_IpServer)); // IpAddress

	MemoryCpy(0x00E61F70, gLoadFiles.m_LoadFiles.m_Serial, sizeof(gLoadFiles.m_LoadFiles.m_Serial)); // ClientSerial

	SetCompleteHook(0xFF, 0x0065FD79, &ProtocolCoreEx);

	//Helper inventory
	SetByte(0x0095D010, 0xEB);
	SetCompleteHook(0xE9, 0x0095DFBE, 0x0095DFD3);

	//Set TimegetTime fluid system
	//MemorySet(0x004DA290, 0x90, 6);
	//SetCompleteHook(0xE8, 0x004DA290, &timeGetTime);

	if (gLoadFiles.m_LoadFiles.m_ManagerFps == 1) {
		/*SetDword(0x004D9D3B, (DWORD)&FrameValue);
		SetDword(0x004DAC60, (DWORD)&FrameValue);
		SetDword(0x7B55338, (DWORD)10);
		SetDword(0x004D597B, (DWORD)&MainTickCount);
		SetDword(0x004DA289, (DWORD)&MainTickCount);
		SetDword(0x004DA297, (DWORD)&MainTickCount);
		SetDword(0x004DA3A2, (DWORD)&MainTickCount);
		SetDword(0x004DA3CE, (DWORD)&MainTickCount);
		SetDword(0x004DA3D9, (DWORD)&MainTickCount);
		SetDword(0x0063D326, (DWORD)&MainTickCount);
		SetDword(0x00642112, (DWORD)&MainTickCount);*/

		//SetCompleteHook(0xE9, 0x004DA280, &CheckTickCount1);

		SetCompleteHook(0xE9, 0x004DA3A1, &CheckTickCount2);
		SetCompleteHook(0xE8, 0x005BAFAB, &CRenderBoolean);
	}

	if (gLoadFiles.m_LoadFiles.m_SiegeSkillAllMaps == 1) {
		SetByte((0x005B89C3 + 3), 0x00);
		SetByte((0x005B89C9 + 3), 0x00);
		SetByte((0x005B89CF + 3), 0x00);
		SetByte((0x005B89D5 + 3), 0x00);
		SetByte((0x005B89DB + 3), 0x00);
		SetByte((0x005B89E1 + 3), 0x00);
		SetWord((0x005B89E7 + 3), 0x00);
		SetByte((0x005C6314 + 2), 0x00);
		SetByte((0x005C6327 + 2), 0x00);
		SetByte((0x005C633A + 2), 0x00);
		SetByte((0x005C634D + 2), 0x00);
		SetByte((0x005C6360 + 2), 0x00);
		SetByte((0x005C6373 + 2), 0x00);
		SetWord((0x005C6386 + 2), 0x00);
	}

	gHealthBar.Init();

	gCustomMap.Init();

	VirtualizeOffset(0x004D9D39, 12);

	VirtualizeOffset(0x004D9D45, 7);

	VirtualizeOffset(0x004D9EFC, 15);

	VirtualizeOffset(0x004DAC5C, 8);

	VirtualizeOffset(0x005451F7, 5);

	VirtualizeOffset(0x00545230, 8);

	VirtualizeOffset(0x005A52E9, 8);

	LoadReferenceAddressTable((HMODULE)hins, MAKEINTRESOURCE(IDR_BIN1), (DWORD)&NewAddressData1);

	LoadReferenceAddressTable((HMODULE)hins, MAKEINTRESOURCE(IDR_BIN2), (DWORD)&NewAddressData2);

	LoadReferenceAddressTable((HMODULE)hins, MAKEINTRESOURCE(IDR_BIN3), (DWORD)&NewAddressData3);

	gCustomMessage.Init();

	if (gLoadFiles.ReadCustomJewels("Data//Files//CustomJewel.LORD-GAMING") == 0)
	{
		//gAntiHack.CloseApp();
		return;
	}

	if (gLoadFiles.m_LoadFiles.m_Minimizer) {
		gTrayMode.Load();
	}

	//InitVBA();


	gCustomJewel.Load(gLoadFiles.m_CustomJewel.CustomJewelInfo);

	gCustomWing.Init();

	gCustomItem.Init();

	gMakePreview.Init();

	gCustomEffects.Init();

	InitCustomNameColor();

	gPacketManager.LoadEncryptionKey("Data\\Enc1.dat");

	gPacketManager.LoadDecryptionKey("Data\\Dec2.dat");

	gRenderObject.Init();

	gAntiHack.Init();

	InitCommon();

	gInterface.lastReport = GetTickCount();


	InitItem();

	//gTextColor.Load();

	InitJewel();

	InitPrintPlayer();

	InitReconnect();

	InitResolution();

	InitWing();


	g_ShowInventoryGX.Init();

	gCharacterList.Init();

	gLoadImages.Init();

	gInterface.Init();

	gHelperSystem.Init();

	gMenuWindow.Init();

	gDescriptions.Init();

	gTradeX.Init();

	gChaosBoxGenesis.Init();

	gCustomMonster.Init();

	gCustomBow.Init();

	gCustomItemPosition.Init();

	gCustomItemSize.Init();

	//gCustomItemFloor.Init();

	//InitChatWindow();

	gMuHelper.Init();

	gMuHelperInterface.Init();

	gRenderModel.Init();

	gCounterItem.Init();

	gCCustomSetEffect.Init();

	gPatente.Init();

	//gCustomClaws.Init();

	gCustomItemValue.Init();

	if (gLoadFiles.m_LoadFiles.m_CustomPersonalShop == 1) {
		gPersonalShop.Init();
	}

	//gCustomItemForce.Init();

	gCustomServerName.Init();

	gMessageColor.Init();

	gGraphic.Init();

	gCustomJewelStack.Init();

	gElementSlots.Init();

	gVisualInventory.Init();

	AutoLogin.Load();

	gDisableExcellent.Init();

	gCustomMonsterName.Init();

	gDarkSpirit.Init();

	gCreateFont.Init();

	gCharacterLevel.Init();

	gCustomMonsterEffect.Init();

	gCustomMonsterGlow.Init();

	if (gLoadFiles.m_LoadFiles.m_ItemToolTipDrop == 1) {
		gRenderItem.Init();
	}

	gCustomSkillEffect.Init();


#if(DOWNGRADE)
	CSceneS0(); 
	InterfaceRemakeLoad();
	gObjUser.Load();
	gCChatClassic.Load();
	gChatExpanded.Load();
	gChatExpanded.Switch();
	RemakeLoginLoad();
#endif

	//gWideScreen.Init();

}

int StartMyMain() {
	((void(*)())0x004CF4D0)();

	StartMain();
	return 1;
}


void InitHook() {
	static bool initialized = false;

	if (!initialized) {
		initialized = true;

		SetByte(0x004D1E33, 0xEB);
		SetByte(0x004D1E69, 0xEB);

		SetCompleteHook(0xE8, 0x004D2103, &StartMyMain);


		//Change limit models
		SetByte(0x004CFA8C + 3, 0x5B);
		SetByte(0x004CFA8C + 4, 0x2F);
		
		SetByte(0x0060D982 + 3, 0x5B);
		SetByte(0x0060D982 + 4, 0x2F);
		
		SetByte(0x0060F353 + 3, 0x5B);
		SetByte(0x0060F353 + 4, 0x2F);
		
		SetByte(0x006103EB + 3, 0x5B);
		SetByte(0x006103EB + 4, 0x2F);
		
		SetByte(0x00969C5D + 3, 0x5B);
		SetByte(0x00969C5D + 4, 0x2F);
		
		//Push limit array
		SetByte(0x005CF1D1 + 1, 0x5C);
		SetByte(0x005CF1D1 + 2, 0x2F);
		
		SetByte(0x006103FC + 1, 0x5C);
		SetByte(0x006103FC + 2, 0x2F);
		
		//limit array
		SetByte(0x00969B3E + 1, 0x70);
		SetByte(0x00969B3E + 2, 0x28);
		SetByte(0x00969B3E + 3, 0x34);
		
		SetByte(0x00969B5E + 2, 0x5B);
		SetByte(0x00969B5E + 3, 0x33);
		
		SetByte(0x00969B6E + 1, 0x5B);
		SetByte(0x00969B6E + 2, 0x33);
		
		SetByte(0x00969BAC + 1, 0x6C);
		SetByte(0x00969BAC + 2, 0x28);
		SetByte(0x00969BAC + 3, 0x34);


		//nt MAX_MODELS = 10951;
		//nt size_BMD = (MAX_MODELS + 1024) * 260;
		//etDword(0x004CFA8C + 3, MAX_MODELS);
		//etDword(0x0060D982 + 3, MAX_MODELS);
		//etDword(0x0060F353 + 3, MAX_MODELS);
		//etDword(0x006103EB + 3, MAX_MODELS);
		//etDword(0x00969C5D + 3, MAX_MODELS);
		//etDword(0x00969B3E + 1, (size_BMD + 4));
		//etDword(0x00969B5E + 2, (MAX_MODELS + 1024));
		//etDword(0x00969B6E + 1, (MAX_MODELS + 1024));
		//etDword(0x00969BAC + 1, size_BMD);
	}
}



extern "C" _declspec(dllexport) void  EntryProc() {
	StartMain();
}

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) // OK
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		InitHook();
		gHotKey.InitKeyBoard((HINSTANCE)hModule);
		hins = (HINSTANCE)hModule;
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)StartAddress, 0, 0, 0);
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)CheckMacroThread, 0, 0, 0);

		break;
	case DLL_PROCESS_DETACH:
		g_Running = false;
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	}

	return 1;
}