#include "StdAfx.h"
#include "Util.h"
#include "ShowInfoItemDrop.h"
#include "Interface.h"
#include "WindowTray.h"


ShowInventoryGX g_ShowInventoryGX;

ShowInventoryGX::ShowInventoryGX(void)
{
}

ShowInventoryGX::~ShowInventoryGX(void)
{
}

void CreateItemTooltip(int item_t)
{
    int itemshow = (int)(item_t + 2);
    POINT RenderPos;

    int sx = pCursorX - 15;
    int sy = pCursorY;
    char* item = new char[0x6Bu];
    memcpy(item, (const void*)itemshow, 0x6Bu);

    if (*(WORD*)itemshow < 7168)
    {
        SetItemAttrInt((int)item, *(BYTE*)(itemshow + 2), *(BYTE*)(itemshow + 23), *(BYTE*)(itemshow + 24));
        RenderItemInfo(GetUI3D(GetInstance()), sx, sy, (int)item, 0, 0, false);
    }
}


void ShowInventoryGX::RenderItemName(int This, int Index, int o, int ItemLevel, int ItemOption, int ItemExtOption, bool Sort)
{
    Render_ItemName(This, Index, o, ItemLevel, ItemOption, ItemExtOption, Sort);
    CreateItemTooltip((int)&*(LPVOID*)0x81F6C00 + 848 * Index);
}

void ShowInventoryGX::Init()
{
    SetCompleteHook(0xE8, 0x00842AC7, &ShowInventoryGX::RenderItemName);
}
