#pragma once

#include "Lua.h"

struct CUSTOM_ITEM_POSITION_INFO {
	int ItemIndex;
	float PosX;
	float PosY;
	float AngleX;
	float AngleY;
	float AngleZ;
};

class CCustomItemPosition {
public:
	CCustomItemPosition();
	~CCustomItemPosition();
	void RestartLua();

	bool CheckCustomItemPosition(int ItemIndex);
	CUSTOM_ITEM_POSITION_INFO * getItemPosition(int ItemIndex);
	void Init();

private:
	Lua m_Lua;

public:
	std::map<int, CUSTOM_ITEM_POSITION_INFO> m_CustomItemPositionInfo;
};

extern CCustomItemPosition gCustomItemPosition;