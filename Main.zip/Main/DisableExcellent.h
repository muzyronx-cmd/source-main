#pragma once

#include "Lua.h"

struct DISABLE_EXCELLENT_INFO {
	int ItemIndex;
};

class DisableExcellent {
public:
	DisableExcellent();
	~DisableExcellent();

	void RestartLua();
	void Init();
	bool CanDisableExcellent(int ItemIndex);
	static void DisableExcellentFunc();

public:
	std::map<int, DISABLE_EXCELLENT_INFO> m_DisableExcellent;
	Lua m_Lua;
};

extern DisableExcellent gDisableExcellent;