#include "stdafx.h"
#include "ItemTooltip.h"
#include "Util.h"
#include "Common.h"
#include "Offset.h"

nCInfo GInfo;


nCInfo::nCInfo()
{
	this->m_CustomInfo.clear();
	this->m_CustomDescripcionInfo.clear();
}

nCInfo::~nCInfo()
{
}



void nCInfo::loadnInformation(nInformation * info) // OK
{
	for (int n = 0; n < MaxLine; n++)
	{
		if ( info[n].ItemIndex < 0 || info[n].ItemIndex > 7680)
		{
			return;
		}
		this->m_CustomInfo.insert(std::pair<int, nInformation>(info[n].ItemIndex,info[n]));
	}
}

void nCInfo::loadnText(nText * info) // OK
{
	for (int n = 0; n < MaxLine; n++)
	{
		if ( info[n].Index < 0 || info[n].Index > 7680)
		{
			return;
		}
		this->m_CustomDescripcionInfo.insert(std::pair<int, nText>(info[n].Index,info[n]));
	}
}


char * nGetTextLine(int TextIndex)
{
	std::map<int, nText>::iterator it = GInfo.m_CustomDescripcionInfo.find( TextIndex );

	if(it !=  GInfo.m_CustomDescripcionInfo.end())
	{
		return it->second.Text;
	}

	return "no found";
}

int nCInfo::nInformationOP(int CurrenLine, int ItemSearch)
{
	std::map<int, nInformation>::iterator it = GInfo.m_CustomInfo.find( ItemSearch );

	if(it !=  GInfo.m_CustomInfo.end())
	{
		tooltiparray * TooltipLine = (tooltiparray*)NewAddressData3;
		int * ColorTexto = (int*)NewAddressData1;
		int * LineWeight = (int*)NewAddressData2;

		wsprintf(TooltipLine[ CurrenLine ], it->second.OptionName);
		ColorTexto[ CurrenLine ] = it->second.OptionColor;
		LineWeight[ CurrenLine++ ] = 1;

		wsprintf(TooltipLine[CurrenLine++], "\n");

		for( int i = 0 ; i < 15 ; i++ )
		{
			if( it->second.TextIndex[ i ] == -1) { continue; }
			wsprintf(TooltipLine[ CurrenLine ], "%s", nGetTextLine( it->second.TextIndex[ i ] ));
			ColorTexto[ CurrenLine ] = it->second.TextColor[ i ];
			LineWeight[ CurrenLine++ ] = 0;
		}
	}

	return CurrenLine;
}

void Borde(float PosX, float PosY, float Width, float Height, float Arg5, int Arg6)
{
	glColor4f(0.0, 0.0, 0.0, 0.80000001);

	pDrawBarForm(PosX, PosY, Width, Height, Arg5, Arg6); //central
	glEnable(0xDE1u);

	glColor4f(0.0, 0.0, 0.0, 1.00000001);

	pDrawBarForm(PosX, PosY, 2, Height, Arg5, Arg6); //central

	pDrawBarForm(PosX + Width - 2, PosY, 2, Height, Arg5, Arg6); //central

	pDrawBarForm(PosX, PosY, Width, 2, Arg5, Arg6); //central

	pDrawBarForm(PosX, PosY + Height - 2, Width, 2, Arg5, Arg6); //central
	glEnable(0xDE1u);
}
