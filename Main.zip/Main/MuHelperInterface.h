#pragma once
// ---------------------------------------------------------------------------------------------
#define MUHELPER_STRUC		0x00E8CB7C
#define World								*(int*)0x00E61E18
#define PlayBuffer			((signed int(__cdecl*)(int a1, int a2, int a3)) 0x006D6C20)

// ---------------------------------------------------------------------------------------------

class CMuHelperInterface
{
public:
	void Init();
	//static void		LoadImages();
	static void		RenderFrame(int *This);
	static void		RenderHelperFrame(int *This);
	void			Button(DWORD Event);
	void UpdateMouseEvent();
public:
	float m_PosX;
	float m_PosY;
};
extern CMuHelperInterface gMuHelperInterface;
// ---------------------------------------------------------------------------------------------