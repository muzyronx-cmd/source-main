#pragma once

class CCharacterLevel {
public:
	CCharacterLevel();
	~CCharacterLevel();

	void Init();
};

extern CCharacterLevel gCharacterLevel;