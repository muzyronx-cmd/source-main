#pragma once

#include "Lua.h"

class LuaInterface {
public:
	LuaInterface();
	~LuaInterface();

	void RegisterInterface(lua_State * Lua);
};