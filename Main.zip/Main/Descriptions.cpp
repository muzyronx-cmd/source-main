#include "stdafx.h"
#include "Descriptions.h"
#include "Util.h"
#include "LuaStack.hpp"
#include "LuaUser.h"
#include "LuaItemObject.h"
#include "CustomJewelStack.h"
#include "Console.h"

arraytooltip * textLine = (arraytooltip*)NewAddressData3;
int * textColor = (int*)NewAddressData1;
int * textBold = (int*)NewAddressData2;

using namespace luaaa;

CDescriptions gDescriptions;

CDescriptions::CDescriptions() : m_Lua(false)
{

}

CDescriptions::~CDescriptions()
{

}

int DescriptionsCall(DWORD Line, DWORD itemObject) {
	if (itemObject == 0) {
		return Line;
	}

	gCustomJewelStack.RenderDescriptionStack(&Line, *(WORD*)(itemObject), *(BYTE*)(itemObject + 22));

	gDescriptions.m_Lua.Generic_Call("SetDescriptions", "iij>i", Line, *(WORD*)(itemObject), itemObject, &Line);
	return Line;
}

__declspec(naked) void SetDescriptionsItem() {
	static DWORD m_EaxOriginal = 0;
	static DWORD m_EbxOriginal = 0;
	static DWORD m_ExitFunc = 0x007E5C71;
	static DWORD m_HookFunc = 0x007E5AF9;

	_asm {
		MOV m_EaxOriginal, EAX;
		MOV m_EbxOriginal, EBX;
		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		PUSH ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x74];
		PUSH EAX;
		CALL[DescriptionsCall];
		MOV DWORD PTR SS : [EBP - 0x74], EAX;
		ADD ESP, 0x8;
		CMP DWORD PTR SS : [EBP + 0x1C], 0x0;
		JNZ EXIT;

		MOV EAX, m_EaxOriginal;
		MOV EBX, m_EbxOriginal;
		JMP[m_HookFunc];

	EXIT:
		MOV EAX, m_EaxOriginal;
		MOV EBX, m_EbxOriginal;
		JMP[m_ExitFunc];
	}
}

void CreateDescription(int Line, char* text, int color, int bold) {
	memcpy(textLine[Line], text, 100);
	textColor[Line] = color;
	textBold[Line] = bold;
}

int SetNewColorDescription(int colorID) {
	int retorno = 0;

	gDescriptions.m_Lua.Generic_Call("SetNewColorDescription", "i>i", colorID, &retorno);

	return retorno;
}

__declspec(naked) void AddNewColorsDescription() {

	static DWORD m_IndexColor = 0;
	static DWORD m_ReturnFunc = 0x005BFDE1;
	static DWORD m_HookFunc = 0x005BFF75;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x94]
		MOV m_IndexColor, ECX;
	}

	if (SetNewColorDescription(m_IndexColor) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP - 0x94], 0x0D;
			JMP[m_ReturnFunc];
		}
	}
}

int SetNewColorBackGroundDescription(int colorID) {
	int retorno = 0;

	gDescriptions.m_Lua.Generic_Call("SetNewColorBackGroundDescription", "i>i", colorID, &retorno);

	return retorno;
}

__declspec(naked) void AddNewColorsBackGroundDescription() {

	static DWORD m_IndexColor = 0;
	static DWORD m_ReturnFunc = 0x005BFF80;
	static DWORD m_HookFunc = 0x005C0044;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0x40]
		MOV EAX, DWORD PTR DS : [EDX * 0x4 + NewAddressData1]
		MOV m_IndexColor, EAX;
	}

	if (SetNewColorBackGroundDescription(m_IndexColor) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP - 0x40];
			CMP DWORD PTR DS : [EDX * 0x4 + NewAddressData1], 0x5;
			JMP[m_ReturnFunc];
		}
	}
}

void setColor3f(float r, float g, float b) {
	glColor3f(r, g, b);
}

void setFontBg(int r, int g, int b, int a) {
	pSetTextBgColor(pTextThis(), r, g, b, a);
}

void setFontColor(int r, int g, int b, int a) {
	pSetTextColor(pTextThis(), r, g, b, a);
}

__declspec(naked) void ItemTooltipRender()
{
	static DWORD Addr = 0x007E5CB6;
	static DWORD Addr_Exc = 0;
	static DWORD Addr_Acc = 0;

	_asm
	{

		MOV ECX, DWORD PTR SS : [EBP + 0x10]
		MOVZX EAX, BYTE PTR DS : [ECX + 0x17]
		MOV Addr_Exc, EAX
		MOVZX EDX, BYTE PTR DS : [ECX + 0x18]
		MOV Addr_Acc, EDX

	}

	if (Addr_Exc >= 1 && Addr_Acc >= 1)
	{
		_asm
		{
			PUSH 1; / Arg7 = 00000001
			PUSH 0; | Arg6 = 00000000
			PUSH 3; | Arg5 = 00000003
			PUSH 0; | Arg4 = 00000000
			MOV EAX, DWORD PTR SS : [EBP - 0x74] ; |
			PUSH EAX; | Arg3
			MOV ECX, DWORD PTR SS : [EBP + 0xC] ; |
			//ADD ECX, 120
			PUSH 0x5; | Arg2
			MOV EDX, DWORD PTR SS : [EBP + 0x8] ; |
			PUSH EDX; | Arg1
			JMP[Addr]
		}
	}
	else
	{
		_asm
		{
			PUSH 1; / Arg7 = 00000001
			PUSH 0; | Arg6 = 00000000
			PUSH 3; | Arg5 = 00000003
			PUSH 0; | Arg4 = 00000000
			MOV EAX, DWORD PTR SS : [EBP - 0x74] ; |
			PUSH EAX; | Arg3
			MOV ECX, DWORD PTR SS : [EBP + 0xC] ; |
			PUSH ECX; | Arg2
			MOV EDX, DWORD PTR SS : [EBP + 0x8] ; |
			PUSH EDX; | Arg1
			JMP[Addr]
		}
	}
}


void CDescriptions::Init()
{

	RegisterLuaItemObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("createDescription", &CreateDescription);

	LuaModule(this->m_Lua.GetState()).fun("glColor3f", &setColor3f);

	LuaModule(this->m_Lua.GetState()).fun("setFontBg", &setFontBg);

	LuaModule(this->m_Lua.GetState()).fun("setFontColor", &setFontColor);

	this->m_LuaUser.RegisterLuaUser(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//Descriptions.lua");

	SetCompleteHook(0xE9, 0x007E5AEF, &SetDescriptionsItem);

	SetCompleteHook(0xE9, 0x005BFDDA, &AddNewColorsDescription);

	SetCompleteHook(0xE9, 0x005BFF78, &AddNewColorsBackGroundDescription);

	SetCompleteHook(0xE9, 0x007E5CA2, &ItemTooltipRender);

}


void CDescriptions::RestartLua()
{
	this->m_Lua.CloseLua();

	this->m_Lua.RegisterLua();

	RegisterLuaItemObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("createDescription", &CreateDescription);

	LuaModule(this->m_Lua.GetState()).fun("glColor3f", &setColor3f);

	LuaModule(this->m_Lua.GetState()).fun("setFontBg", &setFontBg);

	LuaModule(this->m_Lua.GetState()).fun("setFontColor", &setFontColor);

	this->m_LuaUser.RegisterLuaUser(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//Descriptions.lua");
}