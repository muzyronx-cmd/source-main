#include "stdafx.h"
#include "CustomSkillEffect.h"
#include "Util.h"

CCustomSkillEffect gCustomSkillEffect;

CCustomSkillEffect::CCustomSkillEffect() : m_Lua(false)
{
}

CCustomSkillEffect::~CCustomSkillEffect()
{
}

BYTE * EffectStarStruct = (BYTE*)0x87C5708;

void CreateEffectStarMain(int Type, vec3_t Position, vec3_t Position2, vec3_t Angle, int Frequence, ObjectModel * Owner, float Scale, int SubType, int Effect1, int Effect2, vec3_t Color, int Timer)
{
	DWORD Struct;
	int i;

	for (i = 0; ; ++i)
	{
		if (i >= 500)
		{
			return;
		}

		Struct = (DWORD)&EffectStarStruct[2584 * i];

		if (!EffectStarStruct[2584 * i])
		{
			break;
		}
	}

	*(BYTE *)Struct = 1;
	*(DWORD *)(Struct + 4) = Type;
	*(DWORD *)(Struct + 8) = Type;
	*(DWORD *)(Struct + 12) = Frequence;
	*(BYTE *)(Struct + 16) = 1;
	*(BYTE *)(Struct + 17) = 3;

	*(BYTE *)(Struct + 2516) = 0;
	*(WORD *)(Struct + 2536) = SubType;
	*(WORD *)(Struct + 2538) = Effect1;
	*(float *)(Struct + 2520) = 0.0f;
	*(DWORD *)(Struct + 84) = 0;
	*(BYTE *)(Struct + 2550) = 1;
	*(BYTE *)(Struct + 100) = 0;
	*(BYTE *)(Struct + 2548) = 0;

	*(BYTE *)(Struct + 2549) = 0;
	*(BYTE *)(Struct + 2572) = Effect2;
	*(WORD *)(Struct + 2580) = -1;

	*(float *)(Struct + 24) = Position[0];
	*(float *)(Struct + 28) = Position[1];
	*(float *)(Struct + 32) = Position[2];

	*(float *)(Struct + 48) = Angle[0];
	*(float *)(Struct + 52) = Angle[1];
	*(float *)(Struct + 56) = Angle[2];

	*(float *)(Struct + 72) = Color[0];
	*(float *)(Struct + 76) = Color[1];
	*(float *)(Struct + 80) = Color[2];

	*(float *)(Struct + 2524) = 0.0;
	*(float *)(Struct + 2528) = 0.0;
	*(float *)(Struct + 2532) = 0.0;

	if (Owner)
	{
		if (Type != 322 || Frequence != 2)
		{
			*(DWORD *)(Struct + 84) = (DWORD)Owner;
		}
		else
		{
			*(float *)(Struct + 88) = Position2[0];
			*(float *)(Struct + 92) = Position2[1];
			*(float *)(Struct + 96) = Position2[2];

			*(DWORD *)(Struct + 84) = (DWORD)Owner;
		}
	}
	else
	{
		*(float *)(Struct + 88) = Position2[0];
		*(float *)(Struct + 92) = Position2[1];
		*(float *)(Struct + 96) = Position2[2];
	}

	*(DWORD *)(Struct + 104) = 0;

	switch (Type)
	{
	case 322:
		*(float *)(Struct + 88) = *(float *)(*(DWORD *)(Struct + 84) + 252);
		*(float *)(Struct + 92) = *(float *)(*(DWORD *)(Struct + 84) + 256);
		*(float *)(Struct + 96) = *(float *)(*(DWORD *)(Struct + 84) + 260);

		switch (Frequence)
		{
		case 2:
			*(float *)(Struct + 88) = Position2[0];
			*(float *)(Struct + 92) = Position2[1];
			*(float *)(Struct + 96) = Position2[2];
			/**(float *)(Struct + 72) = 1.0;
			*(float *)(Struct + 76) = 0.30000001;
			*(float *)(Struct + 80) = 0.30000001;*/
			*(DWORD *)(Struct + 2512) = 20;
			*(DWORD *)(Struct + 108) = 5;
			*(DWORD *)(Struct + 8) = *(DWORD *)(*(DWORD *)(Struct + 84) + 52);
			break;
		}

		*(float *)(Struct + 20) = Scale;
		break;
	}

	if (*(DWORD *)(Struct + 108) > 50)
	{
		*(DWORD *)(Struct + 108) = 50;
	}
}


void RenderDeathStab(ObjectPreview* character, ObjectModel* object) {
	DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), object->Type);

	if (model == 0) {
		return;
	}

	int Hand = ((int(*)(ObjectModel*))0x556BD0)(object);

	if (*(BYTE *)(*(DWORD *)(model + 44) + 140 * character->gap17[36 * Hand] + 34) || character->gap17[36 * Hand] > *(signed __int16 *)(model + 34))
	{
		return;
	}

	if (character->AttackTime == 8 && *(DWORD*)0xE609E8 != 2) {
		((void(*)(DWORD, ObjectModel*, DWORD))0x6D6C20)(113, 0, 0);
	}

	// DEATH STAB SKILL
	switch (((*(BYTE*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x0B)) & 7))
	{
	case 1:
		SetDword(0x0059C6FD + 1, 0);
		break;
	case 0:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
		SetDword(0x0059C6FD + 1, 300);
		break;
	}

	vec3_t Position, NewPosition;
	Vector(0.f, 0.f, 0.f, Position);

	vec3_t np, NwPosition;
	Vector(0.f, 0.f, 0.f, np);

	vec3_t Color;
	Vector(0.f, 0.f, 0.f, Color);

	if (character->AttackTime >= 2 && character->AttackTime <= 8)
	{
		for (int i = 0; i < 3; i++)
		{
			Position[0] = object->Position[0];
			Position[1] = object->Position[1];
			Position[2] = object->Position[2] + 120.0f;

			NewPosition[0] = (float)(rand() % (2 * 300 + 1) - 300) + Position[0];
			NewPosition[1] = (float)(rand() % (2 * 300 + 1) - 300) + Position[1];
			NewPosition[2] = (float)(rand() % (2 * 300 + 1) - 300) + Position[2];


			NewPosition[0] = NewPosition[0] - sin(object->Angle[2] * 0.017453292f) * 1400.0f;
			NewPosition[1] = cos(object->Angle[2] * 0.017453292f) * 1400.0f + NewPosition[1];

			Vector(1.00f, 1.00f, 1.00f, Color);

			object->SubType = 0;

			if (character->PetSlot != -1) {
				int Effect = 0;
				float R = 0.0;
				float G = 0.0;
				float B = 0.0;

				gCustomSkillEffect.m_Lua.Generic_Call("DeathStabEffect", "i>ifff", character->PetSlot, &Effect, &R, &G, &B);

				Vector(R, G, B, Color);

				object->SubType = Effect;
			}

			if (object->SubType != 0) {
				CreateEffectStarMain(322, Position, NewPosition, object->Angle, 2, object, 40.0, -1, 0, 0, Color, 0);
			}
			else {
				((void(*)(int32_t, vec3_t, vec3_t, vec3_t, int32_t, ObjectModel*, float_t, int16_t,
					WORD, WORD, int32_t, const float_t*, int16_t))0x72D1B0)(322, Position, NewPosition, object->Angle, 2, object, 40.0, -1, 0, 0, -1, Color, 0);
			}
		}
	}

	if (character->AttackTime <= 8)
	{
		vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(ObjectModel*, int))0x4CD7F0)(object, character->gap17[36 * Hand]);

		if (BoneTransform == 0) {
			return;
		}

		((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)model, BoneTransform[0], np, object->m_vPosSword, 1);

		object->m_vPosSword[0] = sin(object->Angle[2] * 0.017453292f) * 300.0f + object->m_vPosSword[0];
		object->m_vPosSword[1] = object->m_vPosSword[1] - cos(object->Angle[2] * 0.017453292f) * 300.0f;
	}

	if (character->AttackTime >= 6 && character->AttackTime <= 12)
	{
		vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(ObjectModel*, int))0x4CD7F0)(object, character->gap17[36 * Hand]);

		if (BoneTransform == 0) {
			return;
		}

		((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)model, BoneTransform[0], np, NwPosition, 1);

		Position[0] = 1.0f;
		Position[1] = 1.0f;
		Position[2] = 1.0f;

		NwPosition[2] = (float)(character->AttackTime - 8) * 10.0f + 100.0f;
		NwPosition[0] = sin(object->Angle[2] * 3.141592741012573 / 180.0f) * NwPosition[2] + NwPosition[0];
		NwPosition[1] = cos(object->Angle[2] * 3.141592741012573 / 180.0f) * -NwPosition[2] + NwPosition[1];

		((void(*)(int, vec3_t, vec3_t,
			vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
			float, int))0x6D9070)(2707, NwPosition, object->Angle, Position, 1, object, -1, 0, 0, 0.0, 0.0, -1);
		((void(*)(int, vec3_t, vec3_t,
			vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
			float, int))0x6D9070)(2707, NwPosition, object->Angle, Position, 1, object, -1, 0, 0, 0.0, 0.0, -1);

		if (character->TargetCharacter != -1)
		{
			DWORD PreviewStruct = ((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), character->TargetCharacter);

			if (PreviewStruct) {
				DWORD structObj = PreviewStruct + 776;

				if (character->AttackTime >= 10)
				{
					if (*(BYTE *)(structObj + 4)) {
						*(BYTE *)(structObj + 29) = 35;
					}
				}
			}
		}
	}

	if (character->AttackTime >= 12)
	{
		character->AttackTime = 15;
	}
}

__declspec(naked) void HookDeathStabEffect() {
	static DWORD m_HookOut = 0x00558395;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		PUSH ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		PUSH ECX;
		CALL[RenderDeathStab];
		ADD ESP, 0x08;
		JMP[m_HookOut];
	}
}

void CCustomSkillEffect::Init()
{
	MemorySet(0x00556CC6, 0x90, 6);
	SetCompleteHook(0xE9, 0x00556CC6, &HookDeathStabEffect);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//SkillCroma.lua");

	this->LuaLoadImage.SetFunctions(this->m_Lua.GetState());
}

void CCustomSkillEffect::RestartLua()
{
	MemorySet(0x00556CC6, 0x90, 6);
	SetCompleteHook(0xE9, 0x00556CC6, &HookDeathStabEffect);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//SkillCroma.lua");

	this->LuaLoadImage.SetFunctions(this->m_Lua.GetState());
}
