#include "stdafx.h"
#include "Common.h"
#include "Offset.h"
#include "LoadFiles.h"
#include "Util.h"

BYTE GensBattleMapCount = 0;
BYTE GensMoveIndexCount = 0;
BYTE GensBattleMap[120];
BYTE GensMoveIndex[120];

void MessageBitmapFail(char* buff) {
	MessageBox(MAIN_WINDOW, buff, "MainError", MB_OK);
}

__declspec(naked) void BitmapFailed() {
	static DWORD m_ReturnFunc = 0x0077245F;

	_asm {
		LEA EAX, DWORD PTR SS : [EBP - 0x20C];
		PUSH EAX;
		CALL[MessageBitmapFail];
		LEA EAX, DWORD PTR SS : [EBP - 0x20C];
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void BitmapFailedFromTexture() {
	static DWORD m_ReturnFunc = 0x00614AEE;

	_asm {
		LEA ECX, DWORD PTR SS : [EBP - 0x324]
		PUSH ECX;
		CALL[MessageBitmapFail];
		LEA ECX, DWORD PTR SS : [EBP - 0x324]
		JMP[m_ReturnFunc];
	}
}

int GetActiveSkill()
{
	lpCharObj lpPlayer = &*(ObjectCharacter*)*(int*)(MAIN_CHARACTER_STRUCT);
	lpViewObj lpViewPlayer = &*(ObjectPreview*)*(int*)(MAIN_VIEWPORT_STRUCT);
	return lpPlayer->pMagicList[lpViewPlayer->ActiveMagic];
}

void SetCharacterSpeed() {
	auto hero = &*(ObjectCharacter*)oUserObjectStruct;
	BYTE Class = GetBaseClass(hero->Class);
	int Divide = 1;

	if (Class == CLASS_WIZARD) {
		Divide = gLoadFiles.m_LoadFiles.DWAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.DWAnimationSpeed;
	}
	else if (Class == CLASS_KNIGHT) {
		Divide = gLoadFiles.m_LoadFiles.DKAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.DKAnimationSpeed;
	}
	else if (Class == CLASS_ELF) {
		Divide = gLoadFiles.m_LoadFiles.FEAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.FEAnimationSpeed;
	}
	else if (Class == CLASS_DARK) {
		Divide = gLoadFiles.m_LoadFiles.MGAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.MGAnimationSpeed;
	}
	else if (Class == CLASS_DARK_LORD) {
		Divide = gLoadFiles.m_LoadFiles.DLAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.DLAnimationSpeed;
	}
	else if (Class == CLASS_SUMMONER) {
		Divide = gLoadFiles.m_LoadFiles.SUAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.SUAnimationSpeed;
	}
	else if (Class == CLASS_RAGEFIGHTER) {
		Divide = gLoadFiles.m_LoadFiles.RFAnimationSpeed <= 0 ? 1 : gLoadFiles.m_LoadFiles.RFAnimationSpeed;
	}

	*(WORD *)(oUserObjectStruct + 84) = *(WORD *)(oUserObjectStruct + 84) / Divide;
	*(WORD *)(oUserObjectStruct + 96) = *(WORD *)(oUserObjectStruct + 96) / Divide;

	WORD AttackSpeed = *(WORD *)(oUserObjectStruct + 84);
	WORD MagicSpeed = *(WORD *)(oUserObjectStruct + 96);

	int MagicAttack = GetActiveSkill();

	if (Class == CLASS_WIZARD) {
		if (MagicAttack == 9 ||
			MagicAttack == 8 ||
			MagicAttack == 13 ||
			MagicAttack == 38 ||
			MagicAttack == 39 ||
			MagicAttack == 5)
		{
			if (MagicSpeed > 450 && MagicSpeed < 480)
			{
				MagicSpeed = 450;
			}
			else if (MagicSpeed > 600 && MagicSpeed < 690)
			{
				MagicSpeed = 600;
			}
			else if (MagicSpeed > 850 && MagicSpeed < 1105)
			{
				MagicSpeed = 850;
			}
			else if (MagicSpeed > 1350 && MagicSpeed < 2355)
			{
				MagicSpeed = 1350;
			}
			else if (MagicSpeed > 2850)
			{
				MagicSpeed = 2850;
			}
		}
		else if (MagicAttack == 14)
		{
			if (MagicSpeed > 3276)
			{
				MagicSpeed = 3276;
			}
		}
	}
	else if (Class == CLASS_KNIGHT) {
		
	}
	else if (Class == CLASS_ELF) {
		if (MagicAttack == 52 ||
			MagicAttack == 51 ||
			MagicAttack == 424 ||
			MagicAttack == 416)
		{
			if (AttackSpeed > 400)
			{
				AttackSpeed = 400;
			}
		}

		if (MagicAttack == 24 ||
			MagicAttack == 414)
		{
			if (AttackSpeed > 600)
			{
				AttackSpeed = 600;
			}
		}
	}
	else if (Class == CLASS_DARK) {
		if (MagicAttack == 55 ||
			MagicAttack == 56 ||
			MagicAttack == 490)
		{
			if (AttackSpeed > 1368)
			{
				AttackSpeed = 1368;
			}
		}
		if (MagicAttack == 9 ||
			MagicAttack == 8 ||
			MagicAttack == 13 ||
			MagicAttack == 5)
		{
			if (MagicSpeed > 450 && MagicSpeed < 480)
			{
				MagicSpeed = 450;
			}
			else if (MagicSpeed > 600 && MagicSpeed < 690)
			{
				MagicSpeed = 600;
			}
			else if (MagicSpeed > 850 && MagicSpeed < 1105)
			{
				MagicSpeed = 850;
			}
			else if (MagicSpeed > 1350 && MagicSpeed < 2355)
			{
				MagicSpeed = 1350;
			}
			else if (MagicSpeed > 2850)
			{
				MagicSpeed = 2850;
			}
		}
		if (MagicAttack == 14)
		{
			if (MagicSpeed > 3276)
			{
				MagicSpeed = 3276;
			}
		}
	}
	else if (Class == CLASS_DARK_LORD) {
		if (MagicAttack == 78 ||
			MagicAttack == 238 ||
			MagicAttack == 518)
		{
			if (AttackSpeed > 249 && AttackSpeed < 264)
			{
				AttackSpeed = 249;
			}
			else if (AttackSpeed > 324 && AttackSpeed < 367)
			{
				AttackSpeed = 324;
			}
			else if (AttackSpeed > 449 && AttackSpeed < 575)
			{
				AttackSpeed = 449;
			}
			else if (AttackSpeed > 699 && AttackSpeed < 1200)
			{
				AttackSpeed = 699;
			}
			else if (AttackSpeed > 1449)
			{
				AttackSpeed = 1449;
			}
		}
	}
	else if (Class == CLASS_SUMMONER) {
		
	}
	else if (Class == CLASS_RAGEFIGHTER) {
		
	}

	*(WORD *)(oUserObjectStruct + 84) = AttackSpeed;
	*(WORD *)(oUserObjectStruct + 96) = MagicSpeed;

	((void(*)())0x5509C0)();
}

__declspec(naked) void DistancePushSkill() {
	static DWORD m_SkillIndex = 0;
	static DWORD m_ReturnFunc = 0x0059B4D2;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x14];
		MOV m_SkillIndex, EAX;
	}

	if (m_SkillIndex >= 19 && m_SkillIndex <= 23) {
		static float Distance = 1.5f;
		_asm {
			PUSH ECX;
			FLD DWORD PTR DS : [Distance];
			FSTP DWORD PTR SS : [EBP - 4];

			JMP[m_ReturnFunc];
		}
	}
	else {
		_asm {
			PUSH ECX;
			FLD DWORD PTR SS : [EBP - 4];
			FSTP DWORD PTR SS : [ESP];
			JMP[m_ReturnFunc];

		}
	}
}

__declspec(naked) void DisablePushSkill() {
	static DWORD m_SkillIndex = 0;
	static DWORD m_ReturnFunc = 0x0059CA46;
	static DWORD m_HookFunc = 0x0059CB07;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x1C];
		MOV m_SkillIndex, EAX;
	}

	if (m_SkillIndex == 0x2F || m_SkillIndex >= 19 && m_SkillIndex <= 23) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			JMP[m_ReturnFunc];
		}
	}
}

void InitCommon() // OK
{
	SetCompleteHook(0xE9, 0x0040B154, &LoginTab);

	SetCompleteHook(0xFF, 0x0064A79A, &CheckMasterLevel); // C1:16

	SetCompleteHook(0xFF, 0x0064A85F, &CheckMasterLevel); // C1:16

	SetCompleteHook(0xFF, 0x00656E03, &CheckMasterLevel); // C1:48

	SetCompleteHook(0xFF, 0x0064AB3D, &CheckMasterLevel); // C1:9C

	SetCompleteHook(0xFF, 0x0064AC02, &CheckMasterLevel); // C1:9C

	SetCompleteHook(0xFF, 0x0063DDF2, &CheckMasterLevel); // C1:F3:03

	SetCompleteHook(0xFF, 0x0063DF89, &CheckMasterLevel); // C1:F3:03

	SetCompleteHook(0xFF, 0x0063EA4C, &CheckMasterLevel); // C1:F3:04

	SetCompleteHook(0xFF, 0x0064CA0C, &CheckMasterLevel); // LevelUp

	SetCompleteHook(0xFF, 0x0077FAF9, &CheckMasterLevel); // Print Level

	SetCompleteHook(0xFF, 0x0081071B, &CheckMasterLevel); // Experience Bar

	SetCompleteHook(0xFF, 0x0081079B, &CheckMasterLevel); // Experience Bar

	SetCompleteHook(0xFF, 0x0047FE31, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x0059890D, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x0059A399, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x0059A93C, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x0059B13B, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x005A4261, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x005A4D52, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x005B6117, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x0065A6CE, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x00727987, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x007861F1, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x007D32FA, &CheckGensBattleMap);

	SetCompleteHook(0xFF, 0x007D3B0D, &CheckGensBattleMap);

	SetCompleteHook(0xE9, 0x008317BD, &CompareGensMoveIndex);

	SetCompleteHook(0xE9, 0x00772459, &BitmapFailed);

	SetCompleteHook(0xE9, 0x00614AE8, &BitmapFailedFromTexture);

	SetCompleteHook(0xE8, 0x0055179F, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00551911, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x0055272F, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x0059C2DE, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x0059D02E, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x0059E6A9, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AC570, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AD840, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005ADAE8, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005ADE42, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AE1D1, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AE870, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AEB93, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AF1CD, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005AF522, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B05E7, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B073E, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B0C23, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B0DA8, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B1898, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B22B3, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B2CB4, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x005B3870, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00616A1A, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x0063F4A7, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00645712, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00647503, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00647594, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00647BDC, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00749B83, &SetCharacterSpeed);
	SetCompleteHook(0xE8, 0x00749C03, &SetCharacterSpeed);

	//Fix cashshop - disabled to restore native CashShop
	//SetByte(0x008553D0, 0xC3);

	SetCompleteHook(0xE9, 0x005880F0, 0x0058811F); //Fix gm wing on Blood castle
	SetDword(0x00588444 + 3, 4095);

	//Release STAFF attack
	SetByte(0x0059A8D0, 0xEB);

	//Fix monster bug
	SetByte(0x0059B001, 0xEB);

	//Fix notice lines
	SetByte(0x00597691+4, 0x30);

	//MemorySet(0x0059B4CB, 0x90, 7);
	//SetCompleteHook(0xE9, 0x0059B4CB, &DistancePushSkill);

	if (gLoadFiles.m_LoadFiles.m_DisablePushSkills == 1) {
		MemorySet(0x0059CA3C, 0x90, 10);
		SetCompleteHook(0xE9, 0x0059CA3C, &DisablePushSkill);
	}
}

BOOL CheckGensBattleMap(int map) // OK
{
	for(int n=0;n < GensBattleMapCount;n++)
	{
		if(GensBattleMap[n] == map)
		{
			return 1;
		}
	}

	return 0;
}

BOOL CheckGensMoveIndex(int idx) // OK
{
	for(int n=0;n < GensMoveIndexCount;n++)
	{
		if(GensMoveIndex[n] == idx)
		{
			return 1;
		}
	}

	return 0;
}

__declspec(naked) void LoginTab() // OK
{
	static DWORD LoginTabAddress1 = 0x0040B16F;

	__asm
	{
		Push 0
		Mov Eax,Dword Ptr Ss:[Ebp-0x38]
		Mov Ecx,Dword Ptr Ds:[Eax+0x350]
		Mov Edx,Dword Ptr Ss:[Ebp-0x38]
		Mov Eax,Dword Ptr Ds:[Edx+0x350]
		Mov Edx,Dword Ptr Ds:[Eax]
		Call Dword Ptr Ds:[Edx+0x30]
		Mov Eax,Dword Ptr Ss:[Ebp-0x38]
		Mov Ecx,Dword Ptr Ds:[Eax+0x354]
		Push Ecx
		Mov Edx,Dword Ptr Ss:[Ebp-0x38]
		Mov Ecx,Dword Ptr Ds:[Edx+0x350]
		Mov Eax,Dword Ptr Ss:[Ebp-0x38]
		Mov Edx,Dword Ptr Ds:[Eax+0x350]
		Mov Eax,Dword Ptr Ds:[Edx]
		Call Dword Ptr Ds:[Eax+0x58]
		Mov Ecx,Dword Ptr Ss:[Ebp-0x38]
		Mov Edx,Dword Ptr Ds:[Ecx+0x350]
		Push Edx
		Mov Eax,Dword Ptr Ss:[Ebp-0x38]
		Mov Ecx,Dword Ptr Ds:[Eax+0x354]
		Mov Edx,Dword Ptr Ss:[Ebp-0x38]
		Mov Eax,Dword Ptr Ds:[Edx+0x354]
		Mov Edx,Dword Ptr Ds:[Eax]
		Call Dword Ptr Ds:[Edx+0x58]
		Jmp [LoginTabAddress1]
	}
}

__declspec(naked) void CheckMasterLevel() // OK
{
	static DWORD CheckMasterLevelAddress1 = 0x005875A0;

	_asm
	{
		Push Ebp
		Mov Ebp,Esp
		Mov Eax,Dword Ptr Ds:[MAIN_CHARACTER_STRUCT]
		Xor Ecx,Ecx
		Mov Cx,Word Ptr Ds:[Eax+0x0E]
		Cmp Ecx,0x190
		Je NEXT
		Xor Eax,Eax
		Jmp EXIT
		NEXT:
		Xor Edx,Edx
		Mov Dl,Byte Ptr Ss:[Ebp+0x08]
		Push Edx
		Call [CheckMasterLevelAddress1]
		Add Esp,0x04
		EXIT:
		Pop Ebp
		Retn
	}
}

__declspec(naked) void CompareGensMoveIndex() // OK
{
	static DWORD CheckGensMoveIndexAddress1 = 0x0051B090;
	static DWORD CheckGensMoveIndexAddress2 = 0x008317FC;
	static DWORD CheckGensMoveIndexAddress3 = 0x008317EA;

	__asm
	{
		Lea Ecx,Dword Ptr Ss:[Ebp-0x08]
		Call [CheckGensMoveIndexAddress1]
		Mov Ecx,Dword Ptr Ds:[Eax]
		Mov Edx,Dword Ptr Ds:[Ecx]
		Push Edx
		Call [CheckGensMoveIndex]
		Add Esp,0x04
		Test Eax,Eax
		Jnz EXIT
		Jmp [CheckGensMoveIndexAddress2]
		EXIT:
		Jmp [CheckGensMoveIndexAddress3]
	}
}
