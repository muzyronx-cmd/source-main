#pragma once

#include "Lua.h"

struct CUSTOM_MONSTER_INFO {
	int MonsterID;
	int Type;
};

class CCustomMonster {
public:
	CCustomMonster();
	~CCustomMonster();

	void Init();
	static ObjectPreview* CreateMonster(int Type, int PositionX, int PositionY, int Key);
	static void Setting_Monster(ObjectPreview *c, int Type, int PositionX, int PositionY);
	static void LoadMonsterModel(int ModelID, char* a2, char* a3, int a4);
	static void LoadMonsterTexture(int ModelID, char* a2, int a3, int a4);
	static void EtcStopAnimationSetting(ObjectPreview* c, ObjectModel* o);
	bool CheckCustomMonster(int MonsterID);

public:
	std::map<int, CUSTOM_MONSTER_INFO> m_CustomMonster;
private:
	Lua m_Lua;
};

extern CCustomMonster gCustomMonster;