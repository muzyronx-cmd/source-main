#pragma once

// Coordinates use the same logical 640x480 plane as the native login controls.
namespace CompactLogin {
struct Rect {
    int x, y, w, h;
    bool Contains(int px, int py) const {
        return px >= x && py >= y && px < x + w && py < y + h;
    }
};
struct Layout {
    Rect panel, user, password, save, enter, back, arrow;
    Rect AccountRow(int index) const {
        return Rect{user.x, user.y + user.h + index * 16, user.w, 16};
    }
};
inline Layout GetLayout() {
    return Layout{
        {222,262,196,136}, {270,290,128,16}, {270,315,128,16},
        {270,340,10,10}, {250,358,58,17}, {332,358,58,17}, {384,292,12,12}
    };
}
// Native text sort values: 1 = left, 3 = centered, 4 = right.
enum TextAlignment { TextLeft = 1, TextCenter = 3 };

struct InputSurfaceState {
    const void* object = nullptr;
    float scaleX = 0, scaleY = 0;
};
// A native edit box stores a DIB whose stride depends on its dimensions and scale.
// Resize must rebuild that surface, not only change the base control's bounds.
// Native is a small adapter; the same sequence is exercised by the regression test.
template<class Native>
void FitInput(Native& input, InputSurfaceState& state, const Rect& bounds,
              float scaleX, float scaleY) {
    if (state.object != input.Identity() || state.scaleX != scaleX ||
        state.scaleY != scaleY || input.Width() != bounds.w || input.Height() != bounds.h) {
        input.RebuildSurface(bounds.w,bounds.h);
        input.RestoreFont();
        state.object = input.Identity();
        state.scaleX = scaleX;
        state.scaleY = scaleY;
    }
    input.Position(bounds.x,bounds.y);
}
enum Action { None, ToggleSave, Submit, Back, ToggleAccounts, SelectAccount, CloseAccounts };
struct Hit { Action action; int account; };
inline Hit HitTest(int x, int y, bool list, int count) {
    const Layout ui = GetLayout();
    if (count < 0) count = 0;
    if (count > 5) count = 5;
    if (ui.arrow.Contains(x,y)) return Hit{ToggleAccounts,-1};
    if (list) {
        for (int i=0;i<count;++i) {
            if (ui.AccountRow(i).Contains(x,y)) return Hit{SelectAccount,i};
        }
        return Hit{CloseAccounts,-1}; // consume outside click; do not submit underneath
    }
    if (Rect{ui.save.x,ui.save.y,92,12}.Contains(x,y)) return Hit{ToggleSave,-1};
    if (ui.enter.Contains(x,y)) return Hit{Submit,-1};
    if (ui.back.Contains(x,y)) return Hit{Back,-1};
    return Hit{None,-1};
}
bool Installed();
void Overlay();
}
