#include "stdafx.h"
#include "LoadImages.h"
#include "LuaLoadImage.h"
#include "CustomCape.h"
#include "Util.h"
#include "TradeX.h"
#include "RenderModel.h"
#include "Patente.h"
#include "Interface.h"
#include "CustomJewelStack.h"
#include "ElementSlots.h"
#include "CustomSkillEffect.h"
#include "Interface.h"

CLoadImages gLoadImages;

CLoadImages::CLoadImages() : m_Lua(true)
{
}

CLoadImages::~CLoadImages()
{
}

void CLoadImages::Init()
{
	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//Controller//LoadImages.lua");

	SetCompleteHook(0xE8, 0x007C1D7E, &this->MainLoadImage);
}


void CLoadImages::RestartLua()
{


	this->m_Lua.DoFile("Data//Files//Lua//Controller//LoadImages.lua");

	SetCompleteHook(0xE8, 0x007C1D7E, &this->MainLoadImage);

	gLoadImages.m_Lua.Generic_Call("LoadImages", ">");

	gCustomCape.LoadImageCape();

	gPatente.StartLoadImage();

	gRenderModel.LoadImageRenderModel();

}

void CLoadImages::MainLoadImage()
{
	((void(*)())0x007C2050)();

	gLoadImages.m_Lua.Generic_Call("LoadImages", ">");

	gInterface.m_Lua.Generic_Call("LoadImages", ">");

	gCustomSkillEffect.m_Lua.Generic_Call("LoadCromaSkill", ">");

	gCustomCape.LoadImageCape();

	gPatente.StartLoadImage();

	gRenderModel.LoadImageRenderModel();

	gTradeX.TradeXIconID = 71000;

	gCustomJewelStack.m_IndexMinus = 71001;

	gCustomJewelStack.m_IndexMinusCliked = 71002;

	gCustomJewelStack.m_IndexAdd = 71003;

	gCustomJewelStack.m_IndexAddCliked = 71004;


	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\TradeIcon.jpg", gTradeX.TradeXIconID, 0x2601, 0x2901, 1, 0);

	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\Button_Minus.jpg", gCustomJewelStack.m_IndexMinus, 0x2601, 0x2901, 1, 0);

	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\Button_Minus_Clicked.jpg", gCustomJewelStack.m_IndexMinusCliked, 0x2601, 0x2901, 1, 0);

	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\Button_Plus.jpg", gCustomJewelStack.m_IndexAdd, 0x2601, 0x2901, 1, 0);

	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\Button_Plus_Clicked.jpg", gCustomJewelStack.m_IndexAddCliked, 0x2601, 0x2901, 1, 0);


	//#if(DOWNGRADE)


	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\none.tga", 51522,                            GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Delete011.tga", 88000,                 GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Ok011.tga", 88016,                     GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character211.tga", 88014,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character212.jpg", 88015,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Interface012.tga", 88003,              GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Interface013.tga", 88004,              GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character97_Cancel.jpg", 88006,    GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character97_Ok.jpg", 88007,        GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Delete021.jpg", 88001,                 GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Ok021.jpg", 88017,                     GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character001.jpg", 88008,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character011.tga", 88009,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character002.jpg", 88010,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\New_Character021.tga", 88011,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Logo\\Layout.tga", 51523,                    GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Upgrade\\CharacterSelect_Button.tga", 51519, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Upgrade\\CharacterOption_Button.tga", 521519,GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\none.tga", 75125,                            GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Boton\\Menu_fastmenu.jpg", 0x7A4B,           GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Boton\\Menu_Inventory.jpg", 0x7A49,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Boton\\Menu_Party.jpg", 0x910,               GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Boton\\Menu_guild.jpg", 0x904,               GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interface\\FontTest.tga", 542028,                         GL_LINEAR, GL_CLAMP, 1, 0);	//lateral party
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\none.tga", 51522,                            GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Menu\\Stats2.jpg", 31352,                     GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Menu\\StatsDL.jpg", 51291,                   GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\Menu\\Stats2.jpg", 51292,                    GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Logo\\MU-logo.tga", 531018,                                       GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Logo\\MU-logo_g.jpg", 531019,                                     GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_vframe.jpg", 51551,                GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_rsframe.tga", 51552,               GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_rsframe_up.jpg", 51553,            GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_rsframe_m.jpg", 51554,             GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_rsframe_down.jpg", 51555,          GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\nis_hframe.jpg", 31275,                GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\dialogue1.tga", 51530,                 GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\dialogue2.tga", 51531,                 GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\dialogue2_1.jpg", 51532,               GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\btnChatOn.jpg", 0x700021,              GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\btnWinSize.jpg", 0x700022,             GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\InterfaceS2\\chat\\btnAlpha.jpg", 0x700023,               GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Logo\\0Account_new.tga", 531020/*35124*/,                         GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Logo\\0On_Botton.jpg", 531021/*35125*/,                           GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Logo\\0On_Botton2.jpg", 531022/*35126*/,                          GL_LINEAR, GL_CLAMP, 1, 0);



	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 51522, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 31292, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 0x7A48, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 31294, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 31295, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\none.tga", 0x7A4A, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Main_Menu_Master.tga", 31293, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu_Red.tga", 0x7A42, GL_LINEAR, GL_CLAMP, 1, 0);//replace
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu_Green.tga", 0x7A41, GL_LINEAR, GL_CLAMP, 1, 0);//replace
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu_Blue.tga", 0x7A40, GL_LINEAR, GL_CLAMP, 1, 0);//replace
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Main_I4.jpg", 31300, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Main_I5.jpg", 31299, GL_LINEAR, GL_CLAMP, 1, 0);
	//
	//InterfaceMenu 97d
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Item_Back02.jpg", 51533, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\Stats2.jpg", 71352, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\StatsDL.jpg", 71291, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\Stats2.jpg", 71292, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\Level_box.jpg", 35353, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\Level_button.jpg", 51290, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Menu\\ePointback.jpg", 0x700020, 0x2601, 0x2901, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\newui_skillbox.jpg", 31312, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\newui_skillbox2.jpg", 31313, GL_LINEAR, GL_CLAMP, 1, 0);

	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Boton\\Menu_Inventory.tga", iNewInventory1, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Boton\\Menu_Character.tga", iNewCharacter1, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Boton\\Menu_Party.tga", iNewParty1, GL_LINEAR, GL_CLAMP, 1, 0);
	((int(__cdecl*)(char* Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Custom\\Interfaceold\\Boton\\Menu_guild.tga", iNewGuild1, GL_LINEAR, GL_CLAMP, 1, 0);
//#endif


	gElementSlots.LoadImageSlot();
}
