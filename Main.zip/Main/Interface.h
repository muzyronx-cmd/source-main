#pragma once

#include "Lua.h"
#include "LuaInterface.h"
#include "LuaGlobal.h"
#include "LuaCharacter.h"
#include "LuaUser.h"
#include "LuaLoadImage.h"
#include "Protocol.h"

#define MAX_OBJECT	300

enum iInterface1
{
	iNewCharacter1 = 0x7A48,
	iNewInventory1 = 0x7A49,
	iNewWinpush1 = 0x7A4A,
	iNewFastMenu1 = 0x7A4B,
	iNewSkillBox1 = 0x7A50,
	iNewParty1 = 0x910,
	iNewGuild1 = 0x904,
};

enum ObjectID
{
	CharacterSelect = 1,
	CharacterOption_Button1,
	CharacterOption_Button2,
	CharacterSelect_Button1,
	CharacterSelect_Button2,
	CharacterSelect_Button3,
	CharacterSelect_Button4,
	CharacterSelect_Button5,
	eMain,
	eParty,
	eCharacter,
	eInventory,
	eShop,
	eFriend,
	eGuild,
	eOrelhinha,
	eJanelinha,
	eLuizinha,
	ebtnWisper,
};

struct InterfaceObject
{
	DWORD	ModelID;
	float	Width;
	float	Height;
	float	X;
	float	Y;
	float	MaxX;
	float	MaxY;
	DWORD	EventTick;
	bool	OnClick;
	bool	OnShow;
	BYTE	Attribute;
	bool	ByClose;
	long	OpenedValue;
	BYTE	Speed;
	char	StatValue[20];
	int		Type;
	//
	bool	FirstLoad;
	void Close()
	{
		this->OnShow = false;
		pSetCursorFocus = false;
		this->ByClose = false;
	};

	void Open()
	{
		this->OnShow = true; pSetCursorFocus = true;
		this->ByClose = false;
	};

	void Open(int Value, int Speed)
	{
		this->OnShow = true; pSetCursorFocus = true;
		this->OpenedValue = Value;
		this->Speed = Speed;
		this->ByClose = false;
		this->FirstLoad = true;
	};

	void Close(int Value, int Speed)
	{
		this->OnShow = false; pSetCursorFocus = false;
		this->OpenedValue = Value;
		this->Speed = Speed;
		this->ByClose = false;
	}

	void CloseAnimated(int Speed)
	{
		pSetCursorFocus = false;
		this->Speed = Speed;
		this->ByClose = true;
	}
};


struct PMSG_PING
{
	PBMSG_HEAD h;
};

class CInterface {
public:
	CInterface();
	~CInterface();

	void MouseMU();


	//PING:
	int		    iniciador;
	int		    msPing;
	int		    lastSend;
	int		    validar;
	char		ServerPing[20];
	char		ultimoping[30];
	int		    ultimo_ping;

	//FPS:
	int		    lastReport;
	int		    frameCount;
	int		    frameRate;
	char		FPS_REAL[30];
	void		UPDATE_FPS();

	//Interfaz Barra Negra

	void Init();
	void RestartLua();
	static void RenderInformation();
	static void MainProc();
	static bool UpdateProc(DWORD* Class);
	static bool UpdateMouse(DWORD* Class);
	static bool UpdateKey(DWORD* Class);
	//static void WebzenScene(HDC hdc);
	int DrawToolTip(int X, int Y, LPCSTR Text, ...);
	int DrawFormat(DWORD Color, int PosX, int PosY, int Width, int Align, LPCSTR Text, ...);
	int DrawMessage(int Mode, LPCSTR Text, ...);
	void BindObject(short MonsterID, DWORD ModelID, float Width, float Height, float X, float Y);
	bool IsWorkZone(short ObjectID);
	void DrawButton(short ObjectID, float PosX, float PosY, float ScaleX, float ScaleY);
	void DrawIMG(short ObjectID, float PosX, float PosY, float ScaleX, float ScaleY);
	void SelectCharButton(DWORD Event);
	void DrawInterface97Menu();
	void EventNewInterface97_All(DWORD Event);
	bool CheckWindow(int WindowID);
	int CCloseWindow(int WindowID);
	void DrawCoord();
	void DrawGUI(short ObjectID, float PosX, float PosY);
	InterfaceObject Data[MAX_OBJECT];

public:
	Lua m_Lua;
	bool interfaceLock;
	bool MiniMapCheck;
	bool CombinedChecks;

private:
	LuaInterface m_LuaInterface;
	LuaGlobal m_LuaGlobal;
	CLuaCharacter m_LuaCharacter;
	CLuaUser m_LuaUser;
	LuaLoadImage m_LoadImage;

public:
	DWORD frameStartTime;
	DWORD frameTimes;
	DWORD frames;

public:
	int FPS;

	HDC hdc;
};

extern CInterface gInterface;