#pragma once

class CMenuWindow {
public:
	CMenuWindow();
	~CMenuWindow();

	void Init();
	void ChangeFontSize(int fontSize, bool resolution = 0);
	void ChangeLanguage(char* lang);
	void ChangeResolution(int value);

public:
	int m_HealthBarDisabled;
	int m_ShadowDisabled;
	int m_WingDisabled;
};

extern CMenuWindow gMenuWindow;