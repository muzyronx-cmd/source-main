#include "stdafx.h"
#include "CustomItemPosition.h"
#include "LuaStack.hpp"
#include "Util.h"
#include "Item.h"

using namespace luaaa;

CCustomItemPosition gCustomItemPosition;

CCustomItemPosition::CCustomItemPosition() : m_Lua(true)
{
	this->m_CustomItemPositionInfo.clear();
}

CCustomItemPosition::~CCustomItemPosition()
{
	this->m_CustomItemPositionInfo.clear();
}

void SetItemPosition(int ItemIndex, float PosX, float PosY, float AngleX, float AngleY, float AngleZ) {
	CUSTOM_ITEM_POSITION_INFO info;

	info.ItemIndex = ItemIndex;

	info.PosX = PosX;

	info.PosY = PosY;

	info.AngleX = AngleX;

	info.AngleY = AngleY;

	info.AngleZ = AngleZ;

	gCustomItemPosition.m_CustomItemPositionInfo.insert(std::make_pair(info.ItemIndex, info));
}

void GetPositionItem(int ItemIndex, float* PosX, float* PosY, float* AngleX, float* AngleY, float* AngleZ) {
	auto itemPos = gCustomItemPosition.getItemPosition(ItemIndex);

	if (itemPos) {
		(*PosX) = itemPos->PosX;
		(*PosY) = itemPos->PosY;
		(*AngleX) = itemPos->AngleX;
		(*AngleY) = itemPos->AngleY;
		(*AngleZ) = itemPos->AngleZ;
	}
}

void __declspec(naked) InventoryItemPosition()
{
	static DWORD m_ItemIndex = 0;
	static DWORD m_HookFunc = 0x005CBFA4;
	static DWORD m_ReturnFunc = 0x005CA175;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_ItemIndex, ECX;
	}

	static float PosX = 0.0;
	static float PosY = 0.0;
	static float AngleX = 0.0;
	static float AngleY = 0.0;
	static float AngleZ = 0.0;

	if (gCustomItemPosition.CheckCustomItemPosition(m_ItemIndex-ITEM_BASE_MODEL)) {
		GetPositionItem(m_ItemIndex - ITEM_BASE_MODEL, &PosX, &PosY, &AngleX, &AngleY, &AngleZ);

		_asm {
			FLD DWORD PTR SS : [EBP - 0x4C]
			FADD DWORD PTR DS : [PosX]
			FSTP DWORD PTR SS : [EBP - 0x4C]

			FLD DWORD PTR SS : [EBP - 0x48]
			FADD DWORD PTR DS : [PosY]
			FSTP DWORD PTR SS : [EBP - 0x48]

			FLD DWORD PTR DS : [AngleX]
			FSTP DWORD PTR DS : [0x82C6320]
			FLD DWORD PTR DS : [AngleY]
			FSTP DWORD PTR DS : [0x82C6324]
			FLD DWORD PTR DS : [AngleZ]
			FSTP DWORD PTR DS : [0x82C6328]
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x8], 0x493;
			JMP[m_ReturnFunc];
		}
	}
}

bool CCustomItemPosition::CheckCustomItemPosition(int ItemIndex)
{
	std::map<int, CUSTOM_ITEM_POSITION_INFO>::iterator it = this->m_CustomItemPositionInfo.find(ItemIndex);

	if (it == this->m_CustomItemPositionInfo.end()) {
		return 0;
	}

	return 1;
}

CUSTOM_ITEM_POSITION_INFO * CCustomItemPosition::getItemPosition(int ItemIndex)
{
	std::map<int, CUSTOM_ITEM_POSITION_INFO>::iterator it = this->m_CustomItemPositionInfo.find(ItemIndex);

	if (it == this->m_CustomItemPositionInfo.end()) {
		return 0;
	}

	return &it->second;
}

void CCustomItemPosition::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemPosition", &SetItemPosition);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomItemPosition.lua");

	this->m_Lua.Generic_Call("StartLoadItemPosition", "");

	SetCompleteHook(0xE9, 0x005CA16E, &InventoryItemPosition);
}


void CCustomItemPosition::RestartLua()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemPosition", &SetItemPosition);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomItemPosition.lua");

	this->m_Lua.Generic_Call("StartLoadItemPosition", "");

	SetCompleteHook(0xE9, 0x005CA16E, &InventoryItemPosition);
}
