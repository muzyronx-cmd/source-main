#pragma once

#include "Protocol.h"

struct PMSG_ANTI_CLIENT_KEY_SEND
{
	PSBMSG_HEAD header;

	char m_MacAddress[40];
	char m_Language[4];
	// Teste AntiHacker
	// Teste AntiHacker
	// Teste AntiHacker
};

class CAntiHack
{
public:
	CAntiHack();
	virtual ~CAntiHack();

	void Init();
	static DWORD WINAPI MainThread(CAntiHack* AntiHack);
	static DWORD WINAPI MainServerThread(LPVOID lpParam);
	void CloseApp();
	void SendCloseServer();
	void GetMac();
	void ClientSendMac();
	char mac_addr[40];
	static void MainSendMove(DWORD character, DWORD object);
	bool SetAdminPrivilege(char* PrivilegeName);

public:
	DWORD m_TickCountProtocol;
	DWORD m_TickCountSend;
	DWORD m_StartedTime;
	DWORD m_TickCountRecv;

	int m_PatentLimit;

	bool LicenseChecked;

	bool lockedWalk;

	int timerCheck1;
	int timerCheck2;
	int timerCheck3;
	int timerCheck4;

	DWORD m_MovesCount;
	DWORD m_LastTickThread;

	DWORD m_PingServer;

	HANDLE m_ThreadHandle;
};

extern CAntiHack gAntiHack;