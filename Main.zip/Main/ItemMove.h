#pragma once

class CItemMove {
public:
	CItemMove();
	~CItemMove();

	void AutoMoveItem();
	void UnequipItem();
	BYTE GetTargetSlot(int ItemIndex);
	bool CheckItemEquiped(BYTE slot);
	ITEM* getItem(BYTE slot);
	bool checkAutoItemMove();
	void SetAutoItemMove(bool value);

public:
	bool m_ItemMove;

public:
	int m_BackupSlot;
	int m_BackupMouseX;
	int m_BackupMouseY;
	int m_BackupTargetSlot;
	bool m_DeleteInventoryCtrl;
	bool m_InventoryCtrlMix;
};

extern CItemMove gItemMove;