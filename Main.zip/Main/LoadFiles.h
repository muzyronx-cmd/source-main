#pragma once

#include "CustomJewel.h"

struct LOAD_FILES_INFOS
{
	char m_Serial[17];
	char m_IpServer[32];
	char m_ScreenDiretory[65];
	char m_DllName[32];
	char m_DllFunction[32];
	char m_WindowName[256];
	char m_DllName2[32];
	char m_DllFunction2[32];
	char m_DllName3[32];
	char m_DllFunction3[32];
	char m_DllName4[32];
	char m_DllFunction4[32];
	char m_DllName5[32];
	char m_DllFunction5[32];
	char ClientVersion[8];

	WORD m_PortCS;
	DWORD m_FixConsumo;
	DWORD m_Minimizer;
	DWORD m_Camera3D;
	DWORD m_DllCRC32;
	DWORD m_AutoClick;
	DWORD m_DllCRC32_2;
	DWORD m_DllCRC32_3;
	DWORD m_DllCRC32_4;
	DWORD m_DllCRC32_5;
	WORD m_ReconnectSwitch;
	DWORD m_ReconnectTime;
	int m_MuHelperOffline;
	int m_SiegeSkillAllMaps;
	int m_ManagerFps;
	int m_LimitFps;

	char m_ServerName1[30];
	char m_ServerName2[30];
	char m_ServerName3[30];
	char m_ServerName4[30];

	DWORD HelperActiveAlert;
	DWORD HelperActiveLevel;

	bool m_CharListSeason13;

	bool m_EnableSkillsMount;

	bool m_ItemTransparente;

	DWORD DWMaxAttackSpeed;
	DWORD DKMaxAttackSpeed;
	DWORD FEMaxAttackSpeed;
	DWORD MGMaxAttackSpeed;
	DWORD DLMaxAttackSpeed;
	DWORD SUMaxAttackSpeed;
	DWORD RFMaxAttackSpeed;

	DWORD DWAnimationSpeed;
	DWORD DKAnimationSpeed;
	DWORD FEAnimationSpeed;
	DWORD MGAnimationSpeed;
	DWORD DLAnimationSpeed;
	DWORD SUAnimationSpeed;
	DWORD RFAnimationSpeed;

	bool m_LuaOnlyCripted;

	bool m_DisablePushSkills;
	bool m_ItemToolTipDrop;

	bool m_CustomPersonalShop;
	bool m_Coin1Switch;
	bool m_Coin2Switch;
	bool m_Coin3Switch;
	bool m_Coin4Switch;

	int ChineseSupport;
	int MaxLevel;

	char m_ReconnectMessage_1[65];
	char m_ReconnectMessage_2[65];
	char m_ReconnectMessage_3[65];
	char m_ReconnectMessage_4[65];

	char m_PrivateCode[125];
};

struct LOAD_CUSTOM_JEWEL_INFO
{
	CUSTOM_JEWEL_INFO CustomJewelInfo[MAX_CUSTOM_JEWEL];
};

class CLoadFiles
{
public:
	CLoadFiles();
	virtual ~CLoadFiles();

	bool ReadConfig(char* name);
	bool ReadCustomJewels(char * name);

	void LoadDll();
	void LoadDll2();
	void LoadDll3();
	void LoadDll4();
	void LoadDll5();

public:
	LOAD_FILES_INFOS m_LoadFiles;
	LOAD_CUSTOM_JEWEL_INFO m_CustomJewel;
};

extern CLoadFiles gLoadFiles;