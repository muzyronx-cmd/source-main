#pragma once

#define DisplayInfoBarCharacter				((int(__fastcall*)(int a1, int a2, signed int a3, signed int a4, char a5)) 0x416640)
#define pRender_rendertext					((int(__thiscall*)(int thisa, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth , int iBoxHeight , int iSort, OUT SIZE * lpTextSize)) 0x00420150)
#define g_Fontthis							((int(__thiscall*)( )) 0x0041FE10)
#define SceneFlag							*(int*)0x0E609E8
#define _Instance							((int(*)()) 0x00482B70)
#define SEASON3B_CheckMouseIn				((bool(__cdecl*)(int a1, int a2, int a3, int a4)) 0x00790B10)
#define g_fScreenRate_x						*(float*)0xE7C3D4
#define g_fScreenRate_y						*(float*)0xE7C3D8
#define IsPress								((int(__cdecl*)(int VKBUTTON)) 0x00791070)
#define pWinWidth							*(GLsizei*)0x0E61E58
#define pWinHeight							*(GLsizei*)0x0E61E5C
#define SetBoundInputField					((int(__thiscall*)(int a1, int a2, int a3)) 0x00417EC0)
#define PlayBuffer							((signed int(__cdecl*)(int a1, int a2, int a3)) 0x006D6C20)
#define RequestLogin						((int(__thiscall*)(int This)) 0x0040B7B0)
#define CancelLogin							((int(__thiscall*)(int This)) 0x0040BBC0)
#define	pFontNormal							*(HGDIOBJ*)0x00E8C588
#define pFontBold							*(HGDIOBJ*)0x00E8C58C
#define pFontBigBold						*(HGDIOBJ*)0x00E8C590
#define pFontNormal2						*(HGDIOBJ*)0x00E8C594
#define pSetFont							((int(__thiscall*)(LPVOID This, int a2)) 0x420120)

extern int PointSY1;

void RemakeLoginLoad();