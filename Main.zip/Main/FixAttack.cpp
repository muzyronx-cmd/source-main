#include "stdafx.h"
#include "FixAttack.h"
#include "Defines.h"
#include "Util.h"

static DWORD ATTACK_RET = 0x00550A16;
static WORD CLASS = 0;
static WORD STR_SPEED = 0;
static WORD MAG_SPEED = 0;
static int MagickAttack = 0;

int GetSkillUsing() {
	lpCharObj lpPlayer = &*(ObjectCharacter*)*(int*)(MAIN_CHARACTER_STRUCT);
	lpViewObj lpViewPlayer = &*(ObjectPreview*)*(int*)(MAIN_VIEWPORT_STRUCT);

	return lpPlayer->pMagicList[lpViewPlayer->ActiveMagic];
}

__declspec(naked) void FixAttackSpeed()
{
	_asm
	{
		MOV EAX, DWORD PTR DS : [0x8128AC8]
		MOVZX ECX, WORD PTR DS : [EAX + 0xB]
		MOV CLASS, CX
		MOVZX ECX, WORD PTR DS : [EAX + 0x54]
		MOV STR_SPEED, CX
		MOVZX ECX, WORD PTR DS : [EAX + 0x60]
		MOV MAG_SPEED, CX
	}
	// --------------------------------------------

	MagickAttack = GetSkillUsing();

	if (CLASS == DarkWizard || CLASS == SoulMaster || CLASS == GrandMaster)
	{
		if (MagickAttack == 9 ||
			MagickAttack == 8 ||
			MagickAttack == 13 ||
			MagickAttack == 38 ||
			MagickAttack == 39 ||
			MagickAttack == 5)
		{
			if (MAG_SPEED > 450 && MAG_SPEED < 480)
			{
				MAG_SPEED = 450;
			}
			else if (MAG_SPEED > 600 && MAG_SPEED < 690)
			{
				MAG_SPEED = 600;
			}
			else if (MAG_SPEED > 850 && MAG_SPEED < 1105)
			{
				MAG_SPEED = 850;
			}
			else if (MAG_SPEED > 1350 && MAG_SPEED < 2355)
			{
				MAG_SPEED = 1350;
			}
			else if (MAG_SPEED > 2850)
			{
				MAG_SPEED = 2850;
			}
		}
		else if (MagickAttack == 14)
		{
			if (MAG_SPEED > 3276)
			{
				MAG_SPEED = 3276;
			}
		}
	}
	// -> Elf
	if (CLASS == Elf || CLASS == MuseElf || CLASS == HightElf)
	{
		if (MagickAttack == 52 ||
			MagickAttack == 51 ||
			MagickAttack == 424 ||
			MagickAttack == 416)
		{
			if (STR_SPEED > 400)
			{
				STR_SPEED = 400;
			}
		}

		if (MagickAttack == 24 ||
			MagickAttack == 414)
		{
			if (STR_SPEED > 600)
			{
				STR_SPEED = 600;
			}
		}
	}
	// -> Magic Gladiator
	if (CLASS == MagicGladiator || CLASS == DuelMaster)
	{
		if (MagickAttack == 55 ||
			MagickAttack == 490)
		{
			if (STR_SPEED > 1368)
			{
				STR_SPEED = 1368;
			}
		}
		if (MagickAttack == 9 ||
			MagickAttack == 8 ||
			MagickAttack == 13 ||
			MagickAttack == 5)
		{
			if (MAG_SPEED > 450 && MAG_SPEED < 480)
			{
				MAG_SPEED = 450;
			}
			else if (MAG_SPEED > 600 && MAG_SPEED < 690)
			{
				MAG_SPEED = 600;
			}
			else if (MAG_SPEED > 850 && MAG_SPEED < 1105)
			{
				MAG_SPEED = 850;
			}
			else if (MAG_SPEED > 1350 && MAG_SPEED < 2355)
			{
				MAG_SPEED = 1350;
			}
			else if (MAG_SPEED > 2850)
			{
				MAG_SPEED = 2850;
			}
		}
		if (MagickAttack == 14)
		{
			if (MAG_SPEED > 3276)
			{
				MAG_SPEED = 3276;
			}
		}
	}
	// -> Dark Lord
	if (CLASS == DarkLord || CLASS == LordEmperor)
	{
		if (MagickAttack == 78 ||
			MagickAttack == 518)
		{
			if (STR_SPEED > 249 && STR_SPEED < 264)
			{
				STR_SPEED = 249;
			}
			else if (STR_SPEED > 324 && STR_SPEED < 367)
			{
				STR_SPEED = 324;
			}
			else if (STR_SPEED > 449 && STR_SPEED < 575)
			{
				STR_SPEED = 449;
			}
			else if (STR_SPEED > 699 && STR_SPEED < 1200)
			{
				STR_SPEED = 699;
			}
			else if (STR_SPEED > 1449)
			{
				STR_SPEED = 1449;
			}
		}
	}

	_asm
	{
		MOVZX ECX, WORD PTR DS : [STR_SPEED]
		MOV DWORD PTR SS : [EBP - 0x28], ECX
		FILD DWORD PTR SS : [EBP - 0x28]
		FMUL QWORD PTR DS : [0x0D27C88]; FLOAT 0.0010007200189989805
		FSTP DWORD PTR SS : [EBP - 0x10]
		MOVZX EAX, WORD PTR DS : [MAG_SPEED]
		MOV DWORD PTR SS : [EBP - 0x2C], EAX
		FILD DWORD PTR SS : [EBP - 0x2C]
		FMUL QWORD PTR DS : [0x0D27C88]; FLOAT 0.0010007200189989805
		FSTP DWORD PTR SS : [EBP - 0x0C]
		MOVZX EDX, WORD PTR DS : [MAG_SPEED]
		MOV DWORD PTR SS : [EBP - 0x30], EDX
		FILD DWORD PTR SS : [EBP - 0x30]
		FMUL QWORD PTR DS : [0x0D281C0]; FLOAT 0.002000000094994903
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR SS : [EBP - 0x10]

		JMP ATTACK_RET
	}
}
// --------------------------------------------------------------------------------------------	
static DWORD RETURN_attack2 = 0x0055157D;

__declspec(naked) void FixAttackSpeed2()
{
	_asm
	{
		MOVZX EDX, WORD PTR DS : [STR_SPEED]
		JMP RETURN_attack2
	}
}

void InitAttackSpeed()
{
	SetCompleteHook(0xE9, 0x005509CE, &FixAttackSpeed);
	SetCompleteHook(0xE9, 0x00551573, &FixAttackSpeed2);
}