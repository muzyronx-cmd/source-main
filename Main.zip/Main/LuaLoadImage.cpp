#include "stdafx.h"
#include "LuaLoadImage.h"
#include "LuaStack.hpp"

using namespace luaaa;

int m_LuaStartImage = 600000;

LuaLoadImage::LuaLoadImage()
{
	
}

LuaLoadImage::~LuaLoadImage()
{
}

void LoadingExtern(char* string, int textureID) {
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)(string, textureID, 0, 0x2900, 0, 0);
}

void LuaImage(char* string, int textureID) {
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)(string, textureID, 0, 0x2900, 0, 0);
}

int LoadImageByDir(char* string) {
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)(string, m_LuaStartImage, 0, 0x2900, 0, 0);
	return m_LuaStartImage++;
}

void LuaLoadImage::SetFunctions(lua_State * lua)
{
	LuaModule(lua).fun("LoadImage", &LuaImage);

	LuaModule(lua).fun("LoadingExtern", &LoadingExtern);


	LuaModule(lua).fun("LoadImageByDir", &LoadImageByDir);
}

