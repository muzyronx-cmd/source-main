#pragma once

#include "Protocol.h"
#include "Lua.h"

struct CUSTOM_JEWEL_STACK_INFO_SEND
{
	PSBMSG_HEAD header;
	BYTE slot;
	BYTE stack;
};

struct CUSTOM_JEWEL_STACK_INFO {
	int ItemIndex;
	int MaxStack;
};

class CCustomJewelStack {
public:
	CCustomJewelStack();
	~CCustomJewelStack();

	void Init();
	bool CheckCustomJewelStack(int ItemIndex);
	bool IsVisible() { return this->m_VisibleSplitStack; };
	CUSTOM_JEWEL_STACK_INFO* GetInfo(int ItemIndex);
	BOOL CheckSplitJewel(int ItemIndex, int TargetItemIndex);
	void RenderDescriptionStack(DWORD* Line, WORD ItemIndex, BYTE durability);
	void ProcessUnSplit(int ItemSlot, int Stack);
	void Open(int ItemIndex, int ItemSlot, int Durability);
	void Close();
	void Update();
	void RenderItem(float x, float y);
	void Render();

public:
	int m_IndexMinus;
	int m_IndexMinusCliked;
	int m_IndexAdd;
	int m_IndexAddCliked;

private:
	bool m_VisibleSplitStack;
	int m_ValueGetStack;

	int m_EventKey;
	int m_EventKey2;

	int m_ItemIndex;
	int m_ItemSlot;
	int m_Durability;

	float m_x;
	float m_y;

private:
	Lua m_Lua;

public:
	std::map<int, CUSTOM_JEWEL_STACK_INFO> m_CustomJewelStackInfo;
};

extern CCustomJewelStack gCustomJewelStack;