#include "stdafx.h"
#include "MessageColor.h"
#include "Util.h"
#include "LuaStack.hpp"

using namespace luaaa;

CMessageColor gMessageColor;

CMessageColor::CMessageColor() : m_Lua(true)
{
	this->m_CustomMessageColorInfo.clear();
}

CMessageColor::~CMessageColor()
{
	this->m_CustomMessageColorInfo.clear();
}

static DWORD m_MessagesIndexReceive = 0;
static DWORD m_ChangeMessageIndex = 0;

int GetMessageType(int MessageID) {
	auto msgInfo = gMessageColor.getInfo(MessageID);

	if (msgInfo) {
		if (msgInfo->Type == 0) {
			return 3;
		}
		else if (msgInfo->Type == 1) {
			return 9;
		}
	}

	return 3;
}

__declspec(naked) void SetAcceptNewColors() {
	static DWORD m_HookFunc = 0x00640405;
	static DWORD m_HookMyFunc = 0x006404A4;
	static DWORD m_ReturnFunc = 0x006403FC;
	static DWORD m_Message = 0x0;

	static DWORD m_MessageType = 0x0;

	static DWORD m_CallFunc1 = 0x00409A50;
	static DWORD m_CallFunc2 = 0x00861110;
	static DWORD m_CallFunc3 = 0x00861180;
	static DWORD m_CallFunc4 = 0x007894E0;
	static DWORD m_CallFunc5 = 0x00409AD0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x10]
		MOVZX EDX, BYTE PTR DS : [ECX + 0x3];
		MOV m_Message, EDX;
	}

	m_MessagesIndexReceive = m_Message;

	if (m_Message >= 25 && m_Message <= 100) {
		m_ChangeMessageIndex = 100;
		m_MessageType = GetMessageType(m_Message);

		_asm {
			MOV EAX, DWORD PTR SS : [EBP - 0x10];
			ADD EAX, 0x0D;
			PUSH EAX;
			LEA ECX, DWORD PTR SS : [EBP - 0x98];
			CALL[m_CallFunc1];
			MOV DWORD PTR SS : [EBP - 0x4], 0x0;
			PUSH 0x00D418C3;
			LEA ECX, DWORD PTR SS : [EBP - 0xB4];
			CALL[m_CallFunc1];
			MOV BYTE PTR SS : [EBP - 0x4], 0x1;
			PUSH 0;
			PUSH m_MessageType;
			LEA ECX, DWORD PTR SS : [EBP - 0x98];
			PUSH ECX;
			LEA EDX, DWORD PTR SS : [EBP - 0xB4];
			PUSH EDX;
			CALL[m_CallFunc2];
			MOV ECX, EAX;
			CALL[m_CallFunc3];
			MOV ECX, EAX;;
			CALL[m_CallFunc4];
			MOV BYTE PTR SS : [EBP - 0x4], 0x0;
			LEA ECX, DWORD PTR SS : [EBP - 0xB4];
			CALL[m_CallFunc5];
			MOV DWORD PTR SS : [EBP - 0x4], -1;
			LEA ECX, DWORD PTR SS : [EBP - 0x98];
			CALL[m_CallFunc5];
			MOV DWORD PTR DS : [0x8793738], 0;
			JMP[m_HookMyFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP - 0x10]
			MOVZX EDX, BYTE PTR DS : [ECX + 0x3];
			JMP[m_ReturnFunc];
		}
	}
}

void SetMessageColor(int m_Message) {
	auto msgInfo = gMessageColor.getInfo(m_Message);

	if (msgInfo) {
		pSetTextBgColor(pTextThis(), msgInfo->BgR, msgInfo->BgG, msgInfo->BgB, msgInfo->BgA);
		pSetTextColor(pTextThis(), msgInfo->TextR, msgInfo->TextG, msgInfo->TextB, msgInfo->TextA);
		return;
	}

	pSetTextBgColor(pTextThis(), 0, 0, 0, 0x96);
	pSetTextColor(pTextThis(), 0x64, 0x96, 0xFF, 0xFF);
}

__declspec(naked) void RenderColorChat() {
	static DWORD m_HookFunc = 0x00788C66;
	static DWORD m_HookMyFunc = 0x00788F29;
	static DWORD m_ReturnFunc = 0x00788C9F;
	static DWORD m_CallFunc = 0x0078C050;
	static DWORD m_Message = 0x0;
	static DWORD m_StructMessage = 0x0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x2C]
		CALL[m_CallFunc];
		MOV m_Message, EAX;
		MOV m_StructMessage, ECX;
	}

	if (m_Message == 2) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else if (*(DWORD*)(m_StructMessage + 60) >= 25 && *(DWORD*)(m_StructMessage + 60) <= 100) {
		SetMessageColor(*(DWORD*)(m_StructMessage + 60));

		_asm {
			JMP[m_HookMyFunc];
		}
	}
	else {
		_asm {
			JMP[m_ReturnFunc];
		}
	}
}

BOOL CheckChangeMessage() {
	if (m_ChangeMessageIndex == 100) {
		return 1;
	}

	return 0;
}

__declspec(naked) void SetNewIndexLine() {
	static DWORD m_Message = 0x0;
	static DWORD m_ReturnFunc = 0x0078C015;

	_asm {
		CALL[CheckChangeMessage];
		TEST EAX, EAX;
		JE EXIT;

		MOV EAX, m_MessagesIndexReceive;
		MOV EDX, DWORD PTR SS : [EBP - 0x4];
		MOV DWORD PTR DS : [EDX + 0x3C], EAX;
		MOV AL, 0x1;
		MOV ESP, EBP;
		POP EBP;
		RETN 0x0C;

	EXIT:
		MOV EDX, DWORD PTR SS : [EBP - 0x4];
		MOV DWORD PTR DS : [EDX + 0x3C], 0x0;
		MOV AL, 0x1;
		MOV ESP, EBP;
		POP EBP;
		RETN 0x0C;
	}
}

__declspec(naked) void ClearNoticesIndex() {
	static DWORD m_ReturnFunc = 0x0078A025;

	_asm {
		MOV m_MessagesIndexReceive, 0
		MOV m_ChangeMessageIndex, 0
		MOV ECX, DWORD PTR SS : [EBP - 0xC];
		MOV DWORD PTR FS : [0], ECX;
		JMP[m_ReturnFunc];
	}
}

void SetCustomMessageColor(int index, int type, int textR, int textG, int textB, int textA, int bgR, int bgG, int bgB, int bgA) {
	CUSTOM_MESSAGE_COLOR_INFO info;

	info.MessageID = index;

	info.Type = type;

	info.TextR = textR;

	info.TextG = textG;

	info.TextB = textB;

	info.TextA = textA;

	info.BgR = bgR;

	info.BgG = bgG;

	info.BgB = bgB;

	info.BgA = bgA;

	gMessageColor.m_CustomMessageColorInfo.insert(std::make_pair(info.MessageID, info));
}

void CMessageColor::Init()
{
	MemorySet(0x0078C015, 0x90, 6);
	SetCompleteHook(0xE9, 0x0078C015, &SetNewIndexLine);

	MemorySet(0x0078A01B, 0x90, 10);
	SetCompleteHook(0xE9, 0x0078A01B, &ClearNoticesIndex);

	MemorySet(0x006403F5, 0x90, 7);
	SetCompleteHook(0xE9, 0x006403F5, &SetAcceptNewColors);

	MemorySet(0x00788C59, 0x90, 8);
	SetCompleteHook(0xE9, 0x00788C59, &RenderColorChat);

	LuaModule(this->m_Lua.GetState()).fun("SetCustomMessageColor", &SetCustomMessageColor);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//MessageColors.lua");

	this->m_Lua.Generic_Call("StartLoadCustomMessageColors", "");
}

CUSTOM_MESSAGE_COLOR_INFO * CMessageColor::getInfo(int messageID)
{
	std::map<int, CUSTOM_MESSAGE_COLOR_INFO>::iterator it = this->m_CustomMessageColorInfo.find(messageID);

	if (it == this->m_CustomMessageColorInfo.end()) {
		return 0;
	}

	return &it->second;
}
