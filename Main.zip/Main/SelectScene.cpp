#include "stdafx.h"
#include "SelectScene.h"
#include "Interface.h"
#include "Util.h"
#include "WideScreen.h"
#include "LoginRemake.h"
#include "CustomMessage.h"
#include "SelectBackground.h"

// Controlado pelo Lua (CharacterList.lua) - ver SelectBackground.h
SELECT_BACKGROUND_INFO gSelectBackground = { 0, false, 3500.0f, -82.0f, 0.0f, -90.0f, 9758.9297f, 18913.109f, 500.0f, 35.0f, false };

float MaoOKPosX = 0;
int PointX11 = -180;
int PointX12 = 50;
int PointY1 = -180;
int VerificarCriacao = 1;
int NewChar = -300;

void LoginScreenS0(int a1, DWORD* a2)
{
	if (World == 94) /*Select Server*/
	{
		SetFloat((0x005DB53F), -2.014084447E38);
		SetFloat((0x005DB55D), -2.70652875E38);
		*(float*)0xE61E3C = 33000.0;
		*(float*)0x87933D0 = -84.0;
		*(float*)0x87933D4 = 0.0;
		*(float*)0x87933D8 = -45.0;
		*(float*)0x87933DC = 24475.79687;
		*(float*)0x87933E0 = 7581.581055;
		*(float*)0x87933E4 = 1834.539917;
		*(float*)0xE61E40 = 35.0;
	}
}

void RenderSSCObjectVisualS0(int a1, int a2)
{
	vec3_t Bone;
	vec3_t Color;
	vec3_t WorldPos;
	/*Select Server*/
	if (World == 94)
	{
		switch (*(DWORD*)(a1 + 48))
		{
		case 1: {
			BeginRender(1.0);
			*(DWORD*)(a1 + 60) = -2;
			*(BYTE*)(a2 + 136) = 0;
			float v552 = 4000;
			float v551 = ((int)(v552 - timeGetTime() * 0.75f) % 4001) * 0.0002500000118743628;
			RenderMesh(a2, 0, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), v551, -1);
			*(BYTE*)(a2 + 136) = -1;
			EndRender();
		}
			  break;
		case 5: {
			BeginRender(1.0);
			*(BYTE*)(a2 + 136) = 0;
			*(float*)(a2 + 72) = 0.80000001;
			*(float*)(a2 + 76) = 0.69999999;
			*(float*)(a2 + 80) = 0.30000001;
			RenderMesh(a2, 0, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 23, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 23, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 24, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 24, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 25, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 25, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 26, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 26, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 27, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 27, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			RenderMesh(a2, 28, 66, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), -1);
			RenderMesh(a2, 28, 68, *(float*)(a1 + 152), *(DWORD*)(a1 + 68), *(float*)(a1 + 100), *(float*)(a1 + 104), *(float*)(a1 + 108), 32042);
			*(BYTE*)(a2 + 136) = -1;
			EndRender();
			float v409 = (double)(rand() % 10) / 20.0 + 1.399999976158142;
			float v19 = v409 - 0.300000011920929;
			Vector(0.0, 0.0, 0.0, WorldPos);
			TransformPosition(a2, Joint(37), WorldPos, Bone, 0);
			Vector(1.0, 0.30000001, 0.0, Color);
			CreateSprite(32114, Bone, v409, Color, a1, 0.0, 0);
			CreateSprite(32114, Bone, v19, Color, a1, 0.0, 0);
			v409 = (double)(rand() % 10) / 20.0 + 1.0;
			float v20 = v409 + 0.300000011920929;
			CreateSprite(32002, Bone, v20, Color, a1, 0.0, 0);
			v409 = (double)(rand() % 8) / 20.0 + 0.4000000059604645;
			CreateSprite(32114, Bone, v409, Color, a1, 0.0, 0);
			float v21 = v409 - 0.2000000029802322;
			CreateSprite(32114, Bone, v21, Color, a1, 0.0, 0);
		}
			  break;
		case 38: {
			*(DWORD*)(a1 + 60) = -2;
			if (!(rand() % 6)) {
				Vector(0.020, 0.020, 0.050, Color);
				CreateParticle(32146, a1 + 252, a1 + 264, Color, 20, *(float*)(a1 + 96), a2);
			}
		}
			   break;
		case 54: {
			*(DWORD*)(a1 + 60) = -2;
			if (!(rand() % 2)) {
				Vector(0.22, 0.15000001, 0.15000001, Color);
				CreateParticle(32287, a1 + 252, a1 + 264, Color, 2, *(float*)(a1 + 96), 0);
			}
		}
			   break;
		}
	}
	RenderCryingWolf2ndObjectVisual(a1, a2);
}

void SelectCharInterfaceDowngrade()
{
	float x;
	float X;
	int CharCreate = 0;

	if (pWinWidth <= 1024)
	{
		x = pWinWidth / pWinHeightReal / 2 - 128;
		X = pWinWidth / pWinHeightReal;
	}
	if (pWinWidth >= 1360 && pWinWidth <= 1366)
	{
		x = pWinWidth / pWinHeightReal / 2 - 231;
		X = pWinWidth / pWinHeightReal / 2 + 228;
		MaoOKPosX = 13;
	}
	if (pWinWidth == 1280)
	{
		x = pWinWidth / pWinHeightReal / 2 - 108;
		X = pWinWidth / pWinHeightReal + 39;
		MaoOKPosX = -1;
	}
	if (pWinWidth == 1440)
	{
		x = pWinWidth / pWinHeightReal / 2 - 231;
		X = pWinWidth / pWinHeightReal / 2 + 254;
		MaoOKPosX = -2;
	}
	if (pWinWidth == 1600)
	{
		x = pWinWidth / pWinHeightReal / 2 - 21;
		X = pWinWidth / pWinHeightReal / 2 + 212;
		MaoOKPosX = -1;
	}
	if (pWinWidth == 1680)
	{
		x = pWinWidth / pWinHeightReal / 2 - 21;
		X = pWinWidth / pWinHeightReal / 2 + 254;
		MaoOKPosX = -2;
	}
	if (pWinWidth >= 1920)
	{
		x = pWinWidth / pWinHeightReal / 2 - 21;
		X = pWinWidth / pWinHeightReal / 2 + 212;
		MaoOKPosX = -1;
	}

	if ((GetKeyState(VK_RETURN) & 0x100) != 0)
	{
		VerificarCriacao = 1;
		keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0);
	}

	if ((GetKeyState(VK_ESCAPE) & 0x100) != 0)
	{
		VerificarCriacao = 1;
		keybd_event(VK_ESCAPE, 0, KEYEVENTF_KEYUP, 0);
	}

	if (!*(BYTE*)((int)sub_482B70() + 33948))
	{
		for (int i = 0; i < 5; ++i)
		{
			if (!*(BYTE*)(sub_96A4C0(sub_402BC0(), i) + 780))
			{
				CharCreate = 1;
				break;
			}
		}

		//-- Check Character Image
		if (CharCreate == 1)
		{
			if (PointY1 < 0)
			{
				PlayBuffer(27, 0, 0);
				PointY1 += 20;
			}
		}
		else
		{
			if (PointY1 >= -180)
			{
				PlayBuffer(27, 0, 0);
				PointY1 -= 20;
			}
		}

		RenderBitmap(88014, 221.0, PointY1 + 4, 199.0, 109.0, 0, 0, 0.77734375, 0.8515625, 1, 1, 0);

		//-- Create Character
		if (CharCreate == 1)
		{
			if (pCheckMouseOver((int)288, (int)80, (int)70, (int)25))
			{
				if (*(BYTE*)0x8793386)
				{
					VerificarCriacao = 1;
					PointY1 -= 180;
					PlayBuffer(25, 0, 0);
					sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
				}

				RenderBitmap(88015, 286.0, PointY1 + 78.6999969, 70.0, 25.0, 0, 0, 0.546875, 0.78125, 1, 1, 0);
			}
		}
	}

	if (SelectedHero == 0 ||
		SelectedHero == 1 ||
		SelectedHero == 2 ||
		SelectedHero == 3 ||
		SelectedHero == 4 ||
		SelectedHero == 5)
	{
		if (PointX11 < -10)
		{
			PlayBuffer(27, 0, 0);
			PointX11 += 20;
		}
		if (PointX12 < 193)
		{
			PlayBuffer(27, 0, 0);
			PointX12 += 20;
		}
	}
	else
	{
		if (PointX11 > -180)
		{
			PlayBuffer(27, 0, 0);
			PointX11 -= 20;
		}
		if (PointX12 > 10)
		{
			PlayBuffer(27, 0, 0);
			PointX12 -= 20;
		}
	}

	if (VerificarCriacao == 0)
	{
		if (NewChar < 0)
		{
			PlayBuffer(27, 0, 0);
			NewChar += 50;
		}
	}
	else
	{
		if (NewChar > -300)
		{
			PlayBuffer(27, 0, 0);
			NewChar -= 50;
		}
	}

	for (int i = 0; i < 5; ++i)
	{
		if (SelectedHero == i)
		{
			if (pCheckMouseOver((int)501.0, (int)274.0, (int)70.0, (int)13.0))
			{
				SelectedCharacter = i;
				SelectedHero = i;
				if (*(BYTE*)0x8793386)
				{
					PlayBuffer(25, 0, 0);
					DelectPlayerSend();
				}

			}

			if (pCheckMouseOver((int)424.0, (int)274.0, (int)70.0, (int)13.0))
			{
				SelectedCharacter = i;
				SelectedHero = i;
				if (*(BYTE*)0x8793386)
				{
					PlayBuffer(25, 0, 0);
					ConnectPlayerSend(0);
				}
			}
		}
	}

	BeginBitmap();
	pDrawImage(51523, 0, 0, 1024.0, 512.0, 0, 0, 1.0, 1.0, 1, 1, 0.0); //fundo
	EndOpengl();
}

signed int sub_9CEBF0(double a1)
{
	return (signed int)a1;
}

int DEvent;
int SlectPJ;
//----- (00403FA0) --------------------------------------------------------
void DisplayCreateCharacter(BYTE JCByte)
{
	float x;
	float NickCharX1 = 0;
	float y = 51;
	float w = 150;
	float h = 35;
	float currentx;
	int v9; // [sp+0h] [bp-4h]@1
	int GetCharactername[8] = { 20, 21, 22, 23, 24, 1687, 3150, 3175 };
	signed int v5; // eax@8
	int v6; // ST08_4@8
	signed int v7; // eax@8
	int v8; // eax@8
	int v11; // ST04_4@11
	int v17; // ST00_4@11
	int v25; // [sp+101Ch] [bp-1Ch]@32
	int v26; // [sp+1020h] [bp-18h]@26
	char v24; // [sp+814h] [bp-824h]@33
	int v29; // [sp+1034h] [bp-4h]@33
	int v48; // [sp+2Ch] [bp-7Ch]@7

	VerificarCriacao = 0;

	glDisable(GL_TEXTURE_2D);
	glColor4f(0.0, 0.0, 0.0, 1.0);
	pDrawBarForm((640 / 2) - 60, NewChar + 110, 120, 109, 0.0, 0);
	glColor4f(1.0, 1.0, 1.0, 1.0);
	glEnable(GL_TEXTURE_2D);

	v9 = (int)sub_482B70() + 33936;
	sub_404570(v9);

	EnableAlphaTest(1);
	glColor3f(1.0, 1.0, 1.0);

	if (pWinWidth <= 1024)
	{
		x = pWinWidth / pWinHeightReal / 2 - 128;
	}
	if (pWinWidth >= 1360 && pWinWidth <= 1366)
	{
		x = pWinWidth / pWinHeightReal / 2 - 233;
	}
	if (pWinWidth == 1280)
	{
		x = pWinWidth / pWinHeightReal / 2 - 108;
	}
	if (pWinWidth == 1440)
	{
		x = pWinWidth / pWinHeightReal / 2 - 183;
		NickCharX1 += -6;
	}
	if (pWinWidth == 1600)
	{
		x = pWinWidth / pWinHeightReal / 2 - 223;
		NickCharX1 += -6;
	}
	if (pWinWidth == 1680)
	{
		x = pWinWidth / pWinHeightReal / 2 - 183;
		NickCharX1 += -6;
	}
	if (pWinWidth >= 1920)
	{
		x = pWinWidth / pWinHeightReal / 2 - 223;
		NickCharX1 += -6;
	}


	int Personage;

	//-- Tela de cria��o
	RenderBitmap(88009, 214.0, NewChar + 10, 213.0, 375, 0, 0, 0.83203125, 0.73203125, 1, 1, 0);
	//-- Nome da classe
	pSetFont(pTextThis(), (int)pFontNormal2);
	pSetTextColor(pTextThis(), 168, 136, 49, 0xFFu);
	pDrawText(pTextThis(), (int)(x + 92.0 + NickCharX1), (int)(NewChar + 212), pGetTextLine(pTextLineThis, GetCharactername[*(BYTE*)0x7BD0483]), 70, 0, 3, 0);
	pSetFont(pTextThis(), *(DWORD*)0xE8C588);

	SlectPJ = *(BYTE*)0x7BD0483;

	Personage = 3;

	if (pCheckMouseOver((int)386, (int)208, (int)20.0, (int)22.0) && *(BYTE*)0x8793386 && GetTickCount() > DEvent + 600 && SlectPJ < Personage)
	{
		SlectPJ++;
		*(DWORD*)(v9 + 2640) = SlectPJ;
		JCButtonShow(v9);
		*(BYTE*)0x7BD0483 = SlectPJ;
		DEvent = GetTickCount();
		PlayBuffer(25, 0, 0);
		RenderBitmap(88010, 386.0, NewChar + 208.0, 19.0, 20.0, 0, 0, 0.59375, 0.625, 1, 1, 0);
	}

	if (SlectPJ == Personage)
	{
		glDisable(GL_TEXTURE_2D);
		glColor4f(0.0, 0.0, 0.0, 0.7);
		pDrawBarForm(385.0, NewChar + 207.0, 19, 19, 0.0, 0);
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glEnable(GL_TEXTURE_2D);
	}

	if (pCheckMouseOver((int)366, (int)208, (int)20.0, (int)22.0) && *(BYTE*)0x8793386 && GetTickCount() > DEvent + 600 && SlectPJ > CLASS_WIZARD)
	{
		SlectPJ--;
		*(DWORD*)(v9 + 2640) = SlectPJ;
		JCButtonShow(v9);
		*(BYTE*)0x7BD0483 = SlectPJ;
		DEvent = GetTickCount();
		PlayBuffer(25, 0, 0);
		RenderBitmap(88008, 366.0, NewChar + 208.0, 19.0, 20.0, 0, 0, 0.59375, 0.625, 1, 1, 0);
	}

	if (SlectPJ == CLASS_WIZARD)
	{
		glDisable(GL_TEXTURE_2D);
		glColor4f(0.0, 0.0, 0.0, 0.7);
		pDrawBarForm(365.0, NewChar + 207.0, 19, 19, 0.0, 0);
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glEnable(GL_TEXTURE_2D);
	}

	//-- Bot�o Cancel
	if (pCheckMouseOver((int)237, (int)361, 72, 21))
	{
		if (*(BYTE*)0x8793386 && GetTickCount() > DEvent + 300)
		{
			VerificarCriacao = 1;
			JGCloseChar((int)sub_482B70(), v9);
			PlayBuffer(25, 0, 0);
		}
		RenderBitmap(88006, 235.0, NewChar + 359, 72.0, 21.0, 0, 0, 0.5625, 0.65625, 1, 1, 0);
	}

	//-- Bot�o OK - Criar char
	if (pCheckMouseOver((int)338, (int)363, 72, 21))
	{
		if ((GetKeyState(VK_LBUTTON) & 0x100) != 0)
		{
			VerificarCriacao = 1;
			keybd_event(VK_RETURN, 1, 0, 0);
			PlayBuffer(25, 0, 0);
		}
		else
		{
			keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0);
		}
		RenderBitmap(88007, 335.0, NewChar + 359, 72.0, 21.0, 0, 0, 0.5625, 0.65625, 1, 1, 0);
	}

	//-- Campo de Nome do Personagem
	if (*(DWORD*)0xE60960 == 1)
	{
		(*(void(__thiscall**)(int))(*(DWORD*)*(DWORD*)0xE8C544 + 20))(*(DWORD*)0xE8C544);
		SetBoundInputField(*(DWORD*)0xE8C544, x + 108.0, y + NewChar + 140.0);
	}
	else if (!*(DWORD*)0xE60960)
	{
		v8 = SpiriteGetInfoY(v9 + 120) + 21;
		v11 = sub_9CEBF0((double)v8 / *(float*)0xE7C3D8);
		v48 = SpiriteGetInfoX(v9 + 120);
		v17 = sub_9CEBF0((double)(v48 + 78) / *(float*)0xE7C3D4);
		sub_596EF0(v17, v11, 0);
	}
}

int __fastcall SelectServerBarPosition(int a1, int a2, signed int a3, signed int a4, char a5)
{
	return DisplayInfoBarCharacter(a1, a2, a3 + 170, a4 + 45, a5);
}

void EffectSystem(int a1, int a2, int a3, int color, int a5, float a6, int a7)
{
	EnableAlphaBlend();
	float v66 = (double)(WorldTime % 3600);
	RenderCircle(32142, a2, 50.0, 70.0, 200.0, v66, 0.0, 0.0);
}

int __fastcall DisplayInfoBarCharacterPosition(int a1, int a2, signed int a3, signed int a4, char a5)
{
	int PosY = 0;
	if (pWinWidth == 1280)
	{
		PosY += 23;
	}
	else if (pWinWidth < 1024)
	{
		PosY += -26;
	}
	return DisplayInfoBarCharacter(a1, a2, a3, a4 + 150 + PosY, a5);
}

void ClassFaceDimension(GLint x, int y, GLsizei width, GLsizei height)
{
	int PosX = 0;
	int PosY = 0;

	if (pWinWidth == 1280)
	{
		PosY += 26;
		PosX += -15;
	}
	else if (pWinWidth == 1440)
	{
		PosY += 20;
		PosX += -8;
	}
	else if (pWinWidth == 1600)
	{
		PosY += 20;
		PosX += 2;
	}
	else if (pWinWidth == 1680)
	{
		PosY += 30;
		PosX += 4;
	}
	else if (pWinWidth == 1024)
	{
		PosX += -38;
	}
	else if (pWinWidth < 1024)
	{
		PosY += -36;
		PosX += -76;
	}
	else if (pWinWidth >= 1920)
	{
		PosY += 35;
		PosX += 17;
	}

	BeginOpengl(x + 72 - PosX, y + NewChar - 8 - PosY, 75, 75);
}

void LoginScreen97D(int a1, DWORD* a2)
{
	if (SceneFlag == 4) /*Select Character*/
	{

		if (gSelectBackground.UseCamera)
		{
			// camera definida pelo Lua (SetSelectCamera)
			*(float*)0xE61E3C = gSelectBackground.CamDist;
			*(float*)0x87933D0 = gSelectBackground.AngX;
			*(float*)0x87933D4 = gSelectBackground.AngY;
			*(float*)0x87933D8 = gSelectBackground.AngZ;
			*(float*)0x87933DC = gSelectBackground.PosX;
			*(float*)0x87933E0 = gSelectBackground.PosY;
			*(float*)0x87933E4 = gSelectBackground.PosZ;
			*(float*)0xE61E40 = gSelectBackground.Fov;
		}
		else
		{
			*(float*)0xE61E3C = 3500.0;
			*(float*)0x87933D0 = -82.0; //meu Y
			*(float*)0x87933D4 = 0.0;
			*(float*)0x87933D8 = -90.0;
			*(float*)0x87933DC = 9758.9297;
			*(float*)0x87933E0 = 18913.109;
			*(float*)0x87933E4 = 500.0;
			*(float*)0xE61E40 = 35.0;
		}
	}
}


__declspec(naked) void SelectCharacterSize1S0()
{
	static float D27AF0;
	D27AF0 = 0.93f;

	static DWORD Bufferx = 0x0057F165;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [ECX + 0x368]
		JMP[Bufferx]

	}
}

__declspec(naked) void SelectCharacterSize2S0()
{
	static float D27AF0;
	D27AF0 = 0.93f;

	static DWORD Bufferx = 0x0057F154;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [EAX + 0x368]
		JMP[Bufferx]

	}
}

__declspec(naked) void SelectCharacterSize3S0()
{
	static float D27AF0;
	D27AF0 = 0.86f;

	static DWORD Bufferx = 0x0057F176;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [EDX + 0x368]
		JMP[Bufferx]

	}
}

__declspec(naked) void SelectCharacterSize4S0()
{
	static float D27AF0;
	D27AF0 = 0.94f;

	static DWORD Bufferx = 0x0057F143;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [EDX + 0x368]
		JMP[Bufferx]

	}
}

__declspec(naked) void SelectCharacterSize5S0()
{
	static float D27AF0;
	D27AF0 = 0.92f;

	static DWORD Bufferx = 0x0057F187;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [EAX + 0x368]
		JMP[Bufferx]

	}
}

__declspec(naked) void SelectCharacterSize6S0()
{
	static float D27AF0;
	D27AF0 = 0.89f;

	static DWORD Bufferx = 0x0057F198;
	_asm
	{
		FLD DWORD PTR DS : [D27AF0]
		FSTP DWORD PTR DS : [ECX + 0x368]
		JMP[Bufferx]

	}
}
__declspec(naked) void SelectCharacterSize7S0()
{
	static float D2B994;
	D2B994 = 1.03f;
	static DWORD Bufferx = 0x0057F198;
	_asm
	{
		FLD DWORD PTR DS : [D2B994]
		FSTP DWORD PTR DS : [EDX + 0x368]
		JMP[Bufferx]

	}
}

#define sub_4D5EC0R			((int(*)()) 0x4D5EC0)

void MULOGOS22()
{
	if (*(int*)0x0E609E8 == 2)
	{
		glColor3f(1.0f, 1.0f, 1.0f);
		*(float*)0xE8CB18 = *(float*)0xE8CB18 + 0.01999999955296516;
		if (*(float*)0xE8CB18 > 10.0)
			*(float*)0xE8CB18 = 10.0;
		pGLSwitchBlend();
		float v25 = *(float*)0xE8CB18 - 0.300000011920929;
		float v24 = *(float*)0xE8CB18 - 0.300000011920929;
		float v23 = *(float*)0xE8CB18 - 0.300000011920929;
		float v22 = *(float*)0xE8CB18 - 0.300000011920929;
		glColor4f(v22, v23, v24, v25);
		pDrawImage(531019, 217.60001, 38.0, 204.8, 102.4, 0.0, 0.0, 1.0, 1.0, 1, 1, 0.0);
		pSetBlend(1);
		glColor4f(*(float*)0xE8CB18, *(float*)0xE8CB18, *(float*)0xE8CB18, *(float*)0xE8CB18);
		pDrawImage(531018, 217.60001, 38.0, 204.8, 102.4, 0.0, 0.0, 1.0, 1.0, 1, 1, 0.0);
		//
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glEnable(GL_TEXTURE_2D);


		// PARTE PRETA HALLOWEEN

		//int locX = 255;
		//int locY = 460;
		//
		//EnableAlphaTest(1);
		//glColor3f(1.0, 1.0, 1.0);
		//pDrawImage(590063, -0.20001, 452.0, 1220.8, 47.4, 0.0, 0.0, 1.0, 1.0, 1, 1, 0.0);
		//pDrawText(pTextThis(), locX, locY, gCustomMessage.GetMessage(54), 100, 0, 15, 0);
	}
}

void sub_4D5EC022()
{
	MULOGOS22();
	sub_4D5EC0R();
}

DWORD SelectCharacterCord(int a4)
{
	int v4; // ST1C_4@11
	char v5; // ST14_1@12
	void* v6; // eax@12
	int v7; // eax@12
	DWORD result; // eax@12
	int v9; // [sp+14h] [bp-20h]@5
	int v10; // [sp+18h] [bp-1Ch]@5
	float v11; // [sp+1Ch] [bp-18h]@5
	float v12; // [sp+20h] [bp-14h]@0
	float v13; // [sp+24h] [bp-10h]@0
	signed int i; // [sp+28h] [bp-Ch]@3
	signed int v15; // [sp+30h] [bp-4h]@3

	sub_63CB40();
	sub_4D5130(*(BYTE*)(a4 + 4));

	if (*(int*)0x0E609E8 == 4)
		World = (gSelectBackground.WorldId > 0) ? gSelectBackground.WorldId : 74;
	v15 = 8;

	for (i = 0; i < *(BYTE*)(a4 + 6); ++i)
	{
		v9 = v15 + a4;
		v10 = (unsigned __int8)sub_587380(*(BYTE*)(v15 + a4 + 15));
		v11 = 0.0;

		switch (*(BYTE*)(v15 + a4))
		{
		case 0:
			v12 = 8008.0;
			v13 = 18885.0;
			v11 = 115.0;
			break;
		case 1:
			v12 = 0.0f;// 7986.0;
			v13 = 0.0f;// 19145.0;
			v11 = 0.0f;// 90.0;
			break;
		case 2:
			v12 = 0.0f;// 7986.0;
			v13 = 0.0f;// 19145.0;
			v11 = 0.0f;// 90.0;
			break;
		case 3:
			v12 = 0.0f;// 7986.0;
			v13 = 0.0f;// 19145.0;
			v11 = 0.0f;// 90.0;
			break;
		case 4:
			v12 = 0.0f;// 7986.0;
			v13 = 0.0f;// 19145.0;
			v11 = 0.0f;// 90.0;
			break;
		default:
			break;
		}

		//gInfoLog.Output(LOG_CHAT,"[%d] [%d]",v9,v10);
		v4 = sub_586DA0(*(BYTE*)v9, v10, 0, v12, v13, v11);//-- Agrega Personaje con Coordenada

		*(WORD*)(v4 + 130) = *(WORD*)(v9 + 12);

		*(BYTE*)(v4 + 21) = *(BYTE*)(v9 + 14);

		sub_9CF1C0((char*)(v4 + 56), (const void*)(v9 + 1), 0xAu);

		*(BYTE*)(v4 + 66) = 0;

		sub_57FD90(*(BYTE*)v9, v9 + 16, 0, 0);
		//pPreviewCharSet(*(BYTE *)v9, (BYTE *)(v9 + 16), 0, 0);//-- Mostrar Equipamiento

		*(BYTE*)(v4 + 24) = *(BYTE*)(v9 + 33);

		v15 += 34;
	}

	*(DWORD*)0x87935A4 = 51;

	pWarehouseExSet(pWarehouseExThis(pWindowThis()), *(BYTE*)(a4 + 7));

	result = GetTickCount();
	*(DWORD*)0xE8CB30 = result;
	return result;
}

signed int SelectCreateCharCoord(int a4)
{
	double v1; // ST14_4@8
	float v4; // ST14_4@8
	int v5; // eax@8
	void* v6; // ST24_4@10
	signed int result; // eax@10
	void* v8; // eax@12
	void* v9; // eax@14
	float v10; // [sp+1Ch] [bp-14h]@2
	DWORD v11; // [sp+20h] [bp-10h]@8
	float v12; // [sp+24h] [bp-Ch]@0
	float v13; // [sp+28h] [bp-8h]@0

	if (*(BYTE*)(a4 + 4) == 1)
	{
		v10 = 0.0;

		switch (*(BYTE*)(a4 + 15))
		{
		case 0:
			v12 = 8282.0;
			v13 = 19845.0;
			v10 = 35.0;
			break;
		case 1:
			v12 = 0.0f;// 8282.0;
			v13 = 0.0f;// 19845.0;
			v10 = 0.0f;// 35.0;
			break;
		case 2:
			v12 = 0.0f;// 8282.0;
			v13 = 0.0f;// 19845.0;
			v10 = 0.0f;// 35.0;
			break;
		case 3:
			v12 = 0.0f;// 8282.0;
			v13 = 0.0f;// 19845.0;
			v10 = 0.0f;// 35.0;
			break;
		case 4:
			v12 = 0.0f;// 8282.0;
			v13 = 0.0f;// 19845.0;
			v10 = 0.0f;// 35.0;
			break;
		default:
			break;
		}
		sub_57D760(*(BYTE*)(a4 + 15));
		sub_586DA0(*(BYTE*)(a4 + 15), (unsigned __int8)*(BYTE*)0x7BD0483, *(BYTE*)0x7BD0484, v12, v13, v10);
		//v1 = *(BYTE *)(a4 + 15);
		v11 = ((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), *(BYTE*)(a4 + 15));
		if (v11)
		{
			*(WORD*)(v11 + 130) = *(WORD*)(a4 + 16);
			*(BYTE*)(v11 + 19) = sub_587380(*(BYTE*)(a4 + 18));
			sub_9CF1C0((char*)(v11 + 56), (const void*)(a4 + 5), 0xAu);
			*(BYTE*)(v11 + 66) = 0;
		}
		*(DWORD*)0x87935A4 = 53;
		v6 = (char*)sub_482B70();
		sub_668520((char*)sub_482B70());
		sub_4057B0((char*)sub_482B70() + 32632);
		result = sub_402AD0((char*)sub_482B70() + 36744);
	}
	else
	{
		result = *(BYTE*)(a4 + 4);
		if (*(BYTE*)(a4 + 4))
		{
			if (*(BYTE*)(a4 + 4) == 2)
			{
				result = sub_484A10(sub_482B70(), 55, 0);
			}
		}
		else
		{
			result = sub_484A10(sub_482B70(), 54, 0);
		}
	}
	return result;
}

void CharacterTeleport(int a1, float a2, float a3, float a4)
{
	if (*(DWORD*)(MAIN_SCREEN_STATE) == 4)
	{
		int v5 = ((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), a1);
		int v8 = v5 + 776;
		if (v5)
		{
			*(float*)(v8 + 156) = 0.30000001;
			*(float*)(v8 + 160) = 0.30000001;
			*(float*)(v8 + 164) = 0.30000001;
			*(float*)(v8 + 252) = a2;
			*(float*)(v8 + 256) = a3;
			*(float*)(v8 + 272) = a4;
		}
	}
}

void CharacterCharacteristics(int a1, float a2, float xpos)
{
	char* Name;
	//char* Status;
	int Class;
	char Reset[256];
	char Level[256];
	float X = 471;
	float Y = 51;
	int This = (int)sub_482B70() + 36744;
	int Hero00 = This;
	Hero00 = *(DWORD*)(This + 4) + 368 * a1;
	//
	Name = strcpy((char*)Hero00 + 176, (const char*)(*((DWORD*)Hero00 + 42) + 56));
	//Status = (char*)Hero00 + 240;
	Class = sub_587620(*(BYTE*)(*(DWORD*)(Hero00 + 168) + 19));
	gInterface.DrawFormat(eGold, X + 67 + xpos, Y + 6 + a2, 190, 2, (const char*)Name);
	gInterface.DrawFormat(eWhite180, X + 35 + xpos, Y + 20 + a2, 190, 0, (const char*)Class);
	//gInterface.DrawFormat(eWhite180, X - 50 + xpos, Y + 7 + a2, 190, 4, (const char*)Status);
	wsprintf(Level, "Level: %d", *(WORD*)(*(DWORD*)(Hero00 + 168) + 130));
	pSetTextColor(pTextThis(), 160, 160, 160, 0xFF);
	pDrawText(pTextThis(), X - 74 + xpos, Y + 20 + a2, Level, 190, 0, 4, 0);
}

void CharacterSelect360()
{
	for (int i = 0; i < 5; i++)
	{
		int v5 = ((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), i);
		int v8 = v5 + 776;
		if (gInterface.IsWorkZone(CharacterSelect))
		{
			*(float*)(v8 + 272) = *(float*)(v8 + 272) + 5.0;  //AQUI � A VELOCIDADE DO GIRO DA 360
		}
		else
		{
			*(float*)(v8 + 272) = 70;
		}
	}
}

// Usado quando a lista de personagens e desenhada pelo Lua (CharacterList.lua).
// Mantem apenas: moldura (Layout.tga), atalhos Enter/Esc e a animacao do painel de criacao.
void SelectCharFrameOnly()
{
	if ((GetKeyState(VK_RETURN) & 0x100) != 0)
	{
		VerificarCriacao = 1;
		keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0);
	}

	if ((GetKeyState(VK_ESCAPE) & 0x100) != 0)
	{
		VerificarCriacao = 1;
		keybd_event(VK_ESCAPE, 0, KEYEVENTF_KEYUP, 0);
	}

	if (VerificarCriacao == 0)
	{
		if (NewChar < 0)
		{
			PlayBuffer(27, 0, 0);
			NewChar += 50;
		}
	}
	else
	{
		if (NewChar > -300)
		{
			PlayBuffer(27, 0, 0);
			NewChar -= 50;
		}
	}

	BeginBitmap();
	pDrawImage(51523, 0, 0, 1024.0, 512.0, 0, 0, 1.0, 1.0, 1, 1, 0.0); //moldura
	EndOpengl();
}

void pSetCursorGlobal()
{
	if (*(int*)0x0E609E8 != 4)
	{
		if (PointX11 > -180)
		{
			PlayBuffer(27, 0, 0);
			PointX11 -= 20;
		}
		if (PointX12 > 10)
		{
			PlayBuffer(27, 0, 0);
			PointX12 -= 20;
		}
	}

	if (*(int*)0x0E609E8 == 4)
	{
		if (PointSY1 <= 220)
		{
			PointSY1 += 20;
		}

		if (gSelectBackground.LuaUI)
		{
			SelectCharFrameOnly();
		}
		else
		{
			SelectCharInterfaceDowngrade();
		}
	}

	if (*(DWORD*)(MAIN_SCREEN_STATE) == 4 && !gSelectBackground.LuaUI)
	{
		float X = 471;
		float Y = 51;
		float XButton = 0;
		float YButton = 0;

		XButton = -50;
		YButton = 35;
		//
		if (!*(BYTE*)((int)sub_482B70() + 33948))
		{
			//Create Select
			//OK
			if (gInterface.IsWorkZone(CharacterOption_Button1))
			{
				if (gInterface.Data[CharacterOption_Button1].OnClick)
				{
					gInterface.DrawButton(CharacterOption_Button1, 472 + XButton, 238 + YButton, 0, 32);
				}
				else
				{
					gInterface.DrawButton(CharacterOption_Button1, 472 + XButton, 238 + YButton, 0, 16);
				}
			}
			else
			{
				gInterface.DrawButton(CharacterOption_Button1, 472 + XButton, 238 + YButton, 0, 0);
			}
			//DELETE
			if (gInterface.IsWorkZone(CharacterOption_Button2))
			{
				if (gInterface.Data[CharacterOption_Button2].OnClick)
				{
					gInterface.DrawButton(CharacterOption_Button2, 549 + XButton, 238 + YButton, 0, 32);
				}
				else
				{
					gInterface.DrawButton(CharacterOption_Button2, 549 + XButton, 238 + YButton, 0, 16);
				}
			}
			else
			{
				gInterface.DrawButton(CharacterOption_Button2, 549 + XButton, 238 + YButton, 0, 0);
			}

			gInterface.DrawFormat(eGold, X + 25 + XButton, Y + 20 + 207, 190, 2, "Conectar");
			gInterface.DrawFormat(eGold, X + 105 + XButton, Y + 20 + 207, 190, 2, "Deletar");
			//0
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 0) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button1))
				{
					if (gInterface.Data[CharacterSelect_Button1].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, 51 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, 51 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, 51 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, Y + 13 + YButton, 210, 3, "Sem Personagem");
			}
			//1
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 1) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button2))
				{
					if (gInterface.Data[CharacterSelect_Button2].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, 88 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, 88 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, 88 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, 88 + 13 + YButton, 210, 3, "Sem Personagem");
			}
			//2
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 2) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button3))
				{
					if (gInterface.Data[CharacterSelect_Button3].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, 125 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, 125 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, 125 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, 125 + 13 + YButton, 210, 3, "Sem Personagem");
			}

			//3
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 3) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button4))
				{
					if (gInterface.Data[CharacterSelect_Button4].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, 162 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, 162 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, 162 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, 162 + 13 + YButton, 210, 3, "Sem Personagem");
			}
			//4
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 4) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button5))
				{
					if (gInterface.Data[CharacterSelect_Button5].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, 199 + 13 + YButton, 210, 3, "Sem Personagem");
			}
			//4
			if (!*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 4) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button5))
				{
					if (gInterface.Data[CharacterSelect_Button5].OnClick)
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 70);
						sub_483B20((int)sub_482B70(), (int)sub_482B70() + 33936);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 35);
					}
				}
				else
				{
					gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, 199 + YButton, 0, 0);
				}
				gInterface.DrawFormat(eWhite180, X - 29 + XButton, 199 + 13 + YButton, 210, 3, "Sem Personagem");
			}

			//Character Select
			CharacterSelect360();
			if (*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 0) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button1))
				{

					if (gInterface.Data[CharacterSelect_Button1].OnClick)
					{
						PlayBuffer(25, 0, 0);
						SelectedHero = 0;
						CharacterTeleport(0, 8590, 18785, 75);
						CharacterTeleport(1, 0.0, 8171.84083, 90.0);
						CharacterTeleport(2, 0.0, 8171.84083, 90.0);
						CharacterTeleport(3, 0.0, 8171.84083, 90.0);
						CharacterTeleport(4, 0.0, 8171.84083, 90.0);

						gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, Y + YButton, 0, 70);
					}
					else
					{
						if (SelectedHero == 0)
						{
							gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, Y + YButton, 0, 70);
						}
						else
						{
							gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, Y + YButton, 0, 35);
						}
					}

					if (SelectedHero == 0)
					{
						SelectedCharacter = 0;
					}
				}
				else
				{
					if (SelectedHero == 0)
					{
						gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, Y + YButton, 0, 70);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button1, 471 + XButton, Y + YButton, 0, 0);
					}
				}
				CharacterCharacteristics(0, 0 + YButton, XButton);
			}
			//1
			if (*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 1) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button2))
				{

					if (gInterface.Data[CharacterSelect_Button2].OnClick)
					{
						PlayBuffer(25, 0, 0);
						SelectedHero = 1;
						CharacterTeleport(1, 8590, 18785, 75);
						CharacterTeleport(0, 0.0, 8171.94083, 90.0);
						CharacterTeleport(2, 0.0, 8171.94083, 90.0);
						CharacterTeleport(3, 0.0, 8171.94083, 90.0);
						CharacterTeleport(4, 0.0, 8171.94083, 90.0);

						gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, Y + 37 + YButton, 0, 70);
					}
					else
					{
						if (SelectedHero == 1)
						{
							gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, Y + 37 + YButton, 0, 70);
						}
						else
						{
							gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, Y + 37 + YButton, 0, 35);
						}
					}
					SelectedCharacter = SelectedHero;
				}
				else
				{
					if (SelectedHero == 1)
					{
						gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, Y + 37 + YButton, 0, 70);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button2, 471 + XButton, Y + 37 + YButton, 0, 0);
					}
				}
				CharacterCharacteristics(1, 37 + YButton, XButton);
			}
			//2
			if (*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 2) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button3))
				{

					if (gInterface.Data[CharacterSelect_Button3].OnClick)
					{
						PlayBuffer(25, 0, 0);
						SelectedHero = 2;
						CharacterTeleport(2, 8590, 18785, 75);
						CharacterTeleport(0, 0.0, 8171.94083, 90.0);
						CharacterTeleport(1, 0.0, 8171.94083, 90.0);
						CharacterTeleport(3, 0.0, 8171.94083, 90.0);
						CharacterTeleport(4, 0.0, 8171.94083, 90.0);

						gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, Y + 74 + YButton, 0, 70);
					}
					else
					{
						if (SelectedHero == 2)
						{
							gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, Y + 74 + YButton, 0, 70);
						}
						else
						{
							gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, Y + 74 + YButton, 0, 35);
						}
					}

					SelectedCharacter = SelectedHero;
				}
				else
				{
					if (SelectedHero == 2)
					{
						gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, Y + 74 + YButton, 0, 70);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button3, 471 + XButton, Y + 74 + YButton, 0, 0);
					}
				}
				CharacterCharacteristics(2, 74 + YButton, XButton);
			}
			//3
			if (*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 3) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button4))
				{

					if (gInterface.Data[CharacterSelect_Button4].OnClick)
					{
						PlayBuffer(25, 0, 0);
						SelectedHero = 3;
						CharacterTeleport(3, 8590, 18785, 75);
						CharacterTeleport(0, 0.0, 8171.94083, 90.0);
						CharacterTeleport(1, 0.0, 8171.94083, 90.0);
						CharacterTeleport(2, 0.0, 8171.94083, 90.0);
						CharacterTeleport(4, 0.0, 8171.94083, 90.0);

						gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, Y + 111 + YButton, 0, 70);
					}
					else
					{
						if (SelectedHero == 3)
						{
							gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, Y + 111 + YButton, 0, 70);
						}
						else
						{
							gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, Y + 111 + YButton, 0, 35);
						}
					}
					SelectedCharacter = SelectedHero;
				}
				else
				{
					if (SelectedHero == 3)
					{
						gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, Y + 111 + YButton, 0, 70);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button4, 471 + XButton, Y + 111 + YButton, 0, 0);
					}
				}

				CharacterCharacteristics(3, 111 + YButton, XButton);
			}
			//4
			if (*(BYTE*)(((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x0096A4C0)(((LPVOID(*)()) 0x402BC0)(), 4) + 780))
			{
				if (gInterface.IsWorkZone(CharacterSelect_Button5))
				{

					if (gInterface.Data[CharacterSelect_Button5].OnClick)
					{
						PlayBuffer(25, 0, 0);
						SelectedHero = 4;
						CharacterTeleport(4, 8590, 18785, 75);
						CharacterTeleport(0, 0.0, 8171.94083, 90.0);
						CharacterTeleport(1, 0.0, 8171.94083, 90.0);
						CharacterTeleport(2, 0.0, 8171.94083, 90.0);
						CharacterTeleport(3, 0.0, 8171.94083, 90.0);

						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, Y + 148 + YButton, 0, 70);
					}
					else
					{
						if (SelectedHero == 4)
						{
							gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, Y + 148 + YButton, 0, 70);
						}
						else
						{
							gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, Y + 148 + YButton, 0, 35);
						}
					}

					SelectedCharacter = SelectedHero;
				}
				else
				{
					if (SelectedHero == 4)
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, Y + 148 + YButton, 0, 70);
					}
					else
					{
						gInterface.DrawButton(CharacterSelect_Button5, 471 + XButton, Y + 148 + YButton, 0, 0);
					}
				}
				CharacterCharacteristics(4, 148 + YButton, XButton);
			}
		}
	}

	((void(__cdecl*)())0x005BB0B0)();
}

void CSceneS0()
{
	SetCompleteHook(0xE8, 0x005EDDA9, &RenderSSCObjectVisualS0);
	SetDword(0x004D75F0, 94);//Select Server
	/*Select Server*/
	SetCompleteHook(0xE8, 0x004D76FB, &LoginScreenS0);//Select Server
	SetCompleteHook(0xE8, 0x004D79C3, &LoginScreenS0);//Select Server
	SetDword((0x004D7A0E), 480);//Select Server
	SetByte((0x004D7A18), 0);//Select Server
	MemorySet(0x0040A7EF, 0x90, 0x5); //Remover Button Menu SelectServer/
	MemorySet(0x0040A87E, 0x90, 0x5); //Remover Button Cr�dits SelectServer/
	SetCompleteHook(0xE8, 0x004D7EB1, &sub_4D5EC022);
	SetCompleteHook(0xE8, 0x00414086, &SelectServerBarPosition); //MOV
	SetCompleteHook(0xE8, 0x004140D9, &SelectServerBarPosition); //MOV
	SetCompleteHook(0xE8, 0x0041412E, &SelectServerBarPosition); //MOV
	SetCompleteHook(0xE8, 0x004141BA, &SelectServerBarPosition); //MOV
	SetCompleteHook(0xE8, 0x004141EB, &SelectServerBarPosition); //MOV
	SetByte(0x00414239, 0); //POSI��O X DA SEGUNDA BARRA
	SetCompleteHook(0xE8, 0x004D7534, &EffectSystem);							//Efeito ao selecionar o Personagem
	SetCompleteHook(0xE8, 0x004D7568, &EffectSystem);							//Efeito ao selecionar o Personagem
	SetCompleteHook(0xE8, 0x401DA0 + 0xA9, &DisplayInfoBarCharacterPosition);	//Posicionamento das informa��es dos personagens
	SetCompleteHook(0xE8, 0x0040464E, &ClassFaceDimension);						//Posicionamento dos avatares das classes
	SetCompleteHook(0xE9, 0x00403126, 0x00403243);								//Destaca o ESC sobre o Menu Create Char
	SetCompleteHook(0xE9, 0x00403FA0, &DisplayCreateCharacter);					//Tela de cria��o de personagem

	//	SetDword((LPVOID)0x004D6C2C, 75);										//World Number Scene 97d
	SetCompleteHook(0xE8, 0x004D712A, &LoginScreen97D);							//Coordenadas para o Mapa e Personagens

	SetDword((0x004D6C73), 0);
	SetByte((0x00402106), 0);
	SetDword((0x004053A2 + 1), 51522); //remove deco.tga
	SetDword((0x00401D2F + 1), 51522);	//remove characterex
	SetDword((0x004D752F + 1), 51522);
	SetDword((0x004D7563 + 1), 51522);

	SetCompleteHook(0xE8, 0x00663E8C, &SelectCharacterCord);					//Coordenadas do Personagem
	SetCompleteHook(0xE8, 0x00663E9D, &SelectCreateCharCoord);					//Coordenadas do Personagem

	MemorySet(0x00405380, 0x90, 0x20D);											//Remo��o dos bot�es
	MemorySet(0x004D74CE, 0x90, 0x5);											//Remo��o dos Efeitos em Bolas
	MemorySet(0x004D7568, 0x90, 0x5);											//Remo��o dos Efeitos em Bolas
	MemorySet(0x004D7465, 0x90, 0x5);											//Remo��o dos Efeitos no Ch�o

	SetByte((0x004D7183), 0);													//Resolu��o da Tela de Personagem
	SetDword((0x00401D2F + 1), 51522);											//Removido CharacterEx.tga
	SetDword((0x004D7179), 480);												//Resolu��o da Tela de Personagem

	SetCompleteHook(0xE9, 0x0057F159, &SelectCharacterSize1S0);		//Tamanho do Personagem PJ1
	SetCompleteHook(0xE9, 0x0057F148, &SelectCharacterSize2S0);		//Tamanho do Personagem PJ2
	SetCompleteHook(0xE9, 0x0057F16A, &SelectCharacterSize3S0);		//Tamanho do Personagem PJ3
	SetCompleteHook(0xE9, 0x0057F137, &SelectCharacterSize4S0);		//Tamanho do Personagem PJ4
	SetCompleteHook(0xE9, 0x0057F17B, &SelectCharacterSize5S0);		//Tamanho do Personagem PJ5
	SetCompleteHook(0xE9, 0x0057F18C, &SelectCharacterSize6S0);		//Tamanho do Personagem PJ6
	SetCompleteHook(0xE9, 0x0057F19D, &SelectCharacterSize7S0);		//Tamanho do Personagem PJ7	


	SetCompleteHook(0xE8, 0x004D5EE6, &pSetCursorGlobal);
}
