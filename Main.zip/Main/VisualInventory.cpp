#include "stdafx.h"
#include "VisualInventory.h"
#include "Util.h"
#include "Console.h"
#include "HelperSystem.h"
#include "HelperManager.h"
#include "Item.h"
#include "ItemMove.h"
#include "LuaStack.hpp"
#include "Descriptions.h"
#include "CustomWing.h"
#include "CustomMessage.h"
#include "PersonalShop.h"
#include "LoadFiles.h"

using namespace luaaa;

VisualInventory gVisualInventory;

void CreateVisualDescription(int Line, char* text, int color, int bold) {
	memcpy(textLine[Line], text, 100);
	textColor[Line] = color;
	textBold[Line] = bold;
}

void setVisualInventory(int switchVisual, int originalDescription) {
	gVisualInventory.InventoryVisualSwitch = switchVisual;
	gVisualInventory.InventoryVisualOriginalDescription = originalDescription;

	gVisualInventory.InitFromLua();
}

VisualInventory::VisualInventory() : m_Lua(true)
{
	gVisualInventory.InventoryVisualOpen = 0;

	this->InventoryVisualSwitch = 0;
	this->InventoryVisualOriginalDescription = 0;

	//Sw 1
	m_ItemInventoryEquip[0].x = 15;
	m_ItemInventoryEquip[0].y = 87;
	m_ItemInventoryEquip[0].width = 46;
	m_ItemInventoryEquip[0].height = 66;

	//Sw2
	m_ItemInventoryEquip[1].x = 135;
	m_ItemInventoryEquip[1].y = 87;
	m_ItemInventoryEquip[1].width = 46;
	m_ItemInventoryEquip[1].height = 66;

	//Helm
	m_ItemInventoryEquip[2].x = 75;
	m_ItemInventoryEquip[2].y = 44;
	m_ItemInventoryEquip[2].width = 46;
	m_ItemInventoryEquip[2].height = 46;

	//Armor
	m_ItemInventoryEquip[3].x = 75;
	m_ItemInventoryEquip[3].y = 87;
	m_ItemInventoryEquip[3].width = 46;
	m_ItemInventoryEquip[3].height = 66;

	//Pants
	m_ItemInventoryEquip[4].x = 75;
	m_ItemInventoryEquip[4].y = 150;
	m_ItemInventoryEquip[4].width = 46;
	m_ItemInventoryEquip[4].height = 46;

	//Gloves
	m_ItemInventoryEquip[5].x = 15;
	m_ItemInventoryEquip[5].y = 150;
	m_ItemInventoryEquip[5].width = 46;
	m_ItemInventoryEquip[5].height = 46;

	//Boots
	m_ItemInventoryEquip[6].x = 135;
	m_ItemInventoryEquip[6].y = 150;
	m_ItemInventoryEquip[6].width = 46;
	m_ItemInventoryEquip[6].height = 46;

	//asa
	m_ItemInventoryEquip[7].x = 120;
	m_ItemInventoryEquip[7].y = 44;
	m_ItemInventoryEquip[7].width = 61;
	m_ItemInventoryEquip[7].height = 46;

	//Pet
	m_ItemInventoryEquip[8].x = 15;
	m_ItemInventoryEquip[8].y = 44;
	m_ItemInventoryEquip[8].width = 46;
	m_ItemInventoryEquip[8].height = 46;

	gVisualInventory.m_ItemsInfo.clear();
}

VisualInventory::~VisualInventory()
{
	//gVisualInventory.Release();
}

void VisualInventory::Release()
{
	gVisualInventory.m_ItemsInfo.clear();

	this->InventoryVisualOpen = 0;

	SetByte(0x0083703A + 3, 0xC);
}

void VisualInventory::Init()
{
	this->m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("createDescription", &CreateVisualDescription);

	LuaModule(this->m_Lua.GetState()).fun("setVisualInventory", &setVisualInventory);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//DescriptionsItemsVisual.lua");
}



int CheckRenderItemToolTip(int x, int y, ITEM* itemObj) {
	if (itemObj) {
		auto pItemAttr = pGetItemAttr(itemObj->Type);
		PERSONAL_SHOP_ITENS_VALUE* itemInfo = nullptr;

		if (CheckWindowOpen(ObjWindow::OtherStore)) {
			itemInfo = gPersonalShop.getItemTarget(itemObj->x + 8 * itemObj->y + 204);
		}
		else {
			itemInfo = gPersonalShop.getItem(itemObj->x + 8 * itemObj->y + 204);
		}

		if (pItemAttr) {
			if (pItemAttr->m_byItemSlot >= 240 && pItemAttr->m_byItemSlot <= 248) {
				for (int i = 0; i < 100; ++i) {
					memset(textLine[i], 0, 100);
					textColor[i] = 0;
					textBold[i] = 0;
				}

				int Line = 0;

				if (itemInfo) {
					if (CheckMouseIn(*(DWORD*)((DWORD)pMyShopInventoryThis(pWindowThis()) + 20), *(DWORD*)((DWORD)pMyShopInventoryThis(pWindowThis()) + 24), 190, 429)) {
						if (gPersonalShop.WindowValueVisible == 0) {
							char buffer[100];

							if (gLoadFiles.m_LoadFiles.m_Coin1Switch) {
								if (itemInfo->Coin1 > 0) {
									sprintf_s(buffer, gCustomMessage.GetMessage(41), itemInfo->Coin1);

									memcpy(textLine[Line], buffer, 100);
									textColor[Line] = 6;
									textBold[Line] = 1;
									Line++;
								}
							}

							if (gLoadFiles.m_LoadFiles.m_Coin2Switch) {
								if (itemInfo->Coin2 > 0) {
									sprintf_s(buffer, gCustomMessage.GetMessage(42), itemInfo->Coin2);

									memcpy(textLine[Line], buffer, 100);
									textColor[Line] = 6;
									textBold[Line] = 1;
									Line++;
								}
							}

							if (gLoadFiles.m_LoadFiles.m_Coin3Switch) {
								if (itemInfo->Coin3 > 0) {
									sprintf_s(buffer, gCustomMessage.GetMessage(43), itemInfo->Coin3);

									memcpy(textLine[Line], buffer, 100);
									textColor[Line] = 6;
									textBold[Line] = 1;
									Line++;
								}
							}

							if (gLoadFiles.m_LoadFiles.m_Coin4Switch) {
								if (itemInfo->Coin4 > 0) {
									sprintf_s(buffer, gCustomMessage.GetMessage(44), itemInfo->Coin4);

									memcpy(textLine[Line], buffer, 100);
									textColor[Line] = 6;
									textBold[Line] = 1;
									Line++;
								}
							}

							memcpy(textLine[Line], "\n", 100);
							textColor[Line] = 6;
							textBold[Line] = 1;
							Line++;
						}
					}
				}

				gVisualInventory.m_Lua.Generic_Call("RenderDescriptionVisualItem", "ii>", itemObj->Type, Line);

				SIZE TextSize = { 0, 0 };
				float fRateY = *(float*)0xE7C3D8 / 1.1f;
				int	Height = 0;
				int	EmptyLine = 20;
				int TextLine = 10;

				pTextSetFont(pTextThis(), g_hFont);
				GetTextExtentPoint32(((HDC(__thiscall*)(LPVOID))0x41FF80)(pTextThis()), textLine[0], strlen(textLine[0]), &TextSize);

				Height = (TextLine * TextSize.cy + EmptyLine * TextSize.cy / 2.0f) / fRateY;

				int iScreenHeight = 400;

				int sy = y;

				sy += 20;

				if ((sy + Height) > iScreenHeight)
				{
					sy += iScreenHeight - (sy + Height);
				}

				((void(*)(int, int, ITEM*, int, int, int, int))0x5BF700)(x, sy, itemObj, 0, 3, 0, 1);

				return 1;
			}
		}
	}

	return 0;
}

__declspec(naked) void ItemToolTip()
{
	static DWORD m_ExitFunc = 0x007E5AF9;
	static DWORD m_ReturnFunc = 0x007E3E73;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x10]
		PUSH EAX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC] ;
		PUSH ECX;
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		PUSH EDX;
		CALL[CheckRenderItemToolTip];
		TEST EAX, EAX;
		JE RETURN;

		ADD ESP, 0xC;
		JMP[m_ExitFunc];

	RETURN:
		ADD ESP, 0xC;
		MOV EAX, DWORD PTR SS : [EBP + 0x10] ;
		MOV DWORD PTR SS : [EBP - 0x1C] , 0;
		JMP[m_ReturnFunc];
	}
}

bool CheckFullSet(ObjectPreview* c) {
	int tmpLevel = 10;
	bool Success = true;
	int  start = 5, end = 1;

	*(DWORD*)0x7BD0458 = 0;

	bool bHero = false;

	if (c == Hero)
	{
		bHero = true;
		start = 6;
		end = 2;
	}

	if (GetBaseClass(c->Class) == CLASS_DARK)
	{
		end = 3;
	}

	if (bHero == true)
	{
		for (int i = start; i >= end; i--)
		{
			if ((GetBaseClass(c->Class) == CLASS_RAGEFIGHTER) && (i == 5)) {
				continue;
			}

			if (*(WORD*)(*(DWORD*)0x8128AC4 + 107 * i + 4672) == -1)
			{
				Success = false;
				break;
			}
		}

		if (Success)
		{
			int Type = *(WORD*)(*(DWORD*)0x8128AC4 + 5314) % 512;

			tmpLevel = (*(DWORD*)(*(DWORD*)0x8128AC4 + 5316) >> 3) & 0xF;

			if (gVisualInventory.CheckItemExist(246)) {
				auto item = gVisualInventory.getItem(246);

				if (item) {
					tmpLevel = (item->Level >> 3) & 0xF;
					Type = item->Type % 512;
				}
			}

			for (int i = start; i >= end; i--)
			{
				if ((GetBaseClass(c->Class) == CLASS_RAGEFIGHTER) && (i == 3)) {
					continue;
				}

				int Level = (*(DWORD*)(*(DWORD*)0x8128AC4 + 107 * i + 4674) >> 3) & 0xF;
				int ItemType = (*(WORD*)(*(DWORD*)0x8128AC4 + 107 * i + 4672) % 512);

				if (gVisualInventory.CheckItemExist(240 + i)) {
					auto item = gVisualInventory.getItem(240 + i);

					if (item) {
						Level = (item->Level >> 3) & 0xF;
						ItemType = item->Type % 512;
					}
				}

				if (Level < 9)
				{
					*(DWORD*)0x7BD0458 = 0;
					Success = false;
					break;
				}


				if (Type != ItemType)
				{
					*(DWORD*)0x7BD0458 = 0;
					Success = false;
					break;
				}

				if (Level >= 9 && tmpLevel >= Level)
				{
					tmpLevel = Level;
					*(DWORD*)0x7BD0458 = Level;
				}
			}
		}

		*(DWORD*)0x7BD045C = true;

		if (GetBaseClass(c->Class) == CLASS_DARK && Success)
		{
			if (*(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4111
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4116
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4119
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4128
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4133
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4143
				&& *(WORD*)(*(DWORD*)0x8128AC4 + 4993) != 4144
				)
			{
				*(DWORD*)0x7BD045C = false;
			}
		}
	}
	else
	{
		for (int i = 5; i >= end; i--)
		{
			if (c->BodyPart[i].Type == -1)
			{
				Success = false;
				break;
			}
		}

		if (Success)
		{
			int Type = (c->BodyPart[5].Type - ITEM_BASE_MODEL) % 512;
			tmpLevel = c->BodyPart[5].Level & 0xf;

			for (int i = 5; i >= end; i--)
			{
				int Level = c->BodyPart[i].Level & 0xf;
				if (Level < 9)
				{
					*(DWORD*)0x7BD0458 = 0;
					Success = false;
					break;
				}
				if (Type != (c->BodyPart[i].Type - ITEM_BASE_MODEL) % 512)
				{
					*(DWORD*)0x7BD0458 = 0;
					Success = false;
					break;
				}

				if (Level >= 9 && tmpLevel >= Level)
				{
					tmpLevel = Level;
					*(DWORD*)0x7BD0458 = Level;
				}
			}
		}

		*(DWORD*)0x7BD045C = true;

		if (GetBaseClass(c->Class) == CLASS_DARK && Success)
		{
			if (c->BodyPart[BODYPART_ARMOR].Type != 4111
				&& c->BodyPart[BODYPART_ARMOR].Type != 4116
				&& c->BodyPart[BODYPART_ARMOR].Type != 4119
				&& c->BodyPart[BODYPART_ARMOR].Type != 4128
				&& c->BodyPart[BODYPART_ARMOR].Type != 4133
				&& c->BodyPart[BODYPART_ARMOR].Type != 4143
				&& c->BodyPart[BODYPART_ARMOR].Type != 4144
				)
			{
				*(DWORD*)0x7BD045C = false;
			}
		}
	}

	if (((bool(*)(int))0x4E65A0)(*(int*)0xE61E18))
	{
		((void(*)(ObjectPreview*))0x4E6670)(c);
	}

	return Success;
}

void VisualInventory::InitFromLua()
{
	if (this->InventoryVisualSwitch == 0) {
		return;
	}

	SetCompleteHook(0xE8, 0x0057231F, &CheckFullSet);
	SetCompleteHook(0xE8, 0x0057F8FE, &CheckFullSet);
	SetCompleteHook(0xE8, 0x0078538D, &CheckFullSet);

	SetCompleteHook(0xE9, 0x00837734, &gVisualInventory.Render);

	SetCompleteHook(0xE8, 0x005B6C3B, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x005C7842, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x0063E312, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x0063EBE9, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x0063ED0E, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x00640CFA, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x00835E4F, &gVisualInventory.MainSetCharacterClass);
	SetCompleteHook(0xE8, 0x00836502, &gVisualInventory.MainSetCharacterClass);

	if (this->InventoryVisualOriginalDescription == 0) {
		MemorySet(0x007E3E6C, 0x90, 7);
		SetCompleteHook(0xE9, 0x007E3E6C, &ItemToolTip);
	}
}


// RENDER BUTTONS

void RenderButtonsArrow()
{
	float x = *((DWORD*)pInventoryThis(pWindowThis()) + 9);
	float y = *((DWORD*)pInventoryThis(pWindowThis()) + 10);

	if (CheckMouseIn(x + 15, y + 35, 35, 35))
	{
		//RenderImage2(0x7E59, x + 15, y + 35, 35.0, 35.0, 0, 0.18, 0.52, 0.18, 1, 1, 1.0);
	}
	else
	{
		//RenderImage2(0x7E59, x + 15, y + 35, 35.0, 35.0, 0, 0.18, 0.52, 0.18, 1, 1, 1.0);
	}

	if (CheckMouseIn(x + 150, y + 35, 35, 35))
	{
		//RenderImage2(0x7E5A, x + 150, y + 35, 35.0, 35.0, 0, 0.18, 0.52, 0.18, 1, 1, 1.0);
	}
	else
	{
		//RenderImage2(0x7E5A, x + 150, y + 35, 35.0, 35.0, 0, 0.18, 0.52, 0.18, 1, 1, 1.0);
	}
}

// ALTERAR O NOME DO (INVENTÁRIO VISUAL)
void RenderTextTitleInventory() {
	pSetTextBgColor(pTextThis(), 0x00, 0x00, 0x00, 0xFF);
	pSetTextColor(pTextThis(), 0xFF, 0xFF, 0xFF, 0xFF);

	int locX = 545;
	int locY = 12;

	if (CheckWindowOpen(ObjWindow::Character)) {
		locX = 355;
	}

	pDrawText(pTextThis(), locX, locY, gCustomMessage.GetMessage(46), 80, 0, 8, 0);
	if (gVisualInventory.InventoryVisualOpen) {
		pDrawText(pTextThis(), locX, locY, gCustomMessage.GetMessage(53), 80, 0, 8, 0);
	}
}

__declspec(naked) void VisualInventory::Render()
{
	static DWORD m_ReturnFunc = 0x00837741;
	static DWORD m_CallFunc = 0x0635FD0;

	_asm {
		MOV DWORD PTR SS : [EBP - 0x4] , ECX;
		PUSH 0x1;
		CALL[m_CallFunc];
		ADD ESP, 0x04;
		CALL[RenderButtonsArrow];
		CALL[RenderTextTitleInventory];
		JMP[m_ReturnFunc];
	}
}

bool VisualInventory::Update(DWORD Struct)
{
	if (this->InventoryVisualSwitch == 0) {
		return 0;
	}

	if (CheckMouseIn(*((DWORD*)pInventoryThis(pWindowThis()) + 9) + 15, *((DWORD*)pInventoryThis(pWindowThis()) + 10) + 10, 35, 35)) {
		if (IsPressKey(VK_LBUTTON)) {
			SetByte(0x0083703A + 3, 0xC);
			gVisualInventory.InventoryVisualOpen = 0;
			ResetMouseL();
		}
	}

	if (CheckMouseIn(*((DWORD*)pInventoryThis(pWindowThis()) + 9) + 150, *((DWORD*)pInventoryThis(pWindowThis()) + 10) + 10, 35, 35)) {
		if (IsPressKey(VK_LBUTTON)) {
			SetByte(0x0083703A + 3, 0x9);
			gVisualInventory.InventoryVisualOpen = 1;
			ResetMouseL();
		}
	}

	if (gVisualInventory.InventoryVisualOpen) {
		*(DWORD*)(Struct + 284) = -1;

		for (int i = 0; i < 9; i++) {
			if ((i != 5 || GetBaseClass((Hero)->Class) != 6)) {
				if (CheckMouseIn(*((DWORD*)pInventoryThis(pWindowThis()) + 9) + gVisualInventory.m_ItemInventoryEquip[i].x
					, *((DWORD*)pInventoryThis(pWindowThis()) + 10) + gVisualInventory.m_ItemInventoryEquip[i].y
					, gVisualInventory.m_ItemInventoryEquip[i].width
					, gVisualInventory.m_ItemInventoryEquip[i].height)) {
					*(DWORD*)(Struct + 284) = 240 + i;
					return 1;
				}
			}
		}

		return 1;
	}

	return 0;
}

void VisualInventory::CheckCanEquipItem(int slot)
{
	auto itemObj = ((ITEM * (__thiscall*)(DWORD))0x7D9430)(((DWORD(*)())0x7DD0F0)());

	if (itemObj) {
		auto elementSlot = gVisualInventory.getItem(slot);
		auto itemAttr = pGetItemAttr(itemObj->Type);

		int StackEquiped = slot - 240;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 8) {
			StackEquiped = 8;
		}

		if (elementSlot != nullptr || (itemAttr != nullptr && itemAttr->m_byItemSlot != slot)) {
			glColor4f(0.9f, 0.1f, 0.1f, 0.4f);

			EnableAlphaTest(1);

			pDrawBarForm(*((DWORD*)pInventoryThis(pWindowThis()) + 9) + gVisualInventory.m_ItemInventoryEquip[StackEquiped].x
				, *((DWORD*)pInventoryThis(pWindowThis()) + 10) + gVisualInventory.m_ItemInventoryEquip[StackEquiped].y, gVisualInventory.m_ItemInventoryEquip[StackEquiped].width - 4, gVisualInventory.m_ItemInventoryEquip[StackEquiped].height - 4, 0.0, 0);

			((void(*)())0x637A30)();
		}
	}
}

void VisualInventory::RenderItemToolTip(int slot)
{
	auto itemObj = gVisualInventory.getItem(slot);


	if (itemObj) {
		int StackEquiped = slot - 240;
		int Line = 0;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 8) {
			StackEquiped = 8;
		}

		int EquipamentX = *((DWORD*)pInventoryThis(pWindowThis()) + 9) + gVisualInventory.m_ItemInventoryEquip[StackEquiped].x;
		int EquipamentY = *((DWORD*)pInventoryThis(pWindowThis()) + 10) + gVisualInventory.m_ItemInventoryEquip[StackEquiped].y;
		int EquipamentWidth = gVisualInventory.m_ItemInventoryEquip[StackEquiped].width;
		int EquipamentHeight = gVisualInventory.m_ItemInventoryEquip[StackEquiped].height;

		int iTargetX = EquipamentX + EquipamentWidth / 2;
		int iTargetY = EquipamentY + EquipamentHeight / 2;

		itemObj->bySelectedSlotIndex = slot;

		if (this->InventoryVisualOriginalDescription == 0) {
			for (int i = 0; i < 100; ++i) {
				memset(textLine[i], 0, 100);
				textColor[i] = 0;
				textBold[i] = 0;
			}

			gVisualInventory.m_Lua.Generic_Call("RenderDescriptionVisualItem", "ii>", itemObj->Type, Line);

			SIZE TextSize = { 0, 0 };
			float fRateY = *(float*)0xE7C3D8 / 1.1f;
			int	Height = 0;
			int	EmptyLine = 20;
			int TextLine = 10;

			pTextSetFont(pTextThis(), g_hFont);
			GetTextExtentPoint32(((HDC(__thiscall*)(LPVOID))0x41FF80)(pTextThis()), textLine[0], strlen(textLine[0]), &TextSize);

			Height = (TextLine * TextSize.cy + EmptyLine * TextSize.cy / 2.0f) / fRateY;

			int iScreenHeight = 400;

			int sy = iTargetY;

			sy += 20;

			if ((sy + Height) > iScreenHeight)
			{
				sy += iScreenHeight - (sy + Height);
			}

			((void(*)(int, int, ITEM*, int, int, int, int))0x5BF700)(iTargetX, sy, itemObj, 0, 3, 0, 1);
		}
		else {
			((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), iTargetX, iTargetY, itemObj, 0, 0, 0);
		}
	}
}


void VisualInventory::Render3DItem()
{
	for (int i = 0; i < 9; i++) {
		auto itemObj = gVisualInventory.getItem(240 + i);

		if (itemObj) {
			if ((i != 5 || GetBaseClass((Hero)->Class) != 6)) {
				glColor4f(1.0, 1.0, 1.0, 1.0);

				((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)((float)(*((DWORD*)pInventoryThis(pWindowThis()) + 9) + gVisualInventory.m_ItemInventoryEquip[i].x)
					, (float)(*((DWORD*)pInventoryThis(pWindowThis()) + 10) + gVisualInventory.m_ItemInventoryEquip[i].y)
					, (float)gVisualInventory.m_ItemInventoryEquip[i].width
					, (float)gVisualInventory.m_ItemInventoryEquip[i].height, itemObj->Type, itemObj->Level, itemObj->Option1, itemObj->ExtOption, 0);
			}
		}
	}
}

void VisualInventory::AddItem(BYTE slot, BYTE* ItemInfo)
{
	std::map<int, ITEMS_SLOTS_INFO>::iterator it = gVisualInventory.m_ItemsInfo.find(slot);

	if (it == gVisualInventory.m_ItemsInfo.end()) {
		ITEMS_SLOTS_INFO info;

		auto pTargetItemSlot = &info.pItemObj;
		auto pTempItem = ((ITEM * (__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

		if (pTempItem == nullptr) {
			return;
		}

		pTempItem->lineal_pos = slot;

		pTempItem->ex_src_type = 1;

		memcpy(pTargetItemSlot, pTempItem, sizeof(ITEM));

		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), pTempItem);

		info.slot = slot;

		gVisualInventory.m_ItemsInfo.insert(std::make_pair(slot, info));
	}
	else {
		auto pTargetItemSlot = &it->second.pItemObj;
		auto pTempItem = ((ITEM * (__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

		if (pTempItem == nullptr) {
			return;
		}

		pTempItem->lineal_pos = slot;

		pTempItem->ex_src_type = 1;

		memcpy(pTargetItemSlot, pTempItem, sizeof(ITEM));

		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), pTempItem);

		it->second.slot = slot;
	}

	if (slot == 248) {
		this->EffectHelper(((int(*)(BYTE*))0x58AA80)(ItemInfo));
	}

	if (slot == 247) {
		if (gCustomWing.CheckCustomWingIsCape(((int(*)(BYTE*))0x58AA80)(ItemInfo) + ITEM_BASE_MODEL)) {
			((void(*)(ObjectPreview*, ObjectModel*, int)) 0x558630)(Hero, &(Hero)->Object, 0);
		}
	}
}

void VisualInventory::AddItem(BYTE slot, ITEM* itemObj)
{
	std::map<int, ITEMS_SLOTS_INFO>::iterator it = gVisualInventory.m_ItemsInfo.find(slot);

	if (it == gVisualInventory.m_ItemsInfo.end()) {
		ITEMS_SLOTS_INFO info;

		info.slot = slot;

		ITEM* pEquipmentItemSlot = &info.pItemObj;

		memcpy(pEquipmentItemSlot, itemObj, sizeof(ITEM));

		gVisualInventory.m_ItemsInfo.insert(std::make_pair(slot, info));
	}
	else {
		it->second.slot = slot;

		ITEM* pEquipmentItemSlot = &it->second.pItemObj;

		memcpy(pEquipmentItemSlot, itemObj, sizeof(ITEM));
	}

	if (slot == 248) {
		this->EffectHelper(itemObj->Type);
	}

	if (gCustomWing.CheckCustomWingIsCape(itemObj->Type + ITEM_BASE_MODEL)) {
		((void(*)(ObjectPreview*, ObjectModel*, int)) 0x558630)(Hero, &(Hero)->Object, 0);
	}

	gVisualInventory.MainSetCharacterClass(Hero);
}

void VisualInventory::DeleteItem(int slot)
{
	std::map<int, ITEMS_SLOTS_INFO>::iterator it = gVisualInventory.m_ItemsInfo.find(slot);

	if (it == gVisualInventory.m_ItemsInfo.end()) {
		return;
	}

	if (slot == 248) {
		if (gHelperSystem.CheckIsHelper(it->second.pItemObj.Type + ITEM_BASE_MODEL)) {
			gHelperManager.DeleteHelper(Hero);
		}
	}

	if (gCustomWing.CheckCustomWingIsCape(it->second.pItemObj.Type + ITEM_BASE_MODEL)) {
		((void(*)(ObjectPreview*, ObjectModel*, int)) 0x558630)(Hero, &(Hero)->Object, 0);
	}

	it->second.Clear();

	gVisualInventory.m_ItemsInfo.erase(it);

	gVisualInventory.MainSetCharacterClass(Hero);

	if (slot == 248) {
		this->RecoveryOldHelper();
	}
}

void VisualInventory::Unequip(int slot)
{
	std::map<int, ITEMS_SLOTS_INFO>::iterator it = gVisualInventory.m_ItemsInfo.find(slot);

	if (it == gVisualInventory.m_ItemsInfo.end()) {
		return;
	}

	if (slot == 248) {
		if (gHelperSystem.CheckIsHelper(it->second.pItemObj.Type + ITEM_BASE_MODEL)) {
			gHelperManager.DeleteHelper(Hero);
		}
	}

	if (gCustomWing.CheckCustomWingIsCape(it->second.pItemObj.Type + ITEM_BASE_MODEL)) {
		((void(*)(ObjectPreview*, ObjectModel*, int)) 0x558630)(Hero, &(Hero)->Object, 0);
	}

	it->second.pItemObj.Type = -1;
	it->second.pItemObj.Level = 0;
	it->second.pItemObj.Number = -1;
	it->second.pItemObj.Option1 = 0;
	it->second.pItemObj.ExtOption = 0;

	gVisualInventory.m_ItemsInfo.erase(it);

	gVisualInventory.MainSetCharacterClass(Hero);

	if (slot == 248) {
		this->RecoveryOldHelper();
	}
}

void VisualInventory::EffectHelper(int ItemIndex)
{
	auto c = Hero;

	auto getHelper = gItemMove.getItem(8);

	if (getHelper != nullptr) {
		((void(*)(ObjectModel*))0x5012D0)(&c->Object);

		((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), c, -1);

		gHelperManager.DeleteHelper(c);
	}

	if (gHelperSystem.CheckIsHelper(ItemIndex + ITEM_BASE_MODEL)) {
		c->PetSlot = ItemIndex + ITEM_BASE_MODEL;

		gHelperManager.CreateHelper(ItemIndex, gHelperSystem.GetHelperModel(c->PetSlot), c->Object.Position, c, 0);
	}
}

void VisualInventory::RecoveryOldHelper()
{
	auto getHelper = gItemMove.getItem(8);

	if (getHelper != nullptr) {
		auto c = Hero;

		if (gHelperSystem.CheckIsHelper(getHelper->Type + ITEM_BASE_MODEL)) {
			((void(*)(ObjectModel*))0x5012D0)(&c->Object);

			((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), c, -1);

			c->PetSlot = getHelper->Type + ITEM_BASE_MODEL;

			gHelperManager.CreateHelper(getHelper->Type, gHelperSystem.GetHelperModel(c->PetSlot), c->Object.Position, c, 0);
		}
		else
		{
			gHelperManager.DeleteHelper(c);

			c->PetSlot = getHelper->Type + ITEM_BASE_MODEL;
			c->PetLevel = 0;

			switch (getHelper->Type)
			{
			case 6656:
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(7827, c->Object.Position, &c->Object, 0, 0);
				break;
			case 6658:
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(233, c->Object.Position, &c->Object, 0, 0);
				break;
			case 6659:
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(323, c->Object.Position, &c->Object, 0, 0);
				break;
			case 6660:
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(226, c->Object.Position, &c->Object, 0, 0);
				break;
			case 6693:
				c->PetExcellent = getHelper->Option1;

				switch (getHelper->Option1)
				{
				case 1:
					((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(384, c->Object.Position, &c->Object, 0, 0);
					break;
				case 2:
					((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(386, c->Object.Position, &c->Object, 0, 0);
					break;
				case 4:
					((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(387, c->Object.Position, &c->Object, 0, 0);
					break;
				default:
					((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(385, c->Object.Position, &c->Object, 0, 0);
					break;
				}
				break;
			case 6720:
			case 6721:
				((void(__thiscall*)(void*, int, int, vec3_t, ObjectPreview*, int, int))0x009250E0)(((void* (*)())0x004DB230)(), getHelper->Type, c->PetSlot, c->Object.Position, c, 0, 0);
				break;
			case 6723:
			case 6736:
			case 6762:
			case 6779:
				((void(__thiscall*)(void*, int, int, vec3_t, ObjectPreview*, int, int))0x009250E0)(((void* (*)())0x004DB230)(), getHelper->Type, c->PetSlot, c->Object.Position, c, 0, 0);
				break;
			default:
				break;
			}
		}
	}
}

void VisualInventory::MainSetCharacterClass(ObjectPreview* character)
{
	((void(*)(ObjectPreview*))0x57F410)(character);

	auto hero = Hero;

	if (character == Hero) {
		if (gVisualInventory.CheckItemExist(240)) {
			auto item = gVisualInventory.getItem(240);

			if (item) {
				character->WeaponFirstSlot = item->Type + ITEM_BASE_MODEL;
				character->WeaponFirstLevel = (item->Level >> 3) & 0xF;
				character->WeaponSecondExcellent = item->Option1;
				character->WeaponFirstAncient = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(241)) {
			auto item = gVisualInventory.getItem(241);

			if (item) {
				character->WeaponSecondSlot = item->Type + ITEM_BASE_MODEL;
				character->WeaponSecondLevel = (item->Level >> 3) & 0xF;
				character->WeaponSecondExcellent = item->Option1;
				character->WeaponSecondAncient = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(242)) {
			auto item = gVisualInventory.getItem(242);

			if (item) {
				character->BodyPart[BODYPART_HELM].Type = item->Type + ITEM_BASE_MODEL;
				character->BodyPart[BODYPART_HELM].Level = (item->Level >> 3) & 0xF;
				character->BodyPart[BODYPART_HELM].Option1 = item->Option1;
				character->BodyPart[BODYPART_HELM].ExtOption = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(243)) {
			auto item = gVisualInventory.getItem(243);

			if (item) {
				character->BodyPart[BODYPART_ARMOR].Type = item->Type + ITEM_BASE_MODEL;
				character->BodyPart[BODYPART_ARMOR].Level = (item->Level >> 3) & 0xF;
				character->BodyPart[BODYPART_ARMOR].Option1 = item->Option1;
				character->BodyPart[BODYPART_ARMOR].ExtOption = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(244)) {
			auto item = gVisualInventory.getItem(244);

			if (item) {
				character->BodyPart[BODYPART_PANTS].Type = item->Type + ITEM_BASE_MODEL;
				character->BodyPart[BODYPART_PANTS].Level = (item->Level >> 3) & 0xF;
				character->BodyPart[BODYPART_PANTS].Option1 = item->Option1;
				character->BodyPart[BODYPART_PANTS].ExtOption = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(245)) {
			auto item = gVisualInventory.getItem(245);

			if (item) {
				character->BodyPart[BODYPART_GLOVES].Type = item->Type + ITEM_BASE_MODEL;
				character->BodyPart[BODYPART_GLOVES].Level = (item->Level >> 3) & 0xF;
				character->BodyPart[BODYPART_GLOVES].Option1 = item->Option1;
				character->BodyPart[BODYPART_GLOVES].ExtOption = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(246)) {
			auto item = gVisualInventory.getItem(246);

			if (item) {
				character->BodyPart[BODYPART_BOOTS].Type = item->Type + ITEM_BASE_MODEL;
				character->BodyPart[BODYPART_BOOTS].Level = (item->Level >> 3) & 0xF;
				character->BodyPart[BODYPART_BOOTS].Option1 = item->Option1;
				character->BodyPart[BODYPART_BOOTS].ExtOption = item->ExtOption;
			}
		}

		if (gVisualInventory.CheckItemExist(247)) {
			auto item = gVisualInventory.getItem(247);

			if (item) {
				character->WingsSlot = item->Type + ITEM_BASE_MODEL;
				character->WingsLevel = (item->Level >> 3) & 0xF;
			}
		}

		if (gVisualInventory.CheckItemExist(248)) {
			auto item = gVisualInventory.getItem(248);

			if (item) {
				character->PetSlot = item->Type + ITEM_BASE_MODEL;
				character->PetLevel = (item->Level >> 3) & 0xF;

				((void(*)(ObjectPreview*))0x54EA80)(character);
			}
		}
	}
}
