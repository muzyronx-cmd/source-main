#pragma once

#include "Lua.h"

class ELEMENT_SLOTS_INFO {
public:
	ELEMENT_SLOTS_INFO() {
		this->slot = -1;
	};

	~ELEMENT_SLOTS_INFO() {
	};

	void Clear() {
		this->slot = -1;
	}

	bool ItemEquiped;
	BYTE slot;
	ITEM pItemObj;
};

struct ITEM_ELEMENT_EQUIPED
{
	int x;
	int y;
	int width;
	int height;
	int ImageID;
	int Active;
	int isPet;
};

class CElementSlots {
public:
	CElementSlots();
	~CElementSlots();
	void Release();
	void Init();
	static void Render();
	static void Update();
	static void UpdateKey();
	void RenderEquippedItemSlot();
	static void RenderEquippedItem();
	static void RenderEquippedItem2();
	static void RenderItemToolTip();
	static void RenderItem3D();
	static void UnequipItem();
	static void CheckPickItem();
	static void BackUpPickedItem();
	static void CheckEquipItem();
	void LoadImageSlot();

	void AddItem(BYTE slot, BYTE* ItemInfo);
	void AddItem(BYTE slot, ITEM* itemObj);
	ELEMENT_SLOTS_INFO* getElement(int slot);
	ITEM* getItemElement(int slot);
	void DeleteItem(int slot);
	void Unequip(int slot);
	void EffectPet(int slot, int ItemIndex);
	void DeleteEffectPets(int slot);
	void DeleteDarkSpirit(int ItemIndex);
	bool AddDarkSpirit(int ItemIndex);

public:
	int ImageNewSlot1;
	int ImageNewSlot2;
	int ImageNewSlot3;
	int ImageNewSlot4;

public:
	std::map<int, ELEMENT_SLOTS_INFO> m_ElementSlots;
	ITEM_ELEMENT_EQUIPED m_ElementEquiped[4];

private:
	Lua m_Lua;
};

extern CElementSlots gElementSlots;