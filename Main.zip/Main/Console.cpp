#include "StdAfx.h"
#include "Console.h"

#define MAX_BUFF 1024

FILE * file = NULL;

#if( USE_CONSOLE == TRUE)

CConsole Console;
DWORD PiD;

CConsole::CConsole()
{
	FILE * file = fopen("ConsoleLog.txt", "a");

	if (file == NULL)
	{
		MessageBoxA(NULL, "Error in Opening ConsoleLog.txt", "ERROR", MB_ICONSTOP);
		ExitProcess(0);
	}
}

CConsole::~CConsole()
{
	fclose(file);
}

void closeMenu()
{
	char buf[MAX_BUFF];
	HWND hwnd = NULL;

	wsprintf(buf, (CONSOLETITLE));
	SetConsoleTitle((LPCTSTR)buf);

	while (hwnd == NULL)
	{
		hwnd = FindWindowEx(NULL, NULL, NULL, (LPCTSTR)buf);
	}

	HMENU hmenu = GetSystemMenu(hwnd, FALSE);
	DeleteMenu(hmenu, SC_CLOSE, MF_BYCOMMAND);
	//DeleteMenu(hmenu, SC_MINIMIZE, MF_BYCOMMAND);
	DeleteMenu(hmenu, SC_MAXIMIZE, MF_BYCOMMAND);
	DeleteMenu(hmenu, SC_MOUSEMENU, MF_BYCOMMAND);
	DeleteMenu(hmenu, SC_SIZE, MF_BYCOMMAND);
	DeleteMenu(hmenu, SC_MOVE, MF_BYCOMMAND);
	SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_DRAWFRAME);
}

void __stdcall LoggerCore(PVOID pVoid)
{
	AllocConsole();
	closeMenu();
	SetConsoleTitleA(CONSOLETITLE);
	while (true)
		Sleep(1);
}


void CConsole::InitCore()
{
	CreateThread(0, 0, (LPTHREAD_START_ROUTINE)LoggerCore, 0, 0, &PiD);
	Sleep(100);

	this->ConsoleOutput(0, "[ MAIN ] Console Loaded");
}

void CConsole::ConsoleOutput(bool WriteToFile, const char* Format, ...)
{
	SYSTEMTIME t;
	GetLocalTime(&t);

	char Message[3072];
	DWORD dwBytesWritten;
	HANDLE Handle = GetStdHandle(STD_OUTPUT_HANDLE);
	va_list pArguments;
	va_start(pArguments, Format);
	vsprintf(Message, Format, pArguments);
	va_end(pArguments);
	char currdate[11] = { 0 };
	sprintf_s(currdate, "(%02d:%02d:%02d)", t.wHour, t.wMinute, t.wSecond);
	char outputmsg[3072];
	sprintf_s(outputmsg, "%s %s\n", currdate, Message);
	WriteFile(Handle, outputmsg, strlen(outputmsg), &dwBytesWritten, NULL);

	if (WriteToFile == TRUE)
	{
		fprintf(file, outputmsg);
	}
}

#endif