#include "stdafx.h"
#include "RenderModel.h"
#include "LuaBMD.h"
#include "LuaObject.h"
#include "Util.h"

CRenderModel gRenderModel;

CRenderModel::CRenderModel() : m_Lua(true)
{

}

CRenderModel::~CRenderModel()
{

}

int RenderModelBodyLua(int ItemIndex, DWORD BMDStruct, DWORD ObjectStruct) {
	int retorno = 0;

	gRenderModel.m_Lua.Generic_Call("RenderModelBody", "iii>i", BMDStruct, ObjectStruct, ItemIndex, &retorno);

	return retorno;
}

__declspec(naked) void RenderModelBody() {
	static DWORD m_Index = 0;
	static DWORD m_BMDStruct = 0;
	static DWORD m_ObjectStruct = 0;
	static DWORD m_ReturnFunc = 0x005FA782;
	static DWORD m_HookFunc = 0x00608175;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		MOV m_Index, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		MOV m_ObjectStruct, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_BMDStruct, ECX;
	}

	if (RenderModelBodyLua(m_Index, m_BMDStruct, m_ObjectStruct) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x10], 0x14A2
			JMP[m_ReturnFunc];
		}
	}
}

int RenderModelBodyColorLua(int ItemIndex, DWORD BMDStruct, DWORD ObjectStruct) {
	int retorno = 0;

	gRenderModel.m_Lua.Generic_Call("RenderModelBodyColor", "iii>i", BMDStruct, ObjectStruct, ItemIndex, &retorno);

	return retorno;
}

__declspec(naked) void RenderModelBodyColor() {
	static DWORD m_Index = 0;
	static DWORD m_BMDStruct = 0;
	static DWORD m_ObjectStruct = 0;
	static DWORD m_ReturnFunc = 0x006083C8;
	static DWORD m_HookFunc = 0x00608F8F;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		MOV m_Index, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		MOV m_ObjectStruct, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_BMDStruct, ECX;
	}

	if (RenderModelBodyColorLua(m_Index, m_BMDStruct, m_ObjectStruct) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x10], 0x89A
			JMP[m_ReturnFunc];
		}
	}
}

int RenderModelBodyColor2Lua(int ItemIndex, DWORD BMDStruct, DWORD ObjectStruct) {
	int retorno = 0;

	gRenderModel.m_Lua.Generic_Call("RenderModelBodyColor2", "iii>i", BMDStruct, ObjectStruct, ItemIndex, &retorno);

	return retorno;
}

__declspec(naked) void RenderModelBodyColor2() {
	static DWORD m_Index = 0;
	static DWORD m_BMDStruct = 0;
	static DWORD m_ObjectStruct = 0;
	static DWORD m_ReturnFunc = 0x0060906D;
	static DWORD m_HookFunc = 0x006097AC;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		MOV m_Index, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		MOV m_ObjectStruct, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_BMDStruct, ECX;
	}

	if (RenderModelBodyColor2Lua(m_Index, m_BMDStruct, m_ObjectStruct) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x10], 0x0E98
			JMP[m_ReturnFunc];
		}
	}
}

void CRenderModel::Init()
{
	SetCompleteHook(0xE9, 0x005FA77B, &RenderModelBody);

	SetCompleteHook(0xE9, 0x006083C1, &RenderModelBodyColor);

	SetCompleteHook(0xE9, 0x00609066, &RenderModelBodyColor2);

	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//RenderModel.lua");

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());
}


void CRenderModel::RestartLua()
{
	SetCompleteHook(0xE9, 0x005FA77B, &RenderModelBody);

	SetCompleteHook(0xE9, 0x006083C1, &RenderModelBodyColor);

	SetCompleteHook(0xE9, 0x00609066, &RenderModelBodyColor2);

	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//RenderModel.lua");

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());
}

void CRenderModel::LoadImageRenderModel()
{
	this->m_Lua.Generic_Call("StartLoadImages", ">");
}
