#pragma once

#include "Lua.h"
#include "LuaInterface.h"
#include "LuaGlobal.h"
#include "Protocol.h"
#include "Console.h"
#include "CustomJewelStack.h"

//**********************************************//
//*********** GameServer -> Client  ************//
//**********************************************//
struct SDHP_CHAOS_BOX_GENESIS_OPEN_CLIENT_RECV
{
	PSBMSG_HEAD header; //
	int state;
	int selectedKey;
	int selectedComb;
};

struct PMSG_CHAOS_BOX_GENESIS_LIST_RECV
{
	PSWMSG_HEAD header; //
	BYTE count;
};

struct PMSG_CHAOS_BOX_GENESIS_ITEM_INFO
{
	BYTE slot;
	BYTE ItemInfo[MAX_ITEM_INFO];
};

struct PMSG_CHAOS_BOX_GENESIS_STATE_RECV
{
	PSBMSG_HEAD header; //
	int state;
};

//**********************************************//
//*********** Client -> GameServer  ************//
//**********************************************//
struct SDHP_CHAOS_BOX_GENESIS_SET_INFO_SEND
{
	PSBMSG_HEAD header; //
	int state;
	int selectedKey;
	int selectedComb;
};

struct SDHP_CHAOS_BOX_GENESIS_MIX_SEND
{
	PSBMSG_HEAD header; //
	int state;
};

//**********************************************//
//***************** Functions  *****************//
//**********************************************//

class CHAOS_MACHINE_ITENS {
public:
	CHAOS_MACHINE_ITENS() {

	};

	~CHAOS_MACHINE_ITENS() {

	};

	void Clear() {
		this->slot = -1;

		if (this->pItemObj) {
			((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), this->pItemObj);
			this->pItemObj = nullptr;
		}
	}


	ITEM* pItemObj;
	BYTE slot;
};

class CChaosBoxGenesis {
public:
	enum EVENT_STATE
	{
		EVENT_NONE = 0,
		EVENT_SCROLL_BTN_DOWN,
		EVENT_SCROLL_BTN_CLIKED,
	};

public:
	CChaosBoxGenesis();
	~CChaosBoxGenesis();

	void RestartLua();
	void Init();
	void Open(SDHP_CHAOS_BOX_GENESIS_OPEN_CLIENT_RECV * lpMsg);
	void Close();
	void Render();
	void Update();
	void UpdateKeyEvent();
	void UpdateMouseEvent();
	void Scrolling(int value);
	void OpenProcess();
	void RenderItensChaosMachine(float x, float y, float height, int MaxLines);
	void CalcLinesRender();
	void InsertItemChaosMachine(BYTE slot, BYTE* ItemInfo);
	void RenderItemInformation(float x, float y, ITEM* pItemObj);
	void DelItem(BYTE slot);
	void DeleteAllItems();
	void RenderItemImage(ITEM* pItemObj);
	void RenderScroll(float x, float y, float width, float height, int MaxLines);
	void ScrollLines(int mode);
	int CheckCanMoveItemChaosBox(int ItemIndex);
	void ChaosBoxGenesisStateRecv(PMSG_CHAOS_BOX_GENESIS_STATE_RECV * lpMsg);
	void ChaosBoxGenesisListItemRecv(PMSG_CHAOS_BOX_GENESIS_LIST_RECV * lpMsg);

	bool CheckMouse();
	void MoveItemFromInventory();
	void MoveItemToInventory();

	bool CheckChaosBoxGenesisSourceEmptySlot()
	{
		if (this->m_ChaosMachineItens.size() < 120) {
			return 1;
		}

		return 0;
	}

	int getCountItensByIndexLevel(int ItemIndex, int Level, int Exc, int Luck, int Skill, int Life) {
		int count = 0;

		for (auto &itemTarget : this->m_ChaosMachineItens) {
			auto itemObj = itemTarget.pItemObj;

			if (itemObj == nullptr) {
				continue;
			}

			if (Exc != -1) {
				if ((itemObj->Option1 & 63) <= 0) {
					continue;
				}
			}

			if (Luck != 0) {
				if (((itemObj->Level >> 2) & 1) == 0) {
					continue;
				}
			}

			if (Skill != 0) {
				if (((itemObj->Level >> 7) & 1) == 0) {
					continue;
				}
			}

			if (Life != 0) {
				int Option3 = ((itemObj->Level) & 3) + ((itemObj->Option1) & 64) / 64 * 4;

				if (Life > Option3) {
					continue;
				}
			}

			if (itemObj->Type == ItemIndex && (Level == -1 || itemObj->Level == (Level * 8))) {
				if (gCustomJewelStack.CheckCustomJewelStack(ItemIndex)) {
					if (itemObj->Durability <= 0) {
						count += 1;
					}
					else {
						count += itemObj->Durability;
					}
				}
				else {
					count++;
				}
			}
		}

		return count;
	}

	int getCountItensByIndex(int ItemIndex) {
		int count = 0;

		for (auto &itemTarget : this->m_ChaosMachineItens) {
			auto itemObj = itemTarget.pItemObj;

			if (itemObj == nullptr) {
				continue;
			}

			if (itemObj->Type == ItemIndex) {
				if (gCustomJewelStack.CheckCustomJewelStack(ItemIndex)) {
					if (itemObj->Durability <= 0) {
						count += 1;
					}
					else {
						count += itemObj->Durability;
					}
				}
				else {
					count++;
				}
			}
		}

		return count;
	}

	bool isVisible() {
		return this->m_Visible;
	}

public:
	int ChaosBoxGenesisState;
	int ChaosBoxGenesisSelectedKey;
	int ChaosBoxGenesisSelectedComb;

	int ItemPointer;

private:
	bool m_Visible;
	bool m_InventoryVisible;

	float m_PosX;
	float m_PosY;
	float m_HeightBox;

	int m_iMouseY;

	float ScrollBarPosX;
	float ScrollBarPosY;

	int ScrollBarOffset;
	int ScrollBarMaxOffset;
	float ScrollBarPos;
	float ScrollBarEsp;
	float ScrollBarMultiplier;

	int m_MaxLines;

	EVENT_STATE m_EventState;

private:
	Lua m_Lua;
	LuaInterface m_LuaInterface;
	LuaGlobal m_LuaGlobal;

public:
	std::vector<CHAOS_MACHINE_ITENS> m_ChaosMachineItens;
};

extern CChaosBoxGenesis gChaosBoxGenesis;