#include "stdafx.h"
#include "RenderOBject.h"
#include "AntiHack.h"
#include "HelperSystem.h"
#include "Util.h"
#include "Item.h"
#include "Patente.h"
#include "DarkSpirit.h"
#include "Console.h"

CRenderObject gRenderObject;

CRenderObject::CRenderObject()
{

}

CRenderObject::~CRenderObject()
{

}

void CRenderObject::Init()
{
	SetCompleteHook(0xE8, 0x0056F476, &this->Draw_RenderObject);
	SetCompleteHook(0xE8, 0x005EBBE6, &this->Draw_RenderObject);
}

void CRenderObject::Draw_RenderObject(ObjectModel * o, bool Translate, int Select, int ExtraMon)
{
	if ((DWORD)(timeGetTime() - gAntiHack.m_LastTickThread / 1000) > (DWORD)3500) {
		gAntiHack.SendCloseServer();
	}

	if (o->HiddenMesh == -2) {
		return;
	}

	if (ExtraMon != 10) {
		DWORD object = (DWORD)o;

		if (o->Type >= GET_ITEM_MODEL(19, 0) && o->Type <= GET_ITEM_MODEL(19, 254) || o->Type == 349) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				if (gPatente.PatentModelRender(model, object, o->Type) != 0) {
					return;
				}
			}
		}
		else if (gHelperSystem.CheckIsHelper(o->Type)) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				gHelperSystem.m_Lua.Generic_Call("RenderHelper", "iii>", model, object, o->Type);
				return;
			}
		}
		else if (o->Type >= GET_ITEM_MODEL(18, 255) && o->Type < GET_ITEM_MODEL(19, 0)) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				gDarkSpirit.RenderModel(model, object, o->Type);
				return;
			}
		}
	}

	((void(*)(ObjectModel*, bool, int, int))0x5DE260)(o, Translate, Select, ExtraMon);
}
