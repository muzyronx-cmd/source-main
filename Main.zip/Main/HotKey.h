#pragma once

extern BOOL VKF7_State;

#define pPlayerState			*(int*)0x0E609E8
#define cName (char*)*(DWORD*)(0x8128AC4)

class HotKey
{
public:
	HotKey();
	virtual ~HotKey();

	void InitKeyBoard(HINSTANCE hins);

	static LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam);
	static LRESULT WINAPI Window(HWND Window, DWORD Message, WPARAM wParam, LPARAM lParam);

public:
	HINSTANCE hIstance;

private:
	HHOOK HookKB;
	HHOOK HookMS;
};

extern HotKey gHotKey;