#pragma once

class RenderItem {
public:
	RenderItem();
	~RenderItem();

	void Init();
	static void RenderItemName(DWORD itemObj, DWORD itemSelected, DWORD itemStruct, DWORD ItemLevel, DWORD ItemOption, DWORD ItemExtOption, bool Sort);
};

extern RenderItem gRenderItem;