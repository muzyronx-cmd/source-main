#pragma once

#include "Lua.h"

struct ITEM_VALUE_INFO
{
	int Index;
	int Level;
	int Grade;
	int BuyValue;
	int Coin1;
	int Coin2;
	int Coin3;
	int SellValue;
	int SellCoin1;
	int SellCoin2;
	int SellCoin3;
};

class CCustomItemValue {
public:
	CCustomItemValue();
	~CCustomItemValue();

	void Init();

	ITEM_VALUE_INFO* GetItemInfo(int ItemIndex, int Level, int ExtOption);

private:
	Lua m_Lua;

public:
	std::vector<ITEM_VALUE_INFO> m_ItemValueInfo;
};

extern CCustomItemValue gCustomItemValue;