#pragma once

#include "Lua.h"

struct CUSTOM_MONSTER_NAME_INFO {
	int Class;
	int Map;
	int X;
	int Y;
	std::string name;
};

class CCustomMonsterName {
public:
	CCustomMonsterName();
	~CCustomMonsterName();

	void Init();
	CUSTOM_MONSTER_NAME_INFO * getMonster(int Class, int Map, int X, int Y);
	static void SetMonsterAttribute(lpViewObj ObjectMonster, int MonsterID);

public:
	Lua m_Lua;

	std::vector<CUSTOM_MONSTER_NAME_INFO> m_CustomMonsterNameInfo;
};

extern CCustomMonsterName gCustomMonsterName;