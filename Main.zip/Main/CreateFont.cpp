#include "stdafx.h"
#include "CreateFont.h"
#include "LuaStack.hpp"

using namespace luaaa;
CCreateFont gCreateFont;

CCreateFont::CCreateFont() : m_Lua(true)
{
}

CCreateFont::~CCreateFont()
{
}

void SetFont(int index, int bold, int addSize, int charSet, std::string name) {
	gCreateFont.m_fontInfo[index].Bold = bold;
	gCreateFont.m_fontInfo[index].AddSize = addSize;
	gCreateFont.m_fontInfo[index].CharSet = charSet;
	gCreateFont.m_fontInfo[index].Name = name;
}

void CCreateFont::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetFont", &SetFont);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//Font.lua");
}
