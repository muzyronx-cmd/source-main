#include "stdafx.h"
#include "LoadFiles.h"
#include "..\\..\\Util\\CCRC32.H"

CLoadFiles gLoadFiles;

CLoadFiles::CLoadFiles()
{
}

CLoadFiles::~CLoadFiles()
{
}

bool CLoadFiles::ReadConfig(char * name)
{
	HANDLE file = CreateFile(name, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, 0);

	if (file == INVALID_HANDLE_VALUE)
	{
		return 0;
	}

	if (GetFileSize(file, 0) != sizeof(LOAD_FILES_INFOS))
	{
		CloseHandle(file);
		return 0;
	}

	DWORD OutSize = 0;

	if (ReadFile(file, &this->m_LoadFiles, sizeof(LOAD_FILES_INFOS), &OutSize, 0) == 0)
	{
		CloseHandle(file);
		return 0;
	}

	for (int n = 0; n < sizeof(LOAD_FILES_INFOS); n++)
	{
		((BYTE*)&this->m_LoadFiles)[n] += (BYTE)(0xE4 ^ HIBYTE(n));
		((BYTE*)&this->m_LoadFiles)[n] ^= (BYTE)(0x9D ^ LOBYTE(n));
	}

	CloseHandle(file);
	return 1;
}

bool CLoadFiles::ReadCustomJewels(char * name)
{
	HANDLE file = CreateFile(name, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, 0);

	if (file == INVALID_HANDLE_VALUE)
	{
		return 0;
	}

	if (GetFileSize(file, 0) != sizeof(LOAD_CUSTOM_JEWEL_INFO))
	{
		CloseHandle(file);
		return 0;
	}

	DWORD OutSize = 0;

	if (ReadFile(file, &this->m_CustomJewel, sizeof(LOAD_CUSTOM_JEWEL_INFO), &OutSize, 0) == 0)
	{
		CloseHandle(file);
		return 0;
	}

	for (int n = 0; n < sizeof(LOAD_CUSTOM_JEWEL_INFO); n++)
	{
		((BYTE*)&this->m_CustomJewel)[n] += (BYTE)(0xFC ^ HIBYTE(n));
		((BYTE*)&this->m_CustomJewel)[n] ^= (BYTE)(0xCA ^ LOBYTE(n));
	}

	CloseHandle(file);
	return 1;
}

void CLoadFiles::LoadDll()
{
	if (this->m_LoadFiles.m_DllCRC32 == 0)
	{
		return;
	}

	CCRC32 CRC32;

	DWORD DLLCRC32;

	if (CRC32.FileCRC(this->m_LoadFiles.m_DllName, &DLLCRC32, 1024) == 0)
	{
		ExitProcess(0);
	}

	if (this->m_LoadFiles.m_DllCRC32 != DLLCRC32)
	{
		ExitProcess(0);
	}

	HMODULE module = LoadLibrary(this->m_LoadFiles.m_DllName);

	if (module == 0)
	{
		ExitProcess(0);
	}

	void(*EntryProc)() = (void(*)())GetProcAddress(module, this->m_LoadFiles.m_DllFunction);

	if (EntryProc != 0)
	{
		EntryProc();
	}
}

void CLoadFiles::LoadDll2()
{
	if (this->m_LoadFiles.m_DllCRC32_2 == 0)
	{
		return;
	}

	CCRC32 CRC32;

	DWORD DLLCRC32;

	if (CRC32.FileCRC(this->m_LoadFiles.m_DllName2, &DLLCRC32, 1024) == 0)
	{
		ExitProcess(0);
	}

	if (this->m_LoadFiles.m_DllCRC32_2 != DLLCRC32)
	{
		ExitProcess(0);
	}

	HMODULE module = LoadLibrary(this->m_LoadFiles.m_DllName2);

	if (module == 0)
	{
		ExitProcess(0);
	}

	void(*EntryProc)() = (void(*)())GetProcAddress(module, this->m_LoadFiles.m_DllFunction2);

	if (EntryProc != 0)
	{
		EntryProc();
	}
}

void CLoadFiles::LoadDll3()
{
	if (this->m_LoadFiles.m_DllCRC32_3 == 0)
	{
		return;
	}

	CCRC32 CRC32;

	DWORD DLLCRC32;

	if (CRC32.FileCRC(this->m_LoadFiles.m_DllName3, &DLLCRC32, 1024) == 0)
	{
		ExitProcess(0);
	}

	if (this->m_LoadFiles.m_DllCRC32_3 != DLLCRC32)
	{
		ExitProcess(0);
	}

	HMODULE module = LoadLibrary(this->m_LoadFiles.m_DllName3);

	if (module == 0)
	{
		ExitProcess(0);
	}

	void(*EntryProc)() = (void(*)())GetProcAddress(module, this->m_LoadFiles.m_DllFunction3);

	if (EntryProc != 0)
	{
		EntryProc();
	}
}

void CLoadFiles::LoadDll4()
{
	if (this->m_LoadFiles.m_DllCRC32_4 == 0)
	{
		return;
	}

	CCRC32 CRC32;

	DWORD DLLCRC32;

	if (CRC32.FileCRC(this->m_LoadFiles.m_DllName4, &DLLCRC32, 1024) == 0)
	{
		ExitProcess(0);
	}

	if (this->m_LoadFiles.m_DllCRC32_4 != DLLCRC32)
	{
		ExitProcess(0);
	}

	HMODULE module = LoadLibrary(this->m_LoadFiles.m_DllName4);

	if (module == 0)
	{
		ExitProcess(0);
	}

	void(*EntryProc)() = (void(*)())GetProcAddress(module, this->m_LoadFiles.m_DllFunction4);

	if (EntryProc != 0)
	{
		EntryProc();
	}
}

void CLoadFiles::LoadDll5()
{
	if (this->m_LoadFiles.m_DllCRC32_5 == 0)
	{
		return;
	}

	CCRC32 CRC32;

	DWORD DLLCRC32;

	if (CRC32.FileCRC(this->m_LoadFiles.m_DllName5, &DLLCRC32, 1024) == 0)
	{
		ExitProcess(0);
	}

	if (this->m_LoadFiles.m_DllCRC32_5 != DLLCRC32)
	{
		ExitProcess(0);
	}

	HMODULE module = LoadLibrary(this->m_LoadFiles.m_DllName5);

	if (module == 0)
	{
		ExitProcess(0);
	}

	void(*EntryProc)() = (void(*)())GetProcAddress(module, this->m_LoadFiles.m_DllFunction5);

	if (EntryProc != 0)
	{
		EntryProc();
	}
}
