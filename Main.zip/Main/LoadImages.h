#pragma once

#include "Lua.h"
#include "LuaLoadImage.h"

class CLoadImages {
public:
	CLoadImages();
	~CLoadImages();

	void RestartLua();
	void Init();
	static void MainLoadImage();

private:
	Lua m_Lua;

	LuaLoadImage m_LuaLoadImage;
};

extern CLoadImages gLoadImages;