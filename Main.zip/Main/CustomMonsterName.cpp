#include "stdafx.h"
#include "CustomMonsterName.h"
#include "LuaStack.hpp"

using namespace luaaa;

CCustomMonsterName gCustomMonsterName;

CCustomMonsterName::CCustomMonsterName() : m_Lua(true)
{
	this->m_CustomMonsterNameInfo.clear();
}

CCustomMonsterName::~CCustomMonsterName()
{
}

void SetCustomMonsterName(int Class, int Map, int X, int Y, std::string name) {
	CUSTOM_MONSTER_NAME_INFO info;

	info.Class = Class;

	info.Map = Map;

	info.X = X;

	info.Y = Y;

	info.name = name;

	gCustomMonsterName.m_CustomMonsterNameInfo.push_back(info);
}

void CCustomMonsterName::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetCustomMonsterName", SetCustomMonsterName);

	this->m_Lua.DoFile("Data//Files//Lua//Monster//CustomMonsterName.lua");

	SetCompleteHook(0xE8, 0x0058101A, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058105B, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058109C, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005810DD, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058111E, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058115F, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005811A0, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005811E1, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x00581222, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x00581263, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005812A8, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005812ED, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058132E, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x0058136F, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005813B4, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x005813F9, &this->SetMonsterAttribute);
	SetCompleteHook(0xE8, 0x00586859, &this->SetMonsterAttribute);
}

CUSTOM_MONSTER_NAME_INFO * CCustomMonsterName::getMonster(int Class, int Map, int X, int Y)
{
	for (auto &monster : this->m_CustomMonsterNameInfo)
	{
		if (monster.Class != Class) {
			continue;
		}

		if (monster.Map != Map) {
			continue;
		}

		if ((monster.X == -1 || monster.X == X) || (monster.Y == -1 || monster.Y == Y)) {
			return &monster;
		}
	}

	return nullptr;
}

void CCustomMonsterName::SetMonsterAttribute(lpViewObj ObjectMonster, int MonsterID)
{
	((void(*)(lpViewObj, int))0x00580BB0)(ObjectMonster, MonsterID);

	auto monster = gCustomMonsterName.getMonster(MonsterID, pMapNumber, ObjectMonster->RespawnPosX, ObjectMonster->RespawnPosY);

	if (monster) {
		sprintf_s(ObjectMonster->Name, monster->name.c_str());
	}
}
