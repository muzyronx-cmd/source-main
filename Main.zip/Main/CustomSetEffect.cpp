#include "stdafx.h"
#include "CustomSetEffect.h"
#include "Util.h"
#include "LuaStack.hpp"

using namespace luaaa;

CCustomSetEffect gCCustomSetEffect;

CCustomSetEffect::CCustomSetEffect() : m_Lua(false)
{

}

CCustomSetEffect::~CCustomSetEffect()
{

}

void CreateEffectSetPlayer(DWORD ObjectStruct, DWORD ItemIndex) {
	DWORD BMDStruct = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), ItemIndex);

	if (BMDStruct != 0) {
		gCCustomSetEffect.m_Lua.Generic_Call("CreateEffectSetPlayer", "jjii>", BMDStruct, ObjectStruct, ItemIndex, *(DWORD*)0x7BD0458);
	}
}

__declspec(naked) void CheckSetEffect() {
	static DWORD m_ReturnFunc = 0x0057AD5E;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOVSX EDX, WORD PTR DS : [ECX + 0x19C];
		PUSH EDX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC]
		PUSH ECX;
		CALL[CreateEffectSetPlayer];
		ADD ESP, 0x8;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOVSX EDX, WORD PTR DS : [ECX + 0x19C];
		JMP[m_ReturnFunc];
	}
}

void CreateSetEffectSprite(DWORD BMDStruct, DWORD ObjectStruct, int BonePlayer, int EffectID, float Scale, float LightR, float LightB, float LightG, float PosX, float PosY, float PosZ) {
	if (BMDStruct == 0 || ObjectStruct == 0) {
		return;
	}

	auto Object = &*(ObjectModel*)ObjectStruct;

	if (Object != nullptr) {
		vec3_t p, Position;
		vec3_t Light;

		Vector(LightR, LightG, LightB, Light);
		Vector(PosX, PosY, PosZ, p);

		vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(DWORD, int))0x4CD7F0)(ObjectStruct, BonePlayer);

		if (BoneTransform != 0) {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[0], p, Position, 1);

			((void(*)(int, vec3_t, float, vec3_t, DWORD, float, int))0x771310)(EffectID, Position, Scale, Light, ObjectStruct, 0.0, 0);
		}
	}
}

void CreateSetEffectParticle(DWORD BMDStruct, DWORD ObjectStruct, int BonePlayer, int EffectID, int EffectLv, float Scale, float LightR, float LightB, float LightG, float PosX, float PosY, float PosZ) {
	if (BMDStruct == 0 || ObjectStruct == 0) {
		return;
	}

	auto Object = &*(ObjectModel*)ObjectStruct;

	if (Object != nullptr) {
		vec3_t p, Position;
		vec3_t Light;

		Vector(LightR, LightG, LightB, Light);
		Vector(PosX, PosY, PosZ, p);

		vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(DWORD, int))0x4CD7F0)(ObjectStruct, BonePlayer);

		if (BoneTransform != 0) {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[0], p, Position, 1);

			((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(EffectID, Position, Object->Angle, Light, EffectLv, Scale, ObjectStruct);
		}
	}
}

void CreateSetEffectSkill(DWORD BMDStruct, DWORD ObjectStruct, int BonePlayer, int EffectID, int EffectLv, float Scale, float LightR, float LightB, float LightG, float PosX, float PosY, float PosZ) {
	if (BMDStruct == 0 || ObjectStruct == 0) {
		return;
	}

	auto Object = &*(ObjectModel*)ObjectStruct;

	if (Object != nullptr) {
		vec3_t p, Position;
		vec3_t Light;

		Vector(LightR, LightG, LightB, Light);
		Vector(PosX, PosY, PosZ, p);

		vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(DWORD, int))0x4CD7F0)(ObjectStruct, BonePlayer);

		if (BoneTransform != 0) {
			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[0], p, Position, 1);

			((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(EffectID, Position, Object->Angle, Light, EffectLv, Scale, ObjectStruct);

			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(EffectID, Position, Object->Angle, Light, EffectLv, Object, -1, 0, 0, 0, 0.0, -1);
		}
	}
}

void CCustomSetEffect::Init()
{
	this->m_Lua.DoFile("Data//Files//Lua//EffectSystem//CharacterSetEffect.lua");

	SetCompleteHook(0xE9, 0x0057AD57, &CheckSetEffect);

	LuaModule(this->m_Lua.GetState()).fun("CreateSprite", &CreateSetEffectSprite);

	LuaModule(this->m_Lua.GetState()).fun("CreateParticle", &CreateSetEffectParticle);

	LuaModule(this->m_Lua.GetState()).fun("CreateSkill", &CreateSetEffectSkill);
}


void CCustomSetEffect::RestartLua()
{
	this->m_Lua.DoFile("Data//Files//Lua//EffectSystem//CharacterSetEffect.lua");

	SetCompleteHook(0xE9, 0x0057AD57, &CheckSetEffect);

	LuaModule(this->m_Lua.GetState()).fun("CreateSprite", &CreateSetEffectSprite);

	LuaModule(this->m_Lua.GetState()).fun("CreateParticle", &CreateSetEffectParticle);

	LuaModule(this->m_Lua.GetState()).fun("CreateSkill", &CreateSetEffectSkill);
}
