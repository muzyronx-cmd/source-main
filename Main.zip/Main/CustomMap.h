#pragma once

class CCustomMap {
public:
	CCustomMap();
	~CCustomMap();

	void Init();
};

extern CCustomMap gCustomMap;