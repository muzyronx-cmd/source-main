#include "stdafx.h"
#include "MuHelperInterface.h"
#include "Util.h"
#include "Offset.h"
#include "Interface.h"
#include "Defines.h"
#include "MuHelper.h"
#include "Protocol.h"
#include "Common.h"
#include "LoadFiles.h"

// ---------------------------------------------------------------------------------------------
CMuHelperInterface gMuHelperInterface;
// ---------------------------------------------------------------------------------------------

#define pHelperMouseClick		((char(__thiscall*)(int a1)) 0x007D2920)

char FixHelperMouseClick(int a1)
{
	if (CheckWindowOpen(ChaosBox) || CheckWindowOpen(Warehouse)) {
		return 0;
	}

	return pHelperMouseClick(a1);
}

void CMuHelperInterface::UpdateMouseEvent()
{
	if (CheckWindowOpen(Helper) == 0) {
		return;
	}

	if (CheckMouseIn(this->m_PosX + 50, this->m_PosY + 350, 90, 25)) {
		if (IsPressKey(VK_LBUTTON) && *(BYTE*)0x8793386) {
			ResetMouseL();

			gMuHelper.RunningOffHelper();
		}
	}
}

void RenderButtonOffMuHelper(DWORD x, DWORD y) {
	gMuHelperInterface.m_PosX = x;
	gMuHelperInterface.m_PosY = y;

	if (CheckMouseIn(x + 50, y + 350, 90, 25)) {
		RenderImage2(31326, (float)(x + 50), (float)(y + 350), (float)100, (float)25, 0, 0.2264566, 1.0, 0.2245212, 1, 1, 1.0);
	}
	else {
		RenderImage2(31326, (float)(x + 50), (float)(y + 350), (float)100, (float)25, 0, 0, 1.0, 0.2245212, 1, 1, 1.0);
	}

	pTextSetFont(pTextThis(), g_hFontBig);

	pSetTextColor(pTextThis(), 225, 225, 225, 255);

	pDrawText(pTextThis(), (float)(x + 50), (float)(y + 355), "Off Helper", 80, 0, 3, 0);

	pTextSetFont(pTextThis(), g_hFont);
}

__declspec(naked) void AddButtonOffMuHelper() {
	static DWORD m_ReturnFunc = 0x007F67A5;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x2D8];
		MOV ECX, DWORD PTR DS : [EAX + 0xCC];
		PUSH ECX;
		MOV EDX, DWORD PTR SS : [EBP - 0x2D8];
		MOV EAX, DWORD PTR DS : [EDX + 0xC8];
		PUSH EAX;
		CALL[RenderButtonOffMuHelper];
		ADD ESP, 0xC;


		PUSH 0x0DD1;
		JMP[m_ReturnFunc];
	}
}

void CMuHelperInterface::Init()
{
	SetCompleteHook(0xE8, 0x007D2B0C, &FixHelperMouseClick);

	if (gLoadFiles.m_LoadFiles.m_MuHelperOffline == 1) {
		SetCompleteHook(0xE9, 0x007F67A0, &AddButtonOffMuHelper);

		MemorySet(0x007F67F8, 0x90, 5);
		MemorySet(0x007F6875, 0x90, 5);
	}
}
