#include "stdafx.h"
#include "ChaosBoxGenesis.h"
#include "LuaStack.hpp"
#include "ItemMove.h"
#include "LuaGlobal.h"

using namespace luaaa;

class ChaosMachineGenesisLua {
public:
	ChaosMachineGenesisLua() : index(-1) {

	};

	ChaosMachineGenesisLua(int index) {
		this->index = index;
	};

	~ChaosMachineGenesisLua() {

	};

	int getIndex() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return -1;
		}

		return gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Type;
	};

	int getLevel() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		return (gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Level / 8) & 0xF;
	};

	int getOption1() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		return gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Option1;
	};

	int getExtOption() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		return gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->ExtOption;
	};

	int getLuck() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		return ((gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Level >> 2) & 1);
	};

	int getSkill() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		return ((gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Level >> 7) & 1);
	};

	int getLife() const {
		if (this->index == -1 || this->index > (int)gChaosBoxGenesis.m_ChaosMachineItens.size()) {
			return 0;
		}

		int oplevel = gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Level;
		int option1 = gChaosBoxGenesis.m_ChaosMachineItens[this->index].pItemObj->Option1;
		int Option3 = ((oplevel) & 3) + ((option1) & 64) / 64 * 4;

		return Option3;
	};

private:
	int index;
};

CChaosBoxGenesis gChaosBoxGenesis;

CChaosBoxGenesis::CChaosBoxGenesis() : m_Lua(true)
{
	this->m_Visible = 0;
	this->m_iMouseY = 0;

	this->ChaosBoxGenesisState = 0;

	this->m_MaxLines = 6;

	this->m_HeightBox = 70;

	this->m_ChaosMachineItens.clear();
}

CChaosBoxGenesis::~CChaosBoxGenesis()
{
	std::vector<CHAOS_MACHINE_ITENS>::iterator li = this->m_ChaosMachineItens.begin();

	for (; li != this->m_ChaosMachineItens.end(); li++) {
		li->Clear();
	}

	this->m_ChaosMachineItens.clear();
}

BOOL RenderChaosMachineExternalFunc() {
	if (gChaosBoxGenesis.isVisible()) {
		gChaosBoxGenesis.Render();
		return 1;
	}

	return 0;
}

__declspec(naked) void RenderChaosMachine() {
	static DWORD m_HookFunc = 0x0082C6C9;
	static DWORD m_ExitFunc = 0x0082C755;

	_asm {
		Call[RenderChaosMachineExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR SS : [EBP - 0x4], ECX;
		PUSH 0x1;
		JMP[m_HookFunc];
	}
}

BOOL ChaosMachineOpenningProcessFunc() {
	if (gChaosBoxGenesis.isVisible()) {
		gChaosBoxGenesis.OpenProcess();
		return 1;
	}

	return 0;
}

__declspec(naked) void ChaosMachineOpenningProcess() {
	static DWORD m_HookFunc = 0x0082C0B7;
	static DWORD m_ExitFunc = 0x0082C105;

	_asm {
		Call[ChaosMachineOpenningProcessFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV ECX, 0x00EBB848;
		JMP[m_HookFunc];
	}
}

BOOL UpdateMouseChaosMachineExternalFunc() {
	if (gChaosBoxGenesis.isVisible()) {
		gChaosBoxGenesis.UpdateMouseEvent();
		return 1;
	}

	return 0;
}

__declspec(naked) void UpdateMouseChaosMachine() {
	static DWORD m_HookFunc = 0x0082C3BA;
	static DWORD m_ExitFunc = 0x0082C467;

	_asm {
		Call[UpdateMouseChaosMachineExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR SS : [EBP - 0x4], ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x4];
		JMP[m_HookFunc];
	}
}

BOOL UpdateChaosMachineExternalFunc() {
	if (gChaosBoxGenesis.isVisible()) {
		gChaosBoxGenesis.Update();
		return 1;
	}

	return 0;
}

__declspec(naked) void UpdateChaosMachine() {
	static DWORD m_HookFunc = 0x0082C495;
	static DWORD m_ExitFunc = 0x0082C6AB;

	_asm {
		Call[UpdateChaosMachineExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV EAX, DWORD PTR SS : [EBP - 0x88];
		JMP[m_HookFunc];
	}
}

BOOL ClosingMachineExternalFunc() {
	if (gChaosBoxGenesis.isVisible()) {
		gChaosBoxGenesis.Close();
		return 1;
	}

	return 0;
}

__declspec(naked) void ChaosMachineClosingProcess() {
	static DWORD m_HookFunc = 0x0082C144;
	static DWORD m_ExitFunc = 0x0082C144;

	static DWORD m_OldEax = 0;

	_asm {
		MOV m_OldEax, EAX;

		Call[ClosingMachineExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		MOV DWORD PTR SS : [EBP - 0x850], ECX;
		JMP[m_ExitFunc];

	EXIT:
		MOV EAX, m_OldEax;
		MOV DWORD PTR SS : [EBP - 0x850], ECX;
		JMP[m_HookFunc];
	}
}

void RenderItensChaosMachineLua(float x, float y, float height, int MaxLines) {
	gChaosBoxGenesis.RenderItensChaosMachine(x, y, height, MaxLines);
}

int getCountItensByIndexLua(int index) {
	return gChaosBoxGenesis.getCountItensByIndex(index);
}

int getCountItensByIndexLevelLua(int index, int level, int exc, int luck, int skill, int life) {
	return gChaosBoxGenesis.getCountItensByIndexLevel(index, level, exc, luck, skill, life);
}

int getChaosBoxGenesisState() {
	return gChaosBoxGenesis.ChaosBoxGenesisState;
}

int getChaosBoxGenesisSelectedKey() {
	return gChaosBoxGenesis.ChaosBoxGenesisSelectedKey;
}

int getChaosBoxGenesisSelectedComb() {
	return gChaosBoxGenesis.ChaosBoxGenesisSelectedComb;
}

void SetChaosBoxGenesis(int selectedKey, int selectedComb) {
	gChaosBoxGenesis.ChaosBoxGenesisSelectedKey = selectedKey;
	gChaosBoxGenesis.ChaosBoxGenesisSelectedComb = selectedComb;

	SDHP_CHAOS_BOX_GENESIS_SET_INFO_SEND pMsg;

	pMsg.header.set(0xEF, 0x20, sizeof(pMsg));

	pMsg.state = 0;

	pMsg.selectedKey = selectedKey;

	pMsg.selectedComb = selectedComb;

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

int getMaxItens() {
	return (int)gChaosBoxGenesis.m_ChaosMachineItens.size();
}

void SendChaosMachineMix() {
	SDHP_CHAOS_BOX_GENESIS_MIX_SEND pMsg;

	pMsg.header.set(0xEF, 0x22, sizeof(pMsg));

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CChaosBoxGenesis::RestartLua()
{
	m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//Manager//ChaosMachine//ChaosMachine.lua");

	SetCompleteHook(0xE9, 0x0082C6C4, &RenderChaosMachine);

	SetCompleteHook(0xE9, 0x0082C48F, &UpdateChaosMachine);

	SetCompleteHook(0xE9, 0x0082C3B4, &UpdateMouseChaosMachine);

	SetCompleteHook(0xE9, 0x0082C0B2, &ChaosMachineOpenningProcess);

	SetCompleteHook(0xE9, 0x0082C13E, &ChaosMachineClosingProcess);

	LuaModule(this->m_Lua.GetState()).fun("RenderItensChaosMachine", &RenderItensChaosMachineLua);

	LuaModule(this->m_Lua.GetState()).fun("getCountItensByIndex", &getCountItensByIndexLua);

	LuaModule(this->m_Lua.GetState()).fun("getCountItensByIndexLevel", &getCountItensByIndexLevelLua);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisState", &getChaosBoxGenesisState);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisSelectedKey", &getChaosBoxGenesisSelectedKey);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisSelectedComb", &getChaosBoxGenesisSelectedComb);

	LuaModule(this->m_Lua.GetState()).fun("SetChaosBoxGenesis", &SetChaosBoxGenesis);

	LuaModule(this->m_Lua.GetState()).fun("getMaxItens", &getMaxItens);

	LuaModule(this->m_Lua.GetState()).fun("SendChaosMachineMix", &SendChaosMachineMix);

	LuaClass<ChaosMachineGenesisLua> luaChaosMachine(this->m_Lua.GetState(), "ChaosMachine");

}

void CChaosBoxGenesis::Init()
{
	m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//Manager//ChaosMachine//ChaosMachine.lua");

	SetCompleteHook(0xE9, 0x0082C6C4, &RenderChaosMachine);

	SetCompleteHook(0xE9, 0x0082C48F, &UpdateChaosMachine);

	SetCompleteHook(0xE9, 0x0082C3B4, &UpdateMouseChaosMachine);

	SetCompleteHook(0xE9, 0x0082C0B2, &ChaosMachineOpenningProcess);

	SetCompleteHook(0xE9, 0x0082C13E, &ChaosMachineClosingProcess);

	LuaModule(this->m_Lua.GetState()).fun("RenderItensChaosMachine", &RenderItensChaosMachineLua);

	LuaModule(this->m_Lua.GetState()).fun("getCountItensByIndex", &getCountItensByIndexLua);

	LuaModule(this->m_Lua.GetState()).fun("getCountItensByIndexLevel", &getCountItensByIndexLevelLua);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisState", &getChaosBoxGenesisState);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisSelectedKey", &getChaosBoxGenesisSelectedKey);

	LuaModule(this->m_Lua.GetState()).fun("getChaosBoxGenesisSelectedComb", &getChaosBoxGenesisSelectedComb);

	LuaModule(this->m_Lua.GetState()).fun("SetChaosBoxGenesis", &SetChaosBoxGenesis);

	LuaModule(this->m_Lua.GetState()).fun("getMaxItens", &getMaxItens);

	LuaModule(this->m_Lua.GetState()).fun("SendChaosMachineMix", &SendChaosMachineMix);

	LuaClass<ChaosMachineGenesisLua> luaChaosMachine(this->m_Lua.GetState(), "ChaosMachine");
	luaChaosMachine.ctor<int>();
	luaChaosMachine.fun("getIndex", &ChaosMachineGenesisLua::getIndex);
	luaChaosMachine.fun("getLevel", &ChaosMachineGenesisLua::getLevel);
	luaChaosMachine.fun("getOption1", &ChaosMachineGenesisLua::getOption1);
	luaChaosMachine.fun("getExtOption", &ChaosMachineGenesisLua::getExtOption);
	luaChaosMachine.fun("getLuck", &ChaosMachineGenesisLua::getLuck);
	luaChaosMachine.fun("getSkill", &ChaosMachineGenesisLua::getSkill);
	luaChaosMachine.fun("getLife", &ChaosMachineGenesisLua::getLife);
}

void CChaosBoxGenesis::Open(SDHP_CHAOS_BOX_GENESIS_OPEN_CLIENT_RECV * lpMsg)
{
	m_Visible = 1;

	m_EventState = EVENT_NONE;

	gChaosBoxGenesis.ChaosBoxGenesisState = lpMsg->state;

	gChaosBoxGenesis.ChaosBoxGenesisSelectedKey = lpMsg->selectedKey;

	gChaosBoxGenesis.ChaosBoxGenesisSelectedComb = lpMsg->selectedComb;

}

void CChaosBoxGenesis::Close()
{
	this->m_Visible = 0;

	this->DeleteAllItems();
}

void CChaosBoxGenesis::Render()
{
	this->m_Lua.Generic_Call("ChaosMachineRender", ">");
}

void CChaosBoxGenesis::Update()
{
	this->ItemPointer = -1;

	this->m_Lua.Generic_Call("ChaosMachineUpdate", ">");
}

void CChaosBoxGenesis::UpdateKeyEvent()
{

}

void CChaosBoxGenesis::UpdateMouseEvent()
{
	if (CheckMouseIn((int)ScrollBarPosX, (int)(ScrollBarPosY + ScrollBarPos), 15, 30)) {
		if (IsPressKey(VK_LBUTTON)) {
			m_EventState = EVENT_SCROLL_BTN_CLIKED;
			ResetMouseL();
		}

		m_EventState = EVENT_SCROLL_BTN_DOWN;
	}
	else {
		m_EventState = EVENT_NONE;
	}

	if (CheckMouseIn(this->m_PosX + 125, this->m_PosY, 50, this->m_HeightBox + 15)) {
		if (IsRepeatKey(VK_LBUTTON)) {
			int iMoveValue = pCursorY - m_iMouseY;

			if (iMoveValue < 0) {
				if (pCursorY <= (this->m_PosY + ScrollBarPos) + (20 / 2)) {
					this->ScrollLines(0);
				}
			}
			else if (iMoveValue > 0) {
				if (pCursorY >= (this->m_PosY + ScrollBarPos) + (20 / 2)) {
					this->ScrollLines(1);
				}
			}

			m_iMouseY = pCursorY;
		}
	}

	this->m_Lua.Generic_Call("ChaosMachineUpdateMouse", ">");
}

void CChaosBoxGenesis::Scrolling(int value)
{
	if (CheckMouseIn((int)this->m_PosX, (int)this->m_PosY, 160, this->m_HeightBox + 15)) {
		if (value > 0) {
			this->ScrollLines(0);
		}

		if (value < 0) {
			this->ScrollLines(1);
		}
		return;
	}

	this->m_Lua.Generic_Call("ChaosMachineScrolling", "i>", value);
}

void CChaosBoxGenesis::OpenProcess()
{
	m_EventState = EVENT_NONE;

	this->m_Lua.Generic_Call("ChaosMachineOpenning", ">");
}

void CChaosBoxGenesis::RenderItensChaosMachine(float x, float y, float height, int MaxLines)
{
	EnableAlphaTest(1);

	float SizeY = 0;

	char buffer[256];

	pTextSetFont(pTextThis(), g_hFont);

	int LineStart = 0;
	int LineCount = 0;

	for (auto &itemTarget : this->m_ChaosMachineItens) {
		if (LineStart >= ScrollBarOffset && LineCount <= MaxLines) {
			if (!itemTarget.pItemObj) {
				continue;
			}

			if (pCursorX >= x && pCursorX <= x + 130) {
				if (pCursorY >= y + SizeY && pCursorY <= y + (SizeY + 8)) {
					this->ItemPointer = itemTarget.slot;

					RenderItemInformation(x - 100, y + 125, itemTarget.pItemObj);
				}
			}

			auto itemAttr = pGetItemAttr(itemTarget.pItemObj->Type);

			if (!itemAttr) {
				continue;
			}

			EnableAlphaTest(true);

			pSetTextBgColor2(pTextThis(), 0);

			pSetTextColor(pTextThis(), 225, 225, 225, 255);

			pTextSetFont(pTextThis(), g_hFont);

			sprintf_s(buffer, "%s + %d", itemAttr->Name, (itemTarget.pItemObj->Level >> 3) & 0xF);
			pDrawText(pTextThis(), (int)(x), (int)(y + SizeY), buffer, 190, 0, 1, 0);

			DisableAlphaBlend();

			SizeY += 10;
			LineCount++;
		}

		LineStart++;
	}

	DisableAlphaBlend();

	this->m_PosX = x;
	this->m_PosY = y;
	this->m_HeightBox = height - 30;

	if (this->m_MaxLines != MaxLines) {
		this->m_MaxLines = MaxLines;
		this->CalcLinesRender();
	}

	this->RenderScroll(x - 5, y - 15, 160, height, MaxLines);
}

void CChaosBoxGenesis::CalcLinesRender()
{
	ScrollBarOffset = 0;
	ScrollBarPos = 0;
	ScrollBarMaxOffset = (int)(this->m_ChaosMachineItens.size() - (m_MaxLines+1));
	ScrollBarMultiplier = (float)((float)this->m_HeightBox / (float)(this->m_ChaosMachineItens.size() - (m_MaxLines)));
}

void CChaosBoxGenesis::InsertItemChaosMachine(BYTE slot, BYTE * ItemInfo)
{
	CHAOS_MACHINE_ITENS info;

	info.pItemObj = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

	info.slot = slot;

	this->m_ChaosMachineItens.push_back(info);

	this->CalcLinesRender();
}

void CChaosBoxGenesis::RenderItemInformation(float x, float y, ITEM * pItemObj)
{
	if (CheckWindowOpen(ObjWindow::ExpandInventory)) {
		return;
	}

	glColor4f(0.0f, 0.0f, 0.0f, 1.0f);

	pDrawBarForm(45, 40, 215.0f, 370.0f, 0.0, 0);

	((void(*)())0x637A30)();

	EnableAlphaTest(true);

	((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), 155, 130, pItemObj, 0, 0, 0);

	((void(*)())0x637A30)();

	DisableAlphaBlend();

	this->RenderItemImage(pItemObj);
}

void CChaosBoxGenesis::DelItem(BYTE slot)
{
	std::vector<CHAOS_MACHINE_ITENS>::iterator li = this->m_ChaosMachineItens.begin();

	for (; li != this->m_ChaosMachineItens.end(); li++) {
		auto pItem = &(*li);

		if (pItem->slot == slot) {
			pItem->Clear();
			this->m_ChaosMachineItens.erase(li);
			break;
		}
	}
}

void CChaosBoxGenesis::DeleteAllItems()
{
	for (auto &itemChaosBox : this->m_ChaosMachineItens) {
		itemChaosBox.Clear();
	}

	this->m_ChaosMachineItens.clear();
}

void CChaosBoxGenesis::RenderItemImage(ITEM * pItemObj)
{
	glMatrixMode(0x1701);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(int, int, int, int))0x6363D0)(0, 0, *(GLsizei*)MAIN_RESOLUTION_X, *(GLsizei*)MAIN_RESOLUTION_Y);

	((void(*)(float, float, float, float))0x6358A0)(1.f, (float)(*(DWORD*)MAIN_RESOLUTION_X) / (float)(*(DWORD*)MAIN_RESOLUTION_Y), *(float*)0xE61E38, *(float*)0xE61E3C);

	glMatrixMode(0x1700);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(vec34_t))0x635830)(*(vec34_t*)0x87933A0);

	((void(*)())0x635DE0)();

	((void(*)())0x635E40)();

	auto lpAttr = pGetItemAttr(pItemObj->Type);

	float width = lpAttr->Width;
	float height = lpAttr->Height;

	((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)((float)155, (float)100, (float)width * 3, (float)height * 4, (int)pItemObj->Type, (int)pItemObj->Level * 8, (int)pItemObj->Option1, (int)pItemObj->ExtOption, 0);

	glMatrixMode(0x1700);
	glPopMatrix();
	glMatrixMode(0x1701);
	glPopMatrix();

	glColor3f(1, 1, 1);
	pSetBlend(false);
}

void CChaosBoxGenesis::RenderScroll(float x, float y, float width, float height, int MaxLines)
{
	this->m_MaxLines = MaxLines;

	//Bar
	EnableAlphaTest(1);

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	RenderImage(31270, x + width - 11, y + 14, 7, 3);

	for (int i = 0; i < MaxLines; i++) {
		RenderImage(31271, x + width - 11, (y + 13) + (float)(i * 10 + 4), 7, 15);
	}

	RenderImage(31272, x + width - 11, y + height - 8, 7, 3);

	int Line = 0;

	if (m_EventState == EVENT_SCROLL_BTN_DOWN) {
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	}
	else {
		glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	}

	RenderImage(31273, x + width - 15, y + 10 + ScrollBarPos, 15, 30);

	ScrollBarPosY = (float)(y + 10);
	ScrollBarPosX = (float)(x + width - 15);

	DisableAlphaBlend();
}

void CChaosBoxGenesis::ScrollLines(int mode)
{
	if (mode == 0) { //Up
		if (ScrollBarOffset > 0) {
			ScrollBarOffset = ScrollBarOffset - 1;
			ScrollBarPos = ScrollBarPos - ScrollBarMultiplier;
		}
	}
	else if (mode == 1) { //Down
		if (ScrollBarOffset < ScrollBarMaxOffset) {
			ScrollBarOffset = ScrollBarOffset + 1;
			ScrollBarPos = ScrollBarPos + ScrollBarMultiplier;
		}
	}
}

int CChaosBoxGenesis::CheckCanMoveItemChaosBox(int ItemIndex)
{
	int retorno = 0;

	this->m_Lua.Generic_Call("ChaosMachineCheckCanMoveItem", "i>i", ItemIndex, &retorno);

	return retorno;
}

void CChaosBoxGenesis::ChaosBoxGenesisStateRecv(PMSG_CHAOS_BOX_GENESIS_STATE_RECV * lpMsg)
{
	this->ChaosBoxGenesisState = lpMsg->state;

	this->m_Lua.Generic_Call("ChaosMachineMixResult", "i>", this->ChaosBoxGenesisState);
}

void CChaosBoxGenesis::ChaosBoxGenesisListItemRecv(PMSG_CHAOS_BOX_GENESIS_LIST_RECV * lpMsg)
{
	this->DeleteAllItems();

	if (lpMsg->count <= 0) {
		return;
	}

	for (int n = 0; n < lpMsg->count; n++) {
		auto lpInfo = (PMSG_CHAOS_BOX_GENESIS_ITEM_INFO*)(((BYTE*)lpMsg) + sizeof(PMSG_CHAOS_BOX_GENESIS_LIST_RECV) + (sizeof(PMSG_CHAOS_BOX_GENESIS_ITEM_INFO)*n));

		this->InsertItemChaosMachine(lpInfo->slot, lpInfo->ItemInfo);
	}

	this->CalcLinesRender();
}

bool CChaosBoxGenesis::CheckMouse()
{
	if (CheckMouseIn((int)this->m_PosX, (int)this->m_PosY, 160, 200)) {
		return true;
	}

	return false;
}

void CChaosBoxGenesis::MoveItemFromInventory()
{
	gItemMove.m_InventoryCtrlMix = 0;

	gItemMove.m_BackupMouseX = pCursorX;
	gItemMove.m_BackupMouseY = pCursorY;

	int PointedSlot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);

	bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

	if (IsExtInv == 1 && PointedSlot == -1) {
		if (this->CheckChaosBoxGenesisSourceEmptySlot() == 0)
		{
			return;
		}

		DWORD ItemExpanded1 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), pCursorX, pCursorY);
		DWORD ItemExpanded2 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), pCursorX, pCursorY);

		if (ItemExpanded1 != -1) {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj) {
				if (this->CheckCanMoveItemChaosBox(pItemObj->Type) == 0) {
					return;
				}

				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

				if (slotEmpty != -1) {
					gItemMove.m_BackupSlot = ItemExpanded1 + 76;
					gItemMove.m_BackupTargetSlot = slotEmpty;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::ChaosBoxGenesis);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
		else if (ItemExpanded2 != -1) {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj) {
				if (this->CheckCanMoveItemChaosBox(pItemObj->Type) == 0) {
					return;
				}

				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

				if (slotEmpty != -1) {
					gItemMove.m_BackupSlot = ItemExpanded2 + 108;
					gItemMove.m_BackupTargetSlot = slotEmpty;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::ChaosBoxGenesis);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
		else {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj != nullptr) {
				if (this->CheckCanMoveItemChaosBox(pItemObj->Type) == 0) {
					return;
				}

				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				if (itemAttribute) {
					gItemMove.m_BackupTargetSlot = -1;
					gItemMove.m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, -1, MovePosition::ChaosBoxGenesis);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
	}
	else {
		if (PointedSlot != -1) {
			if (gItemMove.CheckItemEquiped(PointedSlot)) {
				auto item = gItemMove.getItem(PointedSlot);

				if (item->Type != -1) {
					auto itemAttribute = pGetItemAttr(item->Type);

					int value = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

					if (value != -1) {
						gItemMove.m_BackupSlot = PointedSlot;
						gItemMove.m_BackupTargetSlot = value + 12;
						SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
						ResetMouseR();
						gItemMove.m_ItemMove = 1;
						gItemMove.m_DeleteInventoryCtrl = 0;
					}
				}
			}
		}
		else {
			if (this->CheckChaosBoxGenesisSourceEmptySlot() == 0)
			{
				return;
			}

			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj != nullptr) {
				if (this->CheckCanMoveItemChaosBox(pItemObj->Type) == 0) {
					return;
				}

				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				if (itemAttribute) {
					gItemMove.m_BackupTargetSlot = -1;
					gItemMove.m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, -1, MovePosition::ChaosBoxGenesis);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
	}
}

void CChaosBoxGenesis::MoveItemToInventory()
{
	if (!this->CheckMouse()) {
		return;
	}

	if (gItemMove.checkAutoItemMove()) {
		return;
	}

	float SizeY = 0;
	int LineStart = 0;
	int LineCount = 0;

	for (auto &itemChaosBox : this->m_ChaosMachineItens) {
		if (LineStart >= ScrollBarOffset && LineCount <= 8) {
			if (!itemChaosBox.pItemObj) {
				continue;
			}

			if (pCursorX >= this->m_PosX && pCursorX <= this->m_PosX + 130) {
				if (pCursorY >= this->m_PosY + SizeY && pCursorY <= this->m_PosY + (SizeY + 8)) {
					auto itemAttr = pGetItemAttr(itemChaosBox.pItemObj->Type);

					if (itemAttr) {
						int slotInventory = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttr->Width, itemAttr->Height);

						if (slotInventory == -1) {
							int slotEmptyInv1 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), itemAttr->Width, itemAttr->Height);

							if (slotEmptyInv1 == -1) {
								int slotEmptyInv2 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), itemAttr->Width, itemAttr->Height);

								if (slotEmptyInv2 != -1) {
									gItemMove.m_BackupSlot = itemChaosBox.slot;
									gItemMove.m_BackupTargetSlot = slotInventory + 108;
									SendItemMove(gItemMove.m_BackupSlot, MovePosition::ChaosBoxGenesis, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									gItemMove.m_ItemMove = 1;
									gItemMove.m_InventoryCtrlMix = 0;
									gItemMove.m_DeleteInventoryCtrl = 0;
								}
							}
							else {
								gItemMove.m_BackupSlot = itemChaosBox.slot;
								gItemMove.m_BackupTargetSlot = slotInventory + 76;
								SendItemMove(gItemMove.m_BackupSlot, MovePosition::ChaosBoxGenesis, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								gItemMove.m_ItemMove = 1;
								gItemMove.m_InventoryCtrlMix = 0;
								gItemMove.m_DeleteInventoryCtrl = 0;
							}
						}
						else {
							gItemMove.m_BackupSlot = itemChaosBox.slot;
							gItemMove.m_BackupTargetSlot = slotInventory + 12;
							SendItemMove(gItemMove.m_BackupSlot, MovePosition::ChaosBoxGenesis, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
							ResetMouseR();
							gItemMove.m_ItemMove = 1;
							gItemMove.m_InventoryCtrlMix = 0;
							gItemMove.m_DeleteInventoryCtrl = 0;
						}
					}
				}
			}

			SizeY += 10;
			LineCount++;
		}

		LineStart++;
	}
}
