#include "StdAfx.h"
#include "HelperView.h"
#include "HelperSystem.h"
#include "LuaEffects.h"
#include "Item.h"
#include "CharacterList.h"
#include "Console.h"
#include "PetMode.h"

WORD * DetectSafeZone = &*(WORD*)0x82C6AA0;

enum eActionType
{
	ACTION_STAND = 0,
	ACTION_WALK = 0,
	ACTION_RUN = 0,
	ACTION_ATTACK1 = 3,
	ACTION_ATTACK2 = 4,
	ACTION_STUCK = 5,
	ACTION_DEAD = 6,
};


HELPER_VIEWPtr HELPER_VIEW::Make()
{
	HELPER_VIEWPtr HelperProcess(new HELPER_VIEW);
	HelperProcess->Init();
	return HelperProcess;
}

bool HELPER_VIEW::Create(int itemType, int modelType, vec3_t Position, ObjectPreview * Owner, int SubType)
{
	if (this->m_Obj == nullptr) {
		return 0;
	}

	if (this->m_Obj->Live) {
		return 0;
	}

	m_startTick = GetTickCount();

	m_pOwner = Owner;
	m_itemType = itemType + ITEM_BASE_MODEL;

	this->m_Obj->Type = modelType;
	this->m_Obj->Live = true;
	this->m_Obj->Visible = false;
	this->m_Obj->LightEnable = true;
	this->m_Obj->ContrastEnable = false;
	this->m_Obj->AlphaEnable = false;
	this->m_Obj->EnableBoneMatrix = false;
	this->m_Obj->Owner = &m_pOwner->Object;
	this->m_Obj->SubType = SubType;
	this->m_Obj->HiddenMesh = -1;
	this->m_Obj->BlendMesh = -1;
	this->m_Obj->BlendMeshLight = 1.f;
	this->m_Obj->Scale = 0.7f;
	this->m_Obj->LifeTime = 30;
	this->m_Obj->Alpha = 0.f;
	this->m_Obj->AlphaTarget = 1.f;

	VectorCopy(Position, this->m_Obj->Position);
	VectorCopy(this->m_Obj->Owner->Angle, this->m_Obj->Angle);
	Vector(75.f, 75.f, 75.f, this->m_Obj->Light);

	this->m_Obj->PriorAnimationFrame = 0.f;
	this->m_Obj->AnimationFrame = 0.f;
	this->m_Obj->Velocity = 0.5f;

	return 1;
}

void HELPER_VIEW::Render()
{
	if (m_Obj == nullptr || m_Obj->Owner == nullptr) {
		return;
	}

	if (!m_Obj->Live) {
		return;
	}

	int Effect = 0;

	if (g_isCharacterBuff((LPVOID)(*(DWORD*)((DWORD)m_Obj + 472) + 484), 18)) {
		Effect = 10;
	}

	m_Obj->Visible = ((bool(*)(float, float, float))0x5DBA10)(m_Obj->Position[0] * 0.01f, m_Obj->Position[1] * 0.01f, -50.0f);

	if (!m_Obj->Visible) {
		return;
	}

	((void(*)(ObjectModel*, bool, int, int))0x5EBBB0)(m_Obj, 0, 0, Effect);

	DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), m_Obj->Type);

	if (model != 0) {
		//gHelperSystem.m_Lua.Generic_Call("MoveEffects", "iii>", model, (DWORD)(m_Obj), m_Obj->Type);

		short safe = (this->IsMiniatureZone(m_Obj)) ? 1 : 0;
		gHelperSystem.RenderEffectHelper(model, (DWORD)(m_Obj), m_Obj->Type, safe);
		return;
	}
}

// In the safe zone, and anywhere while the owner is in pet mode, a mount follows its owner as a miniature.
// An owner riding in the city keeps the mount under it in the safe zone too.
bool HELPER_VIEW::IsMiniatureZone(ObjectModel* ObjectStruct)
{
	if (this->IsMount() && gPetMode.IsCityRiding(this->m_pOwner)) {
		return false;
	}

	if ((DetectSafeZone[PositionMap((int)floor(ObjectStruct->Owner->Position[0] / 100.0f), (int)floor(ObjectStruct->Owner->Position[1] / 100.0f))] & 1) == 1) {
		return true;
	}

	return this->IsMount() && gPetMode.IsActive(this->m_pOwner);
}
// The inventory preview spins the owner in place, so the helper is turned around the owner by the same amount.
void HELPER_VIEW::RenderPreview(float angleDelta)
{
	if (m_Obj == nullptr || m_Obj->Owner == nullptr || !m_Obj->Live || m_Obj->Alpha <= 0.0f) {
		return;
	}

	vec3_t position, angle;
	VectorCopy(m_Obj->Position, position);
	VectorCopy(m_Obj->Angle, angle);
	auto visible = m_Obj->Visible;

	float offsetX = position[0] - m_Obj->Owner->Position[0];
	float offsetY = position[1] - m_Obj->Owner->Position[1];
	float distance = sqrtf(offsetX * offsetX + offsetY * offsetY);
	const float maxDistance = 120.0f;

	if (distance > maxDistance) {
		offsetX *= maxDistance / distance;
		offsetY *= maxDistance / distance;
	}

	float radians = angleDelta * (3.14159265f / 180.0f);
	float c = cosf(radians);
	float s = sinf(radians);

	m_Obj->Position[0] = m_Obj->Owner->Position[0] + (offsetX * c) - (offsetY * s);
	m_Obj->Position[1] = m_Obj->Owner->Position[1] + (offsetX * s) + (offsetY * c);
	m_Obj->Angle[2] = angle[2] + angleDelta;
	m_Obj->Visible = true;

	((void(*)(ObjectModel*, bool, int, int))0x5EBBB0)(m_Obj, 0, 0, 0);

	VectorCopy(position, m_Obj->Position);
	VectorCopy(angle, m_Obj->Angle);
	m_Obj->Visible = visible;
}

// The world object keeps its own (miniature, safe zone) state, so the mounted pose is applied only for this draw.
void HELPER_VIEW::RenderPreviewMounted()
{
	if (m_Obj == nullptr || m_Obj->Owner == nullptr || !m_Obj->Live) {
		return;
	}

	vec3_t position, angle;
	VectorCopy(m_Obj->Position, position);
	VectorCopy(m_Obj->Angle, angle);
	bool visible = m_Obj->Visible;
	float scale = m_Obj->Scale;
	float alpha = m_Obj->Alpha;
	WORD action = m_Obj->CurrentAction;
	WORD priorAction = m_Obj->PriorAction;
	float frame = m_Obj->AnimationFrame;
	float priorFrame = m_Obj->PriorAnimationFrame;

	VectorCopy(m_Obj->Owner->Position, m_Obj->Position);
	VectorCopy(m_Obj->Owner->Angle, m_Obj->Angle);

	if (m_Type == 4) {
		m_Obj->Position[2] -= 30.0f;
	}

	m_Obj->Scale = this->PetOriginalSize;
	m_Obj->Alpha = 1.0f;
	m_Obj->Visible = true;
	m_Obj->CurrentAction = 0;
	m_Obj->PriorAction = m_MountPriorAction;
	m_Obj->AnimationFrame = m_MountFrame;
	m_Obj->PriorAnimationFrame = m_MountPriorFrame;

	DWORD now = GetTickCount();

	if (now - m_MountTick >= 40) {
		m_MountTick = now;

		DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), m_Obj->Type);

		if (model != 0) {
			float velocity = (m_Type == 8) ? 0.40f : ((m_Type == 16) ? 0.30f : 0.34f);

			*(WORD *)(model + 160) = m_Obj->CurrentAction;

			((bool(__thiscall*)(DWORD*, int, int, int, float, vec3_t, vec3_t)) 0x545180)
				((DWORD*)model, (int)&m_Obj->AnimationFrame, (int)&m_Obj->PriorAnimationFrame, (int)&m_Obj->PriorAction, velocity, m_Obj->Position, m_Obj->Angle);
		}

		m_MountFrame = m_Obj->AnimationFrame;
		m_MountPriorFrame = m_Obj->PriorAnimationFrame;
		m_MountPriorAction = m_Obj->PriorAction;
	}

	((void(*)(ObjectModel*, bool, int, int))0x5EBBB0)(m_Obj, 0, 0, 0);

	VectorCopy(position, m_Obj->Position);
	VectorCopy(angle, m_Obj->Angle);
	m_Obj->Visible = visible;
	m_Obj->Scale = scale;
	m_Obj->Alpha = alpha;
	m_Obj->CurrentAction = action;
	m_Obj->PriorAction = priorAction;
	m_Obj->AnimationFrame = frame;
	m_Obj->PriorAnimationFrame = priorFrame;
}

void HELPER_VIEW::Update()
{
	if (m_Obj == nullptr) {
		return;
	}

	if (!m_Obj->Live || m_Obj->Owner == nullptr) {
		m_Obj->Live = 0;
		return;
	}

	if (!m_Obj->Owner->Live || m_Obj->Owner->Kind != KIND_PLAYER)
	{
		m_Obj->Live = 0;
		return;
	}

	((void(*)(ObjectModel *)) 0x00541460)(m_Obj);

	DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), m_Obj->Type);

	if (model != 0) {
		UpdateModel(model);

		UpdateMove(model);
	}
}

void HELPER_VIEW::UpdateModel(DWORD model)
{
	*(WORD *)(model + 160) = m_Obj->CurrentAction;

	((bool(__thiscall*)(DWORD*, int, int, int, float, vec3_t, vec3_t)) 0x545180)
		((DWORD*)model, (int)&m_Obj->AnimationFrame, (int)&m_Obj->PriorAnimationFrame, (int)&m_Obj->PriorAction, m_Obj->Velocity, m_Obj->Position, m_Obj->Angle);
}

void HELPER_VIEW::WorkMoviment(ObjectModel* ObjectStruct, DWORD BMDStruct, float MaxPos, int type, int movement, int state)
{
	vec3_t p, Position;
	Vector(0.f, 0.f, 0.f, p);

	vec3_t Color;
	Vector(0.f, 0.f, 0.f, Color);

	float OwnerPosition0;
	float OwnerPosition1;
	float Position0;
	float Position1;
	float PetPosition;
	float Angle;
	float SetDirection;

	if (type == 0)
	{
		if (movement == 0)
		{
			MaxPos = 150.0f;

			OwnerPosition0 = ObjectStruct->Owner->Position[0];
			OwnerPosition1 = ObjectStruct->Owner->Position[1];
			Position0 = ObjectStruct->Position[0];
			Position1 = ObjectStruct->Position[1];

			PetPosition = (OwnerPosition1 - Position1) * (OwnerPosition1 - Position1) + (OwnerPosition0 - Position0) * (OwnerPosition0 - Position0);

			if (PetPosition >= (MaxPos * MaxPos))
			{
				Angle = CreateAngle(Position0, Position1, OwnerPosition0, OwnerPosition1);
				ObjectStruct->Angle[2] = TurnAngle2(ObjectStruct->Angle[2], Angle, 20.0);
			}

			AngleMatrix(ObjectStruct->Angle, ObjectStruct->Matrix);
			VectorRotate(ObjectStruct->Direction, ObjectStruct->Matrix, Position);

			ObjectStruct->Position[0] = Position[0] + ObjectStruct->Position[0];
			ObjectStruct->Position[1] = Position[1] + ObjectStruct->Position[1];
			ObjectStruct->Position[2] = Position[2] + ObjectStruct->Position[2];

			ObjectStruct->Position[2] += (float)(rand() % 16 - 8);

			if (!(rand() % 32))
			{
				if (PetPosition < MaxPos * MaxPos)
				{
					SetDirection = -(float)(rand() % 64 + 16) * 0.10f;
					ObjectStruct->Angle[2] = (float)(rand() % 360);
				}
				else
				{
					SetDirection = -(float)(rand() % 64 + 128) * 0.10f;
				}

				ObjectStruct->Direction[0] = 0.0f;
				ObjectStruct->Direction[1] = SetDirection;
				ObjectStruct->Direction[2] = (float)(rand() % 64 - 32) * 0.1f;
			}

			if (ObjectStruct->Owner->Position[2] + 150.0 > ObjectStruct->Position[2])
			{
				ObjectStruct->Direction[2] = ObjectStruct->Direction[2] + 1.5f;
			}
			if (ObjectStruct->Owner->Position[2] + 200.0 < ObjectStruct->Position[2])
			{
				ObjectStruct->Direction[2] = ObjectStruct->Direction[2] - 1.5f;
			}

			ObjectStruct->CurrentAction = 0;
		}
		else if (movement == 2)
		{
			vec3_t OwnerPos;
			float Angle;

			if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
				ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1] + 80.f;
			}

			ObjectStruct->Position[2] = ObjectStruct->Owner->Scale * 230.0f + ObjectStruct->Owner->Position[2];

			Vector(
				ObjectStruct->Owner->Position[0] - ObjectStruct->Position[0]
				, ObjectStruct->Owner->Position[1] - ObjectStruct->Position[1]
				, ObjectStruct->Owner->Position[2] - ObjectStruct->Position[2]
				, OwnerPos);

			float PetMap = OwnerPos[0] * OwnerPos[0] + OwnerPos[1] * OwnerPos[1];

			bool Walking = 0;

			if (PetMap < MaxPos * MaxPos * MaxPos * MaxPos)
			{
				if (PetMap >= MaxPos * MaxPos)
				{
					Angle = CreateAngle(ObjectStruct->Position[0], ObjectStruct->Position[1], ObjectStruct->Owner->Position[0], ObjectStruct->Owner->Position[1]);
					ObjectStruct->Angle[2] = TurnAngle2(ObjectStruct->Angle[2], Angle, +25.0);

					Walking = 1;
					ObjectStruct->CurrentAction = 2; //Setar correr
				}
			}
			else
			{
				ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
				ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
				ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
				ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2] + 200.0f;
				ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
				ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
				ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];
			}

			vec3_t VecPos;

			AngleMatrix(ObjectStruct->Angle, ObjectStruct->Matrix);
			VectorRotate(ObjectStruct->Direction, ObjectStruct->Matrix, VecPos);

			ObjectStruct->Position[0] = ObjectStruct->Position[0] + VecPos[0];
			ObjectStruct->Position[1] = ObjectStruct->Position[1] + VecPos[1];
			ObjectStruct->Position[2] = ObjectStruct->Position[2] + VecPos[2];

			float Velocity = 0.0;

			if (PetMap > MaxPos * MaxPos)
			{
				if (PetMap >= (MaxPos * 2) * (MaxPos * 2))
				{
					Velocity = log(PetMap) * 1.30f;
				}
				else if (PetMap >= (MaxPos + (MaxPos / 2)) * (MaxPos + (MaxPos / 2)))
				{
					Velocity = log(PetMap) * 1.20f;
				}
				else
				{
					Velocity = log(PetMap) * 1.05f;
				}
			}

			ObjectStruct->Direction[0] = 0.0f;
			ObjectStruct->Direction[1] = -Velocity;
			ObjectStruct->Direction[2] = 0.0f;

			if (!Walking)
			{
				ObjectStruct->CurrentAction = 0;
			}
		}
		else
		{
			bool AutoMove = 1;
			static float LostPostion = 3000.0f;

			vec3_t OwnerPos;

			Vector(ObjectStruct->Owner->Position[0], ObjectStruct->Owner->Position[1], ObjectStruct->Owner->Position[2], OwnerPos);

			vec3_t PetPos;

			Vector(ObjectStruct->Position[0], ObjectStruct->Position[1], ObjectStruct->Position[2], PetPos);

			vec3_t d;

			Vector(OwnerPos[0] - PetPos[0], OwnerPos[1] - PetPos[1], OwnerPos[2] - PetPos[2], d);

			float PetMap = d[0] * d[0] + d[1] * d[1];

			float dir1 = ((OwnerPos[0] > PetPos[0]) ? OwnerPos[0] - PetPos[0] : PetPos[0] - OwnerPos[0]);
			float dir2 = ((OwnerPos[1] > PetPos[1]) ? OwnerPos[1] - PetPos[1] : PetPos[1] - OwnerPos[1]);

			float angle = atan2(dir1, dir2) * 180.0f / 3.14159265359f;

			vec3_t VecPos, Random;

			if (PetMap < MaxPos * MaxPos * MaxPos * MaxPos)
			{
				if (PetMap >= MaxPos * MaxPos)
				{
					if (ObjectStruct->Position[0] < ObjectStruct->Owner->Position[0] - 1.0f && ObjectStruct->Position[1] < ObjectStruct->Owner->Position[1] - 1.0f)
					{
						ObjectStruct->Angle[2] = 180.0;//v->
						ObjectStruct->Angle[2] -= angle;//v->
					}
					else if (ObjectStruct->Position[0] < ObjectStruct->Owner->Position[0] - 1.0f && ObjectStruct->Position[1] > ObjectStruct->Owner->Position[1] - 1.0f)
					{
						ObjectStruct->Angle[2] = 0.0;//v->
						ObjectStruct->Angle[2] += angle;//v->
					}
					else if (ObjectStruct->Position[0] > ObjectStruct->Owner->Position[0] - 1.0f && ObjectStruct->Position[1] > ObjectStruct->Owner->Position[1] - 1.0f)
					{
						ObjectStruct->Angle[2] = 360.0;//v->
						ObjectStruct->Angle[2] -= angle;//v->
					}
					else if (ObjectStruct->Position[0] > ObjectStruct->Owner->Position[0] - 1.0f && ObjectStruct->Position[1] < ObjectStruct->Owner->Position[1] - 1.0f)
					{
						ObjectStruct->Angle[2] = 180.0;//v->
						ObjectStruct->Angle[2] += angle;//v->
					}

					ObjectStruct->CurrentAction = ACTION_RUN;
				}
				else
				{
					if (AutoMove)
					{
						float t = (float)(timeGetTime() % 4001) * 0.003140000160783529f;

						Random[0] = cos(t) * 100.0f + ObjectStruct->Owner->Position[0];

						Random[1] = sin(t) * 100.0f + ObjectStruct->Owner->Position[1];

						Random[2] = ObjectStruct->Owner->Position[2];

						float a = CreateAngle(ObjectStruct->Position[0], ObjectStruct->Position[1], Random[0], Random[1]);

						ObjectStruct->Angle[2] = TurnAngle2(ObjectStruct->Angle[2], a, 75.0f);
					}
					else
					{
						ObjectStruct->CurrentAction = ACTION_STAND;
					}
				}
			}
			else
			{
				ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
				ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
				ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
				ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
				ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
				ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];
			}

			AngleMatrix(ObjectStruct->Angle, ObjectStruct->Matrix);

			VectorRotate(ObjectStruct->Direction, ObjectStruct->Matrix, VecPos);

			ObjectStruct->Position[0] = ObjectStruct->Position[0] + VecPos[0];

			ObjectStruct->Position[1] = ObjectStruct->Position[1] + VecPos[1];

			ObjectStruct->Position[2] = ObjectStruct->Position[2] + VecPos[2];

			float MoveSpeed = 0.0;

			if (PetMap > MaxPos * MaxPos)  {
				if (PetMap >= (MaxPos * 2) * (MaxPos * 2)) {
					MoveSpeed = log(PetMap) * 1.30f;
				}
				else if (PetMap >= (MaxPos + (MaxPos / 2)) * (MaxPos + (MaxPos / 2))) {
					MoveSpeed = log(PetMap) * 1.20f;
				}
				else  {
					MoveSpeed = log(PetMap) * 1.05f;
				}
			}
			else
			{
				if (AutoMove) {
					MoveSpeed = log(PetMap) * 1.0f;
				}
			}

			ObjectStruct->Direction[0] = 0.0f;
			ObjectStruct->Direction[1] = -MoveSpeed;
			ObjectStruct->Direction[2] = 0.0f;

			if (PetMap >= LostPostion * LostPostion) {
				if (ObjectStruct->Position[0] < ObjectStruct->Owner->Position[0]) {
					ObjectStruct->Position[0] = ObjectStruct->Position[0] + d[0] + (float)(rand() % 360);
				}

				if (ObjectStruct->Position[0] > ObjectStruct->Owner->Position[0]) {
					ObjectStruct->Position[0] = ObjectStruct->Position[0] + d[0] - (float)(rand() % 360);
				}

				if (ObjectStruct->Position[1] < ObjectStruct->Owner->Position[1]) {
					ObjectStruct->Position[1] = ObjectStruct->Position[1] + d[1] + (float)(rand() % 360);
				}

				if (ObjectStruct->Position[1] > ObjectStruct->Owner->Position[1]) {
					ObjectStruct->Position[1] = ObjectStruct->Position[1] + d[1] - (float)(rand() % 360);
				}
			}

			if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
				ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
			}

			if (AutoMove) {
				ObjectStruct->CurrentAction = ACTION_RUN;
			}
		}
	}
	else if (type == 2 || type == 4) //Uniria // Dinorant
	{
		if (this->IsMiniatureZone(ObjectStruct) && !state)
		{
			if (this->Miniature == 1) {
				this->WorkdMovimentMiniature(ObjectStruct, BMDStruct, MaxPos);
			}
			else {
				ObjectStruct->Alpha = 0.0f;
			}
			return;
		}

		ObjectStruct->Scale = this->PetOriginalSize;

		if (ObjectStruct->Owner->Teleport == 1 || ObjectStruct->Owner->Teleport == 2) {
			ObjectStruct->Alpha = ObjectStruct->Alpha - 0.1f;

			if (ObjectStruct->Alpha < 0.0f) {
				ObjectStruct->Alpha = 0.0f;
			}
		}
		else {
			ObjectStruct->Alpha = 1.0f;
		}

		ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
		ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
		ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];

		if (gHelperSystem.CheckHelperType(ObjectStruct->Type, 4) != 0)
		{
			if (pMapNumber == 8 || pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132)) {
				ObjectStruct->Position[2] = ObjectStruct->Position[2] - 10.0f;
			}
			else if (pMapNumber != -1) {
				ObjectStruct->Position[2] = ObjectStruct->Position[2] - 30.0f;
			}
		}

		ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
		ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
		ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];

		if (ObjectStruct->Owner->CurrentAction >= 15 && ObjectStruct->Owner->CurrentAction <= 37 
			|| ObjectStruct->Owner->CurrentAction == 74 
			|| ObjectStruct->Owner->CurrentAction == 75
			|| ObjectStruct->Owner->CurrentAction == 259
			|| ObjectStruct->Owner->CurrentAction == 260) {
			if (gHelperSystem.CheckHelperType(ObjectStruct->Type, 4) != 0 && (pMapNumber == 8 || pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132))) {
				SetCurrentAction(ObjectStruct, 3, 1);
			}
			else {
				SetCurrentAction(ObjectStruct, 2, 1);
			}

			if (!(rand() % 2) && pMapNumber != 10 && !((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132)) {
				if (ObjectStruct->Owner) {
					if (!g_isCharacterBuff((LPVOID)(*(DWORD *)((DWORD)ObjectStruct + 472) + 484), 18)) {
						Vector((float)(rand() % 64 - 32) + ObjectStruct->Position[0], (float)(rand() % 64 - 32) + ObjectStruct->Position[1], (float)(rand() % 32 - 16) + ObjectStruct->Position[2], Position);
						
						Vector(1.0f, 1.0f, 1.0f, Color);

						if (pMapNumber == 2) {
							((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)
								(32101, Position, ObjectStruct->Angle, Color, 0, 1.0f, ObjectStruct);
						}
						else {
							((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)
								(32102, Position, ObjectStruct->Angle, Color, 0, 1.0f, ObjectStruct);
						}
					}
				}
			}
		}
		else if (ObjectStruct->Owner->CurrentAction == 68 || ObjectStruct->Owner->CurrentAction == 69) {
			if (pMapNumber == 8 || pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132)) {
				SetCurrentAction(ObjectStruct, 7, 1);
			}
			else {
				SetCurrentAction(ObjectStruct, 6, 1);
			}
		}
		else if (ObjectStruct->Owner->CurrentAction >= 38 && ObjectStruct->Owner->CurrentAction <= 59
			|| ((bool(*)(WORD))0x542280)(ObjectStruct->Owner->CurrentAction) == true)
		{
			if (gHelperSystem.CheckHelperType(ObjectStruct->Type, 4) != 0)
			{
				if (pMapNumber == 8 || pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132)) {
					SetCurrentAction(ObjectStruct, 5, 1);
				}
				else {
					SetCurrentAction(ObjectStruct, 4, 1);
				}
			}
			else
			{
				SetCurrentAction(ObjectStruct, 3, 1);
			}
		}
		else
		{
			if (gHelperSystem.CheckHelperType(ObjectStruct->Type, 4) != 0) {
				if (pMapNumber == 8 || pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132)) {
					SetCurrentAction(ObjectStruct, 1, 1);
				}
				else {
					SetCurrentAction(ObjectStruct, 0, 1);
				}
			}
			else {
				SetCurrentAction(ObjectStruct, 0, 1);
			}
		}
		
		ObjectStruct->Velocity = 0.34f;
		ObjectStruct->Live = ObjectStruct->Owner->Live;
	}
	else if (type == 8) //Fenrir
	{
		if (this->IsMiniatureZone(ObjectStruct) && !state)
		{
			if (this->Miniature == 1) {
				this->WorkdMovimentMiniature(ObjectStruct, BMDStruct, MaxPos);
			}
			else {
				ObjectStruct->Alpha = 0.0f;
			}
			return;
		}

		ObjectStruct->Scale = this->PetOriginalSize;

		if (ObjectStruct->Owner->Teleport == 1 || ObjectStruct->Owner->Teleport == 2)
		{
			ObjectStruct->Alpha = ObjectStruct->Alpha - 0.1f;

			if (ObjectStruct->Alpha < 0.0f)
			{
				ObjectStruct->Alpha = 0.0f;
			}
		}
		else
		{
			ObjectStruct->Alpha = 1.0f;
		}

		ObjectStruct->HeadAngle[0] = ObjectStruct->Owner->HeadAngle[0];
		ObjectStruct->HeadAngle[1] = ObjectStruct->Owner->HeadAngle[1];
		ObjectStruct->HeadAngle[2] = ObjectStruct->Owner->HeadAngle[2];
		ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
		ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
		ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
		ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
		ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
		ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];

		if (ObjectStruct->Owner->CurrentAction >= 90 && ObjectStruct->Owner->CurrentAction <= 101
			|| ((bool(*)(WORD))0x5422E0)(ObjectStruct->Owner->CurrentAction) == true
			|| ObjectStruct->Owner->CurrentAction == 282)
		{
			SetCurrentAction(ObjectStruct, 3, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 102 && ObjectStruct->Owner->CurrentAction <= 105)
		{
			SetCurrentAction(ObjectStruct, 4, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 106 && ObjectStruct->Owner->CurrentAction <= 109)
		{
			SetCurrentAction(ObjectStruct, 5, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 122 && ObjectStruct->Owner->CurrentAction <= 125 || ObjectStruct->Owner->CurrentAction == 231)
		{
			SetCurrentAction(ObjectStruct, 0, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 278 && ObjectStruct->Owner->CurrentAction <= 281)
		{
			SetCurrentAction(ObjectStruct, 5, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 262 && ObjectStruct->Owner->CurrentAction <= 265)
		{
			SetCurrentAction(ObjectStruct, 4, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 274 && ObjectStruct->Owner->CurrentAction <= 277)
		{
			SetCurrentAction(ObjectStruct, 0, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else if (ObjectStruct->Owner->CurrentAction >= 247 && ObjectStruct->Owner->CurrentAction <= 256)
		{
			SetCurrentAction(ObjectStruct, 0, 1);
			ObjectStruct->Velocity = 0.40f;
			return;
		}
		else {
			if (ObjectStruct->Owner->CurrentAction >= 126 && ObjectStruct->Owner->CurrentAction <= 129)
			{
				SetCurrentAction(ObjectStruct, 1, 1);
				ObjectStruct->Velocity = 1.0f;
			}
			else if (ObjectStruct->Owner->CurrentAction >= 110 && ObjectStruct->Owner->CurrentAction <= 121)
			{
				SetCurrentAction(ObjectStruct, 2, 1);
				ObjectStruct->Velocity = 0.60f;
			}
			else if (ObjectStruct->Owner->CurrentAction >= 270 && ObjectStruct->Owner->CurrentAction <= 273)
			{
				SetCurrentAction(ObjectStruct, 2, 1);
				ObjectStruct->Velocity = 0.60f;
			}
			else if (ObjectStruct->Owner->CurrentAction >= 266 && ObjectStruct->Owner->CurrentAction <= 269)
			{
				SetCurrentAction(ObjectStruct, 1, 1);
				ObjectStruct->Velocity = 1.0f;
			}
			else if (ObjectStruct->Owner->CurrentAction == 67
				&& ObjectStruct->CurrentAction >= 1
				&& ObjectStruct->CurrentAction <= 14)
			{
				SetCurrentAction(ObjectStruct, 0, 1);
				ObjectStruct->Velocity = 0.40f;
			}

			if (pMapNumber != 10)
			{
				if (!(rand() % 3) && (pMapNumber < 24 || pMapNumber > 29) && pMapNumber != 36)
				{
					if (ObjectStruct->Owner)
					{
						if (!g_isCharacterBuff((LPVOID)(*(DWORD *)((DWORD)ObjectStruct + 472) + 484), 18)) {
							Vector((float)(rand() % 64 - 32) + ObjectStruct->Position[0], (float)(rand() % 64 - 32) + ObjectStruct->Position[1], (float)(rand() % 32 - 16) + ObjectStruct->Position[2], Position);
							Vector(1.0f, 1.0f, 1.0f, Color);

							if (pMapNumber == 2)
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32101, Position, ObjectStruct->Angle, Color, 0, 1.0f, 0);
							}
							else if (pMapNumber != 10 && !((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132))
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32102, Position, ObjectStruct->Angle, Color, 0, 1.0f, 0);
							}
						}
					}
				}
			}
			else
			{
				int Effect = 0;

				Vector(1.0f, 1.0f, 1.0f, Color);
				Vector(120.0f, 0.0f, 32.0f, p);

				if (ObjectStruct->AnimationFrame > 1.0 && ObjectStruct->AnimationFrame < 1.2)
				{
					((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[22], p, Position, 0);

					Effect = 1;

					Position[0] = Position[0] + 40.0f;
				}

				if (ObjectStruct->AnimationFrame > 4.8 && ObjectStruct->AnimationFrame <= 5.0)
				{
					((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[44], p, Position, 0);

					Effect = 1;
					Position[0] = Position[0] + 40.0f;
					Position[2] = Position[2] + 700.0f;
				}

				if (Effect)
				{
					p[0] = Position[0];
					p[1] = Position[1];
					p[2] = Position[1];

					((void(*)(int, vec3_t, vec3_t,
						vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
						float, int))0x6D9070)(32279, p, ObjectStruct->Angle, Color, 1, ObjectStruct, -1, 0, 0, 0, 0.0, -1);

					for (int j = 0; j < ((rand() % 5) + 5); ++j)
					{
						p[0] = (float)(rand() % 50 - 25) + Position[0];
						p[1] = (float)(rand() % 50 - 25) + Position[1];
						p[2] = (float)(rand() % 16 - 8) + Position[2] - 10.0f;

						((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32101, p, ObjectStruct->Angle, Color, 0, 1.0f, 0);
					}
				}
			}
		}
	}
	else if (type == 16) //Horse
	{
		if (this->IsMiniatureZone(ObjectStruct) && !state)
		{
			if (this->Miniature == 1) {
				this->WorkdMovimentMiniature(ObjectStruct, BMDStruct, MaxPos);
			}
			else {
				ObjectStruct->Alpha = 0.0f;
			}
			return;
		}

		ObjectStruct->Scale = this->PetOriginalSize;

		{
			*(DWORD *)(BMDStruct + 84) = 7;

			ObjectStruct->HeadAngle[0] = ObjectStruct->Owner->HeadAngle[0];
			ObjectStruct->HeadAngle[1] = ObjectStruct->Owner->HeadAngle[1];
			ObjectStruct->HeadAngle[2] = ObjectStruct->Owner->HeadAngle[2];
			ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
			ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
			ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
			ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
			ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
			ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];

			if (ObjectStruct->Owner->CurrentAction == 87)
			{
				SetCurrentAction(ObjectStruct, 3, 1);
				ObjectStruct->Velocity = 0.34f;
			}
			else if (ObjectStruct->Owner->CurrentAction == 79)
			{
				bool Show = 0;

				Vector(1.0f, 1.0f, 1.0f, Color);
				Vector(120.0f, 0.0f, (float)(rand() % 64) - 32.0f, p);

				if (pMapNumber == 10 || ((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132))
				{
					if (ObjectStruct->AnimationFrame <= 1.0f || ObjectStruct->AnimationFrame >= 1.201f)
					{
						if (ObjectStruct->AnimationFrame <= 1.101f || ObjectStruct->AnimationFrame >= 1.40f)
						{
							if (ObjectStruct->AnimationFrame <= 1.3f || ObjectStruct->AnimationFrame >= 1.601f)
							{
								if (ObjectStruct->AnimationFrame > 1.5f &&ObjectStruct->AnimationFrame <= 1.80f)
								{
									((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[38], p, Position, 0);
									Show = 1;
								}
							}
							else
							{
								((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[32], p, Position, 0);
								Show = 1;
							}
						}
						else
						{
							((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[19], p, Position, 0);
							Show = 1;
						}
					}
					else
					{
						((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[13], p, Position, 0);
						Show = 1;
					}

					if (Show)
					{
						Vector(Position[0] + (float)(rand() % 16 - 8),
							Position[1] + (float)(rand() % 16 - 8),
							Position[2], p);

						((void(*)(int, vec3_t, vec3_t,
							vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
							float, int))0x6D9070)(32279, p, ObjectStruct->Angle, Color, 1, 0, -1, 0, 0, 0, 0.0, -1);

						for (int k = 0; k<rand() % 5 + 5; ++k)
						{
							Vector(Position[0] + (float)(rand() % 50 - 25),
								Position[1] + (float)(rand() % 50 - 25),
								Position[2] + (float)(rand() % 16 - 8) - 10, p);

							((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32101, p, ObjectStruct->Angle, Color, 0, 1.0f, 0);
						}
					}
				}
				else if (!(rand() % 2) && !((bool(*)(int))0x4DB1C0)(pMapNumber)) {
					if (ObjectStruct->Owner) {
						if (!g_isCharacterBuff((LPVOID)(*(DWORD *)((DWORD)ObjectStruct + 472) + 484), 18))
						{
							Vector(ObjectStruct->Position[0] + (float)(rand() % 64 - 32),
								ObjectStruct->Position[1] + (float)(rand() % 64 - 32),
								ObjectStruct->Position[2] + (float)(rand() % 32 - 16), p);

							if (pMapNumber == 2)
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32101, p, ObjectStruct->Angle, Color, 0, 1.0, 0);
							}
							else if (pMapNumber != 10 && !((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132))
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32102, p, ObjectStruct->Angle, Color, 0, 1.0, 0);
							}
						}
					}
				}

				SetCurrentAction(ObjectStruct, 1, 1);
				ObjectStruct->Velocity = 0.34f;
			}
			else if (ObjectStruct->Owner->CurrentAction < 82 || ObjectStruct->Owner->CurrentAction > 86)
			{
				if (ObjectStruct->Owner->CurrentAction == 88)
				{
					SetCurrentAction(ObjectStruct, 5, 1);
					ObjectStruct->Velocity = 1.00f;
				}
				else if (ObjectStruct->Owner->CurrentAction == 89)
				{
					SetCurrentAction(ObjectStruct, 6, 1);
					ObjectStruct->Velocity = 1.00f;
				}
				else
				{
					SetCurrentAction(ObjectStruct, 0, 1);
					ObjectStruct->Velocity = 0.30f;
					ObjectStruct->gap04[5] = 0;
				}
			}
			else
			{
				SetCurrentAction(ObjectStruct, 2, 1);
				ObjectStruct->Velocity = 0.34f;
			}

			if (ObjectStruct->CurrentAction != 1)
			{
				if (ObjectStruct->Owner)
				{
					if (!g_isCharacterBuff((LPVOID)(*(DWORD *)((DWORD)ObjectStruct + 472) + 484), 18))
					{
						if ((rand() % 4) == 0) {
							Vector(50.0f, -4.0f, 0.0f, p);

							((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[27], p, Position, 0);

							if (pMapNumber == 7 || pMapNumber == 67)
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32214, Position, ObjectStruct->Angle, ObjectStruct->Light, 0, 1.0, 0);
							}
							else
							{
								((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(32101, Position, ObjectStruct->Angle, ObjectStruct->Light, 0, 1.0, 0);
							}
						}
					}
				}
			}

			if (ObjectStruct->CurrentAction == 3)
			{
				vec3_t Pos1, Pos2, p, p2;

				Vector(60.f, 0.f, 0.f, Pos1);
				Vector(0.f, 0.f, 0.f, Pos2);
				Vector(1.f, 1.f, 1.f, Color);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[9], Pos1, p, false);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[9], Pos2, p2, false);
				((void(*)(ObjectPreview*, vec3_t, vec3_t, vec3_t, int))0x7293F0)(Hero, p, p2, Color, 0);
			}

			if (ObjectStruct->CurrentAction == 3)
			{
				((void(*)(ObjectModel*))0x5039A0)(ObjectStruct);
			}

			if (ObjectStruct->Owner->ExtState == 1)
			{
				vec34_t Matrix;
				vec3_t Angles;

				Vector(0.0f, 50.0f, 0.0f, Angles);
				Vector(0.0f, 0.0f, 0.0f, p);

				for (int l = 0; l < 4; ++l)
				{
					p[2] = p[2] + 90.0f;
					AngleMatrix(p, Matrix);
					VectorRotate(Angles, Matrix, Position);

					Position[0] = Position[0] + ObjectStruct->Position[0];
					Position[1] = Position[1] + ObjectStruct->Position[1];
					Position[2] = Position[2] + ObjectStruct->Position[2];

					for (int m = 0; m < 3; ++m)
					{
						((void(*)(int32_t, vec3_t, vec3_t, vec3_t, int32_t, ObjectModel*, float_t, int16_t,
							WORD, WORD, int32_t, const float_t*, int16_t))0x72D1B0)(1551, Position, Position, p, 0, ObjectStruct, 40.0f, 2, 0, 0, -1, 0, -1);
					}
				}
			}

			ObjectStruct->Owner->ExtState = 0;
			ObjectStruct->Live = ObjectStruct->Owner->Live;
		}
	}
}

void HELPER_VIEW::WorkdMovimentMiniature(ObjectModel * ObjectStruct, DWORD BMDStruct, float MaxPos)
{
	vec3_t OwnerPos;
	float Angle;

	ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];

	Vector(
		ObjectStruct->Owner->Position[0] - ObjectStruct->Position[0]
		, ObjectStruct->Owner->Position[1] - ObjectStruct->Position[1]
		, ObjectStruct->Owner->Position[2] - ObjectStruct->Position[2]
		, OwnerPos);

	float PetMap = OwnerPos[0] * OwnerPos[0] + OwnerPos[1] * OwnerPos[1];

	bool Walking = 0;

	if (PetMap < MaxPos * MaxPos * MaxPos)
	{
		if (PetMap >= (MaxPos * MaxPos) + 20)
		{

			// PET FICAR UM AO LADO DO OUTRO
			Angle = CreateAngle(ObjectStruct->Position[0], ObjectStruct->Position[1], ObjectStruct->Owner->Position[0], ObjectStruct->Owner->Position[1]);
			ObjectStruct->Angle[2] = TurnAngle2(ObjectStruct->Angle[2], Angle+30, 17.0);

			Walking = 1;

			if (m_Type == 16) {
				ObjectStruct->CurrentAction = 1;
			}
			else {
				ObjectStruct->CurrentAction = 2; //Setar correr
			}
		}
	}
	else
	{
		ObjectStruct->Position[0] = ObjectStruct->Owner->Position[0];
		ObjectStruct->Position[1] = ObjectStruct->Owner->Position[1];
		ObjectStruct->Position[2] = ObjectStruct->Owner->Position[2];
		ObjectStruct->Angle[0] = ObjectStruct->Owner->Angle[0];
		ObjectStruct->Angle[1] = ObjectStruct->Owner->Angle[1];
		ObjectStruct->Angle[2] = ObjectStruct->Owner->Angle[2];
	}

	vec3_t VecPos;

	AngleMatrix(ObjectStruct->Angle, ObjectStruct->Matrix);
	VectorRotate(ObjectStruct->Direction, ObjectStruct->Matrix, VecPos);

	if (OwnerPos[0] == 0.0f && OwnerPos[1] == 0.0f && OwnerPos[2] == 0.0f) {
		VecPos[0] = 40.f;
		VecPos[1] = 120.f;
	}

	ObjectStruct->Position[0] = ObjectStruct->Position[0] + VecPos[0];
	ObjectStruct->Position[1] = ObjectStruct->Position[1] + VecPos[1];
	ObjectStruct->Position[2] = ObjectStruct->Position[2] + VecPos[2];

	float Velocity = 0.0;

	if (PetMap > MaxPos * MaxPos)
	{
		if (PetMap >= (MaxPos * 180) * (MaxPos * 80))
		{
			Velocity = log(PetMap) * 1.30f;
		}
		else if (PetMap >= (MaxPos + (MaxPos / 180)) * (MaxPos + (MaxPos / 180)))
		{
			Velocity = log(PetMap) * 1.20f;
		}
		else
		{
			Velocity = log(PetMap) * 1.05f;
		}
	}

	ObjectStruct->Direction[0] = 0.00005f;
	ObjectStruct->Direction[1] = -Velocity;
	ObjectStruct->Direction[2] = 0.0f;

	if (!Walking)
	{
		ObjectStruct->CurrentAction = 0;
	}

	ObjectStruct->Scale = this->SizeMiniature;
	ObjectStruct->Velocity = this->VelocityMiniature;
}

void HELPER_VIEW::UpdateMove(DWORD model)
{
	WorkMoviment(m_Obj, model, 180.f, m_Type, m_Movement, 0);

	if (m_HeightFloor > 0.0f && m_Type == 0)
	{
		m_Obj->Position[2] = m_Obj->Owner->Position[2] + m_HeightFloor;
	}

	if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
		if (m_Type == 0) {
			m_Obj->Position[2] = m_Obj->Owner->Position[2] + gCharacterList.FlyingAddHeight;
		}
	}
}
