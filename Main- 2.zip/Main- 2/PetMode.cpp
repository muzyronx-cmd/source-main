#include "stdafx.h"
#include "PetMode.h"
#include "HelperSystem.h"
#include "Interface.h"
#include "Util.h"
#include <math.h>

CPetMode gPetMode;

#define PM_SetPlayerStop				((void(__cdecl*)(ObjectPreview* Character)) 0x0054EA80)
#define PM_DrawMessage					((int(__cdecl*)(LPCSTR Text, int Mode)) 0x00597630)
#define PM_GetViewportCharacter(n)		((ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), n))
#define PM_TerrainWall					((WORD*)0x082C6AA0)
#define PM_REGISTRY_KEY					"SOFTWARE\\Webzen\\Mu\\Config"
#define PM_MAP_ICARUS					10

// Each set is normal, over, press, disable; ".tga" is read from the ".ozt" next to it.
// Pet button: dismount art from D:\MuAdventure\MountMini, then the generated "mount back" art.
// City button: the same pair with a house badge (Tools\PetMode\gerar_botao_montar.py).
static const int PM_IMAGE_FIRST = 71120;
static const int PM_IMAGE_COUNT = 16;
static const int PM_IMAGE_PET_DOWN = PM_IMAGE_FIRST + 0;
static const int PM_IMAGE_PET_UP = PM_IMAGE_FIRST + 4;
static const int PM_IMAGE_CITY_UP = PM_IMAGE_FIRST + 8;
static const int PM_IMAGE_CITY_DOWN = PM_IMAGE_FIRST + 12;
static const int PM_IMAGE_OVER = 1;
static const int PM_IMAGE_PRESS = 2;
static const int PM_IMAGE_DISABLE = 3;
static const char* PM_ImageFile[PM_IMAGE_COUNT] =
{
	"Custom\\PetMode\\riding_manager_down_normal.tga",
	"Custom\\PetMode\\riding_manager_down_over.tga",
	"Custom\\PetMode\\riding_manager_down_press.tga",
	"Custom\\PetMode\\riding_manager_down_disable.tga",
	"Custom\\PetMode\\riding_manager_up_normal.tga",
	"Custom\\PetMode\\riding_manager_up_over.tga",
	"Custom\\PetMode\\riding_manager_up_press.tga",
	"Custom\\PetMode\\riding_manager_up_disable.tga",
	"Custom\\PetMode\\riding_city_up_normal.tga",
	"Custom\\PetMode\\riding_city_up_over.tga",
	"Custom\\PetMode\\riding_city_up_press.tga",
	"Custom\\PetMode\\riding_city_up_disable.tga",
	"Custom\\PetMode\\riding_city_down_normal.tga",
	"Custom\\PetMode\\riding_city_down_over.tga",
	"Custom\\PetMode\\riding_city_down_press.tga",
	"Custom\\PetMode\\riding_city_down_disable.tga",
};

// The art is 46x53; the texture is stretched to 64x64, so the buttons keep that proportion on screen.
// The interface is laid out on 640x480; the column is centered on the right edge.
static const int PM_DOCK_WIDTH = 35;
static const int PM_DOCK_HEIGHT = 40;
static const int PM_DOCK_GAP = 6;
static const int PM_DOCK_MARGIN = 4;
static const DWORD PM_TOGGLE_DELAY = 800;

// Windows docked on the right side of the screen are drawn over the button column.
static const int PM_CoverWindows[] =
{
	ObjWindow::FriendList, ObjWindow::MoveList, ObjWindow::Party, ObjWindow::Quest, ObjWindow::Guild,
	ObjWindow::Trade, ObjWindow::Warehouse, ObjWindow::ChaosBox, ObjWindow::PetInfo, ObjWindow::Shop,
	ObjWindow::Inventory, ObjWindow::Store, ObjWindow::OtherStore, ObjWindow::Character, ObjWindow::GuildMaster,
	ObjWindow::Options, ObjWindow::SkillTree, ObjWindow::CashShop, ObjWindow::FullMap, ObjWindow::NPC_Dialog,
	ObjWindow::GensInfo, ObjWindow::ExpandInventory, ObjWindow::ExpandWarehouse, ObjWindow::Helper,
};

static int PM_ReadRegistry(const char* name, int defaultValue)
{
	HKEY key;
	int value = defaultValue;

	if (RegOpenKeyExA(HKEY_CURRENT_USER, PM_REGISTRY_KEY, 0, KEY_READ, &key) == ERROR_SUCCESS)
	{
		DWORD data = 0;
		DWORD size = sizeof(data);
		DWORD type = 0;

		if (RegQueryValueExA(key, name, 0, &type, (LPBYTE)&data, &size) == ERROR_SUCCESS && type == REG_DWORD)
		{
			value = (int)data;
		}

		RegCloseKey(key);
	}

	return value;
}

static void PM_WriteRegistry(const char* name, int value)
{
	HKEY key;

	if (RegCreateKeyExA(HKEY_CURRENT_USER, PM_REGISTRY_KEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, NULL) == ERROR_SUCCESS)
	{
		DWORD data = (DWORD)value;

		RegSetValueExA(key, name, 0, REG_DWORD, (const BYTE*)&data, sizeof(data));
		RegCloseKey(key);
	}
}

// The client marks a character as inside the safe zone in three places (creation, teleport and every
// movement update). Riding in the city keeps that mark off, so every native riding check rides.
static BYTE __cdecl PM_SafeZoneFlag(ObjectPreview* character)
{
	return (gPetMode.IsCityRiding(character)) ? 0 : 1;
}

// The city mount clears InSafeZone so the riding pose stays. Combat still follows the real tile:
// a mounted character attacks only outside the city, and cannot be attacked while standing on one.
static BYTE __cdecl PM_CityCombatBlocked(ObjectPreview* character)
{
	return (gPetMode.IsCityRiding(character) && gPetMode.InSafeTile(character)) ? 1 : 0;
}

static BYTE __cdecl PM_PhysicalBlocked(ObjectPreview* attacker, ObjectPreview* target)
{
	if (attacker != nullptr && attacker->InSafeZone)
	{
		return 1;
	}

	if (PM_CityCombatBlocked(attacker) || PM_CityCombatBlocked(target))
	{
		return 1;
	}

	return 0;
}

__declspec(naked) void PM_BlockPhysicalAttack()
{
	static DWORD m_Allow = 0x005A0915;
	static DWORD m_Block = 0x005A2D76;

	__asm
	{
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		PUSH ECX;
		PUSH EAX;
		CALL PM_PhysicalBlocked;
		ADD ESP, 0x8;
		TEST AL, AL;
		JNZ Blocked;
		JMP[m_Allow];
	Blocked:
		JMP[m_Block];
	}
}

__declspec(naked) void PM_BlockSkillUse()
{
	static DWORD m_Allow = 0x005B3D46;
	static DWORD m_Block = 0x005B4A6A;

	__asm
	{
		PUSH EBP;
		MOV EBP, ESP;
		SUB ESP, 0x28;
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		PUSH EAX;
		CALL PM_CityCombatBlocked;
		ADD ESP, 0x4;
		TEST AL, AL;
		JNZ Blocked;
		JMP[m_Allow];
	Blocked:
		JMP[m_Block];
	}
}

__declspec(naked) void PM_SafeZoneMove()
{
	static DWORD m_Back = 0x00561750;

	_asm
	{
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		PUSH EAX;
		CALL PM_SafeZoneFlag;
		ADD ESP, 0x4;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV BYTE PTR DS : [ECX + 0xE], AL;
		JMP[m_Back];
	}
}

__declspec(naked) void PM_SafeZoneCreate()
{
	static DWORD m_Back = 0x004F0B06;

	_asm
	{
		MOV EAX, DWORD PTR SS : [EBP - 0x10];
		PUSH EAX;
		CALL PM_SafeZoneFlag;
		ADD ESP, 0x4;
		MOV ECX, DWORD PTR SS : [EBP - 0x10];
		MOV BYTE PTR DS : [ECX + 0xE], AL;
		JMP[m_Back];
	}
}

__declspec(naked) void PM_SafeZoneTeleport()
{
	static DWORD m_Back = 0x0057DDE7;

	_asm
	{
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		PUSH EAX;
		CALL PM_SafeZoneFlag;
		ADD ESP, 0x4;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV BYTE PTR DS : [ECX + 0xE], AL;
		JMP[m_Back];
	}
}

CPetMode::CPetMode()
{
	this->m_Flags = 0;
	this->m_Suspended = false;
	this->m_PetKeyDown = false;
	this->m_CityKeyDown = false;
	this->m_LastToggle = 0;
	memset(this->m_State, 0, sizeof(this->m_State));
}

void CPetMode::Init()
{
	this->m_Flags = (BYTE)(PM_ReadRegistry("PetMode", 0) & PM_FLAG_MASK);

	if (this->m_Flags == PM_FLAG_MASK)
	{
		this->m_Flags = PM_FLAG_PET;
	}

	SetCompleteHook(0xE9, 0x00561740, &PM_SafeZoneMove);
	SetCompleteHook(0xE9, 0x004F0AF6, &PM_SafeZoneCreate);
	SetCompleteHook(0xE9, 0x0057DDD7, &PM_SafeZoneTeleport);
	SetCompleteHook(0xE9, 0x005A0905, &PM_BlockPhysicalAttack);
	SetCompleteHook(0xE9, 0x005B3D40, &PM_BlockSkillUse);
}

void CPetMode::LoadImages()
{
	for (int i = 0; i < PM_IMAGE_COUNT; i++)
	{
		((int(__cdecl*)(char*, int, int, int, int, int))0x00772330)((char*)PM_ImageFile[i], PM_IMAGE_FIRST + i, GL_LINEAR, GL_CLAMP, 1, 0);
	}
}

int CPetMode::GetDockX()
{
	return 640 - PM_DOCK_MARGIN - PM_DOCK_WIDTH;
}

int CPetMode::GetDockY(int slot)
{
	int total = (PM_DOCK_COUNT * PM_DOCK_HEIGHT) + ((PM_DOCK_COUNT - 1) * PM_DOCK_GAP);

	return ((480 - total) / 2) + (slot * (PM_DOCK_HEIGHT + PM_DOCK_GAP));
}

int CPetMode::GetDockWidth()
{
	return PM_DOCK_WIDTH;
}

int CPetMode::GetDockHeight()
{
	return PM_DOCK_HEIGHT;
}

bool CPetMode::InGame()
{
	return *(DWORD*)MAIN_SCREEN_STATE == 5 && oUserPreviewStruct != 0;
}

bool CPetMode::HasMount(ObjectPreview* character)
{
	return character != nullptr && gHelperSystem.IsMount(character->PetSlot);
}

BYTE CPetMode::GetFlags(ObjectPreview* character)
{
	// The hero follows the local choice right away; the server echo only confirms it.
	if (character == (ObjectPreview*)oUserPreviewStruct)
	{
		return this->m_Flags;
	}

	return this->m_State[character->aIndex];
}

bool CPetMode::IsActive(ObjectPreview* character)
{
	if (character == nullptr || this->m_Suspended || !this->InGame() || pMapNumber == PM_MAP_ICARUS)
	{
		return false;
	}

	return (this->GetFlags(character) & PM_FLAG_PET) != 0;
}

bool CPetMode::IsCityRiding(ObjectPreview* character)
{
	if (character == nullptr || !this->InGame())
	{
		return false;
	}

	return (this->GetFlags(character) & PM_FLAG_CITY) != 0 && this->HasMount(character);
}

bool CPetMode::InSafeTile(ObjectPreview* character)
{
	if (character == nullptr)
	{
		return false;
	}

	int x = (int)floor(character->Object.Position[0] / 100.0f);
	int y = (int)floor(character->Object.Position[1] / 100.0f);

	return (PM_TerrainWall[PositionMap(x, y)] & 1) != 0;
}

bool CPetMode::IsCovered()
{
	LPVOID window = pWindowThis();

	if (window == NULL)
	{
		return false;
	}

	for (int i = 0; i < (int)(sizeof(PM_CoverWindows) / sizeof(PM_CoverWindows[0])); i++)
	{
		if (pCheckWindow(window, PM_CoverWindows[i]) != 0)
		{
			return true;
		}
	}

	return false;
}

bool CPetMode::CanToggle(BYTE flag)
{
	if (flag == PM_FLAG_PET && pMapNumber == PM_MAP_ICARUS)
	{
		return false;
	}

	return (GetTickCount() - this->m_LastToggle) >= PM_TOGGLE_DELAY;
}

void CPetMode::RenderButton(int slot, int image, bool disabled, const char* tooltip)
{
	int x = GetDockX();
	int y = GetDockY(slot);
	bool hover = CheckMouseIn(x, y, PM_DOCK_WIDTH, PM_DOCK_HEIGHT);

	if (disabled)
	{
		image += PM_IMAGE_DISABLE;
	}
	else if (hover && *(BYTE*)0x8793384 != 0)
	{
		image += PM_IMAGE_PRESS;
	}
	else if (hover)
	{
		image += PM_IMAGE_OVER;
	}

	EnableAlphaTest(true);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	RenderImage2(image, (float)x, (float)y, (float)PM_DOCK_WIDTH, (float)PM_DOCK_HEIGHT, 0.0f, 0.0f, 1.0f, 1.0f, true, true, 1.0f);

	if (hover)
	{
		pTextSetFont(pTextThis(), g_hFontBold);
		pSetTextColor(pTextThis(), 255, 255, 255, 255);
		pSetTextBgColor(pTextThis(), 0, 0, 0, 200);
		pDrawText(pTextThis(), x - 126, y + (PM_DOCK_HEIGHT / 2) - 6, tooltip, 120, 0, 3, 0);
	}

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

void CPetMode::Render()
{
	if (!this->InGame() || this->IsCovered())
	{
		return;
	}

	bool mount = this->HasMount(Hero);
	bool pet = (this->m_Flags & PM_FLAG_PET) != 0;
	bool city = (this->m_Flags & PM_FLAG_CITY) != 0;

	const char* petText = (!mount) ? "Equipe uma montaria"
		: ((pMapNumber == PM_MAP_ICARUS) ? "Indisponivel em Icarus" : ((pet) ? "Montar (Ctrl+Z)" : "Modo Pet (Ctrl+Z)"));

	const char* cityText = (!mount) ? "Equipe uma montaria"
		: ((city) ? "Mini pet na cidade (Ctrl+X)" : "Montar na cidade (Ctrl+X)");

	this->RenderButton(PM_DOCK_PET, (pet) ? PM_IMAGE_PET_UP : PM_IMAGE_PET_DOWN, !mount || !this->CanToggle(PM_FLAG_PET), petText);
	this->RenderButton(PM_DOCK_CITY, (city) ? PM_IMAGE_CITY_DOWN : PM_IMAGE_CITY_UP, !mount || !this->CanToggle(PM_FLAG_CITY), cityText);
}

void CPetMode::UpdateMouse()
{
	if (!this->InGame() || this->IsCovered())
	{
		return;
	}

	static const int slots[] = { PM_DOCK_PET, PM_DOCK_CITY };
	static const BYTE flags[] = { PM_FLAG_PET, PM_FLAG_CITY };

	for (int i = 0; i < 2; i++)
	{
		if (!CheckMouseIn(GetDockX(), GetDockY(slots[i]), PM_DOCK_WIDTH, PM_DOCK_HEIGHT))
		{
			continue;
		}

		// Clicks on the buttons must not reach the world, or the character walks to the cursor.
		gInterface.interfaceLock = 1;

		if (*(BYTE*)0x8793386 != 0)
		{
			ResetMouseL();

			if (this->HasMount(Hero) && this->CanToggle(flags[i]))
			{
				this->Toggle(flags[i]);
			}
		}

		return;
	}
}

void CPetMode::UpdateKey()
{
	bool focused = GetForegroundWindow() == MAIN_WINDOW && GetFocus() == MAIN_WINDOW;
	bool ctrl = focused && (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
	bool petDown = ctrl && (GetAsyncKeyState('Z') & 0x8000) != 0;
	bool cityDown = ctrl && (GetAsyncKeyState('X') & 0x8000) != 0;

	if (petDown && !this->m_PetKeyDown)
	{
		this->TryToggle(PM_FLAG_PET);
	}

	if (cityDown && !this->m_CityKeyDown)
	{
		this->TryToggle(PM_FLAG_CITY);
	}

	this->m_PetKeyDown = petDown;
	this->m_CityKeyDown = cityDown;
}

void CPetMode::TryToggle(BYTE flag)
{
	if (!this->InGame())
	{
		return;
	}

	if (!this->HasMount(Hero))
	{
		PM_DrawMessage("Equipe uma montaria para usar este modo.", 1);
	}
	else if (flag == PM_FLAG_PET && pMapNumber == PM_MAP_ICARUS)
	{
		PM_DrawMessage("O Modo Pet nao pode ser usado em Icarus.", 1);
	}
	else if (this->CanToggle(flag))
	{
		this->Toggle(flag);
	}
}

void CPetMode::Toggle(BYTE flag)
{
	bool enable = (this->m_Flags & flag) == 0;

	// Pet everywhere and riding in the city ask for opposite things, so turning one on turns the other off.
	this->m_Flags = (enable) ? flag : 0;
	this->m_LastToggle = GetTickCount();

	PM_WriteRegistry("PetMode", this->m_Flags);

	this->SendState();
	this->Refresh(Hero);

	if (flag == PM_FLAG_PET)
	{
		PM_DrawMessage((enable) ? "Modo Pet ativado: a montaria segue voce como mascote." : "Modo Pet desativado: voce voltou a montar.", 1);
	}
	else
	{
		PM_DrawMessage((enable) ? "Montaria na cidade ativada: voce continua montado na Safe Zone." : "Montaria na cidade desativada: na Safe Zone ela volta a ser mini pet.", 1);
	}
}

void CPetMode::SendState()
{
	PMSG_PET_MODE_SEND pMsg;

	pMsg.header.set(0xF3, 0xD8, sizeof(pMsg));

	pMsg.state = this->m_Flags;

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CPetMode::EnterWorld()
{
	memset(this->m_State, 0, sizeof(this->m_State));

	// The server starts every character with both modes off, so the saved choice is sent on each login.
	this->SendState();
}

void CPetMode::GCPetModeRecv(BYTE* lpMsg, int size)
{
	PMSG_PET_MODE_LIST_RECV* lpHead = (PMSG_PET_MODE_LIST_RECV*)lpMsg;

	if (size < (int)sizeof(PMSG_PET_MODE_LIST_RECV) || size < (int)(sizeof(PMSG_PET_MODE_LIST_RECV) + (lpHead->count * sizeof(PMSG_PET_MODE_INFO))))
	{
		return;
	}

	for (int n = 0; n < lpHead->count; n++)
	{
		PMSG_PET_MODE_INFO* lpInfo = (PMSG_PET_MODE_INFO*)(lpMsg + sizeof(PMSG_PET_MODE_LIST_RECV) + (sizeof(PMSG_PET_MODE_INFO) * n));

		this->SetState(MAKE_NUMBERW(lpInfo->index[0], lpInfo->index[1]), lpInfo->state);
	}
}

void CPetMode::SetState(int aIndex, BYTE state)
{
	state &= PM_FLAG_MASK;

	if (aIndex < 0 || aIndex >= (int)sizeof(this->m_State) || this->m_State[aIndex] == state)
	{
		return;
	}

	this->m_State[aIndex] = state;

	for (int n = 0; n < MAX_MAIN_VIEWPORT; n++)
	{
		ObjectPreview* character = PM_GetViewportCharacter(n);

		if (character != nullptr && character->Object.Live != 0 && character->aIndex == aIndex)
		{
			this->Refresh(character);
			return;
		}
	}
}

// The safe-zone mark is only rewritten on the next movement update and a standing character only
// picks a new pose on the next stop, so both are refreshed when a mode changes.
void CPetMode::Refresh(ObjectPreview* character)
{
	if (character == nullptr || character->Object.Live == 0)
	{
		return;
	}

	character->InSafeZone = this->InSafeTile(character) && !this->IsCityRiding(character);

	if (this->HasMount(character) && character->Movement == 0)
	{
		PM_SetPlayerStop(character);
	}
}
