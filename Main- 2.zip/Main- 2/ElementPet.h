#pragma once

#include "HelperView.h"

class CElementPet {
public:
	CElementPet();
	~CElementPet();

	void Relese();

	bool CreateHelper(int Index, int ModelIndex, vec3_t Position, ObjectPreview* m_Owner, int SubType = 0);
	void DeleteHelper(ObjectPreview *Owner, int itemType = -1, bool allDelete = false);
	void Register(BoostSmart_Ptr(HELPER_VIEW) info);
	void UnRegister(ObjectPreview *Owner, int itemType, bool isUnregistAll = false);
	bool CheckExistsHelper(ObjectPreview *Owner);

	void RenderElement();
	void RenderPreview(ObjectModel* owner, float angleDelta);
	void UpdateElement();

private:
	std::vector<BoostSmart_Ptr(HELPER_VIEW)> m_ElementPet;
};

extern CElementPet gElementPetFirst;
extern CElementPet gElementPetSecond;