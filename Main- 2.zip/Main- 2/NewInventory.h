#pragma once

#include "Lua.h"

#define NEW_INVENTORY_CLASSIC_WIDTH		190
#define NEW_INVENTORY_HEIGHT			429
#define NEW_INVENTORY_SCREEN_WIDTH		640
#define NEW_INVENTORY_SCREEN_HEIGHT		480
#define NEW_INVENTORY_MAX_SLOTS			12
#define NEW_INVENTORY_MAX_ELEMENTS		4
#define NEW_INVENTORY_MAX_COINS			3
#define NEW_INVENTORY_MAX_VALUES		8
#define NEW_INVENTORY_MAX_WINDOWS		64
#define NEW_INVENTORY_MAX_SLOT_NAMES	(NEW_INVENTORY_MAX_SLOTS + NEW_INVENTORY_MAX_ELEMENTS)

enum NEW_INVENTORY_SIZE
{
	NEW_INVENTORY_SIZE_LARGE = 0,
	NEW_INVENTORY_SIZE_COMPACT = 1,
};

enum NEW_INVENTORY_BUTTON_LABEL
{
	NEW_INVENTORY_LABEL_SHRINK = 0,
	NEW_INVENTORY_LABEL_EXPAND,
	NEW_INVENTORY_LABEL_DOCK,
	NEW_INVENTORY_LABEL_CLOSE,
	NEW_INVENTORY_LABEL_HIDE_SET,
	NEW_INVENTORY_LABEL_SHOW_SET,
	NEW_INVENTORY_LABEL_HIDE_ACC,
	NEW_INVENTORY_LABEL_SHOW_ACC,
	NEW_INVENTORY_LABEL_COUNT,
};

struct NEW_INVENTORY_RECT
{
	int x;
	int y;
	int width;
	int height;
};

struct NEW_INVENTORY_COIN
{
	char Label[32];
	int ValueIndex;
	BYTE Color[4];
};

struct NEW_INVENTORY_LAYOUT
{
	bool Wide;
	bool Managed;
	bool Forced;
	int InventoryX;
	int InventoryY;
	int ExtensionX;
	int PairedWindow;
	int PairedX;
};

class CNewInventory
{
public:
	CNewInventory();
	~CNewInventory();

	void Init();
	void LoadConfig();
	void RegisterLua(lua_State* lua);

	void SetPos(DWORD This, int x, int y);
	void ApplyEquipmentSlots(DWORD This);
	void UpdateLayout(DWORD This);

	void UpdateButtons();
	void RenderFrame(DWORD This);
	void RenderExpansionSlots(DWORD extension);
	void RenderTitleAndCoins(DWORD This);
	void RenderEquipmentOverlay(DWORD This);
	void RenderRowButtons(DWORD This);
	bool RenderShopButton(DWORD button);
	void LoadImages();

	bool IsWide() { return this->m_Wide; };
	bool IsCompact() { return !this->m_Wide && this->m_Enabled != 0 && this->m_Style == 1 && this->m_CompactSkin != 0; };
	bool IsSkinned() { return this->m_Wide || this->IsCompact(); };
	int GetWidth();
	int GetCenterOffset();
	int GetOptionOffsetX();
	int GetOptionOffsetY();
	int GetCompanionX() { return this->m_CompanionX; };
	int GetPosX();
	int GetPosY();
	int GetButtonX(int index);
	int GetButtonY();
	bool GetVisualTabRect(int index, NEW_INVENTORY_RECT* rect);

	void SetCoinValue(int index, DWORD value);
	DWORD GetCoinValue(int index);
	void SetExpandPrice(int slot, int coin, DWORD value);
	void FinishExpandBuy(int result, int count);
	int ExpandedSlotAtCursor();
	int FindEmptyExpandedSlot(int width, int height);

	void SetSlotRect(int slot, int x, int y, int width, int height);
	void SetElementRect(int slot, int x, int y, int width, int height);
	void SetSlotName(int slot, const char* name);
	void SetCoin(int index, const char* label, int valueIndex, BYTE r, BYTE g, BYTE b);
	void AddClassicWindow(int window);
	void SetPairedWindow(int window, int enabled);

private:
	NEW_INVENTORY_LAYOUT ComputeLayout();
	void SetMode(bool wide);
	void RestoreClassicPositions(DWORD This);
	void MovePairedWindow(int window, int x);
	int GetPairedWindowX(int window);
	bool PairedButtonsInPlace(int window);
	void MoveExtension(int x);
	int GetExtensionX();
	bool IsWindowOpen(int window);
	void SwapExternalRects(bool wide);
	void PatchWidth(int width);
	void ResolveSlotRect(int slot, NEW_INVENTORY_RECT* rect);
	void ResolveElementRect(int slot, NEW_INVENTORY_RECT* rect);
	int GetContentShift() { return (this->m_Wide) ? (this->GetCenterOffset() - this->m_CenterOffset) : 0; };

	void UnlockExpansion(int count);
	void FormatExpandPrice(int slot, char* buffer, int size);
	void LoadUserSettings();
	void SaveUserSettings();
	int GetButtonOffsetX(int index);
	int GetButtonOffsetY();
	int HiddenSetShift();
	void KeepCenterOnScreen(NEW_INVENTORY_LAYOUT* layout);
	int GetHeaderHeight() { return (this->m_Wide) ? 30 : 22; };
	NEW_INVENTORY_RECT* GetTabRects();

	void RenderHeader(int x, int y);
	void RenderVisualTabs(int x, int y);
	bool RenderHeaderButton(int x, int y, int size, int icon, bool danger, const char* tooltip, bool marked = false);
	void HandleDrag(int x, int y, int width);
	void RenderSlotWells(DWORD This, int x, int y);
	void RenderSections(DWORD This, int x, int y);
	void RenderCompactSections(DWORD This, int x, int y);
	void RenderCoins(int x, int y, NEW_INVENTORY_RECT* rects);
	void RenderPreview(int x, int y);
	void GetPreviewControlRects(int px, int py, NEW_INVENTORY_RECT* toggle, NEW_INVENTORY_RECT* mount);
	void RenderCharacterModel(int x, int y, int width, int height);
	void AnimateMountedPose(ObjectModel* object);

	void DrawRect(float x, float y, float width, float height, float r, float g, float b, float a);
	void DrawGradient(float x, float y, float width, float height, const float* top, const float* bottom, int bands);
	void DrawBorder(float x, float y, float width, float height, float r, float g, float b, float a);
	void DrawAccentBorder(float x, float y, float width, float height, float alpha);
	void DrawFrameTexture(int x, int y);
	void DrawModernFrame(int x, int y, int width, int headerHeight);
	void RenderRowButton(int x, int y, int index, int image, bool danger, bool marked, const char* tooltip);
	bool DrawIconButton(int left, int top, int width, int height, int image, bool danger, bool marked, bool disabled);
	void DrawGrip(int x, int y, bool hover);
	void DrawCard(int x, int y, int width, int height, const char* caption);
	void DrawCoinBox(int x, int y, int width, int height, const char* label, const char* value, BYTE* color);
	void DrawTooltip(int centerX, int anchorY, const char* text, bool below);
	void DrawTooltipIn(int centerX, int anchorY, const char* text, bool below, int left, int right);
	void SetPendingTooltip(int centerX, int anchorY, const char* text, bool below);
	void DrawLabel(int x, int y, const char* text, int width, int align, BYTE r, BYTE g, BYTE b, BYTE a, bool bold);
	bool DrawButton(int x, int y, int width, int height, const char* text, bool active, bool repeat);
	int GetTextWidth(const char* text);
	void FormatNumber(DWORD value, char* buffer, int size);

public:
	int m_Enabled;
	int m_Style;
	int m_ExtensionRight;
	int m_CloseButton;
	int m_AllowMove;
	int m_AllowResize;
	int m_CompactSkin;
	int m_ShowSet;
	int m_ShowAccessories;
	int m_SizeMode;
	int m_PreviewEnabled;
	int m_PreviewVisible;
	int m_PreviewMounted;
	float m_PreviewFov;
	float m_PreviewDistance;
	float m_PreviewHeight;
	float m_PreviewAngle;
	float m_PreviewRotateSpeed;
	float m_Accent[3];

	int m_Width;
	int m_CenterOffset;
	int m_GridY;
	int m_ButtonY;
	int m_CompactButtonY;
	int m_OptionOffsetX;
	int m_OptionOffsetY;
	NEW_INVENTORY_RECT m_PreviewRect;
	NEW_INVENTORY_RECT m_CoinRect[NEW_INVENTORY_MAX_COINS];
	NEW_INVENTORY_RECT m_CompactCoinRect[NEW_INVENTORY_MAX_COINS];
	NEW_INVENTORY_RECT m_TabRect[2];
	NEW_INVENTORY_RECT m_CompactTabRect[2];
	NEW_INVENTORY_RECT m_SlotRect[NEW_INVENTORY_MAX_SLOTS];
	NEW_INVENTORY_RECT m_ElementRect[NEW_INVENTORY_MAX_ELEMENTS];
	NEW_INVENTORY_COIN m_Coin[NEW_INVENTORY_MAX_COINS];
	char m_SlotName[NEW_INVENTORY_MAX_SLOT_NAMES][32];
	char m_SectionLabel[3][32];
	char m_TabLabel[2][32];
	char m_ButtonLabel[NEW_INVENTORY_LABEL_COUNT][32];
	char m_PreviewShowLabel[32];
	char m_PreviewHideLabel[32];
	char m_PreviewHintLabel[64];
	char m_PreviewMountLabel[32];

private:
	bool m_Wide;
	bool m_Managed;
	bool m_Forced;
	int m_AppliedShowSet;
	int m_AppliedShowAcc;
	bool m_CloseRequested;
	bool m_SuppressExpandClick;
	bool m_PreviewDragging;
	int m_PreviewLastMouseX;
	bool m_PreviewHasMount;
	WORD m_MountAction;
	WORD m_MountPriorAction;
	float m_MountFrame;
	float m_MountPriorFrame;
	DWORD m_MountTick;
	DWORD m_CoinValue[NEW_INVENTORY_MAX_VALUES];
	int m_ExpandCoin[4];
	DWORD m_ExpandValue[4];
	int m_ExpandKnown[4];
	int m_ExpandConfirm;
	bool m_ExpandBuying;

	int m_Floating;
	int m_FloatX;
	int m_FloatY;
	bool m_Dragging;
	int m_DragOffsetX;
	int m_DragOffsetY;
	int m_CompanionX;

	bool m_TooltipPending;
	bool m_TooltipBelow;
	int m_TooltipX;
	int m_TooltipY;
	char m_TooltipText[64];

	int m_ClassicWindows[NEW_INVENTORY_MAX_WINDOWS];
	int m_ClassicWindowCount;
	int m_PairedEnabled[NEW_INVENTORY_MAX_WINDOWS];

	NEW_INVENTORY_RECT m_SavedVisualRect[9];
	NEW_INVENTORY_RECT m_SavedElementRect[NEW_INVENTORY_MAX_ELEMENTS];
	bool m_RectsSwapped;

	Lua m_Lua;
};

extern CNewInventory gNewInventory;
