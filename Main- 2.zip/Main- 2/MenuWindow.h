#pragma once

class CMenuWindow {
public:
	CMenuWindow();
	~CMenuWindow();

	void Init();
	void ChangeFontSize(int fontSize, bool resolution = 0);
	void ChangeLanguage(char* lang);
	void ChangeResolution(int value);
	void SetWindowMode(int windowed);
	void ApplyPendingMode();
	void ApplySize(int width, int height);
	void UpdateWideCamera();

public:
	int m_HealthBarDisabled;
	int m_ShadowDisabled;
	int m_WingDisabled;
	int m_Windowed;
	int m_ApplyPending;
	int m_PendingWindowed;
	int m_Applying;
};

extern CMenuWindow gMenuWindow;