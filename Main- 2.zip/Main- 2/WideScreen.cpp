#include "stdafx.h"
#include "WideScreen.h"
#include "Util.h"
#include "Offset.h"

JCWideScreem JCPWideScreem;

void OpenInitFile()
{
	((signed int (*)())0x004D0FC0)();

	int X01;
	int X02;
	int X03;
	int C01;//Ventana Central 1

	*(float*)0xE7C3D4 = (double)(unsigned int)pWinHeight / 480.0;

	if (pWinWidth == 1024 && pWinHeight == 600)
	{
		*(int*)0x87933EC = pWinWidth;
		*(int*)0x87933E8 = pWinHeight;
	}

	JCPWideScreem.DisplayWinCDepthBox = (int)pWinWidth / pWinHeightReal - 640;

	JCPWideScreem.JCWinWidth = pWinWidth / pWinHeightReal;
	JCPWideScreem.JCWinWidthAdd = JCPWideScreem.JCWinWidth / 2 - 320;
	X01 = JCPWideScreem.JCWinWidth - (640 - 450);
	X02 = JCPWideScreem.JCWinWidth - (640 - 260);
	X03 = JCPWideScreem.JCWinWidth - (640 - 70);
	C01 = (JCPWideScreem.JCWinWidth / 2) - (230 / 2);
	//
	//
	//SetDouble(0xD23AB8, JCPWideScreem.JCWinWidth); //-- Effect
	SetFloat(0x00D23B7C, JCPWideScreem.JCWinWidth); //-- Effect
	SetFloat(0x00D2C2A0, 480); //-- Effect

	SetDword((0x0040F7B7 + 1), JCPWideScreem.JCWinWidth); //-- Store
	SetDword((0x0048BC81 + 2), JCPWideScreem.JCWinWidth); //-- friend list
	SetDword((0x0048BC8C + 1), JCPWideScreem.JCWinWidth); //-- friend list

	SetDword((0x0085A6A8 + 1), X01);
	SetDword((0x0085A8AE + 1), X01);
	SetDword((0x0085A92D + 1), X01);
	SetDword((0x0085A9AC + 1), X01);
	SetDword((0x0085AA2B + 1), X01);
	SetDword((0x0085AB41 + 1), X01);
	SetDword((0x0085ABCF + 1), X01);
	SetDword((0x0085AD78 + 1), X01);
	SetDword((0x0085AE06 + 1), X01);
	SetDword((0x0085AE94 + 1), X01);
	SetDword((0x0085AFB0 + 1), X01);
	SetDword((0x0085B048 + 1), X01);
	SetDword((0x0085B0D6 + 1), X01);
	SetDword((0x0085B4D9 + 1), X01);
	SetDword((0x0085B56D + 1), X01);
	SetDword((0x0085C020 + 1), X01);
	SetDword((0x0085C0B4 + 1), X01);
	SetDword((0x0085C270 + 1), X01);
	SetDword((0x0085C4C0 + 1), X01);
	SetDword((0x0085C5F2 + 1), X01);
	SetDword((0x0085C686 + 1), X01);
	SetDword((0x0085C71A + 1), X01);
	SetDword((0x0085C7AE + 1), X01);
	SetDword((0x0085C977 + 1), X01);
	SetDword((0x0085CC36 + 1), X01);
	SetDword((0x0085F78B + 1), X01);
	SetDword((0x0085F87A + 1), X01);
	SetDword((0x0085FA1A + 1), X01);
	SetDword((0x0085FA45 + 1), X01);
	SetDword((0x0085FA8B + 1), X01);
	SetDword((0x0085FD25 + 1), X01);
	SetDword((0x0085FE8D + 1), X01);
	SetDword((0x00860033 + 1), X01);
	//--
	SetDword((0x0085A731 + 1), X02);
	SetDword((0x0085A7B0 + 1), X02);
	SetDword((0x0085A82F + 1), X02);
	SetDword((0x0085AAB3 + 1), X02);
	SetDword((0x0085AC5F + 1), X02);
	SetDword((0x0085ACEA + 1), X02);
	SetDword((0x0085B1F5 + 1), X02);
	SetDword((0x0085C148 + 1), X02);
	SetDword((0x0085C1DC + 1), X02);
	SetDword((0x0085CA15 + 1), X02);
	SetDword((0x0085CAA9 + 1), X02);
	SetDword((0x0085CB3D + 1), X02);
	SetDword((0x0085CCCA + 1), X02);
	SetDword((0x0085ED59 + 1), X02);
	SetDword((0x0085EDF7 + 1), X02);
	SetDword((0x0085EE7E + 1), X02);
	SetDword((0x0085EEAB + 1), X02);
	SetDword((0x0085F0F1 + 1), X02);
	SetDword((0x0085F7B6 + 1), X02);
	//--
	SetDword((0x00791B9A + 3), C01);
	SetDword((0x00791C0A + 3), C01);
	SetDword((0x00792E4A + 3), C01);
	SetDword((0x00792EFA + 3), C01);
	SetDword((0x007A0C1F + 3), C01);
	SetDword((0x007A2266 + 3), C01);
	SetDword((0x007A34EF + 3), C01);
	SetDword((0x007A4796 + 3), C01);
	SetDword((0x007A5546 + 3), C01);
	SetDword((0x007A6FF6 + 3), C01);
	SetDword((0x007A81F1 + 3), C01);
	SetDword((0x007A8E9B + 3), C01);
	SetDword((0x007A92FB + 3), C01);
	SetDword((0x007A99DB + 3), C01);
	SetDword((0x007A9E91 + 3), C01);
	SetDword((0x007AAB21 + 3), C01);
	SetDword((0x007AB8B9 + 3), C01);
	SetDword((0x007AC5D9 + 3), C01);
	SetDword((0x007AD561 + 3), C01);
	SetDword((0x007ADDC1 + 3), C01);
	SetDword((0x007AE601 + 3), C01);
	SetDword((0x007B2681 + 3), C01);
	SetDword((0x007B2FB1 + 3), C01);
	SetDword((0x007B3A61 + 3), C01);
	SetDword((0x007B45F1 + 3), C01);
	SetDword((0x007B52F1 + 3), C01);
	SetDword((0x007B5CE1 + 3), C01);
	SetDword((0x007B66CD + 3), C01);
	SetDword((0x007B7491 + 3), C01);
	SetDword((0x007B8581 + 3), C01);
}

double ConvertWidth(float a1)
{
	//return a1 * 1.25;
	return (float)(pWinWidthReal <= 1.25) ? a1 * pWinWidthReal : a1 * pWinHeightReal;
}

//----- (00636450) --------------------------------------------------------
double ConvertHeight(float a1)
{
	//return a1 * 1.25;
	return (float)(a1 * pWinHeightReal);
}

DWORD dword_ConvertX(float a1)
{
	//return a1 * 1.25;
	return (DWORD)(pWinWidthReal <= 1.25) ? a1 * pWinWidthReal : a1 * pWinHeightReal;
}

__declspec (naked) void ConvertModelX()
{
	static DWORD main_addr = 0x006359CC;
	static DWORD ModelX;

	_asm
	{
		MOV EAX, DWORD PTR SS : [EBP + 8]
		MOV ModelX, EAX
	}

	ModelX = dword_ConvertX(ModelX);

	_asm
	{
		MOV EAX, ModelX
		MOV DWORD PTR SS : [EBP + 8] , EAX
		JMP[main_addr]
	}
}

__declspec (naked) void ConverCursor()
{
	static DWORD main_addr = 0x004D06B7;
	static DWORD main_call = 0x009CEBF0;

	_asm
	{
		FILD DWORD PTR SS : [EBP - 0x10C4]
		FDIV DWORD PTR DS : [0xE7C3D8]
		CALL main_call
		MOV DWORD PTR DS : [0x879340C] , EAX
		JMP[main_addr]
	}
}

__declspec (naked) void CompareToCursor()
{
	static DWORD main_addr = 0x004D070A;
	static int WindowLeft = 0x280u;

	WindowLeft = pWinWidth / pWinHeightReal;

	if (pCursorX > WindowLeft)
	{
		pCursorX = WindowLeft;
	}

	_asm
	{
		JMP[main_addr]
	}
}

__declspec (naked) void ObjDialogBox()
{
	static DWORD main_addr = 0x00635B6C;
	static int renderWin = 0x280u;
	static int a2;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP + 0XC]
		MOV EAX, DWORD PTR DS : [EDX]
		MOV a2, EAX
	}

	renderWin = pWinWidth / pWinHeightReal;
	a2 = renderWin * a2 / pWinWidth;

	_asm
	{
		MOV EAX, a2
		MOV ECX, DWORD PTR SS : [EBP + 0xC]
		MOV DWORD PTR DS : [ECX] , EAX
		JMP[main_addr]
	}
}

__declspec (naked) void allNoticeGeneral()
{
	static DWORD main_addr = 0x00597939;
	static DWORD main_call = 0x0041FE10;
	static int WindowMiddle;

	if (*(int*)0x0E609E8 == 5)
	{
		WindowMiddle = pWinWidth / pWinHeightReal / 2;
	}
	else
	{
		WindowMiddle = 0x140;
	}

	_asm
	{
		PUSH WindowMiddle
		CALL main_call
		MOV ECX, EAX; |
		JMP[main_addr]
	}
}

__declspec (naked) void ButtonTooltip()
{
	static DWORD main_addr = 0x00779CF5;
	static DWORD v52; // [sp+24h] [bp-54h]@13
	static DWORD v55; // [sp+5Ch] [bp-1Ch]@12
	static DWORD v56; // [sp+60h] [bp-18h]@12
	static int WindowMiddle;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP - 0x1C]
		MOV v55, EDX
		MOV EAX, DWORD PTR SS : [EBP - 0x18]
		MOV v56, EAX
	}

	WindowMiddle = pWinWidth / pWinHeightReal;

	if (v55 <= WindowMiddle)
		v52 = v56;
	else
		v52 = v56 - (v55 - WindowMiddle);

	_asm
	{
		MOV EDX, v52
		MOV DWORD PTR SS : [EBP - 0x18] , EDX
		JMP[main_addr]
	}
}



signed int JCGetScreenWidth2()
{
	int* v50; // eax@59
	signed int v52; // [sp+0h] [bp-4h]@11


	if (pCheckWindow((LPVOID)GetInstance(), 13) && pCheckWindow((LPVOID)GetInstance(), 16)
		|| pCheckWindow((LPVOID)GetInstance(), 8)
		|| pCheckWindow((LPVOID)GetInstance(), 12)
		|| pCheckWindow((LPVOID)GetInstance(), 9)
		|| pCheckWindow((LPVOID)GetInstance(), 7)
		|| pCheckWindow((LPVOID)GetInstance(), 14)
		|| pCheckWindow((LPVOID)GetInstance(), 15)
		|| pCheckWindow((LPVOID)GetInstance(), 60)
		|| pCheckWindow((LPVOID)GetInstance(), 76))
	{
		v52 = 190 + 190;
	}
	else
	{
		if (pCheckWindow((LPVOID)GetInstance(), 16)
			&& (pCheckWindow((LPVOID)GetInstance(), 4)
				|| pCheckWindow((LPVOID)GetInstance(), 69)))
		{
			v52 = 190 + 190;
		}
		else
		{
			if (pCheckWindow((LPVOID)GetInstance(), 16) && pCheckWindow((LPVOID)GetInstance(), 11))
			{
				v52 = 190 + 190;
			}
			else
			{
				if (pCheckWindow((LPVOID)GetInstance(), 27))
				{
					v52 = 190 + 190;
				}
				else
				{
					if (pCheckWindow((LPVOID)GetInstance(), 13)
						|| pCheckWindow((LPVOID)GetInstance(), 16)
						|| pCheckWindow((LPVOID)GetInstance(), 3)
						|| pCheckWindow((LPVOID)GetInstance(), 21)
						|| pCheckWindow((LPVOID)GetInstance(), 6)
						|| pCheckWindow((LPVOID)GetInstance(), 22)
						|| pCheckWindow((LPVOID)GetInstance(), 23)
						|| pCheckWindow((LPVOID)GetInstance(), 24)
						|| pCheckWindow((LPVOID)GetInstance(), 4)
						|| pCheckWindow((LPVOID)GetInstance(), 18)
						|| pCheckWindow((LPVOID)GetInstance(), 10)
						|| pCheckWindow((LPVOID)GetInstance(), 5)
						|| pCheckWindow((LPVOID)GetInstance(), 25)
						|| pCheckWindow((LPVOID)GetInstance(), 26)
						|| pCheckWindow((LPVOID)GetInstance(), 19)
						|| pCheckWindow((LPVOID)GetInstance(), 20)
						|| pCheckWindow((LPVOID)GetInstance(), 58)
						|| pCheckWindow((LPVOID)GetInstance(), 59)
						|| pCheckWindow((LPVOID)GetInstance(), 62)
						|| pCheckWindow((LPVOID)GetInstance(), 73)
						|| pCheckWindow((LPVOID)GetInstance(), 68)
						|| pCheckWindow((LPVOID)GetInstance(), 69)
						|| pCheckWindow((LPVOID)GetInstance(), 70)
						|| pCheckWindow((LPVOID)GetInstance(), 66)
						|| pCheckWindow((LPVOID)GetInstance(), 75)
						|| pCheckWindow((LPVOID)GetInstance(), 74))
					{
						v52 = 190;
					}
					else
					{
						if (pCheckWindow((LPVOID)GetInstance(), 79))
						{
							if (pCheckWindow((LPVOID)GetInstance(), 80))
								v52 = 190 + 190;
							else
								v52 = 190;
						}
						else
						{
							v52 = 0;
						}
					}
				}
			}
		}
	}
	if (pCheckWindow((LPVOID)GetInstance(), 77))
	{
		if (sub_7D6270(*(DWORD*)(GetInstance() + 300), 0))
			v52 = 190 + 190 + 190;
		else
			v52 = 190 + 190;
	}
	else
	{
		if (pCheckWindow((LPVOID)GetInstance(), 78))
			v52 = 190 + 190 + 190;
	}

	return JCPWideScreem.JCWinWidth - v52;
}

signed int JCWinIngame2()
{
	return 640;
}

//-- (0078B0F0) ChatDialog
double sub_78B0F02()
{
	return 6.0999999;
}

//----- (00668850) --------------------------------------------------------
int  sub_668850(int _this)
{
	return *(DWORD*)(_this + 16);
}

//----- (007DC240) --------------------------------------------------------
void JCMoveViewport(int _this, int a2)
{
	*(DWORD*)(_this + 40) = a2;
}

//----- (007D5CA0) --------------------------------------------------------
char sub_7D5CA0(int a1, int a5)
{
	int JCWinWidthmove; // eax@2
	int v21; // ST0C_4@3
	int v92; // [sp+4h] [bp-88h]@1
	char v109; // [sp+8Bh] [bp-1h]@1
	int v110; // [sp+94h] [bp+8h]@1

	v92 = *(DWORD*)(GetInstance() + 300);
	v109 = 1;

	JCWinWidthmove = JCPWideScreem.JCWinWidth - (640 - 260);
	JCInvExtMove(v92, JCWinWidthmove, 0);
	v110 = sub_7D6270(v92, a5);
	JCWinWidthmove = JCPWideScreem.JCWinWidth - (640 - 70);

	switch (v110)
	{
	case 14: //-- store
		v21 = *(DWORD*)(GetInstance() + 84);
		JCStoreMove(v21, JCWinWidthmove, 0, *(DWORD*)(GetInstance() + 300));
		JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
		break;
		break;
	case 9: //-- window chaos
		v21 = *(DWORD*)(GetInstance() + 52);
		JCChaosMove((void*)v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
		break;
	case 12: //-- windowshop
		v21 = *(DWORD*)(GetInstance() + 44);
		JCShopMove(v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
		break;
	case 15: //-- Other Store
		v21 = *(DWORD*)(GetInstance() + 88);
		JCOtherStoreMove((void*)v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
		break;
	case 76:
		v21 = *(DWORD*)(GetInstance() + 296);
		JCLuckyMove((void*)v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
		break;
	case 16:
		JCInvExtMove(v92, JCWinWidthmove, 0);
		break;
	case 8:
		v21 = *(DWORD*)(GetInstance() + 72);
		JCBaulMove((void*)v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 540), JCWinWidthmove + 15);
		break;
	case 7:
		v21 = *(DWORD*)(GetInstance() + 124);
		JCTradeMove((void*)v21, JCWinWidthmove, 0, v110);
		JCMoveViewport(*(DWORD*)(v21 + 380), JCWinWidthmove + 15);
		JCMoveViewport(*(DWORD*)(v21 + 376), JCWinWidthmove + 15);
		break;
	default:
		v109 = 0;
		break;
	}
	return v109;
}

//----- (007D5940) --------------------------------------------------------
signed int sub_7D5940(int a1)
{
	int JCWinWidthmove; // eax@2
	int v4; // ST10_4@1
	int v21; // eax@1

	v4 = *(DWORD*)(GetInstance() + 300);
	JCWinWidthmove = JCPWideScreem.JCWinWidth - (640 - 260);
	//-- store
	v21 = *(DWORD*)(GetInstance() + 84);
	JCStoreMove(v21, JCWinWidthmove, 0, v4);
	JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
	//-- chaos box
	v21 = *(DWORD*)(GetInstance() + 52);
	JCChaosMove((void*)v21, JCWinWidthmove, 0, 9);
	JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
	//-- shop
	v21 = *(DWORD*)(GetInstance() + 44);
	JCShopMove(v21, JCWinWidthmove, 0, 12);
	JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
	//-- Other Store
	v21 = *(DWORD*)(GetInstance() + 88);
	JCOtherStoreMove((void*)v21, JCWinWidthmove, 0, 15);
	JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
	//-- lucky
	v21 = *(DWORD*)(GetInstance() + 296);
	JCLuckyMove((void*)v21, JCWinWidthmove, 0, 76);
	JCMoveViewport(*(DWORD*)(v21 + 16), JCWinWidthmove + 15);
	//-- baul
	v21 = *(DWORD*)(GetInstance() + 72);
	JCBaulMove((void*)v21, JCWinWidthmove, 0, 8);
	JCMoveViewport(*(DWORD*)(v21 + 540), JCWinWidthmove + 15);
	//--
	v21 = *(DWORD*)(GetInstance() + 124);
	JCTradeMove((void*)v21, JCWinWidthmove, 0, 7);
	JCMoveViewport(*(DWORD*)(v21 + 380), JCWinWidthmove + 15);
	JCMoveViewport(*(DWORD*)(v21 + 376), JCWinWidthmove + 15);
	//--
	*(BYTE*)(v4 + 224) = 0;
	return JCInvExtMove(v4, JCWinWidthmove, 0);
}

void WindowsStore(int ImageID, float PosX, float PosY, float Width, float Height)
{
	DWORD JCWinWidth;
	int This; // ST3C_4@1

	This = *(DWORD*)(GetInstance() + 84);

	if (pCheckWindow(pWindowThis(), 77))
	{
		JCWinWidth = pWinWidth / pWinHeightReal - 570;
	}
	else
	{
		JCWinWidth = pWinWidth / pWinHeightReal - 380;
	}

	JCStoreMove(This, JCWinWidth, 0, *(DWORD*)(GetInstance() + 300));

	JCMoveViewport(*(DWORD*)(This + 16), JCWinWidth + 15);

	pDrawGUI(ImageID, JCWinWidth, PosY, Width, Height);

	//gOffTrade.DrawOffTradeWindow(JCWinWidth, 0);
}

void OpenVaultExt(int This)
{
	DWORD JCWinWidth;

	This = *(DWORD*)(GetInstance() + 304);

	JCWinWidth = pWinWidth / pWinHeightReal - 570;

	*(DWORD*)(This + 16) = JCWinWidth;

	ChangeButtonInfo((char*)(This + 24), *(DWORD*)(This + 16) + 13, *(DWORD*)(This + 20) + 391, 36, 29);

	JCBaulExtShow(This);
}

bool CheckOpenVaultExt(int x, int y, int w, int h)
{
	if (pCheckWindow(pWindowThis(), 78))
	{
		x = (int)(pWinWidth / pWinHeightReal - 570);
		w = (int)(190 * 2);
	}

	return pCheckMouseOver(x, y, w, h);
}

void RotateDmg(float& X, float& Y, float D)
{
	const float Rad = 0.01745329f;
	float sinTh = sin(Rad * (*(float*)0x87933D8));
	float cosTh = cos(Rad * (*(float*)0x87933D8));

	X += D / 0.7071067f * cosTh / 2;
	Y -= D / 0.7071067f * sinTh / 2;
}

__declspec(naked) void RotateFix()
{
	static DWORD jmpBack = 0x0063752D;

	_asm
	{
		Lea Eax, [Ebp - 0x38];
		Lea Ecx, [Ebp - 0x3C];
		Push Dword Ptr[Ebp + 0x18];
		Push Eax;
		Push Ecx;
		Call RotateDmg;
		Add Esp, 0xC;
		jmp[jmpBack];
	}
}

void RenderFaceDimension(GLint x, int y, GLsizei width, GLsizei height)
{
	((void(__cdecl*)(GLint x, int a2, GLsizei width, GLsizei height)) 0x00636480)(x - (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), y, width, height);
}

void RenderLogoMu(int a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9, int a10, int a11, float a12)
{
	RenderBitmap(a1, a2 + (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), a3, a4, a5, a6, a7, a8, a9, a10, a11, a12);
}

void CNewRenderSands(int Picture, float PictureX, float PictureY, float Widht, float a5, float a6, float a7, float a8, float a9)
{
	RenderBitmapUV(Picture, PictureX, PictureY, Widht + JCPWideScreem.DisplayWinCDepthBox, 480.0, a6, a7, a8, a9);
}

int __thiscall JCWideScreem::CNewUIMainPaintFont(int thisa, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, int nTabOrigin)
{
	return CNewPictureFont(thisa, PosX + (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), PosY, Text, nCount, nTabPositions, lpnTabStopPositions, nTabOrigin);
}

void FrameMasterDisplay(DWORD id, float x, float y, float w, float h)
{
	pDrawGUI(id, x, y, w, 428);
}

int FrameMasterSkill(int thisa)
{
	int result; // eax@1

	*(DWORD*)(thisa + 20) = (int)pWinWidth / pWinHeightReal / 2 - 320;
	*(DWORD*)(thisa + 24) = 0;
	*(DWORD*)(thisa + 28) = 640;
	result = thisa;
	*(DWORD*)(thisa + 32) = 428;
	return result;
}

BYTE __thiscall JCWideScreem::FrameHelperDisplay(int thisa, int a2, int x, int y)
{
	int DisplayFrameX;

	DisplayFrameX = (int)pWinWidth / pWinHeightReal - 190;

	return CNewUIMainFrameHelper(thisa, a2, DisplayFrameX, y);
}

void FrameShopDisplayBuy(float x, float y, float w, float h, float arg5, int arg6)
{
	pDrawBarForm(x, y, (double)(int)pWinWidth / pWinHeightReal, h, arg5, arg6);
}

BYTE __thiscall JCWideScreem::FrameShopDisplay(int thisa, int a2, int x, int y)
{
	int DisplayFrameX;

	DisplayFrameX = x + (int)pWinWidth / pWinHeightReal / 2 - 320;

	return InitCashShop(thisa, a2, DisplayFrameX, y);
}

int PaintMatrixModel(float PosX, float PosY, float Width, float Height, int ItemID, int a6, int a7, int a8, char a9)
{
	int v4; // ST10_4@1

	v4 = *(DWORD*)(GetInstance() + 252);

	return pDrawItemModel(PosX + *(DWORD*)(v4 + 36), PosY, Width, Height, ItemID, a6, a7, a8, a9);
}

void PaintBannerShop(int ImageID, float PosX, float PosY, float Width, float Height)
{
	int v4; // ST10_4@1

	v4 = *(DWORD*)(GetInstance() + 252);

	pDrawGUI(ImageID, *(DWORD*)(v4 + 36) + PosX, PosY, Width, Height);
}

bool CheckBannerShop(int x, int y, int w, int h)
{
	int v4; // eax@1

	v4 = *(DWORD*)(GetInstance() + 252);

	return pCheckMouseOver(*(DWORD*)(v4 + 36) + x, y, w, h);
}

signed int FrameScreenWidth()
{
	signed int v52; // [sp+0h] [bp-4h]@11

	if (pCheckWindow((LPVOID)GetInstance(), 13) && pCheckWindow((LPVOID)GetInstance(), 16)
		|| pCheckWindow((LPVOID)GetInstance(), 8)
		|| pCheckWindow((LPVOID)GetInstance(), 12)
		|| pCheckWindow((LPVOID)GetInstance(), 9)
		|| pCheckWindow((LPVOID)GetInstance(), 7)
		|| pCheckWindow((LPVOID)GetInstance(), 14)
		|| pCheckWindow((LPVOID)GetInstance(), 15)
		|| pCheckWindow((LPVOID)GetInstance(), 60)
		|| pCheckWindow((LPVOID)GetInstance(), 76))
	{
		v52 = 380;
	}
	else
	{
		if (pCheckWindow((LPVOID)GetInstance(), 16)
			&& (pCheckWindow((LPVOID)GetInstance(), 4)
				|| pCheckWindow((LPVOID)GetInstance(), 69)))
		{
			v52 = 380;
		}
		else
		{
			if (pCheckWindow((LPVOID)GetInstance(), 16) && pCheckWindow((LPVOID)GetInstance(), 11))
			{
				v52 = 380;
			}
			else
			{
				if (pCheckWindow((LPVOID)GetInstance(), 27))
				{
					v52 = 380;
				}
				else
				{
					if (pCheckWindow((LPVOID)GetInstance(), 13)
						|| pCheckWindow((LPVOID)GetInstance(), 16)
						|| pCheckWindow((LPVOID)GetInstance(), 3)
						|| pCheckWindow((LPVOID)GetInstance(), 21)
						|| pCheckWindow((LPVOID)GetInstance(), 6)
						|| pCheckWindow((LPVOID)GetInstance(), 22)
						|| pCheckWindow((LPVOID)GetInstance(), 23)
						|| pCheckWindow((LPVOID)GetInstance(), 24)
						|| pCheckWindow((LPVOID)GetInstance(), 4)
						|| pCheckWindow((LPVOID)GetInstance(), 18)
						|| pCheckWindow((LPVOID)GetInstance(), 10)
						|| pCheckWindow((LPVOID)GetInstance(), 5)
						|| pCheckWindow((LPVOID)GetInstance(), 25)
						|| pCheckWindow((LPVOID)GetInstance(), 26)
						|| pCheckWindow((LPVOID)GetInstance(), 19)
						|| pCheckWindow((LPVOID)GetInstance(), 20)
						|| pCheckWindow((LPVOID)GetInstance(), 58)
						|| pCheckWindow((LPVOID)GetInstance(), 59)
						|| pCheckWindow((LPVOID)GetInstance(), 62)
						|| pCheckWindow((LPVOID)GetInstance(), 73)
						|| pCheckWindow((LPVOID)GetInstance(), 68)
						|| pCheckWindow((LPVOID)GetInstance(), 69)
						|| pCheckWindow((LPVOID)GetInstance(), 70)
						|| pCheckWindow((LPVOID)GetInstance(), 66)
						|| pCheckWindow((LPVOID)GetInstance(), 75)
						|| pCheckWindow((LPVOID)GetInstance(), 74))
					{
						v52 = 190;
					}
					else
					{
						if (pCheckWindow((LPVOID)GetInstance(), 79))
						{
							if (pCheckWindow((LPVOID)GetInstance(), 80))
								v52 = 380;
							else
								v52 = 190;
						}
						else
						{
							v52 = 0;
						}
					}
				}
			}
		}
	}
	if (pCheckWindow((LPVOID)GetInstance(), 77))
	{
		if (sub_7D6270(*(DWORD*)(GetInstance() + 300), 0))
			v52 = 570;
		else
			v52 = 380;
	}
	else
	{
		if (pCheckWindow((LPVOID)GetInstance(), 78))
			v52 = 570;
	}

	return (int)((int)pWinWidth / pWinHeightReal - v52);
}

char __thiscall JCWideScreem::sub_791480(int This, int a2, float a3, float a4, float a5, float a6, int a7, char a8)
{
	return ((char(__thiscall*)(int, int, float, float, float, float, int, char)) 0x00791480)(This, a2, a3 + (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), a4, a5, a6, a7, a8);
}

char __thiscall JCWideScreem::sub_7A9E80(int This, int a2, int a3, int a4, int a5, float a6)
{
	return ((char(__thiscall*)(int, int, int, int, int, float)) 0x00823CA0)(This, a2 + (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), a3, a4, a5, a6);
}

int __thiscall JCWideScreem::MessageBoxButtonRenderText(int thisa, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, int nTabOrigin)
{
	return CNewPictureFont(thisa, PosX - 4, PosY, Text, nCount, nTabPositions, lpnTabStopPositions, nTabOrigin);
}

int __thiscall JCWideScreem::OpenMainWnd(int thisa, int a2, int a3)
{
	return ((int(__thiscall*)(int thisa, int a2, int a3)) 0x00861EA0)(thisa, a2 + (WIDESCREEN == 1 ? JCPWideScreem.JCWinWidthAdd : 0), a3);
}

void SeedEmpy(int ImageID, float PosX, float PosY, float Width, float Height)
{
	pDrawGUI(ImageID, PosX + (int)pWinWidth / pWinHeightReal / 2 - 320 + 50, PosY, Width, Height);
	glColor4f(0.0, 0.0, 0.0, 1.0); //--
}

void JCWideScreem::Load()
{
	//SetCompleteHook(0xE8, 0x007AA2C9, &sub_791480); // QUEM SABE UM DIA USO - CLASSE DE UMA FUN��O DA CM MONTADA
	//SetCompleteHook(0xE8, 0x007A9EC7, &sub_7A9E80);	// MOVE A JANELA DO CHAOS MIX

	SetCompleteHook(0xE8, 0x00934286, &SeedEmpy);
	SetCompleteHook(0xE8, 0x00855868, &SeedEmpy);
	SetCompleteHook(0xE8, 0x0085589F, &SeedEmpy);
	SetCompleteHook(0xE8, 0x0088643F, &SeedEmpy);
	SetCompleteHook(0xE8, 0x008863F9, &SeedEmpy);
	
	SetCompleteHook(0xE8, 0x007919B8, &MessageBoxButtonRenderText);		// X e Y para bot�es da CM e outros 
	SetCompleteHook(0xE8, 0x00791982, &MessageBoxButtonRenderText);		// X e Y para bot�es da CM e outros 
	SetCompleteHook(0xE8, 0x00778F05, &MessageBoxButtonRenderText);		// X e Y para bot�es dos eventos DS/BC e outros 
	SetCompleteHook(0xE8, 0x0085ECB1, &OpenMainWnd);					// X e Y para bot�es do Friends
	
	SetCompleteHook(0xE9, 0x0063764C, &RotateFix);
	
	SetCompleteHook(0xE8, 0x004D7C98, &RenderLogoMu);
	SetCompleteHook(0xE8, 0x004D7C0D, &RenderLogoMu);
	
	SetCompleteHook(0xE8, 0x0040464E, &RenderFaceDimension);							//Posicionamento dos avatares das classes

	SetCompleteHook(0xE8, 0x004D2180, &OpenInitFile);	//-- Letter Print

	SetCompleteHook(0xE8, 0x00857746, &CheckOpenVaultExt); //-- baul 
	SetCompleteHook(0xE8, 0x0085676E, &OpenVaultExt); //-- Ext
	
	SetCompleteHook(0xE8, 0x00841E49, &WindowsStore);//-- store
	
	SetCompleteHook(0xE8, 0x007D591D, &sub_7D5940);	//-- Abrir 2er ventana
	
	SetCompleteHook(0xE8, 0x0085F0CD, &sub_7D5CA0);	//-- Abrir 3er ventana
	SetCompleteHook(0xE8, 0x0085EFE0, &sub_7D5CA0);	//-- Abrir 3er ventana
	SetCompleteHook(0xE9, 0x0078B0F0, &sub_78B0F02); //-- ChatDialog
	//--
	SetDword(0x004D9746 + 3, 480); //Size Background
	//--
	SetCompleteHook(0xE8, 0x0040F2E9, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D714E, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D79E7, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D9756, &JCWinIngame2); //-- Camara General Renderizado
	//--
	SetCompleteHook(0xE8, 0x005DB4D5, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB1AA, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB22F, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB322, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB3A7, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB46D, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB4AD, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB534, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB5C4, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB628, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB68C, &JCWinIngame2); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x005DB6ED, &JCWinIngame2); //-- Camara General Renderizado
	//-
	SetCompleteHook(0xE9, 0x005C6E80, &JCGetScreenWidth2);
	//--
	SetCompleteHook(0xE9, 0x00779CCD, &ButtonTooltip);
	SetCompleteHook(0xE9, 0x0059792D, &allNoticeGeneral);
	SetCompleteHook(0xE9, 0x00635B55, &ObjDialogBox);
	SetCompleteHook(0xE9, 0x004D06A1, &ConverCursor);
	SetCompleteHook(0xE9, 0x004D06F4, &CompareToCursor);
	//--
	SetCompleteHook(0xE9, 0x006359B6, &ConvertModelX);		//-- Model Print
	//--
	SetCompleteHook(0xE9, 0x00636420, &ConvertWidth);		//-- all texture
	//SetCompleteHook(0xE9, 0x00636450, &ConvertHeight);		//-- all texture
	SetCompleteHook(0xE8, 0x005B97DC, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x005B984C, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x005B9904, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008C2E0F, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008C2E7F, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008CC713, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008CC788, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008D99B8, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008D9A2D, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008EF47B, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008EF4ED, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008EF5C5, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x008EF65A, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x00914FC9, &CNewRenderSands);
	SetCompleteHook(0xE8, 0x0091503E, &CNewRenderSands);
	SetCompleteHook(0xE9, 0x00635B55, &ObjDialogBox);   // 
	SetCompleteHook(0xE9, 0x004D06A1, &ConverCursor);   //
	//--
	SetCompleteHook(0xE9, 0x006359B6, &ConvertModelX);		//-- Model Print //
	//SetCompleteHook(0xE8, 0x0081AA9C, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081AA42, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081A9E8, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081A977, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081A944, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081A73D, &CNewUIMainPaintFont);			//-- Texto masterskill
	//SetCompleteHook(0xE8, 0x0081A6F4, &CNewUIMainPaintFont);			//-- Texto masterskill
	//
	//SetCompleteHook(0xE8, 0x0081A146, &FrameMasterDisplay);				//-- Letter Print
	//SetCompleteHook(0xE8, 0x0081A199, &FrameMasterDisplay);				//-- Letter Print
	//SetCompleteHook(0xE8, 0x00819415, &FrameMasterSkill);				//-- Letter Print
	//SetCompleteHook(0xE8, 0x0085CC50, &FrameHelperDisplay);				//-- Letter Print
	//SetCompleteHook(0xE8, 0x0085C446, &FrameShopDisplay);				//-- Letter Print
	//SetCompleteHook(0xE8, 0x00943D7F, &PaintMatrixModel);				//-- ItemModel CashShop
	//SetCompleteHook(0xE8, 0x008240A9, &FrameShopDisplayBuy);			//-- Letter Print
	//SetCompleteHook(0xE8, 0x00945114, &PaintBannerShop);				//-- Model CashShop
	//SetCompleteHook(0xE8, 0x00945180, &CheckBannerShop);				//-- Model CashShop
	//--
	SetCompleteHook(0xE9, 0x005C6E80, &FrameScreenWidth);
	
	SetByte(0x004D128F, 0x1D); //fix screen 640x320
}