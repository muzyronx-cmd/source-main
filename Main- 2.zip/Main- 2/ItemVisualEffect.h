#pragma once

#include "Lua.h"
#include <vector>
#include <map>

#define ITEM_VISUAL_RECENT 128
#define ITEM_VISUAL_WORLD_STRIDE 1432
#define ITEM_VISUAL_WORLD_LIMIT 400

enum ITEM_VISUAL_KIND
{
	ITEM_VISUAL_GLOW = 0,
	ITEM_VISUAL_FLAME = 1,
	ITEM_VISUAL_FROST = 2,
	ITEM_VISUAL_ARCANE = 3,
	ITEM_VISUAL_MAGIC = 4,
	ITEM_VISUAL_AURA = 5,
	ITEM_VISUAL_KIND_COUNT = 6
};

struct ITEM_VISUAL_DEFINITION
{
	int Id;
	char Name[48];
	int Kind;
	float Color[3];
	float Color2[3];
	float Intensity;
	float Scale;
	float Speed;
	int Particles;
	int Bone;
	float Offset[3];
	int SpriteId;
	int ParticleId;
	int ParticleSub;
	int Enabled;
};

struct ITEM_VISUAL_BIND
{
	int Section;
	int Index;
	int Model;
	int EffectId;
	int Enabled;
};

struct ITEM_VISUAL_SET
{
	int SetId;
	int EffectId;
	int NeedCount;
	std::vector<int> Models;
};

struct ITEM_VISUAL_RECENT_EMIT
{
	DWORD Object;
	int Key;
	DWORD Tick;
};

class CItemVisualEffect
{
public:
	CItemVisualEffect();
	~CItemVisualEffect();

	void Init();
	void RestartLua();
	void OnLinkObject(ObjectPreview* preview, PART_t* part, int modelType);

	int DefinitionCount() const;
	int ActiveBindCount() const;
	int ErrorCount() const;

private:
	void Load();
	void RegisterFunctions();
	void ReloadIfNeeded();
	void BuildIndex();
	void Log(const char* format, ...);
	void ClearLog();
	bool Reserve(DWORD object, int key);
	bool IsWorldCharacter(ObjectPreview* preview) const;
	int CountWorn(ObjectPreview* preview, const ITEM_VISUAL_SET& set) const;
	const ITEM_VISUAL_DEFINITION* FindDefinition(int id) const;
	void Emit(ObjectPreview* preview, PART_t* part, int modelType, const ITEM_VISUAL_DEFINITION& effect, int key);

public:
	void Reset();
	void ApplySettings(int enabled, int maxEmits, float maxDistance, int showPreview, int quality);
	void Define(int id, const char* name, int kind, float r, float g, float b, float r2, float g2, float b2, float intensity, float scale, float speed, int particles, int bone, float offsetX, float offsetY, float offsetZ, int spriteId, int particleId, int particleSub, int enabled);
	void Bind(int section, int index, int effectId, int enabled);
	void DefineSet(int setId, int effectId, int needCount);
	void AddSetPiece(int setId, int section, int index);

private:
	Lua m_Lua;
	bool m_Registered;
	bool m_Enabled;
	int m_MaxEmits;
	float m_MaxDistance;
	int m_ShowPreview;
	int m_Quality;
	int m_ErrorCount;
	DWORD m_CheckTick;
	DWORD m_WindowTick;
	int m_WindowCount;
	int m_RecentCursor;
	FILETIME m_FileTime;
	std::vector<ITEM_VISUAL_DEFINITION> m_Definitions;
	std::vector<ITEM_VISUAL_BIND> m_Binds;
	std::map<int, std::vector<int>> m_BindIndex;
	std::vector<ITEM_VISUAL_SET> m_Sets;
	ITEM_VISUAL_RECENT_EMIT m_Recent[ITEM_VISUAL_RECENT];
};

extern CItemVisualEffect gItemVisualEffect;
