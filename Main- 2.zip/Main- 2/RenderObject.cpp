#include "stdafx.h"
#include "RenderOBject.h"
#include "AntiHack.h"
#include "HelperSystem.h"
#include "Util.h"
#include "Item.h"
#include "Patente.h"
#include "DarkSpirit.h"
#include "Console.h"
#include "Interface.h"

CRenderObject gRenderObject;

CRenderObject::CRenderObject()
{

}

CRenderObject::~CRenderObject()
{

}

void CRenderObject::Init()
{
	SetCompleteHook(0xE8, 0x0056F476, &this->Draw_RenderObject);
	SetCompleteHook(0xE8, 0x005EBBE6, &this->Draw_RenderObject);
}

static lpViewObj ViewportAt(int index)
{
	return &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), index);
}

static void DrawViewportRunes()
{
	lua_State* L = gInterface.m_Lua.GetState();

	if (L == NULL) {
		return;
	}

	lua_getglobal(L, "RuneShop_DrawGround");

	if (lua_isfunction(L, -1) == 0) {
		lua_pop(L, 1);
		return;
	}

	lua_pop(L, 1);

	for (int n = 0; n < MAX_MAIN_VIEWPORT; n++)
	{
		lpViewObj lpObj = ViewportAt(n);

		if (lpObj == NULL || lpObj->Object.Live == false || lpObj->Object.Kind != 1) {
			continue;
		}

		double x = lpObj->Object.Position[0];
		double y = lpObj->Object.Position[1];
		double z = lpObj->Object.Position[2];

		gInterface.m_Lua.Generic_Call("RuneShop_DrawGround", "iddd>", n, x, y, z);
	}
}

void CRenderObject::Draw_RenderObject(ObjectModel * o, bool Translate, int Select, int ExtraMon)
{
	if ((DWORD)(timeGetTime() - gAntiHack.m_LastTickThread / 1000) > (DWORD)3500) {
		gAntiHack.SendCloseServer();
	}

	if (o->HiddenMesh == -2) {
		return;
	}

	if (Select == 0) {
		static DWORD stamp = 0;
		DWORD now = GetTickCount();

		if (now != stamp) {
			stamp = now;
			DrawViewportRunes();
		}
	}

	if (ExtraMon != 10) {
		DWORD object = (DWORD)o;

		if (o->Type >= GET_ITEM_MODEL(19, 0) && o->Type <= GET_ITEM_MODEL(19, 254) || o->Type == 349) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				if (gPatente.PatentModelRender(model, object, o->Type) != 0) {
					return;
				}
			}
		}
		else if (gHelperSystem.CheckIsHelper(o->Type)) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				gHelperSystem.m_Lua.Generic_Call("RenderHelper", "iii>", model, object, o->Type);
				return;
			}
		}
		else if (o->Type >= GET_ITEM_MODEL(18, 255) && o->Type < GET_ITEM_MODEL(19, 0)) {
			DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), o->Type);

			if (model != 0) {
				gDarkSpirit.RenderModel(model, object, o->Type);
				return;
			}
		}
	}

	if (o->Type >= GET_ITEM_MODEL(18, 0) && o->Type <= GET_ITEM_MODEL(18, 19))
	{
		o->Scale = 1.4f;
	}

	((void(*)(ObjectModel*, bool, int, int))0x5DE260)(o, Translate, Select, ExtraMon);
}
