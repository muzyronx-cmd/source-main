#include "stdafx.h"
#include "ItemTransparency.h"
#include "Item.h"
#include "Util.h"
#include <math.h>

#define RENDER_PART_OBJECT_EFFECT_ADDRESS 0x00609E70

#define IT_RENDER_TEXTURE 0x00000002
#define IT_RENDER_CHROME  0x00000004
#define IT_RENDER_BRIGHT  0x00000040

#define IT_TWO_PI 6.283185307179586

#define IT_GL_TEXTURE0          0x84C0
#define IT_GL_ACTIVE_TEXTURE    0x84E0
#define IT_GL_MAX_TEXTURE_UNITS 0x84E2
#define IT_GL_COMBINE           0x8570
#define IT_GL_COMBINE_RGB       0x8571
#define IT_GL_COMBINE_ALPHA     0x8572
#define IT_GL_INTERPOLATE       0x8575
#define IT_GL_CONSTANT          0x8576
#define IT_GL_PRIMARY_COLOR     0x8577
#define IT_GL_PREVIOUS          0x8578
#define IT_GL_SOURCE0_RGB       0x8580
#define IT_GL_SOURCE1_RGB       0x8581
#define IT_GL_SOURCE2_RGB       0x8582
#define IT_GL_SOURCE0_ALPHA     0x8588
#define IT_GL_SOURCE1_ALPHA     0x8589
#define IT_GL_OPERAND0_RGB      0x8590
#define IT_GL_OPERAND1_RGB      0x8591
#define IT_GL_OPERAND2_RGB      0x8592
#define IT_GL_OPERAND0_ALPHA    0x8598
#define IT_GL_OPERAND1_ALPHA    0x8599
#define IT_GL_DOT3_RGB          0x86AE

#define COMBINER_NONE    0
#define COMBINER_GRAY    1
#define COMBINER_PARTIAL 2

typedef void(*PFN_RENDER_PART_OBJECT_EFFECT)(ObjectModel*, int, float*, float, int, int, int, int, int);

typedef void(APIENTRY* PFN_IT_ACTIVE_TEXTURE)(GLenum);

static const PFN_RENDER_PART_OBJECT_EFFECT RenderPartObjectEffectOriginal = (PFN_RENDER_PART_OBJECT_EFFECT)RENDER_PART_OBJECT_EFFECT_ADDRESS;

// The pulse may almost hide the item, but +15 items are never fully invisible nor opaque.
static const float OPACITY_HARD_FLOOR = 0.05f;
static const float OPACITY_HARD_CEILING = 0.90f;

struct COMBINER_STATE
{
	int Units;
	GLint ActiveTexture;
	GLint EnvMode0;
	GLint EnvMode[3];
	GLboolean Enabled[3];
	GLint Binding[3];
};

static int CombinerSupport = -1;
static PFN_IT_ACTIVE_TEXTURE ItActiveTexture = nullptr;
static GLuint WhiteTexture = 0;

CItemTransparency gItemTransparency;

// Afasta a cor do cinza e segura o canal mais alto.
// Brilho aditivo com canal em 1.0 vira branco na tela.
static void SaturateGlow(const float* in, float* out)
{
	float gray = (in[0] + in[1] + in[2]) / 3.0f;
	const float chroma = 2.40f;

	for (int i = 0; i < 3; i++)
	{
		float value = gray + (in[i] - gray) * chroma;

		if (value < 0.0f)
		{
			value = 0.0f;
		}

		out[i] = value;
	}

	float peak = out[0];

	if (out[1] > peak)
	{
		peak = out[1];
	}

	if (out[2] > peak)
	{
		peak = out[2];
	}

	const float cap = 0.72f;

	if (peak > cap && peak > 0.001f)
	{
		float scale = cap / peak;

		out[0] *= scale;
		out[1] *= scale;
		out[2] *= scale;
	}
}

static float Clamp(float value, float minValue, float maxValue)
{
	return (value < minValue) ? minValue : ((value > maxValue) ? maxValue : value);
}

static float Lerp(float a, float b, float t)
{
	return a + (b - a) * t;
}

// 0 -> 1 -> 0 over one period, zero slope at both extremes.
static float Wave(double phase)
{
	return (float)(0.5 - 0.5 * cos(phase * IT_TWO_PI));
}

static float Ease(float w, float smoothness)
{
	return Lerp(w, w * w * (3.0f - 2.0f * w), smoothness);
}

static float SmoothStep(float edge0, float edge1, float x)
{
	float t = Clamp((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);

	return t * t * (3.0f - 2.0f * t);
}

static void MixLook(const ITEM_TRANSPARENCY_LOOK& a, const ITEM_TRANSPARENCY_LOOK& b, float t, ITEM_TRANSPARENCY_LOOK& out)
{
	out.Opacity = Lerp(a.Opacity, b.Opacity, t);
	out.Saturation = Lerp(a.Saturation, b.Saturation, t);
	out.Texture = Lerp(a.Texture, b.Texture, t);
	out.Glow = Lerp(a.Glow, b.Glow, t);
	out.Outline = Lerp(a.Outline, b.Outline, t);

	for (int i = 0; i < 3; i++)
	{
		out.Tint[i] = Lerp(a.Tint[i], b.Tint[i], t);
		out.GlowColor[i] = Lerp(a.GlowColor[i], b.GlowColor[i], t);
		out.OutlineColor[i] = Lerp(a.OutlineColor[i], b.OutlineColor[i], t);
	}
}

static float ReadFloat(const char* section, const char* key, float def, const char* path)
{
	char defBuff[32];
	char buff[32];

	sprintf_s(defBuff, "%f", def);

	GetPrivateProfileString(section, key, defBuff, buff, sizeof(buff), path);

	return (float)atof(buff);
}

static void ReadColor(const char* section, const char* key, float r, float g, float b, vec3_t out, const char* path)
{
	char buff[64];

	out[0] = r;
	out[1] = g;
	out[2] = b;

	if (GetPrivateProfileString(section, key, "", buff, sizeof(buff), path) == 0)
	{
		return;
	}

	float cr, cg, cb;

	if (sscanf_s(buff, "%f,%f,%f", &cr, &cg, &cb) == 3)
	{
		out[0] = Clamp(cr, 0.0f, 1.0f);
		out[1] = Clamp(cg, 0.0f, 1.0f);
		out[2] = Clamp(cb, 0.0f, 1.0f);
	}
}

static DWORD GetModelBMD(int Type)
{
	return ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void*(*)())0x004CDA10)(), Type);
}

static void RenderModelBody(DWORD bmd, int flag, float alpha, ObjectModel* o)
{
	((void(__thiscall*)(DWORD*, int, float, int, float, float, float, int, int))0x5494C0)
		((DWORD*)bmd, flag, alpha, o->BlendMesh, o->BlendMeshLight, o->BlendMeshTexCoordU, o->BlendMeshTexCoordV, o->HiddenMesh, -1);
}

static bool HasExtension(const char* extensions, const char* name)
{
	return (extensions != nullptr && strstr(extensions, name) != nullptr);
}

static int CheckCombinerSupport()
{
	if (CombinerSupport != -1)
	{
		return CombinerSupport;
	}

	if (wglGetCurrentContext() == nullptr)
	{
		return COMBINER_NONE;
	}

	CombinerSupport = COMBINER_NONE;

	const char* version = (const char*)glGetString(GL_VERSION);
	const char* extensions = (const char*)glGetString(GL_EXTENSIONS);

	double glVersion = (version != nullptr) ? atof(version) : 0.0;

	bool dot3 = (glVersion >= 1.3) || (HasExtension(extensions, "GL_ARB_texture_env_combine") && HasExtension(extensions, "GL_ARB_texture_env_dot3"));
	bool crossbar = (glVersion >= 1.4) || HasExtension(extensions, "GL_ARB_texture_env_crossbar");

	PROC proc = wglGetProcAddress("glActiveTexture");

	if ((INT_PTR)proc >= -1 && (INT_PTR)proc <= 3)
	{
		proc = wglGetProcAddress("glActiveTextureARB");
	}

	if (dot3 == false || ((INT_PTR)proc >= -1 && (INT_PTR)proc <= 3))
	{
		return CombinerSupport;
	}

	ItActiveTexture = (PFN_IT_ACTIVE_TEXTURE)proc;

	GLint units = 0;

	glGetIntegerv(IT_GL_MAX_TEXTURE_UNITS, &units);

	if (crossbar && units >= 4)
	{
		CombinerSupport = COMBINER_PARTIAL;
	}
	else if (units >= 3)
	{
		CombinerSupport = COMBINER_GRAY;
	}

	return CombinerSupport;
}

static void SetupPassUnit(GLenum combineRgb, GLenum source1Rgb)
{
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, IT_GL_COMBINE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_COMBINE_RGB, combineRgb);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE0_RGB, IT_GL_PREVIOUS);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND0_RGB, GL_SRC_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE1_RGB, source1Rgb);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND1_RGB, GL_SRC_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_COMBINE_ALPHA, GL_REPLACE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE0_ALPHA, IT_GL_PREVIOUS);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
}

// Unit 0: t*0.5+0.5 | Unit 1: dot3 -> gray | [Unit 2: lerp(t, gray, 1-keep)] | Last unit: * vertex color.
static void BeginCombiner(COMBINER_STATE& state, int mode, float keep)
{
	static const GLfloat bias[4] = { 1.0f, 1.0f, 1.0f, 0.5f };
	static const GLfloat luminance[4] = { 0.65f, 0.795f, 0.555f, 1.0f };

	state.Units = (mode == COMBINER_PARTIAL) ? 3 : 2;

	glGetIntegerv(IT_GL_ACTIVE_TEXTURE, &state.ActiveTexture);

	ItActiveTexture(IT_GL_TEXTURE0);

	glGetTexEnviv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, &state.EnvMode0);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, IT_GL_COMBINE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_COMBINE_RGB, IT_GL_INTERPOLATE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE0_RGB, GL_TEXTURE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND0_RGB, GL_SRC_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE1_RGB, IT_GL_CONSTANT);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND1_RGB, GL_SRC_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE2_RGB, IT_GL_CONSTANT);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND2_RGB, GL_SRC_ALPHA);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_COMBINE_ALPHA, GL_MODULATE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE0_ALPHA, GL_TEXTURE);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE1_ALPHA, IT_GL_PRIMARY_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND1_ALPHA, GL_SRC_ALPHA);
	glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, bias);

	for (int n = 0; n < state.Units; n++)
	{
		ItActiveTexture(IT_GL_TEXTURE0 + 1 + n);

		state.Enabled[n] = glIsEnabled(GL_TEXTURE_2D);
		glGetIntegerv(GL_TEXTURE_BINDING_2D, &state.Binding[n]);
		glGetTexEnviv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, &state.EnvMode[n]);

		if (WhiteTexture == 0)
		{
			static const BYTE white[4] = { 255, 255, 255, 255 };

			glGenTextures(1, &WhiteTexture);
			glBindTexture(GL_TEXTURE_2D, WhiteTexture);
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		}

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, WhiteTexture);

		if (n == 0)
		{
			SetupPassUnit(IT_GL_DOT3_RGB, IT_GL_CONSTANT);
			glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, luminance);
		}
		else if (n == 1 && state.Units == 3)
		{
			GLfloat keepColor[4] = { 0.0f, 0.0f, 0.0f, keep };

			SetupPassUnit(IT_GL_INTERPOLATE, IT_GL_PREVIOUS);
			glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE0_RGB, IT_GL_TEXTURE0);
			glTexEnvi(GL_TEXTURE_ENV, IT_GL_SOURCE2_RGB, IT_GL_CONSTANT);
			glTexEnvi(GL_TEXTURE_ENV, IT_GL_OPERAND2_RGB, GL_SRC_ALPHA);
			glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, keepColor);
		}
		else
		{
			SetupPassUnit(GL_MODULATE, IT_GL_PRIMARY_COLOR);
		}
	}

	ItActiveTexture(IT_GL_TEXTURE0);
}

static void EndCombiner(const COMBINER_STATE& state)
{
	for (int n = state.Units - 1; n >= 0; n--)
	{
		ItActiveTexture(IT_GL_TEXTURE0 + 1 + n);

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, state.EnvMode[n]);
		glBindTexture(GL_TEXTURE_2D, (GLuint)state.Binding[n]);

		if (state.Enabled[n] == GL_FALSE)
		{
			glDisable(GL_TEXTURE_2D);
		}
	}

	ItActiveTexture(IT_GL_TEXTURE0);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, state.EnvMode0);

	ItActiveTexture((GLenum)state.ActiveTexture);
}

static int PatchCallsInRange(BYTE* start, BYTE* end, DWORD target, DWORD hook)
{
	int count = 0;

	MEMORY_BASIC_INFORMATION mbi;

	BYTE* region = start;

	while (region < end && VirtualQuery(region, &mbi, sizeof(mbi)) == sizeof(mbi))
	{
		BYTE* regionEnd = (BYTE*)mbi.BaseAddress + mbi.RegionSize;

		if (regionEnd > end)
		{
			regionEnd = end;
		}

		if (mbi.State == MEM_COMMIT && (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) == 0)
		{
			for (BYTE* p = region; p + 5 <= regionEnd; p++)
			{
				if (*p != 0xE8 && *p != 0xE9)
				{
					continue;
				}

				DWORD address = (DWORD)p;

				if (address + 5 + *(DWORD*)(p + 1) == target)
				{
					SetCompleteHook(*p, address, hook);
					count++;
					p += 4;
				}
			}
		}

		region = regionEnd;
	}

	return count;
}

CItemTransparency::CItemTransparency()
{
	memset(&this->m_Config, 0, sizeof(this->m_Config));
	memset(this->m_Looks, 0, sizeof(this->m_Looks));
	memset(&this->m_Current, 0, sizeof(this->m_Current));

	this->m_Enabled = true;
	this->m_Rendering = false;

	this->m_Frequency.QuadPart = 0;
	this->m_StartCounter.QuadPart = 0;
	this->m_LastUpdateCounter = 0;
	this->m_LastConfigCheck = 0;
	this->m_ConfigWriteTime.dwLowDateTime = 0;
	this->m_ConfigWriteTime.dwHighDateTime = 0;
}

CItemTransparency::~CItemTransparency()
{

}

void CItemTransparency::Init()
{
	QueryPerformanceFrequency(&this->m_Frequency);
	QueryPerformanceCounter(&this->m_StartCounter);

	this->LoadConfig();

	this->InstallHooks();
}

void CItemTransparency::LoadConfig()
{
	const char* path = ITEM_TRANSPARENCY_CONFIG_PATH;
	const char* section = "Item15";

	auto cfg = &this->m_Config;

	cfg->Enable = GetPrivateProfileInt(section, "Enable", 1, path);
	cfg->MinLevel = GetPrivateProfileInt(section, "MinLevel", 15, path);
	cfg->DepthPrepass = GetPrivateProfileInt(section, "DepthPrepass", 1, path);
	cfg->Desaturate = GetPrivateProfileInt(section, "Desaturate", 1, path);

	cfg->Speed = ReadFloat(section, "Speed", 1.0f, path);
	cfg->HoldSeconds = ReadFloat(section, "HoldSeconds", 2.4f, path);
	cfg->PulseSeconds = ReadFloat(section, "PulseSeconds", 2.0f, path);
	cfg->Smoothness = ReadFloat(section, "Smoothness", 0.6f, path);

	cfg->OpacityNormal = ReadFloat(section, "OpacityNormal", 0.40f, path);
	cfg->OpacityGhost = ReadFloat(section, "OpacityGhost", 0.05f, path);
	cfg->OpacityPulse = ReadFloat(section, "OpacityPulse", 0.08f, path);
	cfg->PulseColorFade = ReadFloat(section, "PulseColorFade", 0.35f, path);

	cfg->NormalSaturation = ReadFloat(section, "NormalSaturation", 1.0f, path);
	cfg->NormalSmoke = ReadFloat(section, "NormalSmoke", 0.50f, path);
	ReadColor(section, "NormalColor", 0.90f, 0.92f, 0.95f, cfg->NormalColor, path);
	ReadColor(section, "NormalSmokeColor", 0.45f, 0.47f, 0.50f, cfg->NormalSmokeColor, path);
	ReadColor(section, "NormalOutlineColor", 0.80f, 0.85f, 0.90f, cfg->NormalOutlineColor, path);

	cfg->BodyBrightness = ReadFloat(section, "BodyBrightness", 1.0f, path);
	cfg->GlowIntensity = ReadFloat(section, "GlowIntensity", 0.72f, path);
	cfg->ChromeIntensity = ReadFloat(section, "ChromeIntensity", 0.12f, path);

	ReadColor(section, "BlueColor", 0.02f, 0.18f, 0.92f, cfg->BlueColor, path);
	ReadColor(section, "BlueGlowColor", 0.00f, 0.12f, 0.85f, cfg->BlueGlowColor, path);
	ReadColor(section, "VioletColor", 0.92f, 0.02f, 0.38f, cfg->VioletColor, path);
	ReadColor(section, "VioletGlowColor", 0.85f, 0.00f, 0.32f, cfg->VioletGlowColor, path);

	cfg->Outline = GetPrivateProfileInt(section, "Outline", 1, path);
	cfg->OutlineWings = GetPrivateProfileInt(section, "OutlineWings", 0, path);
	cfg->OutlineWidth = ReadFloat(section, "OutlineWidth", 2.0f, path);
	cfg->OutlineIntensity = ReadFloat(section, "OutlineIntensity", 0.70f, path);
	cfg->OutlinePulse = ReadFloat(section, "OutlinePulse", 0.40f, path);

	cfg->MinLevel = (cfg->MinLevel < 0) ? 0 : ((cfg->MinLevel > 15) ? 15 : cfg->MinLevel);
	cfg->Speed = Clamp(cfg->Speed, 0.05f, 10.0f);
	cfg->HoldSeconds = Clamp(cfg->HoldSeconds, 0.0f, 60.0f);
	cfg->PulseSeconds = Clamp(cfg->PulseSeconds, 0.2f, 30.0f);
	cfg->Smoothness = Clamp(cfg->Smoothness, 0.0f, 1.0f);
	cfg->OpacityNormal = Clamp(cfg->OpacityNormal, OPACITY_HARD_FLOOR, OPACITY_HARD_CEILING);
	cfg->OpacityGhost = Clamp(cfg->OpacityGhost, OPACITY_HARD_FLOOR, OPACITY_HARD_CEILING);
	cfg->OpacityPulse = Clamp(cfg->OpacityPulse, OPACITY_HARD_FLOOR, OPACITY_HARD_CEILING);
	cfg->PulseColorFade = Clamp(cfg->PulseColorFade, 0.0f, 1.0f);
	cfg->NormalSaturation = Clamp(cfg->NormalSaturation, 0.0f, 1.0f);
	cfg->NormalSmoke = Clamp(cfg->NormalSmoke, 0.0f, 2.0f);
	cfg->BodyBrightness = Clamp(cfg->BodyBrightness, 0.0f, 2.0f);
	cfg->GlowIntensity = Clamp(cfg->GlowIntensity, 0.0f, 2.0f);
	cfg->ChromeIntensity = Clamp(cfg->ChromeIntensity, 0.0f, 2.0f);
	cfg->OutlineWidth = Clamp(cfg->OutlineWidth, 1.0f, 6.0f);
	cfg->OutlineIntensity = Clamp(cfg->OutlineIntensity, 0.0f, 2.0f);
	cfg->OutlinePulse = Clamp(cfg->OutlinePulse, 0.0f, 1.0f);

	auto normal = &this->m_Looks[0];

	normal->Opacity = cfg->OpacityNormal;
	normal->Saturation = cfg->NormalSaturation;
	normal->Texture = 1.0f;
	normal->Glow = cfg->NormalSmoke;
	normal->Outline = 0.25f;
	Vector(cfg->BodyBrightness, cfg->BodyBrightness, cfg->BodyBrightness, normal->Tint);
	Vector(1.0f, 1.0f, 1.0f, normal->GlowColor);
	VectorCopy(cfg->NormalOutlineColor, normal->OutlineColor);

	// Imagem 3: brilho rosa/branco, sem a textura transparente.
	auto pink = &this->m_Looks[1];

	pink->Opacity = OPACITY_HARD_FLOOR;
	pink->Saturation = 0.0f;
	pink->Texture = 0.0f;
	pink->Glow = 1.0f;
	pink->Outline = 0.0f;
	Vector(cfg->VioletColor[0], cfg->VioletColor[1], cfg->VioletColor[2], pink->Tint);
	VectorCopy(cfg->VioletGlowColor, pink->GlowColor);
	VectorCopy(cfg->VioletGlowColor, pink->OutlineColor);

	// Imagem 4: brilho azul, sem a textura transparente.
	auto blue = &this->m_Looks[2];

	blue->Opacity = OPACITY_HARD_FLOOR;
	blue->Saturation = 0.0f;
	blue->Texture = 0.0f;
	blue->Glow = 1.0f;
	blue->Outline = 0.0f;
	Vector(cfg->BlueColor[0], cfg->BlueColor[1], cfg->BlueColor[2], blue->Tint);
	VectorCopy(cfg->BlueGlowColor, blue->GlowColor);
	VectorCopy(cfg->BlueGlowColor, blue->OutlineColor);

	WIN32_FILE_ATTRIBUTE_DATA data;

	if (GetFileAttributesEx(path, GetFileExInfoStandard, &data) != 0)
	{
		this->m_ConfigWriteTime = data.ftLastWriteTime;
	}

	this->m_LastUpdateCounter = 0;
}

void CItemTransparency::Toggle()
{
	this->m_Enabled = !this->m_Enabled;

	if (this->m_Enabled)
	{
		pDrawMessage("[F3] Efeito +15 ativado", 1);
	}
	else
	{
		pDrawMessage("[F3] Efeito +15 desativado", 1);
	}
}

int CItemTransparency::InstallHooks()
{
	int count = 0;

	DWORD hook = (DWORD)&CItemTransparency::RenderPartObjectEffect;

	HMODULE module = GetModuleHandle(0);

	auto dos = (IMAGE_DOS_HEADER*)module;

	if (dos != nullptr && dos->e_magic == IMAGE_DOS_SIGNATURE)
	{
		auto nt = (IMAGE_NT_HEADERS*)((BYTE*)module + dos->e_lfanew);

		if (nt->Signature == IMAGE_NT_SIGNATURE)
		{
			auto section = IMAGE_FIRST_SECTION(nt);

			for (WORD n = 0; n < nt->FileHeader.NumberOfSections; n++, section++)
			{
				if ((section->Characteristics & (IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_EXECUTE)) == 0)
				{
					continue;
				}

				BYTE* start = (BYTE*)module + section->VirtualAddress;
				BYTE* end = start + section->Misc.VirtualSize;

				count += PatchCallsInRange(start, end, RENDER_PART_OBJECT_EFFECT_ADDRESS, hook);
			}
		}
	}

	static const DWORD KnownCalls[] = { 0x005666C1, 0x0061041C, 0x00610466 };

	for (int n = 0; n < _countof(KnownCalls); n++)
	{
		count += PatchCallsInRange((BYTE*)KnownCalls[n], (BYTE*)KnownCalls[n] + 5, RENDER_PART_OBJECT_EFFECT_ADDRESS, hook);
	}

	return count;
}

void CItemTransparency::CheckConfigReload()
{
	DWORD tick = GetTickCount();

	if ((tick - this->m_LastConfigCheck) < 1000)
	{
		return;
	}

	this->m_LastConfigCheck = tick;

	WIN32_FILE_ATTRIBUTE_DATA data;

	if (GetFileAttributesEx(ITEM_TRANSPARENCY_CONFIG_PATH, GetFileExInfoStandard, &data) == 0)
	{
		return;
	}

	if (CompareFileTime(&data.ftLastWriteTime, &this->m_ConfigWriteTime) != 0)
	{
		this->LoadConfig();
	}
}

bool CItemTransparency::CheckItem(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel) const
{
	if (this->m_Enabled == false || this->m_Config.Enable == 0 || o == nullptr || Light == nullptr)
	{
		return false;
	}

	if (Type < ITEM_BASE_MODEL || Type >= (ITEM_BASE_MODEL + MAX_ITEM))
	{
		return false;
	}

	if (Alpha <= 0.01f)
	{
		return false;
	}

	int itemIndex = Type - ITEM_BASE_MODEL;

	ITEM_ATTRIBUTE* attr = pGetItemAttr(itemIndex);

	if (attr == nullptr)
	{
		return false;
	}

	switch (itemIndex / MAX_ITEM_TYPE)
	{
	case 0: // Swords
	case 2: // Maces, Scepters
	case 4: // Bows
	case 5: // Staffs
	case 6: // Shields
	case 7: // Helms
	case 8: // Armors
	case 9: // Pants
	case 10: // Gloves
	case 11: // Boots
		break;
	case 13: // Pendants (slot 9) and Rings (slots 10 and 11)
		if (attr->m_byItemSlot != 9 && attr->m_byItemSlot != 10 && attr->m_byItemSlot != 11)
		{
			return false;
		}
		break;
	default:
		return false;
	}

	return ((ItemLevel >> 3) & 15) >= this->m_Config.MinLevel;
}

// Ciclo: cor do item (60% transparente) -> pulso -> brilho rosa -> pulso -> brilho azul -> pulso.
// O pulso apaga a textura no meio e acende o brilho da proxima etapa.
void CItemTransparency::Update()
{
	LARGE_INTEGER now;

	QueryPerformanceCounter(&now);

	if (this->m_LastUpdateCounter != 0 && (now.QuadPart - this->m_LastUpdateCounter) < (this->m_Frequency.QuadPart / 1000))
	{
		return;
	}

	this->m_LastUpdateCounter = now.QuadPart;

	auto cfg = &this->m_Config;

	double seconds = (double)(now.QuadPart - this->m_StartCounter.QuadPart) / (double)this->m_Frequency.QuadPart;
	double segment = (double)cfg->HoldSeconds + (double)cfg->PulseSeconds;
	double time = fmod(seconds * cfg->Speed, segment * ITEM_TRANSPARENCY_LOOK_COUNT);

	int index = (int)(time / segment);

	if (index >= ITEM_TRANSPARENCY_LOOK_COUNT)
	{
		index = ITEM_TRANSPARENCY_LOOK_COUNT - 1;
	}

	double local = time - index * segment;

	float dip = 0.0f;
	float swap = 0.0f;

	if (local > cfg->HoldSeconds)
	{
		float u = (float)((local - cfg->HoldSeconds) / cfg->PulseSeconds);

		dip = Ease(Wave(u), cfg->Smoothness);
		swap = SmoothStep(0.30f, 0.70f, u);
	}

	const ITEM_TRANSPARENCY_LOOK& from = this->m_Looks[index];
	const ITEM_TRANSPARENCY_LOOK& to = this->m_Looks[(index + 1) % ITEM_TRANSPARENCY_LOOK_COUNT];

	ITEM_TRANSPARENCY_LOOK look;

	MixLook(from, to, swap, look);

	// No meio do pulso a textura some e o brilho da proxima cor sobe.
	float body = Lerp(from.Opacity, to.Opacity, swap);
	body *= Lerp(1.0f, 0.0f, dip);

	if (body < OPACITY_HARD_FLOOR && look.Texture > 0.2f)
	{
		body = OPACITY_HARD_FLOOR;
	}

	this->m_Current.Opacity = body;
	this->m_Current.Saturation = look.Saturation;
	this->m_Current.Texture = Lerp(from.Texture, to.Texture, swap) * (1.0f - dip * 0.85f);
	this->m_Current.Glow = Lerp(from.Glow, to.Glow, swap) * (1.0f + dip * 0.20f);
	this->m_Current.Outline = look.Outline * (1.0f - dip);

	float fade = Lerp(1.0f, cfg->PulseColorFade, dip * look.Texture);

	for (int i = 0; i < 3; i++)
	{
		this->m_Current.Tint[i] = Lerp(1.0f, look.Tint[i], 1.0f - look.Texture) * fade;
		this->m_Current.GlowColor[i] = look.GlowColor[i];
		this->m_Current.OutlineColor[i] = look.OutlineColor[i];
	}
}

void CItemTransparency::Render(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType)
{
	this->Update();

	auto current = &this->m_Current;

	int level = ItemLevel & ~(0x0F << 3);

	float opacity = current->Opacity;
	float texture = Clamp(current->Texture, 0.0f, 1.0f);
	bool drawBody = (texture > 0.04f && opacity > 0.03f);

	float peak = Light[0];

	if (Light[1] > peak)
	{
		peak = Light[1];
	}

	if (Light[2] > peak)
	{
		peak = Light[2];
	}

	if (peak < 0.20f)
	{
		peak = 0.20f;
	}

	vec3_t itemHue;
	vec3_t savedGlowColor;
	float savedGlow = current->Glow;

	VectorCopy(current->GlowColor, savedGlowColor);

	for (int i = 0; i < 3; i++)
	{
		itemHue[i] = Clamp(Light[i] / peak, 0.0f, 1.0f);
	}

	float stagePeak = savedGlowColor[0];
	float stageMin = savedGlowColor[0];

	for (int i = 1; i < 3; i++)
	{
		if (savedGlowColor[i] > stagePeak)
		{
			stagePeak = savedGlowColor[i];
		}

		if (savedGlowColor[i] < stageMin)
		{
			stageMin = savedGlowColor[i];
		}
	}

	vec3_t stageColor;
	VectorCopy(savedGlowColor, stageColor);

	// Branco quase puro nao entra no brilho. No lugar fica a cor do item.
	if ((stagePeak - stageMin) < 0.10f)
	{
		VectorCopy(itemHue, stageColor);
	}

	vec3_t mixedGlow;

	for (int i = 0; i < 3; i++)
	{
		mixedGlow[i] = Lerp(stageColor[i], itemHue[i], texture);
	}

	SaturateGlow(mixedGlow, current->GlowColor);

	float brightness = (Light[0] + Light[1] + Light[2]) / 3.0f;

	vec3_t bodyLight;

	for (int i = 0; i < 3; i++)
	{
		bodyLight[i] = Lerp(brightness, Light[i], current->Saturation);
	}

	int combiner = COMBINER_NONE;

	if (this->m_Config.Desaturate != 0 && current->Saturation < 0.999f)
	{
		combiner = CheckCombinerSupport();

		if (combiner == COMBINER_GRAY && current->Saturation >= 0.5f)
		{
			combiner = COMBINER_NONE;
		}
	}

	bool prepass = (drawBody && this->m_Config.DepthPrepass != 0);

	GLint depthFunc = GL_LEQUAL;

	if (prepass)
	{
		// Depth-only pass so the translucent pass below only shows the front-most surface of the item.
		GLboolean colorMask[4];

		glGetBooleanv(GL_COLOR_WRITEMASK, colorMask);
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

		RenderPartObjectEffectOriginal(o, Type, Light, Alpha, level, Option1, ExtOption, Select, RenderType);

		glColorMask(colorMask[0], colorMask[1], colorMask[2], colorMask[3]);

		glGetIntegerv(GL_DEPTH_FUNC, &depthFunc);
		glDepthFunc(GL_LEQUAL);
	}

	// Scaling the alpha reference with the opacity keeps the same texel coverage as the opaque item.
	GLint alphaFunc = GL_ALWAYS;
	GLfloat alphaRef = 0.0f;

	glGetIntegerv(GL_ALPHA_TEST_FUNC, &alphaFunc);
	glGetFloatv(GL_ALPHA_TEST_REF, &alphaRef);

	COMBINER_STATE combinerState = {};

	if (drawBody && combiner != COMBINER_NONE)
	{
		BeginCombiner(combinerState, combiner, current->Saturation);
	}

	// Lua-rendered models (RenderModel.lua) read o->Alpha instead of the Alpha argument.
	float objectAlpha = o->Alpha;

	if (drawBody)
	{
		glAlphaFunc((GLenum)alphaFunc, alphaRef * opacity);

		o->Alpha = Alpha * opacity;

		this->m_Rendering = true;

		RenderPartObjectEffectOriginal(o, Type, bodyLight, Alpha * opacity, level, Option1, ExtOption, Select, RenderType);

		this->m_Rendering = false;

		o->Alpha = objectAlpha;

		glAlphaFunc((GLenum)alphaFunc, alphaRef);
	}

	current->Glow = savedGlow * Lerp(1.05f, 0.58f, texture);

	this->RenderGlow(o, Type, Alpha);

	current->Glow = savedGlow;
	VectorCopy(savedGlowColor, current->GlowColor);

	if (prepass && texture > 0.25f)
	{
		this->RenderOutline(o, Type, Alpha);
	}

	if (drawBody && combiner != COMBINER_NONE)
	{
		EndCombiner(combinerState);
	}

	if (prepass)
	{
		glDepthFunc(depthFunc);
	}
}

void CItemTransparency::RenderGlow(ObjectModel* o, int Type, float Alpha)
{
	auto current = &this->m_Current;

	float glowScale = this->m_Config.GlowIntensity * current->Glow * Alpha;
	float chromeScale = this->m_Config.ChromeIntensity * current->Glow * Alpha;

	if (glowScale <= 0.002f && chromeScale <= 0.002f)
	{
		return;
	}

	DWORD bmd = GetModelBMD(Type);

	if (bmd == 0)
	{
		return;
	}

	float* bodyLight = (float*)(bmd + 72);

	vec3_t backup;

	VectorCopy(bodyLight, backup);

	glPushMatrix();

	if (glowScale > 0.002f)
	{
		Vector(current->GlowColor[0] * glowScale, current->GlowColor[1] * glowScale, current->GlowColor[2] * glowScale, bodyLight);

		RenderModelBody(bmd, IT_RENDER_TEXTURE | IT_RENDER_BRIGHT, 1.0f, o);
	}

	if (chromeScale > 0.002f)
	{
		Vector(current->GlowColor[0] * chromeScale, current->GlowColor[1] * chromeScale, current->GlowColor[2] * chromeScale, bodyLight);

		RenderModelBody(bmd, IT_RENDER_CHROME | IT_RENDER_BRIGHT, 1.0f, o);
	}

	glPopMatrix();

	VectorCopy(backup, bodyLight);
}

// Silhouette and depth-edge contours: the mesh is drawn as lines pushed slightly behind the depth
// written by the prepass, so only lines over a depth discontinuity (outer edge, overlapping plates) survive.
void CItemTransparency::RenderOutline(ObjectModel* o, int Type, float Alpha)
{
	auto cfg = &this->m_Config;

	if (cfg->Outline == 0)
	{
		return;
	}

	if (cfg->OutlineWings == 0 && Type >= (ITEM_BASE_MODEL + GET_ITEM(12, 0)) && Type < (ITEM_BASE_MODEL + GET_ITEM(13, 0)))
	{
		return;
	}

	float scale = cfg->OutlineIntensity * this->m_Current.Outline * Alpha;

	if (scale <= 0.002f)
	{
		return;
	}

	DWORD bmd = GetModelBMD(Type);

	if (bmd == 0)
	{
		return;
	}

	float* bodyLight = (float*)(bmd + 72);

	vec3_t backup;

	VectorCopy(bodyLight, backup);

	GLint polygonMode[2];
	GLfloat lineWidth = 1.0f;
	GLfloat offsetFactor = 0.0f;
	GLfloat offsetUnits = 0.0f;

	glGetIntegerv(GL_POLYGON_MODE, polygonMode);
	glGetFloatv(GL_LINE_WIDTH, &lineWidth);
	glGetFloatv(GL_POLYGON_OFFSET_FACTOR, &offsetFactor);
	glGetFloatv(GL_POLYGON_OFFSET_UNITS, &offsetUnits);

	GLboolean offsetLine = glIsEnabled(GL_POLYGON_OFFSET_LINE);

	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLineWidth(cfg->OutlineWidth);
	glEnable(GL_POLYGON_OFFSET_LINE);
	glPolygonOffset(cfg->OutlineWidth, 4.0f);

	Vector(this->m_Current.OutlineColor[0] * scale, this->m_Current.OutlineColor[1] * scale, this->m_Current.OutlineColor[2] * scale, bodyLight);

	glPushMatrix();

	RenderModelBody(bmd, IT_RENDER_TEXTURE | IT_RENDER_BRIGHT, 1.0f, o);

	glPopMatrix();

	glPolygonOffset(offsetFactor, offsetUnits);

	if (offsetLine == GL_FALSE)
	{
		glDisable(GL_POLYGON_OFFSET_LINE);
	}

	glLineWidth(lineWidth);
	glPolygonMode(GL_FRONT, (GLenum)polygonMode[0]);
	glPolygonMode(GL_BACK, (GLenum)polygonMode[1]);

	VectorCopy(backup, bodyLight);
}

bool CItemTransparency::GetLightScale(float* scale) const
{
	if (this->m_Rendering == false)
	{
		return false;
	}

	VectorCopy(this->m_Current.Tint, scale);

	return true;
}

void CItemTransparency::RenderPartObjectEffect(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType)
{
	gItemTransparency.CheckConfigReload();

	if (gItemTransparency.CheckItem(o, Type, Light, Alpha, ItemLevel) == false)
	{
		RenderPartObjectEffectOriginal(o, Type, Light, Alpha, ItemLevel, Option1, ExtOption, Select, RenderType);
		return;
	}

	gItemTransparency.Render(o, Type, Light, Alpha, ItemLevel, Option1, ExtOption, Select, RenderType);
}
