#pragma once

#include <set>

#include "Lua.h"
#include "LuaEffects.h"
#include "Console.h"
#include "ItemTransparency.h"

class BMDClass {
public:
	BMDClass() : m_Struct(0), LinkObject(-1){

	};

	BMDClass(DWORD Struct) {
		this->m_Struct = Struct;
	};

	~BMDClass() {

	};

	float GetLight(int value) const {
		if (!this->m_Struct) {
			return 0.0f;
		}

		if (value == 0) {
			return *(float*)(this->m_Struct + 72);
		}
		else if (value == 1) {
			return *(float*)(this->m_Struct + 76);
		}
		else if (value == 2) {
			return *(float*)(this->m_Struct + 80);
		}

		return *(float*)(this->m_Struct + 72);
	};

	void SetLight(float r, float g, float b) const {
		if (!this->m_Struct) {
			return;
		}

		float scale[3];

		if (gItemTransparency.GetLightScale(scale))
		{
			r *= scale[0];
			g *= scale[1];
			b *= scale[2];
		}

		*(float*)(this->m_Struct + 72) = r;
		*(float*)(this->m_Struct + 76) = g;
		*(float*)(this->m_Struct + 80) = b;
	};

	void RenderBody(int Flag, float Alpha, int BlendMesh, float BlendMeshLight, float BlendMeshTexCoordU, float BlendMeshTexCoordV, int HiddenMesh, int Texture) const {
		if (!this->m_Struct) {
			return;
		}

		((void(__thiscall*)(DWORD*, int, float, int, float, float, float, int, int))0x5494C0)
			((DWORD*)this->m_Struct, Flag, Alpha, BlendMesh, BlendMeshLight, BlendMeshTexCoordU, BlendMeshTexCoordV, HiddenMesh, Texture);
	};

	void RenderMesh(int i, int RenderFlag, float Alpha, int BlendMesh, float BlendMeshLight, float BlendMeshTexCoordU, float BlendMeshTexCoordV, int MeshTexture) const {
		if (!this->m_Struct) {
			return;
		}

		((void(__thiscall*)(DWORD*, int, int, float, int, float, float, float, int))0x5468A0)
			((DWORD*)this->m_Struct, i, RenderFlag, Alpha, BlendMesh, BlendMeshLight, BlendMeshTexCoordU, BlendMeshTexCoordV, MeshTexture);
	};

	void glColor3f() const {
		if (!this->m_Struct) {
			return;
		}

		glColor3fv(*(vec3_t*)(this->m_Struct + 72));
	};

	void BeginRender(float value) const {
		//glPushMatrix();
	}

	void EndRender() const {
		//glPopMatrix();
	}

	void setMesh(int vlaue) const {
		if (!this->m_Struct) {
			return;
		}

		*(BYTE *)(this->m_Struct + 136) = vlaue;
	}

	void RenderShadowModel() const {
		if (!this->m_Struct) {
			return;
		}

		if (*(BYTE*)0x54A270 == 0xC3) {
			return;
		}

		if (pMapNumber != 10 && !((bool(*)(int))0x4DB1C0)(pMapNumber)) {
			if (!((bool(__thiscall*)(DWORD))0x4E44A0)(((DWORD(*)())0x4DB250)() + 132))
			{
				EnableAlphaTest(1);

				if (pMapNumber == 7) {
					glColor4f(0.0f, 0.0f, 0.0f, 0.2f);
				}
				else {
					glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
				}

				((void(__thiscall*)(void*, DWORD, DWORD, DWORD, DWORD)) 0x54A270)((void*)this->m_Struct, -1, -1, -1, -1);
			}
		}
	}

	void TransformPosition(int Link, float PosX, float PosY, float PosZ) {
		if (!this->m_Struct) {
			return;
		}

		if (Link != -1) {
			vec3_t vPos;

			Vector(PosX, PosY, PosZ, vPos);

			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[Link], vPos, this->Position, 0);
		}

		this->LinkObject = Link;
	}

	void TransformPosition2(int Link, float PosX, float PosY, float PosZ) {
		if (!this->m_Struct) {
			return;
		}

		if (Link != -1) {
			vec3_t vPos;

			Vector(PosX, PosY, PosZ, vPos);

			((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[Link], vPos, this->Position, 1);
		}

		this->LinkObject = Link;
	}

	void CreateSprite(int Bitmap, float Scale, float LightX, float LightY, float LightZ, DWORD ObjectStruct) {
		if (!this->m_Struct || !ObjectStruct) {
			return;
		}

		vec3_t Light;

		Vector(LightX, LightY, LightZ, Light);

		auto obj = (ObjectModel*)ObjectStruct;

		if (obj == nullptr) {
			return;
		}

		((void(*)(int, vec3_t, float, vec3_t, ObjectModel*, float, int))0x771310)(Bitmap, this->Position, Scale, Light, obj, 0.0, 0);
	}

	void CreateParticle(int Bitmap, int SubType, float Scale, float LightR, float LightG, float LightB, DWORD ObjectStruct) {
		if (!this->m_Struct || !ObjectStruct) {
			return;
		}

		vec3_t Light;

		Vector(LightR, LightG, LightB, Light);

		auto obj = (ObjectModel*)ObjectStruct;

		if (obj == nullptr) {
			return;
		}

		((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(Bitmap, Position, obj->Angle, Light, SubType, Scale, obj);
	}

	void CreateEffect(int Bitmap, int SubType, float LightX, float LightY, float LightZ, DWORD ObjectStruct) {
		if (!this->m_Struct || !ObjectStruct) {
			return;
		}

		static CCriticalSection m_critical;

		m_critical.lock();

		auto obj = (ObjectModel*)ObjectStruct;

		if (obj == nullptr) {
			m_critical.unlock();
			return;
		}

		vec3_t Light;

		Vector(LightX, LightY, LightZ, Light);

		((void(*)(int, vec3_t, vec3_t,
			vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
			float, int))0x6D9070)(Bitmap, (this->LinkObject == -1 ? obj->Position : this->Position), obj->Angle, Light, SubType, obj, -1, 0, 0, 0, 0.0, -1);

		m_critical.unlock();
	}

	void CreateEffectsInFenrirUsingSkill(DWORD ObjectStruct) {
		if (!ObjectStruct) {
			return;
		}

		auto o = (ObjectModel*)ObjectStruct;
		vec3_t vLight;
		vec3_t vPos, vPosition;

		Vector(0.0, 0.0, 0.0, vPos);
		Vector(1.0f, 1.0f, 1.0f, vLight);

		if (o == nullptr) {
			return;
		}

		if (o->CurrentAction == 1)
		{
			if (o->AnimationFrame >= 0.0f && o->AnimationFrame <= 1.5f)
			{
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[22], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[28], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[36], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[44], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
			}
		}
		else if (o->CurrentAction == 2)
		{
			if (o->AnimationFrame>1.f && o->AnimationFrame <= 1.4f)
			{
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[22], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[28], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
			}
			else if (o->AnimationFrame>4.8f && o->AnimationFrame <= 5.2f)
			{
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[36], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
				Vector(0.0f, 0.0f, 0.0f, vPos);
				((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)this->m_Struct, BoneTransform[44], vPos, vPosition, false);
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(389, vPosition, o->Angle, vLight, 0, o, -1, 0, 0, 0, 0.0, -1);
			}
		}
	}

private:
	DWORD m_Struct;
	vec3_t Position;
	int LinkObject;
};

class LuaBMD {
public:
	LuaBMD();
	~LuaBMD();

	void RegisterClassBMD(lua_State* lua);
};