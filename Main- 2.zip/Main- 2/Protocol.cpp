#include "stdafx.h"
#include "Protocol.h"
#include "Common.h"
#include "HealthBar.h"
#include "AntiHack.h"
#include "Offset.h"
#include "PacketManager.h"
#include "PrintPlayer.h"
#include "Reconnect.h"
#include "Util.h"
#include "LoadFiles.h"
#include "LuaSocket.h"
#include "CustomPreview.h"
#include "ItemMove.h"
#include "Structs.h"
#include "CustomWing.h"
#include "HelperSystem.h"
#include "HelperManager.h"
#include "Item.h"
#include "TradeX.h"
#include "ChaosBoxGenesis.h"
#include "Camera.h"
#include "CounterItem.h"
#include "Patente.h"
#include "PersonalShop.h"
#include "CharacterList.h"
#include "Console.h"
#include "ElementSlots.h"
#include "ElementPet.h"
#include "VisualInventory.h"
#include "AutoLoginWin.h"
#include "Hunting.h"
#include "Interface.h"
#include "PetMode.h"


BOOL ProtocolCoreEx(BYTE head,BYTE* lpMsg,int size,int key) // OK
{
	if ((DWORD)(timeGetTime() - gAntiHack.m_LastTickThread / 1000) > (DWORD)3500) {
		gAntiHack.SendCloseServer();
	}

	switch(head)
	{
		case 0x11:
			GCDamageRecv((PMSG_DAMAGE_RECV*)lpMsg);
			break;
		case 0x14:
			GCViewportDestroyRecv((PMSG_VIEWPORT_DESTROY_RECV *)lpMsg);
			break;
		case 0x16:
			GCMonsterDieRecv((PMSG_MONSTER_DIE_RECV*)lpMsg);
			break;
		case 0x17:
			GCUserDieRecv((PMSG_USER_DIE_RECV*)lpMsg);
			break;
		case 0x1C:
			gPatente.Clear();
			break;
		case 0x24:
			GCItemMoveRecv((PMSG_ITEM_MOVE_RECV*)lpMsg);
			break;
		case 0x26:
			GCLifeRecv((PMSG_LIFE_RECV*)lpMsg);
			break;
		case 0x27:
			GCManaRecv((PMSG_MANA_RECV*)lpMsg);
			break;
		case 0x37:
			gTradeX.GCTradeResponseRecv((PMSG_TRADE_RESPONSE_RECV*)lpMsg);
			break;
		case 0x3C:
			gTradeX.TradeXOkButtonRecv((PMSG_TRADE_OK_BUTTON_RECV*)lpMsg);
			break;
		case 0x2C:
			GCFruitResultRecv((PMSG_FRUIT_RESULT_RECV*)lpMsg);
			break;
		case 0x9C:
			GCRewardExperienceRecv((PMSG_REWARD_EXPERIENCE_RECV*)lpMsg);
			break;
		case 0xA3:
			GCQuestRewardRecv((PMSG_QUEST_REWARD_RECV*)lpMsg);
			break;
		case 0x3F:
			switch (((lpMsg[0] == 0xC1) ? lpMsg[3] : lpMsg[4]))
			{
			case 0x27:
				gPersonalShop.GCPShopItemPrinceListRecv((PMSG_PSHOP_ITEM_LIST_RECV*)lpMsg);
				return 1;
			}
			break;
		case 0xB1:
			switch(((lpMsg[0]==0xC1)?lpMsg[3]:lpMsg[4]))
			{
				case 0x00:
					GCMapServerMoveRecv((PMSG_MAP_SERVER_MOVE_RECV*)lpMsg);
					break;
				case 0x01:
					GCMapServerMoveAuthRecv((PMSG_MAP_SERVER_MOVE_AUTH_RECV*)lpMsg);
					break;
				case 0x15:
					gTradeX.TradeXItemAddRecv((PMSG_TRADEX_ITEM_ADD_RECV*)lpMsg);
					return 1;
			}
			break;
		case 0xF1:
			switch(((lpMsg[0]==0xC1)?lpMsg[3]:lpMsg[4]))
			{
				case 0x00:
					GCConnectClientRecv((PMSG_CONNECT_CLIENT_RECV*)lpMsg);
					break;
				case 0x01:
					GCConnectAccountRecv((PMSG_CONNECT_ACCOUNT_RECV*)lpMsg);
					break;
				case 0x02:
					GCCloseClientRecv((PMSG_CLOSE_CLIENT_RECV*)lpMsg);
					break;
			}
			break;
		case 0xF3:
			switch(((lpMsg[0]==0xC1)?lpMsg[3]:lpMsg[4]))
			{
				case 0x00:
					GCCharacterListRecv((PMSG_CHARACTER_LIST_RECV*)lpMsg);
					return 1;
				case 0x03:
					GCCharacterInfoRecv((PMSG_CHARACTER_INFO_RECV*)lpMsg);
					break;
				case 0x04:
					GCCharacterRegenRecv((PMSG_CHARACTER_REGEN_RECV*)lpMsg);
					break;
				case 0x05:
					GCLevelUpRecv((PMSG_LEVEL_UP_RECV*)lpMsg);
					break;
				case 0x06:
					GCLevelUpPointRecv((PMSG_LEVEL_UP_POINT_RECV*)lpMsg);
					break;
				case 0x07:
					GCMonsterDamageRecv((PMSG_MONSTER_DAMAGE_RECV*)lpMsg);
					break;
				/*case 0x10:
					GCItemListRecv((PMSG_ITEM_LIST_RECV*)lpMsg);
					break;*/
				case 0x50:
					GCMasterInfoRecv((PMSG_MASTER_INFO_RECV*)lpMsg);
					break;
				case 0x51:
					GCMasterLevelUpRecv((PMSG_MASTER_LEVEL_UP_RECV*)lpMsg);
					break;
				case 0x70:
					GCCustomPreviewCharListRecv((PMSG_CUSTOM_PREVIEW_CHAR_LIST_RECV*)lpMsg);
					return 1;
				case 0x72:
					GCCustomPreviewCharRecv((PMSG_CUSTOM_PREVIEW_CHARSET_RECV*)lpMsg);
					return 1;
				case 0xA9:
					CGItemMoveRecv((PMSG_ITEM_MOVE_RECV2*)lpMsg);
					return 1;
				case 0xE0:
					GCNewCharacterInfoRecv((PMSG_NEW_CHARACTER_INFO_RECV*)lpMsg);
					return 1;
				case 0xE1:
					GCNewCharacterCalcRecv((PMSG_NEW_CHARACTER_CALC_RECV*)lpMsg);
					return 1;
				case 0xE2:
					GCNewHealthBarRecv((PMSG_NEW_HEALTH_BAR_RECV*)lpMsg);
					return 1;
				case 0xE3:
					GCNewGensBattleInfoRecv((PMSG_NEW_GENS_BATTLE_INFO_RECV*)lpMsg);
					return 1;
				case 0xE4:
					GCNewMessageRecv((PMSG_NEW_MESSAGE_RECV*)lpMsg);
					return 1;
				case 0xE9:
					gPatente.GCPatentePlayerRecv((PMSG_VIEWPORT_RECV *)lpMsg);
					return 1;
				case 0xD8:
					gPetMode.GCPetModeRecv(lpMsg, size);
					return 1;
			}
			break;
		case 0xEF:
			switch (((lpMsg[0] == 0xC1) ? lpMsg[3] : lpMsg[4]))
			{
			case 0x20:
				gChaosBoxGenesis.Open((SDHP_CHAOS_BOX_GENESIS_OPEN_CLIENT_RECV*) lpMsg);
				return 1;
			case 0x21:
				gChaosBoxGenesis.ChaosBoxGenesisListItemRecv((PMSG_CHAOS_BOX_GENESIS_LIST_RECV*)lpMsg);
				return 1;
			case 0x23:
				gChaosBoxGenesis.ChaosBoxGenesisStateRecv((PMSG_CHAOS_BOX_GENESIS_STATE_RECV*)lpMsg);
				return 1;
			}
			break;
		case 0xFA:
			gSocket.RecvCustomPacket(lpMsg[4], (PMSG_CUSTOM_SOCKET_SEND*)lpMsg, size);
			return 1;
		case 0xFB:
			switch (((lpMsg[0] == 0xC1) ? lpMsg[3] : lpMsg[4]))
			{
			case 0x2C:
				GCItemCounterRecv((PMSG_ITEM_COUNTER_RECV *)lpMsg);
				return 1;
			case 0x2D:
				GCItemDropMarkRecv((PMSG_ITEM_COUNTER_RECV *)lpMsg);
				return 1;
			case 0x10:
				gTradeX.TradeXStateRecv((PMSG_TRADEX_STATE_RECV*)lpMsg);
				return 1;
			case 0x11:
				gTradeX.TradeXListRecv((PMSG_TRADEX_ITEM_LIST_RECV*)lpMsg);
				return 1;
			case 0x13:
				gTradeX.TradeXDelItemTarget((PMSG_TRADEX_ITEM_DEL_RECV*)lpMsg);
				return 1;
			case 0x16:
				gHunting.ReceiveHunting((PMSG_CHARACTER_HUNTING_INFO_RECV*)lpMsg);
				return 1;

			}
			return 1;
	}

	gAntiHack.m_TickCountProtocol = GetTickCount();

	return ProtocolCore(head,lpMsg,size,key);
}

void GCDamageRecv(PMSG_DAMAGE_RECV* lpMsg) // OK
{
	int aIndex = MAKE_NUMBERW(lpMsg->index[0],lpMsg->index[1]) & 0x7FFF;

	if(ViewIndex == aIndex)
	{
		ViewCurHP = lpMsg->ViewCurHP;
		ViewCurSD = lpMsg->ViewCurSD;
	}

	ViewDamageHP = lpMsg->ViewDamageHP;
	ViewDamageSD = lpMsg->ViewDamageSD;

	if((lpMsg->type & 0x10) != 0)
	{
		if(ViewDamageCount < 3)
		{
			ViewDamageTable[ViewDamageCount++] = lpMsg->ViewDamageHP;
			ViewDamageValue = ViewDamageCount;
		}
	}

	if((lpMsg->type & 0x20) != 0)
	{
		if(ViewDamageCount < 4)
		{
			ViewDamageTable[ViewDamageCount++] = lpMsg->ViewDamageHP;
			ViewDamageValue = ViewDamageCount;
		}
	}
}

void GCViewportDestroyRecv(PMSG_VIEWPORT_DESTROY_RECV * lpMsg)
{
	for (int n = 0; n < lpMsg->count; n++)
	{
		PMSG_VIEWPORT_DESTROY* lpInfo = (PMSG_VIEWPORT_DESTROY*)(((BYTE*)lpMsg) + sizeof(PMSG_VIEWPORT_DESTROY_RECV) + (sizeof(PMSG_VIEWPORT_DESTROY)*n));

		gCustomPreview.DeleteCustomPreview(MAKE_NUMBERW(lpInfo->index[0], lpInfo->index[1]));
		gPatente.DeletePlayer(MAKE_NUMBERW(lpInfo->index[0], lpInfo->index[1]));
	}
}

void GCMonsterDieRecv(PMSG_MONSTER_DIE_RECV* lpMsg) // OK
{
	ViewDamageHP = lpMsg->ViewDamageHP;
}

void GCUserDieRecv(PMSG_USER_DIE_RECV* lpMsg) // OK
{
	int aIndex = MAKE_NUMBERW(lpMsg->index[0],lpMsg->index[1]) & 0x7FFF;

	if(ViewIndex == aIndex)
	{
		ViewCurHP = 0;
	}
}

void GCItemMoveRecv(PMSG_ITEM_MOVE_RECV * lpMsg)
{
	if (lpMsg->result != 255) {
		if (!gTradeX.isVisible() && !gChaosBoxGenesis.isVisible()) {
			if (gItemMove.checkAutoItemMove()) {
				if (gItemMove.m_DeleteInventoryCtrl) {
					if (gItemMove.m_InventoryCtrlMix == 1) {
						auto pItemObj = pInventoryCtrlFindItem(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), gItemMove.m_BackupMouseX, gItemMove.m_BackupMouseY);

						if (pItemObj) {
							pInventoryCtrlDeleteItem(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), pItemObj);
						}

						gItemMove.m_InventoryCtrlMix = false;
					}
					else {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), gItemMove.m_BackupMouseX, gItemMove.m_BackupMouseY, &InventoryCtrl);

						if (pItemObj) {
							pInventoryCtrlDeleteItem(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), InventoryCtrl), pItemObj);
						}
					}
				}
				else {
					auto item = gItemMove.getItem(gItemMove.m_BackupSlot);

					if (item) {
						if (item->Type != -1) {
							pInventoryUnequipItem(pInventoryThis(pWindowThis()), gItemMove.m_BackupSlot);

							item->Type = -1;
							item->Level = 0;
							item->Number = -1;
							item->Option1 = 0;
							item->ExtOption = 0;
						}
					}
				}

				gItemMove.SetAutoItemMove(false);
			}

			if (lpMsg->slot >= 236 && lpMsg->slot <= 239) {
				gElementSlots.AddItem(lpMsg->slot, lpMsg->ItemInfo);
			}
			else if (lpMsg->slot >= 240 && lpMsg->slot <= 248) {
				gVisualInventory.AddItem(lpMsg->slot, lpMsg->ItemInfo);
				gVisualInventory.MainSetCharacterClass(Hero);
			}
		}
	}
	else {
		if (!gTradeX.isVisible()) {
			gItemMove.SetAutoItemMove(false);
		}
	}
}

void GCLifeRecv(PMSG_LIFE_RECV* lpMsg) // OK
{
	if(lpMsg->type == 0xFE)
	{
		ViewMaxHP = lpMsg->ViewHP;
		ViewMaxSD = lpMsg->ViewSD;
	}

	if(lpMsg->type == 0xFF)
	{
		ViewCurHP = ((ViewCurHP==0)?ViewCurHP:lpMsg->ViewHP);
		ViewCurSD = lpMsg->ViewSD;
	}
}

void GCManaRecv(PMSG_MANA_RECV* lpMsg) // OK
{
	if(lpMsg->type == 0xFE)
	{
		ViewMaxMP = lpMsg->ViewMP;
		ViewMaxBP = lpMsg->ViewBP;
	}

	if(lpMsg->type == 0xFF)
	{
		ViewCurMP = lpMsg->ViewMP;
		ViewCurBP = lpMsg->ViewBP;
	}
}

void GCFruitResultRecv(PMSG_FRUIT_RESULT_RECV* lpMsg) // OK
{
	if(lpMsg->result == 0 || lpMsg->result == 3 || lpMsg->result == 6 || lpMsg->result == 17)
	{
		ViewValue = lpMsg->ViewValue;
		ViewPoint = lpMsg->ViewPoint;
		ViewStrength = lpMsg->ViewStrength;
		ViewDexterity = lpMsg->ViewDexterity;
		ViewVitality = lpMsg->ViewVitality;
		ViewEnergy = lpMsg->ViewEnergy;
		ViewLeadership = lpMsg->ViewLeadership;
	}
}

void GCRewardExperienceRecv(PMSG_REWARD_EXPERIENCE_RECV* lpMsg) // OK
{
	ViewDamageHP = lpMsg->ViewDamageHP;
}

void GCQuestRewardRecv(PMSG_QUEST_REWARD_RECV* lpMsg) // OK
{
	int aIndex = MAKE_NUMBERW(lpMsg->index[0],lpMsg->index[1]) & 0x7FFF;

	if(ViewIndex == aIndex)
	{
		ViewPoint = lpMsg->ViewPoint;
	}
}

void GCMapServerMoveRecv(PMSG_MAP_SERVER_MOVE_RECV* lpMsg) // OK
{
	ReconnectOnMapServerMove(lpMsg->IpAddress,lpMsg->ServerPort);
}

void GCMapServerMoveAuthRecv(PMSG_MAP_SERVER_MOVE_AUTH_RECV* lpMsg) // OK
{
	ReconnectOnMapServerMoveAuth(lpMsg->result);
}

void GCConnectClientRecv(PMSG_CONNECT_CLIENT_RECV* lpMsg) // OK
{

	ViewIndex = MAKE_NUMBERW(lpMsg->index[0],lpMsg->index[1]);

	if (lpMsg->PackNothing != lpMsg->PacketNumber || lpMsg->PacketSend == 0)
	{
		gAntiHack.CloseApp();
		return;
	}

	gAntiHack.LicenseChecked = 1;

	gAntiHack.GetMac();

}

void GCConnectAccountRecv(PMSG_CONNECT_ACCOUNT_RECV* lpMsg) // OK
{
	ReconnectOnConnectAccount(lpMsg->result);
}

void GCCloseClientRecv(PMSG_CLOSE_CLIENT_RECV* lpMsg) // OK
{
	ReconnectOnCloseClient(lpMsg->result);
}

void GCCharacterListRecv(PMSG_CHARACTER_LIST_RECV* lpMsg) // OK
{
	ReconnectOnCharacterList();

	gAntiHack.ClientSendMac();

	gCamera.Restore();

	gCharacterList.CGCharacterListRecv(lpMsg);



	gElementSlots.Release();

	gVisualInventory.Release();
}

void GCCharacterInfoRecv(PMSG_CHARACTER_INFO_RECV* lpMsg) // OK
{
	if (!AutoLogin.m_ConnectingAutoLogin) {
		ReconnectOnCharacterInfo();
	}

	gPetMode.EnterWorld();

	ViewReset = lpMsg->ViewReset;
	ViewPoint = lpMsg->ViewPoint;
	ViewCurHP = lpMsg->ViewCurHP;
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewCurMP = lpMsg->ViewCurMP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewCurBP = lpMsg->ViewCurBP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewCurSD = lpMsg->ViewCurSD;
	ViewMaxSD = lpMsg->ViewMaxSD;
	ViewStrength = lpMsg->ViewStrength;
	ViewDexterity = lpMsg->ViewDexterity;
	ViewVitality = lpMsg->ViewVitality;
	ViewEnergy = lpMsg->ViewEnergy;
	ViewLeadership = lpMsg->ViewLeadership;

	DWORD viewport = *(DWORD*)(MAIN_VIEWPORT_STRUCT);
	DWORD character = *(DWORD*)(MAIN_CHARACTER_STRUCT);

	if (viewport != 0)
	{
		*(WORD*)(viewport + 0x07E) = 0;
		*(BYTE*)(viewport + 0x30C) = 0;
	}

	if (character == 0)
	{
		gTradeX.ClearTradeX();
		gCamera.Restore();
		return;
	}

	switch(((*(BYTE*)(character + 0x0B)) & 7))
	{
		case 0:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.DWMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 1:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.DKMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 2:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.FEMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 3:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.MGMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 4:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.DLMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 5:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.SUMaxAttackSpeed>=0xFFFF)?0x02:0x0F));
			break;
		case 6:
			SetByte(0x00556C38,((gLoadFiles.m_LoadFiles.RFMaxAttackSpeed>=0xFFFF)?0x0F:0x0F));
			break;
	}

	gTradeX.ClearTradeX();

	gCamera.Restore();
}

void GCCharacterRegenRecv(PMSG_CHARACTER_REGEN_RECV* lpMsg) // OK
{
	ViewCurHP = lpMsg->ViewCurHP;
	ViewCurMP = lpMsg->ViewCurMP;
	ViewCurBP = lpMsg->ViewCurBP;
	ViewCurSD = lpMsg->ViewCurSD;
}

void GCLevelUpRecv(PMSG_LEVEL_UP_RECV* lpMsg) // OK
{
	ViewPoint = lpMsg->ViewPoint;
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewMaxSD = lpMsg->ViewMaxSD;
	ViewExperience = lpMsg->ViewExperience;
	ViewNextExperience = lpMsg->ViewNextExperience;
}

void GCLevelUpPointRecv(PMSG_LEVEL_UP_POINT_RECV* lpMsg) // OK
{
	if(lpMsg->result >= 16 && lpMsg->result <= 20)
	{
		ViewPoint = lpMsg->ViewPoint;
		ViewMaxHP = lpMsg->ViewMaxHP;
		ViewMaxMP = lpMsg->ViewMaxMP;
		ViewMaxBP = lpMsg->ViewMaxBP;
		ViewMaxSD = lpMsg->ViewMaxSD;
		ViewStrength = lpMsg->ViewStrength;
		ViewDexterity = lpMsg->ViewDexterity;
		ViewVitality = lpMsg->ViewVitality;
		ViewEnergy = lpMsg->ViewEnergy;
		ViewLeadership = lpMsg->ViewLeadership;
	}
}

void GCMonsterDamageRecv(PMSG_MONSTER_DAMAGE_RECV* lpMsg) // OK
{
	ViewCurHP = lpMsg->ViewCurHP;
	ViewCurSD = lpMsg->ViewCurSD;
	ViewDamageHP = lpMsg->ViewDamageHP;
	ViewDamageSD = lpMsg->ViewDamageSD;
}

void GCMasterInfoRecv(PMSG_MASTER_INFO_RECV* lpMsg) // OK
{
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewMaxSD = lpMsg->ViewMaxSD;
}

void GCMasterLevelUpRecv(PMSG_MASTER_LEVEL_UP_RECV* lpMsg) // OK
{
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewMaxSD = lpMsg->ViewMaxSD;
	ViewMasterExperience = lpMsg->ViewMasterExperience;
	ViewMasterNextExperience = lpMsg->ViewMasterNextExperience;
}

void GCCustomPreviewCharListRecv(PMSG_CUSTOM_PREVIEW_CHAR_LIST_RECV * lpMsg)
{
	gCustomPreview.ClearCustomPreviewCharList();

	for (int n = 0; n < lpMsg->count; n++) {
		PMSG_CUSTOM_PREVIEW_CHAR_LIST* lpInfo = (PMSG_CUSTOM_PREVIEW_CHAR_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_CUSTOM_PREVIEW_CHAR_LIST_RECV) + (sizeof(PMSG_CUSTOM_PREVIEW_CHAR_LIST)*n));
		gCustomPreview.InsertCustomPreviewCharList(n, lpInfo->Name, lpInfo->PetIndex, lpInfo->WingIndex);
	}
}

void GCCustomPreviewCharRecv(PMSG_CUSTOM_PREVIEW_CHARSET_RECV * lpMsg)
{
	if (lpMsg->Viewport == 1) {
		gCustomPreview.ClearCustomPreviewList(1);

		for (int n = 0; n < lpMsg->count; n++) {
			PMSG_CUSTOM_PREVIEW_CHARSET_LIST* lpInfo = (PMSG_CUSTOM_PREVIEW_CHARSET_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_CUSTOM_PREVIEW_CHARSET_RECV) + (sizeof(PMSG_CUSTOM_PREVIEW_CHARSET_LIST)*n));
			gCustomPreview.InsertCustomPreviewList(n + 1, lpInfo->Name, lpInfo->PetIndex, lpInfo->WingIndex, lpInfo->index, lpInfo->SecondPetIndex, lpInfo->ElementSlot);
		}
	}
	else {
		gCustomPreview.ClearCustomPreviewList(0);

		for (int n = 0; n < lpMsg->count; n++) {
			PMSG_CUSTOM_PREVIEW_CHARSET_LIST* lpInfo = (PMSG_CUSTOM_PREVIEW_CHARSET_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_CUSTOM_PREVIEW_CHARSET_RECV) + (sizeof(PMSG_CUSTOM_PREVIEW_CHARSET_LIST)*n));
			gCustomPreview.InsertCustomPreviewList(n, lpInfo->Name, lpInfo->PetIndex, lpInfo->WingIndex, lpInfo->index, lpInfo->SecondPetIndex, lpInfo->ElementSlot);
		}
	}
}

void CGItemMoveRecv(PMSG_ITEM_MOVE_RECV2 * lpMsg)
{
	if (lpMsg->result != 0xFF) {
		if (gTradeX.isVisible() || gChaosBoxGenesis.isVisible()) {
			if (lpMsg->SourceFlag == MovePosition::Inventory)
			{
				if (gItemMove.checkAutoItemMove()) {
					if (gItemMove.m_DeleteInventoryCtrl) {
						if (gItemMove.m_InventoryCtrlMix == 1) {
							auto pItemObj = pInventoryCtrlFindItem(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), gItemMove.m_BackupMouseX, gItemMove.m_BackupMouseY);

							if (pItemObj) {
								pInventoryCtrlDeleteItem(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), pItemObj);
							}

							gItemMove.m_InventoryCtrlMix = false;
						}
						else {
							DWORD InventoryCtrl = -1;
							ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), gItemMove.m_BackupMouseX, gItemMove.m_BackupMouseY, &InventoryCtrl);

							if (pItemObj) {
								pInventoryCtrlDeleteItem(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), InventoryCtrl), pItemObj);
							}
						}
					}
					else {
						auto item = gItemMove.getItem(gItemMove.m_BackupSlot);

						if (item) {
							if (item->Type != -1) {
								pInventoryUnequipItem(pInventoryThis(pWindowThis()), gItemMove.m_BackupSlot);

								item->Type = -1;
								item->Level = 0;
								item->Number = -1;
								item->Option1 = 0;
								item->ExtOption = 0;
							}
						}
					}

					gItemMove.SetAutoItemMove(false);

					((void(__thiscall*)(LPVOID))0x7DA5A0)(pTradeGetMyInventoryCtrl(pTradeInventoryThis(pWindowThis())));

				}

				if (lpMsg->TargetFlag == 0) {
					if (lpMsg->TargetSlot >= 236 && lpMsg->TargetSlot <= 239) {
						gElementSlots.AddItem(lpMsg->TargetSlot, lpMsg->ItemInfo);
					}
					else if (lpMsg->TargetSlot >= 240 && lpMsg->TargetSlot <= 248) {
						gVisualInventory.AddItem(lpMsg->TargetSlot, lpMsg->ItemInfo);
						gVisualInventory.MainSetCharacterClass(Hero);
					}
				}
			}
			else if (lpMsg->SourceFlag == MovePosition::TradeX) {
				gTradeX.DelItemSource(lpMsg->SourceSlot);
				gTradeX.CalcLinesRenderSource();
				gItemMove.m_ItemMove = 0;
			}
			else if (lpMsg->SourceFlag == MovePosition::ChaosBoxGenesis) {
				gChaosBoxGenesis.DelItem(lpMsg->SourceSlot);
				gChaosBoxGenesis.CalcLinesRender();
				gItemMove.m_ItemMove = 0;
			}

			if (lpMsg->TargetFlag == MovePosition::TradeX) {
				gTradeX.SourceInserItens(lpMsg->TargetSlot, lpMsg->ItemInfo);
				gTradeX.CalcLinesRenderSource();
			}
			else if (lpMsg->TargetFlag == MovePosition::ChaosBoxGenesis) {
				gChaosBoxGenesis.InsertItemChaosMachine(lpMsg->TargetSlot, lpMsg->ItemInfo);
			}
		}

		gItemMove.m_ItemMove = 0;
	}
	else {
		gItemMove.m_ItemMove = 0;
	}
}

void GCNewCharacterInfoRecv(PMSG_NEW_CHARACTER_INFO_RECV* lpMsg) // OK
{
	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x0E) = lpMsg->Level;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x74) = lpMsg->LevelUpPoint;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x18) = lpMsg->Strength;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x1A) = lpMsg->Dexterity;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x1C) = lpMsg->Vitality;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x1E) = lpMsg->Energy;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x20) = lpMsg->Leadership;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x22) = lpMsg->Life;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x26) = lpMsg->MaxLife;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x24) = lpMsg->Mana;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x28) = lpMsg->MaxMana;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x40) = lpMsg->BP;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x42) = lpMsg->MaxBP;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x2A) = lpMsg->Shield;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x2C) = lpMsg->MaxShield;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x4C) = lpMsg->FruitAddPoint;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x4E) = lpMsg->MaxFruitAddPoint;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x50) = lpMsg->FruitSubPoint;

	*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x52) = lpMsg->MaxFruitSubPoint;

	*(DWORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x10) = lpMsg->Experience;

	*(DWORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x14) = lpMsg->NextExperience;

	//EXTRA
	ViewReset = lpMsg->ViewReset;
	ViewPoint = lpMsg->ViewPoint;
	ViewCurHP = lpMsg->ViewCurHP;
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewCurMP = lpMsg->ViewCurMP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewCurBP = lpMsg->ViewCurBP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewCurSD = lpMsg->ViewCurSD;
	ViewMaxSD = lpMsg->ViewMaxSD;
	ViewStrength = lpMsg->ViewStrength;
	ViewDexterity = lpMsg->ViewDexterity;
	ViewVitality = lpMsg->ViewVitality;
	ViewEnergy = lpMsg->ViewEnergy;
	ViewLeadership = lpMsg->ViewLeadership;
}

void GCNewCharacterCalcRecv(PMSG_NEW_CHARACTER_CALC_RECV* lpMsg) // OK
{
	ViewCurHP = lpMsg->ViewCurHP;
	ViewMaxHP = lpMsg->ViewMaxHP;
	ViewCurMP = lpMsg->ViewCurMP;
	ViewMaxMP = lpMsg->ViewMaxMP;
	ViewCurBP = lpMsg->ViewCurBP;
	ViewMaxBP = lpMsg->ViewMaxBP;
	ViewCurSD = lpMsg->ViewCurSD;
	ViewMaxSD = lpMsg->ViewMaxSD;
	ViewAddStrength = lpMsg->ViewAddStrength;
	ViewAddDexterity = lpMsg->ViewAddDexterity;
	ViewAddVitality = lpMsg->ViewAddVitality;
	ViewAddEnergy = lpMsg->ViewAddEnergy;
	ViewAddLeadership = lpMsg->ViewAddLeadership;
	ViewPhysiDamageMin = lpMsg->ViewPhysiDamageMin;
	ViewPhysiDamageMax = lpMsg->ViewPhysiDamageMax;
	ViewMagicDamageMin = lpMsg->ViewMagicDamageMin;
	ViewMagicDamageMax = lpMsg->ViewMagicDamageMax;
	ViewCurseDamageMin = lpMsg->ViewCurseDamageMin;
	ViewCurseDamageMax = lpMsg->ViewCurseDamageMax;
	ViewMulPhysiDamage = lpMsg->ViewMulPhysiDamage;
	ViewDivPhysiDamage = lpMsg->ViewDivPhysiDamage;
	ViewMulMagicDamage = lpMsg->ViewMulMagicDamage;
	ViewDivMagicDamage = lpMsg->ViewDivMagicDamage;
	ViewMulCurseDamage = lpMsg->ViewMulCurseDamage;
	ViewDivCurseDamage = lpMsg->ViewDivCurseDamage;
	ViewMagicDamageRate = lpMsg->ViewMagicDamageRate;
	ViewCurseDamageRate = lpMsg->ViewCurseDamageRate;
	ViewPhysiSpeed = lpMsg->ViewPhysiSpeed;
	ViewMagicSpeed = lpMsg->ViewMagicSpeed;
	ViewAttackSuccessRate = lpMsg->ViewAttackSuccessRate;
	ViewAttackSuccessRatePvP = lpMsg->ViewAttackSuccessRatePvP;
	ViewDefense = lpMsg->ViewDefense;
	ViewDefenseSuccessRate = lpMsg->ViewDefenseSuccessRate;
	ViewDefenseSuccessRatePvP = lpMsg->ViewDefenseSuccessRatePvP;
	ViewDamageMultiplier = lpMsg->ViewDamageMultiplier;
	ViewRFDamageMultiplierA = lpMsg->ViewRFDamageMultiplierA;
	ViewRFDamageMultiplierB = lpMsg->ViewRFDamageMultiplierB;
	ViewRFDamageMultiplierC = lpMsg->ViewRFDamageMultiplierC;
	ViewDarkSpiritAttackDamageMin = lpMsg->ViewDarkSpiritAttackDamageMin;
	ViewDarkSpiritAttackDamageMax = lpMsg->ViewDarkSpiritAttackDamageMax;
	ViewDarkSpiritAttackSpeed = lpMsg->ViewDarkSpiritAttackSpeed;
	ViewDarkSpiritAttackSuccessRate = lpMsg->ViewDarkSpiritAttackSuccessRate;
}

void GCNewHealthBarRecv(PMSG_NEW_HEALTH_BAR_RECV* lpMsg) // OK
{
	gHealthBar.ClearNewHealthBar();

	for(int n=0;n < lpMsg->count;n++)
	{
		PMSG_NEW_HEALTH_RECV* lpInfo = (PMSG_NEW_HEALTH_RECV*)(((BYTE*)lpMsg)+sizeof(PMSG_NEW_HEALTH_BAR_RECV)+(sizeof(PMSG_NEW_HEALTH_RECV)*n));

		gHealthBar.InsertNewHealthBar(lpInfo->index,lpInfo->type,lpInfo->rate);
	}
}

void GCNewGensBattleInfoRecv(PMSG_NEW_GENS_BATTLE_INFO_RECV* lpMsg) // OK
{
	GensBattleMapCount = lpMsg->GensBattleMapCount;

	GensMoveIndexCount = lpMsg->GensMoveIndexCount;

	memcpy(GensBattleMap,lpMsg->GensBattleMap,sizeof(GensBattleMap));

	memcpy(GensMoveIndex,lpMsg->GensMoveIndex,sizeof(GensMoveIndex));
}

void GCNewMessageRecv(PMSG_NEW_MESSAGE_RECV* lpMsg) // OK
{

}

void GCItemCounterRecv(PMSG_ITEM_COUNTER_RECV * lpMsg)
{
	gCounterItem.ClearById(lpMsg->Type);

	for (int n = 0; n < lpMsg->count; n++)
	{
		auto lpInfo = (PMSG_ITEM_COUNTER_INFO*)(((BYTE*)lpMsg) + sizeof(PMSG_ITEM_COUNTER_RECV) + (sizeof(PMSG_ITEM_COUNTER_INFO)*n));
		gCounterItem.InserCounterItem(lpInfo->ItemIndex, lpInfo->Slot, lpMsg->Type, lpInfo->kills);
	}
}

void GCItemDropMarkRecv(PMSG_ITEM_COUNTER_RECV * lpMsg)
{
	gCounterItem.ClearDropById(lpMsg->Type);

	for (int n = 0; n < lpMsg->count; n++)
	{
		auto lpInfo = (PMSG_ITEM_COUNTER_INFO*)(((BYTE*)lpMsg) + sizeof(PMSG_ITEM_COUNTER_RECV) + (sizeof(PMSG_ITEM_COUNTER_INFO)*n));

		if (lpInfo->kills == 0)
		{
			continue;
		}

		gCounterItem.InserDropItem(lpInfo->ItemIndex, lpInfo->Slot, lpMsg->Type, lpInfo->kills);
	}
}

void GCChatSend(char* name, char* text)
{
	PMSG_CHAT_SEND pMsg;

	pMsg.header.set(0x00, sizeof(pMsg));

	strcpy_s(pMsg.name, name);

	strcpy_s(pMsg.message, text);

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void SendItemMove(int SourceSlot, int SourceFlag, int TargetSlot, int TargetFlag)
{
	PMSG_ITEM_MOVE_SEND pMsg;

	pMsg.header.setE(0x24, sizeof(pMsg));

	pMsg.SourceFlag = SourceFlag;

	pMsg.TargetFlag = TargetFlag;

	pMsg.SourceSlot = SourceSlot;

	pMsg.TargetSlot = TargetSlot;

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void SendRequestTrade(int index) {
	PMSG_TRADE_REQUEST_SEND pMsg;

	pMsg.header.setE(0x36, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(index);

	pMsg.index[1] = SET_NUMBERLB(index);

	DataSend((BYTE*)&pMsg, pMsg.header.size);

	char Text[100];
	lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), ((int(*)(int))0x57D9A0)(index));
	sprintf_s(Text, pGetTextLine(pTextLineThis, 475), lpObj->Name);
	SendMessageClient(Text);
}

void SendRequestParty(WORD index) {
	PMSG_PARTY_REQUEST_SEND pMsg;

	pMsg.header.setE(0x40, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(index);

	pMsg.index[1] = SET_NUMBERLB(index);

	DataSend((BYTE*)&pMsg, pMsg.header.size);

	char Text[100];
	lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), ((int(*)(int))0x57D9A0)(index));
	sprintf_s(Text, pGetTextLine(pTextLineThis, 476), lpObj->Name);
	SendMessageClient(Text);
}

void SendRequestGuild(WORD index) {
	//GuildPlayerKey = index;

	PMSG_GUILD_REQUEST_SEND pMsg;

	pMsg.header.set(0x50, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(index);

	pMsg.index[1] = SET_NUMBERLB(index);

	DataSend((BYTE*)&pMsg, pMsg.header.size);

	char Text[100];
	lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), ((int(*)(int))0x57D9A0)(index));
	sprintf_s(Text, pGetTextLine(pTextLineThis, 477), lpObj->Name);
	SendMessageClient(Text);
}

void SendRequestOpenPersonalShop(WORD index, char* name) {
	PMSG_PSHOP_ITEM_LIST_SEND pMsg;

	pMsg.header.setE(0x3F, 0x05, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(index);
	pMsg.index[1] = SET_NUMBERLB(index);

	std::memcpy(pMsg.name, name, sizeof(pMsg.name));

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void DataSend(BYTE* lpMsg,DWORD size) // OK
{
	BYTE EncBuff[2048];

	if(gPacketManager.AddData(lpMsg,size) != 0 && gPacketManager.ExtractPacket(EncBuff) != 0)
	{
		BYTE send[2048];

		memcpy(send,EncBuff,size);

		if(EncBuff[0] == 0xC3 || EncBuff[0] == 0xC4)
		{
			if(EncBuff[0] == 0xC3)
			{
				BYTE save = EncBuff[1];

				EncBuff[1] = (*(BYTE*)(MAIN_PACKET_SERIAL))++;

				size = gPacketManager.Encrypt(&send[2],&EncBuff[1],(size-1))+2;

				EncBuff[1] = save;

				send[0] = 0xC3;
				send[1] = LOBYTE(size);
			}
			else
			{
				BYTE save = EncBuff[2];

				EncBuff[2] = (*(BYTE*)(MAIN_PACKET_SERIAL))++;

				size = gPacketManager.Encrypt(&send[3],&EncBuff[2],(size-2))+3;

				EncBuff[2] = save;

				send[0] = 0xC4;
				send[1] = HIBYTE(size);
				send[2] = LOBYTE(size);
			}
		}

		((void(__thiscall*)(void*,BYTE*,DWORD))0x00405110)((void*)0x08793750,send,size);
	}
}

void AutoPotionType(int HP, int MP, int AG, int SD)
{
	PMSG_POTION_SEND pMsg;
	pMsg.h.set(0xF3, 0xF5, sizeof(pMsg));
	pMsg.HP = HP;
	pMsg.MP = MP;
	pMsg.AG = AG;
	pMsg.SD = SD;
	DataSend((LPBYTE)&pMsg, pMsg.h.size);
}
