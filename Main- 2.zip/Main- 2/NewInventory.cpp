#include "stdafx.h"
#include "NewInventory.h"
#include "Util.h"
#include "LuaStack.hpp"
#include "VisualInventory.h"
#include "ElementSlots.h"
#include "TradeX.h"
#include "Interface.h"
#include "HelperManager.h"
#include "PetMode.h"

using namespace luaaa;

CNewInventory gNewInventory;

#define NI_GetUISystem					((DWORD(__cdecl*)()) 0x00861110)
#define NI_GetExtension					((DWORD(__thiscall*)(DWORD This)) 0x00861A60)
#define NI_SetEquipmentSlotInfo			((void(__thiscall*)(DWORD This)) 0x00836510)
#define NI_ControlSetPos				((void(__thiscall*)(DWORD This, int x, int y)) 0x007DC240)
#define NI_ButtonSetPos					((void(__thiscall*)(DWORD This, int x, int y)) 0x00778FA0)
#define NI_ExtensionSetPos				((void(__thiscall*)(DWORD This, int x, int y)) 0x007D4E70)
#define NI_RenderFrame					((void(__thiscall*)(DWORD This)) 0x00836EC0)
#define NI_RenderTitleAndZen			((void(__thiscall*)(DWORD This)) 0x00837870)
#define NI_RenderSetOption				((void(__thiscall*)(DWORD This)) 0x00835160)
#define NI_RenderSocketOption			((void(__thiscall*)(DWORD This)) 0x00835290)
#define NI_RenderEquippedItem			((void(__thiscall*)(DWORD This)) 0x00837000)
#define NI_GetBitmap					((DWORD(__thiscall*)(DWORD* This, DWORD Image)) 0x0042CFE0)
#define NI_BitmapManager				((DWORD*)0x09816AA0)
#define NI_EndDrawBar					((void(__cdecl*)()) 0x00637A30)
#define NI_ConvertGold					((void(__cdecl*)(double Value, char* Text, int Mode)) 0x005C1170)
#define NI_GetGoldColor					((DWORD(__cdecl*)(DWORD Value)) 0x005C1130)
#define NI_DrawMessage					((int(__cdecl*)(LPCSTR Text, int Mode)) 0x00597630)
#define NI_GetPickedItem				((ITEM*(__thiscall*)(DWORD This)) 0x007D9430)
#define NI_GetPickedItemManager			((DWORD(__cdecl*)()) 0x007DD0F0)
#define NI_ExpandOpenState				((void(__thiscall*)(DWORD This)) 0x0083C160)
#define NI_ExpandCloseState				((void(__thiscall*)(DWORD This)) 0x0083C1C0)
#define NI_GetPageCount					((int(__thiscall*)(DWORD This)) 0x0083CBE0)
#define NI_INVENTORY_EXPAND_STATE		0x3D4
#define NI_INVENTORY_CURRENT_PAGE		0x3D8
#define NI_EXTENSION_POS_X				0x14
#define NI_EXTENSION_POS_Y				0x18
#define NI_EXTENSION_PAGE_POINT			0x1C
#define NI_GetTextDC					((HDC(__thiscall*)(LPVOID This)) 0x0041FF80)

#define NI_SetCamera					((void(__cdecl*)(float* Target, float* Offset, float* Angle)) 0x004D66C0)
#define NI_BeginOpengl					((void(__cdecl*)(int x, int y, int Width, int Height)) 0x00636480)
#define NI_EndOpengl					((void(__cdecl*)()) 0x006366F0)
#define NI_BeginBitmap					((void(__cdecl*)()) 0x00637770)
#define NI_EndBitmap					((void(__cdecl*)()) 0x00637870)
#define NI_Viewport						((void(__cdecl*)(int x, int y, int Width, int Height)) 0x006363D0)
#define NI_RenderCharacter				((void(__cdecl*)(ObjectPreview* Character, ObjectModel* Object, int Select)) 0x0056F210)
#define NI_SetPlayerStop				((void(__cdecl*)(ObjectPreview* Character)) 0x0054EA80)

#define NI_CameraMatrix					0x087933A0
#define NI_CameraAngle					0x087933D0
#define NI_CameraPosition				0x087933DC
#define NI_ViewportInfo					0x087933E8
#define NI_CameraTopView				0x087933F8
#define NI_CameraFog					0x087933F9
#define NI_PerspectiveInfo				0x08793264
#define NI_CameraFov					0x00E61E40
#define NI_CharacterAttribute			(*(DWORD*)0x08128AC4)
#define NI_Money						(*(DWORD*)(NI_CharacterAttribute + 0x1744))

#define NI_INVENTORY_POS_X				0x24
#define NI_INVENTORY_POS_Y				0x28
#define NI_INVENTORY_CONTROL			0x18
#define NI_INVENTORY_SLOTS				0x2C
#define NI_INVENTORY_SLOT_SIZE			20
#define NI_EQUIPMENT_ITEMS				4672
#define NI_ITEM_SIZE					107
#define NI_FRAME_IMAGE					51533
#define NI_HEADER_HEIGHT				30

static const int NewInventoryButtonOffset[4] = { 0x1CC, 0x120, 0x278, 0x324 };
static const int NI_ROW_BUTTON_W = 36;
static const int NI_ROW_BUTTON_H = 29;
static const int NI_ROW_STRIDE = 37;
static const int NI_ROW_ORIGIN = 2;
static const int NI_ROW_CLEAR = 4;

// Row icons first (in row order), then the personal shop window icons. Generated from Tools\InventoryIcons; ".tga" is read from the ".ozt" next to it.
static const int NI_ICON_FIRST = 71100;
static const int NI_ICON_COUNT = 7;
static const int NI_ICON_SIZE = 20;
static const int NI_ICON_SHOP_OPEN = 5;
static const int NI_ICON_SHOP_CLOSE = 6;
static const char* NI_IconFile[NI_ICON_COUNT] =
{
	"Custom\\NewInventory\\Close.tga",
	"Custom\\NewInventory\\Repair.tga",
	"Custom\\NewInventory\\Shop.tga",
	"Custom\\NewInventory\\Expand.tga",
	"Custom\\NewInventory\\Trash.tga",
	"Custom\\NewInventory\\ShopOpen.tga",
	"Custom\\NewInventory\\ShopClose.tga",
};

// Personal shop window (CNewUIMyShopInventory): buttons array at +0x28 (exit, open, close), shop open flag at +0x24.
static const DWORD NI_MYSHOP_BUTTONS = 0x28;
static const DWORD NI_MYSHOP_OPEN = 0x24;
static const int NI_MYSHOP_BUTTON_SIZE = 0xAC;
static const int NewInventoryWidthPatch[3] = { 0x00834CB1, 0x00834E84, 0x0083826F };

static const int NI_EXPAND_SLOT_COUNT = 4;
static const int NI_EXPAND_SLOT_COLS = 8;
static const int NI_EXPAND_SLOT_ROWS = 4;
static const int NI_EXPAND_CELL = 20;
static const int NI_EXPAND_SLOT_X = 0x0E;
static const int NI_EXPAND_SLOT_Y = 0x2C;
// The native table art is 173x87 drawn at (-4,-3). One table per step keeps a frame around each grid.
static const int NI_EXPAND_SLOT_STEP = 87;
static const DWORD NI_EXPAND_TABLE_IMAGE = 0x7C05;
static const float NI_EXPAND_TABLE_WIDTH = 173.0f;
static const float NI_EXPAND_TABLE_HEIGHT = 87.0f;

static bool NI_ExpansionSlotRect(DWORD extension, int index, int* x, int* y)
{
	if (extension == 0 || index < 0 || index >= NI_EXPAND_SLOT_COUNT || x == nullptr || y == nullptr)
	{
		return false;
	}

	*x = *(int*)(extension + NI_EXTENSION_POS_X) + NI_EXPAND_SLOT_X;
	*y = *(int*)(extension + NI_EXTENSION_POS_Y) + NI_EXPAND_SLOT_Y + (index * NI_EXPAND_SLOT_STEP);
	return true;
}

static bool NI_ExpansionSlotOwned(DWORD extension, int index)
{
	if (extension == 0 || index < 0 || index >= NI_EXPAND_SLOT_COUNT)
	{
		return false;
	}

	if (*(BYTE*)(extension + 0x10 + index) != 0)
	{
		return true;
	}

	DWORD inventory = (DWORD)pInventoryThis(pWindowThis());

	if (inventory == 0)
	{
		return false;
	}

	// Page 0 is the main bag. Page 1 is the first bought slot.
	return NI_GetPageCount(inventory) > (index + 1);
}

// The shop copies a product list here. The list pointer is null until the catalog is loaded.
static void __fastcall NI_CashShopBindList(DWORD list, DWORD)
{
	if (list == 0)
	{
		return;
	}

	((void(__thiscall*)(DWORD))0x009B3260)(list);
}

// 0x941060 walks the product list. Both calls crash when the catalog was never loaded.
static void __declspec(naked) NI_CashShopAtEnd()
{
	static DWORD function = 0x009B5240;

	_asm
	{
		test ecx, ecx
		jz at_end
		jmp[function]
	at_end:
		xor al, al
		ret 4
	}
}

static void __declspec(naked) NI_CashShopFind()
{
	static DWORD function = 0x009B4E00;

	_asm
	{
		test ecx, ecx
		jz not_found
		jmp[function]
	not_found:
		xor al, al
		ret 8
	}
}

// Pages 3 and 4 cannot live in the inventory object: index 3 is the window X and index 4 is the window Y.
static DWORD g_NIExtraControl[2] = { 0, 0 };
static DWORD g_NIExtraOwner = 0;

static int NI_PageForRelativeSlot(DWORD inventory, int slot)
{
	if (inventory == 0 || slot >= 192)
	{
		return -1;
	}

	int page = ((int(__thiscall*)(DWORD, int))0x0083C3C0)(inventory, slot);

	if (slot >= 160)
	{
		return 4;
	}

	return page;
}

static DWORD NI_ControlForPage(DWORD inventory, int page)
{
	if (inventory == 0 || page < 0)
	{
		return 0;
	}

	if (page <= 2)
	{
		return *(DWORD*)(inventory + NI_INVENTORY_CONTROL + (page * 4));
	}

	if (page == 3 || page == 4)
	{
		return g_NIExtraControl[page - 3];
	}

	return 0;
}

static void NI_ReleaseExtraControls()
{
	for (int index = 0; index < 2; index++)
	{
		DWORD control = g_NIExtraControl[index];
		g_NIExtraControl[index] = 0;

		if (control == 0 || *(DWORD*)control == 0)
		{
			continue;
		}

		((void(__thiscall*)(DWORD, int))(*(DWORD*)(*(DWORD*)control + 8)))(control, 1);
	}

	g_NIExtraOwner = 0;
}

static void NI_ShowExtraControl(DWORD control, bool show)
{
	if (control == 0)
	{
		return;
	}

	if (show)
	{
		((void(__thiscall*)(DWORD))0x007DC430)(control);
		((void(__thiscall*)(DWORD))0x007DC3B0)(control);
		return;
	}

	((void(__thiscall*)(DWORD))0x007DC410)(control);
	((void(__thiscall*)(DWORD))0x007DC3D0)(control);
}

static void NI_EnsureExtraControls(DWORD inventory)
{
	if (inventory == 0)
	{
		return;
	}

	if (g_NIExtraOwner == inventory && g_NIExtraControl[0] != 0 && g_NIExtraControl[1] != 0)
	{
		return;
	}

	if (g_NIExtraOwner != inventory)
	{
		NI_ReleaseExtraControls();
	}

	g_NIExtraOwner = inventory;

	DWORD ui = ((DWORD(__thiscall*)(DWORD))0x00861240)(NI_GetUISystem());
	int owner = *(int*)(inventory + 0x14);

	for (int index = 0; index < 2; index++)
	{
		if (g_NIExtraControl[index] != 0)
		{
			continue;
		}

		DWORD memory = ((DWORD(__cdecl*)(unsigned int))0x009D00C5)(0x74);

		if (memory == 0)
		{
			continue;
		}

		DWORD control = ((DWORD(__thiscall*)(DWORD))0x007D9740)(memory);

		if (control == 0)
		{
			continue;
		}

		bool ready = ((bool(__thiscall*)(DWORD, int, DWORD, DWORD, int, int, int, int))0x007D9ED0)(control, owner, ui, inventory, 0, 0, 8, 4);

		if (!ready)
		{
			((void(__thiscall*)(DWORD, int))(*(DWORD*)(*(DWORD*)control + 8)))(control, 1);
			continue;
		}

		g_NIExtraControl[index] = control;
		NI_ShowExtraControl(control, false);
		((void(__thiscall*)(DWORD, int))0x007DC830)(control, *(int*)(inventory + 0x3FC));
	}
}

static DWORD __fastcall NI_GetCtrlHook(DWORD inventory, DWORD, int index)
{
	return NI_ControlForPage(inventory, index);
}

static int __fastcall NI_FindPageHook(DWORD inventory, DWORD, DWORD control)
{
	if (inventory == 0 || control == 0)
	{
		return -1;
	}

	int pages = NI_GetPageCount(inventory);

	for (int page = 0; page < pages && page <= 2; page++)
	{
		if (*(DWORD*)(inventory + NI_INVENTORY_CONTROL + (page * 4)) == control)
		{
			return page;
		}
	}

	for (int index = 0; index < 2; index++)
	{
		if (g_NIExtraControl[index] != 0 && g_NIExtraControl[index] == control)
		{
			return index + 3;
		}
	}

	return -1;
}

static int __fastcall NI_FindEmptyHook(DWORD inventory, DWORD, int width, int height)
{
	if (inventory == 0)
	{
		return -1;
	}

	int pages = NI_GetPageCount(inventory);

	for (int page = 0; page < pages && page <= 2; page++)
	{
		DWORD control = *(DWORD*)(inventory + NI_INVENTORY_CONTROL + (page * 4));

		if (control == 0)
		{
			continue;
		}

		int local = ((int(__thiscall*)(DWORD, int, int))0x007DACA0)(control, width, height);

		if (local != -1)
		{
			return ((int(__thiscall*)(DWORD, int, int))0x0083C480)(inventory, local, page);
		}
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	for (int page = 3; page <= 4; page++)
	{
		if (!NI_ExpansionSlotOwned(extension, page - 1))
		{
			continue;
		}

		DWORD control = g_NIExtraControl[page - 3];

		if (control == 0)
		{
			continue;
		}

		int local = ((int(__thiscall*)(DWORD, int, int))0x007DACA0)(control, width, height);

		if (local != -1)
		{
			return ((int(__thiscall*)(DWORD, int, int))0x0083C480)(inventory, local, page);
		}
	}

	return -1;
}

static bool __fastcall NI_InsertItemHook(DWORD inventory, DWORD, int slot, BYTE* item)
{
	int page = NI_PageForRelativeSlot(inventory, slot);

	if (page >= 3)
	{
		NI_EnsureExtraControls(inventory);
	}

	DWORD control = NI_ControlForPage(inventory, page);

	if (page < 0 || control == 0)
	{
		return false;
	}

	if (page <= 2 && ((bool(__thiscall*)(DWORD, int))0x0083CA50)(inventory, page) == 0)
	{
		return false;
	}

	int local = ((int(__thiscall*)(DWORD, int, int))0x0083C4B0)(inventory, slot, 0x40);

	return ((bool(__thiscall*)(DWORD, int, BYTE*))0x007DA060)(control, local, item);
}

static DWORD __fastcall NI_FindItemHook(DWORD inventory, DWORD, int slot, int pageArg)
{
	int page = (pageArg != 0) ? pageArg : NI_PageForRelativeSlot(inventory, slot);

	if (page >= 3)
	{
		NI_EnsureExtraControls(inventory);
	}

	DWORD control = NI_ControlForPage(inventory, page);

	if (page < 0 || control == 0)
	{
		return 0;
	}

	if (page <= 2 && ((bool(__thiscall*)(DWORD, int))0x0083CA50)(inventory, page) == 0)
	{
		return 0;
	}

	int local = ((int(__thiscall*)(DWORD, int, int))0x0083C4B0)(inventory, slot, 0x40);

	return ((DWORD(__thiscall*)(DWORD, int))0x007DA760)(control, local);
}

static void __fastcall NI_DeleteItemHook(DWORD inventory, DWORD, int slot)
{
	int page = NI_PageForRelativeSlot(inventory, slot);

	if (page >= 3)
	{
		NI_EnsureExtraControls(inventory);
	}

	DWORD control = NI_ControlForPage(inventory, page);

	if (page < 0 || control == 0)
	{
		return;
	}

	int local = ((int(__thiscall*)(DWORD, int, int))0x0083C4B0)(inventory, slot, 0x40);
	DWORD item = ((DWORD(__thiscall*)(DWORD, int))0x007DA760)(control, local);

	if (item != 0)
	{
		((void(__thiscall*)(DWORD, DWORD))0x007DA480)(control, item);
		return;
	}

	DWORD manager = NI_GetPickedItemManager();

	if (manager == 0 || ((DWORD(__thiscall*)(DWORD))0x007D9410)(manager) != control)
	{
		return;
	}

	if (((int(__thiscall*)(DWORD))0x007D94E0)(manager) != slot)
	{
		return;
	}

	((void(__cdecl*)())0x007DD1B0)();
}

// Runs inside the native inventory destructor, while the owner that holds the grid registrations is still alive.
static void __fastcall NI_InventoryReleaseHook(DWORD inventory, DWORD)
{
	if (inventory != 0 && inventory == g_NIExtraOwner)
	{
		NI_ReleaseExtraControls();
	}

	((void(__thiscall*)(DWORD))0x00833C70)(inventory);
}

static bool NI_ExtraGridsActive(DWORD inventory)
{
	if (inventory == 0 || inventory != g_NIExtraOwner)
	{
		return false;
	}

	if (CheckWindowOpen(ObjWindow::ExpandInventory) == 0)
	{
		return false;
	}

	return *(int*)(inventory + NI_INVENTORY_EXPAND_STATE) == 1;
}

// Drop target lookup. Stores the page under the cursor in +0x3D8 for the drop handler.
static int __fastcall NI_GetTargetIndexHook(DWORD inventory, DWORD, DWORD picked)
{
	if (inventory == 0 || picked == 0)
	{
		return -1;
	}

	int pages = NI_GetPageCount(inventory);

	for (int page = 0; page < pages && page <= 2; page++)
	{
		DWORD control = *(DWORD*)(inventory + NI_INVENTORY_CONTROL + (page * 4));

		if (control == 0)
		{
			continue;
		}

		int local = ((int(__thiscall*)(DWORD, DWORD))0x007D95E0)(picked, control);

		if (local != -1)
		{
			*(int*)(inventory + NI_INVENTORY_CURRENT_PAGE) = page;
			return local;
		}
	}

	if (!NI_ExtraGridsActive(inventory))
	{
		return -1;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	for (int page = 3; page <= 4; page++)
	{
		DWORD control = g_NIExtraControl[page - 3];

		if (control == 0 || !NI_ExpansionSlotOwned(extension, page - 1))
		{
			continue;
		}

		int local = ((int(__thiscall*)(DWORD, DWORD))0x007D95E0)(picked, control);

		if (local != -1)
		{
			*(int*)(inventory + NI_INVENTORY_CURRENT_PAGE) = page;
			return local;
		}
	}

	return -1;
}

static DWORD __fastcall NI_CurrentPageControl(DWORD inventory)
{
	if (inventory == 0)
	{
		return 0;
	}

	return NI_ControlForPage(inventory, *(int*)(inventory + NI_INVENTORY_CURRENT_PAGE));
}

// The drop handler 0x838240 reads [inv + page*4 + 0x18] with the current page; pages 3 and 4 would read the window X/Y.
// Each stub replaces "mov ecx, [inv + page*4 + 0x18]; call target" and keeps the target's pushed arguments.
static void __declspec(naked) NI_CurrentControlFindItemAt()
{
	static DWORD function = 0x007DAB80;

	_asm
	{
		mov ecx, dword ptr[ebp - 0x9FBC]
		call NI_CurrentPageControl
		mov ecx, eax
		jmp[function]
	}
}

static void __declspec(naked) NI_CurrentControlCanStack()
{
	static DWORD function = 0x007DD5E0;

	_asm
	{
		mov ecx, dword ptr[ebp - 0x9FBC]
		call NI_CurrentPageControl
		mov ecx, eax
		jmp[function]
	}
}

static void __declspec(naked) NI_CurrentControlCanMove()
{
	static DWORD function = 0x007DC670;

	_asm
	{
		mov ecx, dword ptr[ebp - 0x9FBC]
		call NI_CurrentPageControl
		mov ecx, eax
		jmp[function]
	}
}

static void NI_PatchCurrentControlSite(DWORD address, void* stub)
{
	SetCompleteHook(0xE8, address, stub);
	MemorySet(address + 5, 0x90, 4);
}

// Grids seen by the native page loops plus pages 3 and 4. Mouse-driven callers only get the extras while the expansion window shows them.
static int NI_CollectPages(DWORD inventory, bool interactive, DWORD* controls, int* pages)
{
	int count = 0;

	if (inventory == 0)
	{
		return 0;
	}

	int native = NI_GetPageCount(inventory);

	for (int page = 0; page < native && page <= 2; page++)
	{
		DWORD control = *(DWORD*)(inventory + NI_INVENTORY_CONTROL + (page * 4));

		if (control != 0)
		{
			controls[count] = control;
			pages[count] = page;
			count++;
		}
	}

	if (inventory != g_NIExtraOwner || (interactive && !NI_ExtraGridsActive(inventory)))
	{
		return count;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	for (int page = 3; page <= 4; page++)
	{
		DWORD control = g_NIExtraControl[page - 3];

		if (control == 0 || (interactive && !NI_ExpansionSlotOwned(extension, page - 1)))
		{
			continue;
		}

		controls[count] = control;
		pages[count] = page;
		count++;
	}

	return count;
}

static bool __fastcall NI_ExtraControlsUpdate(DWORD inventory)
{
	if (!NI_ExtraGridsActive(inventory))
	{
		return true;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	for (int page = 3; page <= 4; page++)
	{
		DWORD control = g_NIExtraControl[page - 3];

		if (control != 0 && NI_ExpansionSlotOwned(extension, page - 1) && !((bool(__thiscall*)(DWORD))0x007DB160)(control))
		{
			return false;
		}
	}

	return true;
}

static bool __fastcall NI_ExtraControlsMouse(DWORD inventory)
{
	if (!NI_ExtraGridsActive(inventory))
	{
		return true;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	for (int page = 3; page <= 4; page++)
	{
		DWORD control = g_NIExtraControl[page - 3];

		if (control != 0 && NI_ExpansionSlotOwned(extension, page - 1) && !((bool(__thiscall*)(DWORD))0x007DAF50)(control))
		{
			return false;
		}
	}

	return true;
}

// 0x834FD0 runs the page grids' hover tracking; pages 3 and 4 run right after the native loop.
static void __declspec(naked) NI_InventoryUpdateExtra()
{
	static DWORD resume = 0x00835029;
	static DWORD stop = 0x0083501B;

	_asm
	{
		mov ecx, dword ptr[ebp - 0x0C]
		call NI_ExtraControlsUpdate
		test al, al
		jz consumed
		mov eax, dword ptr[ebp - 0x0C]
		mov edx, dword ptr[eax]
		jmp[resume]
	consumed:
		jmp[stop]
	}
}

// 0x834600 lets each page grid pick up the clicked item; a grid that consumes the click ends the handler.
static void __declspec(naked) NI_InventoryMouseExtra()
{
	static DWORD function = 0x00837A30;
	static DWORD resume = 0x00834687;
	static DWORD stop = 0x00834673;

	_asm
	{
		mov ecx, dword ptr[ebp - 0x10E8]
		call NI_ExtraControlsMouse
		test al, al
		jz consumed
		mov ecx, dword ptr[ebp - 0x10E8]
		call[function]
		jmp[resume]
	consumed:
		jmp[stop]
	}
}

static void __fastcall NI_SetLockHook(DWORD inventory, DWORD, BYTE lock)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);

	*(int*)(inventory + 0x3FC) = (lock != 0) ? 1 : 0;

	for (int i = 0; i < count; i++)
	{
		((void(__thiscall*)(DWORD, int))0x007DC830)(controls[i], lock);
	}
}

static int __fastcall NI_CountTypeHook(DWORD inventory, DWORD, int type)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);
	int total = 0;

	for (int i = 0; i < count; i++)
	{
		total += ((int(__thiscall*)(DWORD, int))0x007DADB0)(controls[i], type);
	}

	return total;
}

static int __fastcall NI_CountIndexHook(DWORD inventory, DWORD, int type)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);
	int total = 0;

	for (int i = 0; i < count; i++)
	{
		total += ((int(__thiscall*)(DWORD, int))0x007DAE40)(controls[i], (WORD)type);
	}

	return total;
}

static int __fastcall NI_CountLevelHook(DWORD inventory, DWORD, int type, int level)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);
	int total = 0;

	for (int i = 0; i < count; i++)
	{
		total += ((int(__thiscall*)(DWORD, int, int))0x007DA940)(controls[i], (WORD)type, level);
	}

	return total;
}

static int __fastcall NI_ItemCountHook(DWORD inventory, DWORD)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);
	int total = 0;

	for (int i = 0; i < count; i++)
	{
		total += ((int(__thiscall*)(DWORD))0x007DA640)(controls[i]);
	}

	return total;
}

static DWORD __fastcall NI_ItemByOrderHook(DWORD inventory, DWORD, int order)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);

	for (int i = 0; i < count && order >= 0; i++)
	{
		int items = ((int(__thiscall*)(DWORD))0x007DA640)(controls[i]);

		if (order < items)
		{
			return ((DWORD(__thiscall*)(DWORD, int))0x007DA660)(controls[i], order);
		}

		order -= items;
	}

	return 0;
}

static DWORD __fastcall NI_FindTypeHook(DWORD inventory, DWORD, int type)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, false, controls, pages);

	for (int i = 0; i < count; i++)
	{
		DWORD item = ((DWORD(__thiscall*)(DWORD, int))0x007DA850)(controls[i], (WORD)type);

		if (item != 0)
		{
			return item;
		}
	}

	return 0;
}

static DWORD __fastcall NI_ItemAtPointHook(DWORD inventory, DWORD, int x, int y, int* page)
{
	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, true, controls, pages);

	for (int i = 0; i < count; i++)
	{
		DWORD item = ((DWORD(__thiscall*)(DWORD, int, int))0x007DAC10)(controls[i], x, y);

		if (item != 0)
		{
			if (page != nullptr)
			{
				*page = pages[i];
			}

			return item;
		}
	}

	if (page != nullptr)
	{
		*page = count;
	}

	return 0;
}

static BYTE __fastcall NI_PointedDurabilityHook(DWORD inventory, DWORD)
{
	int equipped = *(int*)(inventory + 0x11C);

	if (equipped != -1)
	{
		return *(BYTE*)(NI_CharacterAttribute + 0x1240 + (equipped * NI_ITEM_SIZE) + 0x16);
	}

	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, true, controls, pages);

	for (int i = 0; i < count; i++)
	{
		DWORD item = ((DWORD(__thiscall*)(DWORD))0x007DABB0)(controls[i]);

		if (item != 0)
		{
			return *(BYTE*)(item + 0x16);
		}
	}

	return 0;
}

static int __fastcall NI_PointedSlotHook(DWORD inventory, DWORD)
{
	int equipped = *(int*)(inventory + 0x11C);

	if (equipped != -1)
	{
		return equipped;
	}

	DWORD controls[5];
	int pages[5];
	int count = NI_CollectPages(inventory, true, controls, pages);

	for (int i = 0; i < count; i++)
	{
		int local = ((int(__thiscall*)(DWORD))0x007DABF0)(controls[i]);

		if (local != -1)
		{
			return ((int(__thiscall*)(DWORD, int, int))0x0083C480)(inventory, local, pages[i]) + 12;
		}
	}

	return -1;
}

// The grids are registered with the inventory owner, which already feeds them mouse events while they are shown.
static void NI_HideExtraGridsWhenClosed()
{
	if (CheckWindowOpen(ObjWindow::ExpandInventory) != 0)
	{
		return;
	}

	NI_ShowExtraControl(g_NIExtraControl[0], false);
	NI_ShowExtraControl(g_NIExtraControl[1], false);
}

// The first two pages keep the native anchors. Pages 3 and 4 are stored by the DLL.
static void NI_RestoreExpandedGrids(DWORD inventory)
{
	if (inventory == 0)
	{
		return;
	}

	NI_EnsureExtraControls(inventory);

	if (*(int*)(inventory + NI_INVENTORY_EXPAND_STATE) != 1)
	{
		NI_ShowExtraControl(g_NIExtraControl[0], false);
		NI_ShowExtraControl(g_NIExtraControl[1], false);
		return;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (extension != 0)
	{
		int pages = NI_GetPageCount(inventory);

		for (int index = 0; index < NI_EXPAND_SLOT_COUNT; index++)
		{
			int gridX = 0;
			int gridY = 0;

			if (!NI_ExpansionSlotRect(extension, index, &gridX, &gridY))
			{
				continue;
			}

			int page = index + 1;

			if (index < 2)
			{
				*(int*)(extension + NI_EXTENSION_PAGE_POINT + (index * 8)) = gridX;
				*(int*)(extension + NI_EXTENSION_PAGE_POINT + (index * 8) + 4) = gridY;
			}

			DWORD control = NI_ControlForPage(inventory, page);

			if (control == 0)
			{
				continue;
			}

			if (page <= 2 && page >= pages)
			{
				continue;
			}

			NI_ControlSetPos(control, gridX, gridY);

			if (page >= 3)
			{
				NI_ShowExtraControl(control, NI_ExpansionSlotOwned(extension, index));
			}
		}
	}

	NI_ExpandOpenState(inventory);
}

static void __fastcall NI_RenderExpansionSlotsHook(DWORD extension, DWORD)
{
	gNewInventory.RenderExpansionSlots(extension);
}

// A click on the wide window still falls inside the client's ground-drop zone, which assumes a 190-wide inventory glued to the right edge.
static bool NI_CursorBlocksGroundDrop()
{
	if (!gNewInventory.IsSkinned() || CheckWindowOpen(ObjWindow::Inventory) == 0)
	{
		return false;
	}

	if (CheckMouseIn(gNewInventory.GetPosX(), gNewInventory.GetPosY(), gNewInventory.GetWidth(), 429))
	{
		return true;
	}

	if (CheckWindowOpen(ObjWindow::ExpandInventory) == 0)
	{
		return false;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (extension == 0)
	{
		return false;
	}

	return CheckMouseIn(*(int*)(extension + NI_EXTENSION_POS_X), *(int*)(extension + NI_EXTENSION_POS_Y), NEW_INVENTORY_CLASSIC_WIDTH, 429);
}

static bool __cdecl NI_GroundDropZone(int x, int y, int width, int height)
{
	if (NI_CursorBlocksGroundDrop())
	{
		return false;
	}

	return CheckMouseIn(x, y, width, height);
}

struct NEW_INVENTORY_PAIRED
{
	int Window;
	int InstanceOffset;
	DWORD MoveFunc;
	int PosOffset;
	int ControlOffset[2];
	bool ExtensionArg;
	int DefaultEnabled;
};

static const NEW_INVENTORY_PAIRED NewInventoryPaired[] =
{
	{ ObjWindow::Shop,			44,		0x00846B90,	0x14,	{ 16, -1 },		false,	1 },
	{ ObjWindow::Warehouse,		72,		0x00857200,	0x10,	{ 540, -1 },	false,	1 },
	{ ObjWindow::Trade,			124,	0x00863F10,	0x10,	{ 380, 376 },	false,	1 },
	{ ObjWindow::Store,			84,		0x00840D80,	0x14,	{ 16, -1 },		true,	1 },
	{ ObjWindow::OtherStore,	88,		0x0084FA90,	0x14,	{ 16, -1 },		false,	1 },
	{ 76,						296,	0x007F0460,	0x378,	{ 16, -1 },		false,	1 },
	{ ObjWindow::ChaosBox,		52,		0x0082C340,	0x14,	{ 16, -1 },		false,	0 },
};

#define NI_PAIRED_COUNT (sizeof(NewInventoryPaired) / sizeof(NewInventoryPaired[0]))

static const int NewInventoryDefaultClassic[] =
{
	3, 4, 5, 6, 10, 11, 18, 19, 20, 21, 22, 23, 24, 25, 26, 57, 58, 59,
	60, 61, 62, 63, 66, 68, 69, 70, 73, 74, 75, 78, 79, 80,
};

// ---------------------------------------------------------------------------
// Hooks

static void __fastcall InventorySetPosHook(DWORD This, DWORD edx, int x, int y)
{
	gNewInventory.SetPos(This, x, y);
}

static void NI_EnsureExtraControls(DWORD inventory);

static void __fastcall InventoryCreateSlotsHook(DWORD This, DWORD edx)
{
	NI_SetEquipmentSlotInfo(This);

	gNewInventory.ApplyEquipmentSlots(This);
	NI_EnsureExtraControls(This);
}

static void __fastcall InventoryRenderFrameHook(DWORD This, DWORD edx)
{
	gNewInventory.RenderFrame(This);
}

static void __fastcall InventoryRenderTitleHook(DWORD This, DWORD edx)
{
	gNewInventory.RenderTitleAndCoins(This);
}

static void __fastcall InventoryRenderSetOptionHook(DWORD This, DWORD edx)
{
	int offsetX = gNewInventory.GetOptionOffsetX();
	int offsetY = gNewInventory.GetOptionOffsetY();

	*(int*)(This + NI_INVENTORY_POS_X) += offsetX;
	*(int*)(This + NI_INVENTORY_POS_Y) += offsetY;

	NI_RenderSetOption(This);

	*(int*)(This + NI_INVENTORY_POS_X) -= offsetX;
	*(int*)(This + NI_INVENTORY_POS_Y) -= offsetY;
}

static void __fastcall InventoryRenderSocketOptionHook(DWORD This, DWORD edx)
{
	int offsetX = gNewInventory.GetOptionOffsetX();
	int offsetY = gNewInventory.GetOptionOffsetY();

	*(int*)(This + NI_INVENTORY_POS_X) += offsetX;
	*(int*)(This + NI_INVENTORY_POS_Y) += offsetY;

	NI_RenderSocketOption(This);

	*(int*)(This + NI_INVENTORY_POS_X) -= offsetX;
	*(int*)(This + NI_INVENTORY_POS_Y) -= offsetY;
}

// The skinned row draws its own icons in the inventory pass; the native buttons stay as invisible hit areas.
static void __fastcall InventoryRenderButtonsHook(DWORD This, DWORD edx)
{
	if (!gNewInventory.IsSkinned())
	{
		((void(__thiscall*)(DWORD))0x00837730)(This);
		return;
	}

	gNewInventory.RenderRowButtons(This);
}

static void __fastcall MyShopRenderButtonHook(DWORD button, DWORD edx, bool translate)
{
	if (!gNewInventory.RenderShopButton(button))
	{
		((void(__thiscall*)(DWORD, bool))0x007798F0)(button, translate);
	}
}

static void __fastcall InventoryRenderEquippedItemHook(DWORD This, DWORD edx)
{
	NI_RenderEquippedItem(This);

	gNewInventory.RenderEquipmentOverlay(This);
}

// ---------------------------------------------------------------------------
// Lua

static void LuaConfigSetEnabled(int enabled) { gNewInventory.m_Enabled = enabled; }
static void LuaConfigSetStyle(int style) { gNewInventory.m_Style = style; }
static void LuaConfigSetExtensionSide(int right) { gNewInventory.m_ExtensionRight = right; }
static void LuaConfigSetCloseButton(int enabled) { gNewInventory.m_CloseButton = enabled; }

static void LuaConfigSetWindowOptions(int allowMove, int allowResize, int compactSkin, int defaultSize)
{
	gNewInventory.m_AllowMove = allowMove;
	gNewInventory.m_AllowResize = allowResize;
	gNewInventory.m_CompactSkin = compactSkin;
	gNewInventory.m_SizeMode = (defaultSize == NEW_INVENTORY_SIZE_COMPACT) ? NEW_INVENTORY_SIZE_COMPACT : NEW_INVENTORY_SIZE_LARGE;
}

static void LuaConfigSetAccentColor(int r, int g, int b)
{
	gNewInventory.m_Accent[0] = (float)r / 255.0f;
	gNewInventory.m_Accent[1] = (float)g / 255.0f;
	gNewInventory.m_Accent[2] = (float)b / 255.0f;
}

static void LuaConfigSetPreview(int enabled, float fov, float distance, float height, float angle, float rotateSpeed)
{
	gNewInventory.m_PreviewEnabled = enabled;
	gNewInventory.m_PreviewFov = fov;
	gNewInventory.m_PreviewDistance = distance;
	gNewInventory.m_PreviewHeight = height;
	gNewInventory.m_PreviewAngle = angle;
	gNewInventory.m_PreviewRotateSpeed = rotateSpeed;
}

static void LuaConfigSetSlot(int slot, int x, int y, int width, int height) { gNewInventory.SetSlotRect(slot, x, y, width, height); }
static void LuaConfigSetElementSlot(int slot, int x, int y, int width, int height) { gNewInventory.SetElementRect(slot, x, y, width, height); }
static void LuaConfigSetSlotName(int slot, const char* name) { gNewInventory.SetSlotName(slot, name); }

static void LuaConfigSetCoin(int index, const char* label, int valueIndex, int r, int g, int b)
{
	gNewInventory.SetCoin(index, label, valueIndex, (BYTE)r, (BYTE)g, (BYTE)b);
}

template <size_t Size>
static void LuaConfigCopyLabel(char(&target)[Size], const char* text)
{
	if (text)
	{
		strncpy_s(target, text, _TRUNCATE);
	}
}

static void LuaConfigSetSectionLabels(const char* left, const char* center, const char* right)
{
	LuaConfigCopyLabel(gNewInventory.m_SectionLabel[0], left);
	LuaConfigCopyLabel(gNewInventory.m_SectionLabel[1], center);
	LuaConfigCopyLabel(gNewInventory.m_SectionLabel[2], right);
}

static void LuaConfigSetTabLabels(const char* normal, const char* visual)
{
	LuaConfigCopyLabel(gNewInventory.m_TabLabel[0], normal);
	LuaConfigCopyLabel(gNewInventory.m_TabLabel[1], visual);
}

static void LuaConfigSetPreviewLabels(const char* show, const char* hide, const char* hint)
{
	LuaConfigCopyLabel(gNewInventory.m_PreviewShowLabel, show);
	LuaConfigCopyLabel(gNewInventory.m_PreviewHideLabel, hide);
	LuaConfigCopyLabel(gNewInventory.m_PreviewHintLabel, hint);
}

static void LuaConfigSetButtonLabels(const char* shrink, const char* expand, const char* dock, const char* close)
{
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_SHRINK], shrink);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_EXPAND], expand);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_DOCK], dock);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_CLOSE], close);
}

static void LuaConfigSetColumns(int showSet, int showAccessories)
{
	gNewInventory.m_ShowSet = (showSet != 0) ? 1 : 0;
	gNewInventory.m_ShowAccessories = (showAccessories != 0) ? 1 : 0;
}

static void LuaConfigSetColumnLabels(const char* hideSet, const char* showSet, const char* hideAccessories, const char* showAccessories)
{
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_HIDE_SET], hideSet);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_SHOW_SET], showSet);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_HIDE_ACC], hideAccessories);
	LuaConfigCopyLabel(gNewInventory.m_ButtonLabel[NEW_INVENTORY_LABEL_SHOW_ACC], showAccessories);
}

static void LuaConfigClearClassicWindows() { gNewInventory.AddClassicWindow(-1); }
static void LuaConfigAddClassicWindow(int window) { gNewInventory.AddClassicWindow(window); }
static void LuaConfigSetPairedWindow(int window, int enabled) { gNewInventory.SetPairedWindow(window, enabled); }

static void LuaSetInventoryCoin(int index, double value) { gNewInventory.SetCoinValue(index, (DWORD)value); }
static double LuaGetInventoryCoin(int index) { return (double)gNewInventory.GetCoinValue(index); }
static void LuaSetExpandPrice(int slot, int coin, double value) { gNewInventory.SetExpandPrice(slot, coin, (DWORD)value); }
static void LuaFinishExpandBuy(int result, int count) { gNewInventory.FinishExpandBuy(result, count); }
static int LuaGetInventoryPosX() { return gNewInventory.GetPosX(); }
static int LuaGetInventoryPosY() { return gNewInventory.GetPosY(); }
static int LuaGetInventoryWidth() { return gNewInventory.GetWidth(); }
static int LuaGetInventoryCenterX() { return gNewInventory.GetPosX() + gNewInventory.GetCenterOffset(); }
static int LuaGetInventoryButtonX(int index) { return gNewInventory.GetButtonX(index); }
static int LuaGetInventoryButtonY() { return gNewInventory.GetButtonY(); }
static int LuaIsNewInventoryActive() { return gNewInventory.IsSkinned() ? 1 : 0; }
static int LuaIsNewInventoryWide() { return gNewInventory.IsWide() ? 1 : 0; }

// ---------------------------------------------------------------------------
// User settings (position and size chosen in game)

#define NI_REGISTRY_KEY "SOFTWARE\\Webzen\\Mu\\Config"

static int NI_ReadRegistry(const char* name, int defaultValue)
{
	HKEY key;
	int value = defaultValue;

	if (RegOpenKeyExA(HKEY_CURRENT_USER, NI_REGISTRY_KEY, 0, KEY_READ, &key) == ERROR_SUCCESS)
	{
		DWORD data = 0;
		DWORD size = sizeof(data);
		DWORD type = 0;

		if (RegQueryValueExA(key, name, 0, &type, (LPBYTE)&data, &size) == ERROR_SUCCESS && type == REG_DWORD)
		{
			value = (int)data;
		}

		RegCloseKey(key);
	}

	return value;
}

static void NI_WriteRegistry(const char* name, int value)
{
	HKEY key;

	if (RegCreateKeyExA(HKEY_CURRENT_USER, NI_REGISTRY_KEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, NULL) == ERROR_SUCCESS)
	{
		DWORD data = (DWORD)value;

		RegSetValueExA(key, name, 0, REG_DWORD, (const BYTE*)&data, sizeof(data));
		RegCloseKey(key);
	}
}

static int NI_Clamp(int value, int minValue, int maxValue)
{
	if (maxValue < minValue)
	{
		return minValue;
	}

	return (value < minValue) ? minValue : ((value > maxValue) ? maxValue : value);
}

// ---------------------------------------------------------------------------

CNewInventory::CNewInventory() : m_Lua(true)
{
	this->m_Enabled = 1;
	this->m_Style = 1;
	this->m_ExtensionRight = 1;
	this->m_CloseButton = 1;
	this->m_AllowMove = 1;
	this->m_AllowResize = 1;
	this->m_CompactSkin = 1;
	this->m_SizeMode = NEW_INVENTORY_SIZE_LARGE;
	this->m_ShowSet = 1;
	this->m_ShowAccessories = 1;
	this->m_PreviewEnabled = 1;
	this->m_PreviewVisible = 1;
	this->m_PreviewMounted = 0;
	this->m_PreviewFov = 30.0f;
	this->m_PreviewDistance = 480.0f;
	this->m_PreviewHeight = 105.0f;
	this->m_PreviewAngle = -20.0f;
	this->m_PreviewRotateSpeed = 1.5f;

	this->m_Accent[0] = 0.86f;
	this->m_Accent[1] = 0.69f;
	this->m_Accent[2] = 0.35f;

	this->m_Width = 380;
	this->m_CenterOffset = 66;
	this->m_GridY = 186;
	this->m_ButtonY = 389;
	this->m_CompactButtonY = 396;
	this->m_OptionOffsetX = 52;
	this->m_OptionOffsetY = -14;

	this->m_PreviewRect = { 76, 52, 170, 126 };

	this->m_CoinRect[0] = { 76, 351, 170, 14 };
	this->m_CoinRect[1] = { 76, 367, 84, 14 };
	this->m_CoinRect[2] = { 162, 367, 84, 14 };

	this->m_CompactCoinRect[0] = { 11, 365, 168, 13 };
	this->m_CompactCoinRect[1] = { 11, 380, 83, 13 };
	this->m_CompactCoinRect[2] = { 96, 380, 83, 13 };

	this->m_TabRect[0] = { 214, 7, 46, 16 };
	this->m_TabRect[1] = { 260, 7, 46, 16 };

	this->m_CompactTabRect[0] = { 16, 4, 44, 15 };
	this->m_CompactTabRect[1] = { 60, 4, 44, 15 };

	this->m_SlotRect[0] = { 266, 104, 46, 66 };		// weapon right
	this->m_SlotRect[1] = { 322, 104, 46, 66 };		// weapon left / shield
	this->m_SlotRect[2] = { 10, 52, 46, 46 };		// helm
	this->m_SlotRect[3] = { 10, 102, 46, 66 };		// armor
	this->m_SlotRect[4] = { 10, 172, 46, 46 };		// pants
	this->m_SlotRect[5] = { 10, 222, 46, 46 };		// gloves
	this->m_SlotRect[6] = { 10, 272, 46, 46 };		// boots
	this->m_SlotRect[7] = { 287, 52, 61, 46 };		// wings
	this->m_SlotRect[8] = { 294, 274, 46, 46 };		// helper / pet
	this->m_SlotRect[9] = { 303, 206, 28, 28 };		// pendant
	this->m_SlotRect[10] = { 283, 240, 28, 28 };	// ring right
	this->m_SlotRect[11] = { 323, 240, 28, 28 };	// ring left

	this->m_ElementRect[0] = { 269, 176, 24, 24 };
	this->m_ElementRect[1] = { 295, 176, 24, 24 };
	this->m_ElementRect[2] = { 321, 176, 24, 24 };
	this->m_ElementRect[3] = { 347, 176, 24, 24 };

	static const char* slotNames[NEW_INVENTORY_MAX_SLOT_NAMES] =
	{
		"Arma", "Escudo", "Elmo", "Armadura", "Calca", "Luvas", "Botas", "Asa",
		"Pet", "Pendant", "Anel", "Anel", "Extra 1", "Extra 2", "Extra 3", "Extra 4",
	};

	for (int i = 0; i < NEW_INVENTORY_MAX_SLOT_NAMES; i++)
	{
		strcpy_s(this->m_SlotName[i], slotNames[i]);
	}

	this->SetCoin(0, "Zen", 0, 255, 220, 120);
	this->SetCoin(1, "Cash", 1, 120, 220, 255);
	this->SetCoin(2, "Horas", 4, 160, 255, 160);

	strcpy_s(this->m_SectionLabel[0], "SET");
	strcpy_s(this->m_SectionLabel[1], "PERSONAGEM");
	strcpy_s(this->m_SectionLabel[2], "ACESSORIOS");
	strcpy_s(this->m_TabLabel[0], "Normal");
	strcpy_s(this->m_TabLabel[1], "Visual");
	strcpy_s(this->m_PreviewShowLabel, "Exibir");
	strcpy_s(this->m_PreviewHideLabel, "Ocultar");
	strcpy_s(this->m_PreviewHintLabel, "Arraste para girar");
	strcpy_s(this->m_PreviewMountLabel, "Montaria");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_SHRINK], "Diminuir");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_EXPAND], "Aumentar");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_DOCK], "Encaixar");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_CLOSE], "Fechar");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_HIDE_SET], "Ocultar Set");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_SHOW_SET], "Exibir Set");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_HIDE_ACC], "Ocultar Acessorios");
	strcpy_s(this->m_ButtonLabel[NEW_INVENTORY_LABEL_SHOW_ACC], "Exibir Acessorios");

	this->m_Wide = false;
	this->m_AppliedShowSet = -1;
	this->m_AppliedShowAcc = -1;
	this->m_Managed = false;
	this->m_Forced = false;
	this->m_Floating = 0;
	this->m_FloatX = 260;
	this->m_FloatY = 0;
	this->m_Dragging = false;
	this->m_DragOffsetX = 0;
	this->m_DragOffsetY = 0;
	this->m_CompanionX = -1;
	this->m_TooltipPending = false;
	this->m_TooltipBelow = false;
	this->m_TooltipX = 0;
	this->m_TooltipY = 0;
	this->m_TooltipText[0] = 0;
	this->m_CloseRequested = false;
	this->m_SuppressExpandClick = false;
	this->m_PreviewDragging = false;
	this->m_PreviewLastMouseX = 0;
	this->m_PreviewHasMount = false;
	this->m_MountAction = 0xFFFF;
	this->m_MountPriorAction = 0;
	this->m_MountFrame = 0.0f;
	this->m_MountPriorFrame = 0.0f;
	this->m_MountTick = 0;
	this->m_RectsSwapped = false;
	for (int index = 0; index < NI_EXPAND_SLOT_COUNT; index++)
	{
		this->m_ExpandCoin[index] = 0;
		this->m_ExpandValue[index] = 0;
		this->m_ExpandKnown[index] = 0;
	}
	this->m_ExpandConfirm = -1;
	this->m_ExpandBuying = false;

	memset(this->m_CoinValue, 0, sizeof(this->m_CoinValue));
	memset(this->m_SavedVisualRect, 0, sizeof(this->m_SavedVisualRect));
	memset(this->m_SavedElementRect, 0, sizeof(this->m_SavedElementRect));

	this->m_ClassicWindowCount = 0;

	for (int i = 0; i < (int)(sizeof(NewInventoryDefaultClassic) / sizeof(NewInventoryDefaultClassic[0])); i++)
	{
		this->AddClassicWindow(NewInventoryDefaultClassic[i]);
	}

	for (int i = 0; i < NEW_INVENTORY_MAX_WINDOWS; i++)
	{
		this->m_PairedEnabled[i] = (i < (int)NI_PAIRED_COUNT) ? NewInventoryPaired[i].DefaultEnabled : 0;
	}
}

CNewInventory::~CNewInventory()
{
}

void CNewInventory::LoadConfig()
{
	lua_State* lua = this->m_Lua.GetState();

	LuaModule(lua).fun("NewInventorySetEnabled", &LuaConfigSetEnabled);
	LuaModule(lua).fun("NewInventorySetStyle", &LuaConfigSetStyle);
	LuaModule(lua).fun("NewInventorySetExtensionSide", &LuaConfigSetExtensionSide);
	LuaModule(lua).fun("NewInventorySetCloseButton", &LuaConfigSetCloseButton);
	LuaModule(lua).fun("NewInventorySetWindowOptions", &LuaConfigSetWindowOptions);
	LuaModule(lua).fun("NewInventorySetButtonLabels", &LuaConfigSetButtonLabels);
	LuaModule(lua).fun("NewInventorySetColumns", &LuaConfigSetColumns);
	LuaModule(lua).fun("NewInventorySetColumnLabels", &LuaConfigSetColumnLabels);
	LuaModule(lua).fun("NewInventorySetAccentColor", &LuaConfigSetAccentColor);
	LuaModule(lua).fun("NewInventorySetPreview", &LuaConfigSetPreview);
	LuaModule(lua).fun("NewInventorySetSlot", &LuaConfigSetSlot);
	LuaModule(lua).fun("NewInventorySetElementSlot", &LuaConfigSetElementSlot);
	LuaModule(lua).fun("NewInventorySetSlotName", &LuaConfigSetSlotName);
	LuaModule(lua).fun("NewInventorySetCoin", &LuaConfigSetCoin);
	LuaModule(lua).fun("NewInventorySetSectionLabels", &LuaConfigSetSectionLabels);
	LuaModule(lua).fun("NewInventorySetTabLabels", &LuaConfigSetTabLabels);
	LuaModule(lua).fun("NewInventorySetPreviewLabels", &LuaConfigSetPreviewLabels);
	LuaModule(lua).fun("NewInventoryClearClassicWindows", &LuaConfigClearClassicWindows);
	LuaModule(lua).fun("NewInventoryAddClassicWindow", &LuaConfigAddClassicWindow);
	LuaModule(lua).fun("NewInventorySetPairedWindow", &LuaConfigSetPairedWindow);

	char path[] = "Data//Files//Lua//Configs//NewInventory.lua";

	if (GetFileAttributesA(path) != INVALID_FILE_ATTRIBUTES)
	{
		this->m_Lua.DoFile(path);
	}
}

void CNewInventory::RegisterLua(lua_State* lua)
{
	LuaModule(lua).fun("SetInventoryCoin", &LuaSetInventoryCoin);
	LuaModule(lua).fun("GetInventoryCoin", &LuaGetInventoryCoin);
	LuaModule(lua).fun("SetExpandInventoryPrice", &LuaSetExpandPrice);
	LuaModule(lua).fun("FinishExpandInventoryBuy", &LuaFinishExpandBuy);
	LuaModule(lua).fun("GetInventoryPosX", &LuaGetInventoryPosX);
	LuaModule(lua).fun("GetInventoryPosY", &LuaGetInventoryPosY);
	LuaModule(lua).fun("GetInventoryWidth", &LuaGetInventoryWidth);
	LuaModule(lua).fun("GetInventoryCenterX", &LuaGetInventoryCenterX);
	LuaModule(lua).fun("GetInventoryButtonX", &LuaGetInventoryButtonX);
	LuaModule(lua).fun("GetInventoryButtonY", &LuaGetInventoryButtonY);
	LuaModule(lua).fun("IsNewInventoryActive", &LuaIsNewInventoryActive);
	LuaModule(lua).fun("IsNewInventoryWide", &LuaIsNewInventoryWide);
}

void CNewInventory::LoadUserSettings()
{
	if (this->m_AllowResize)
	{
		this->m_SizeMode = (NI_ReadRegistry("NewInventorySize", this->m_SizeMode) == NEW_INVENTORY_SIZE_COMPACT) ? NEW_INVENTORY_SIZE_COMPACT : NEW_INVENTORY_SIZE_LARGE;
	}

	if (this->m_AllowMove)
	{
		this->m_Floating = (NI_ReadRegistry("NewInventoryFloating", 0) != 0) ? 1 : 0;
		this->m_FloatX = NI_Clamp(NI_ReadRegistry("NewInventoryX", this->m_FloatX), 0, NEW_INVENTORY_SCREEN_WIDTH - NEW_INVENTORY_CLASSIC_WIDTH);
		this->m_FloatY = NI_Clamp(NI_ReadRegistry("NewInventoryY", this->m_FloatY), 0, NEW_INVENTORY_SCREEN_HEIGHT - NEW_INVENTORY_HEIGHT);
	}

	this->m_ShowSet = (NI_ReadRegistry("NewInventoryShowSet", this->m_ShowSet) != 0) ? 1 : 0;
	this->m_ShowAccessories = (NI_ReadRegistry("NewInventoryShowAcc", this->m_ShowAccessories) != 0) ? 1 : 0;
	this->m_PreviewVisible = (NI_ReadRegistry("NewInventoryPreview", this->m_PreviewVisible) != 0) ? 1 : 0;
	this->m_PreviewMounted = (NI_ReadRegistry("NewInventoryMounted", this->m_PreviewMounted) != 0) ? 1 : 0;
}

void CNewInventory::SaveUserSettings()
{
	NI_WriteRegistry("NewInventorySize", this->m_SizeMode);
	NI_WriteRegistry("NewInventoryFloating", this->m_Floating);
	NI_WriteRegistry("NewInventoryX", this->m_FloatX);
	NI_WriteRegistry("NewInventoryY", this->m_FloatY);
	NI_WriteRegistry("NewInventoryShowSet", this->m_ShowSet);
	NI_WriteRegistry("NewInventoryShowAcc", this->m_ShowAccessories);
	NI_WriteRegistry("NewInventoryPreview", this->m_PreviewVisible);
	NI_WriteRegistry("NewInventoryMounted", this->m_PreviewMounted);
}

void CNewInventory::Init()
{
	this->LoadConfig();

	if (this->m_Enabled == 0)
	{
		return;
	}

	this->LoadUserSettings();

	SetCompleteHook(0xE9, 0x00834420, &InventorySetPosHook);
	SetCompleteHook(0xE8, 0x008337B0, &InventoryCreateSlotsHook);
	SetCompleteHook(0xE8, 0x0083510E, &InventoryRenderFrameHook);
	SetCompleteHook(0xE8, 0x00835116, &InventoryRenderTitleHook);
	SetCompleteHook(0xE8, 0x0083511E, &InventoryRenderSetOptionHook);
	SetCompleteHook(0xE8, 0x00835126, &InventoryRenderSocketOptionHook);
	SetCompleteHook(0xE8, 0x0083512E, &InventoryRenderButtonsHook);
	SetCompleteHook(0xE8, 0x008424C8, &MyShopRenderButtonHook);
	SetCompleteHook(0xE8, 0x0083514C, &InventoryRenderEquippedItemHook);
	SetCompleteHook(0xE8, 0x00834700, &NI_GroundDropZone);
	SetCompleteHook(0xE8, 0x007D4FAE, &NI_RenderExpansionSlotsHook);
	SetCompleteHook(0xE8, 0x009410B2, &NI_CashShopBindList);
	SetCompleteHook(0xE8, 0x009410E3, &NI_CashShopAtEnd);
	SetCompleteHook(0xE8, 0x0093FDBF, &NI_CashShopFind);
	SetCompleteHook(0xE8, 0x0093FE57, &NI_CashShopFind);
	SetByte(0x007D531E, 4);
	SetByte(0x007D6C3F, 5);
	SetCompleteHook(0xE9, 0x00835720, &NI_GetCtrlHook);
	SetCompleteHook(0xE9, 0x0083C710, &NI_FindPageHook);
	SetCompleteHook(0xE9, 0x00835940, &NI_FindEmptyHook);
	SetCompleteHook(0xE9, 0x008342C0, &NI_InsertItemHook);
	SetCompleteHook(0xE9, 0x00835750, &NI_FindItemHook);
	SetCompleteHook(0xE9, 0x00834320, &NI_DeleteItemHook);
	SetCompleteHook(0xE8, 0x00833805, &NI_InventoryReleaseHook);
	SetCompleteHook(0xE9, 0x0083C6B0, &NI_GetTargetIndexHook);
	NI_PatchCurrentControlSite(0x008386D7, &NI_CurrentControlFindItemAt);
	NI_PatchCurrentControlSite(0x008388F7, &NI_CurrentControlCanStack);
	NI_PatchCurrentControlSite(0x00838972, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838A62, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838B66, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838C41, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838D29, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838E06, &NI_CurrentControlCanMove);
	NI_PatchCurrentControlSite(0x00838EC7, &NI_CurrentControlCanMove);
	SetCompleteHook(0xE9, 0x00835024, &NI_InventoryUpdateExtra);
	SetCompleteHook(0xE9, 0x0083467C, &NI_InventoryMouseExtra);
	MemorySet(0x00834681, 0x90, 6);
	SetCompleteHook(0xE9, 0x00834570, &NI_SetLockHook);
	SetCompleteHook(0xE9, 0x0083BE00, &NI_CountTypeHook);
	SetCompleteHook(0xE9, 0x0083BE60, &NI_CountIndexHook);
	SetCompleteHook(0xE9, 0x0083C8E0, &NI_CountLevelHook);
	SetCompleteHook(0xE9, 0x0083C940, &NI_ItemCountHook);
	SetCompleteHook(0xE9, 0x0083C990, &NI_ItemByOrderHook);
	SetCompleteHook(0xE9, 0x0083CB20, &NI_FindTypeHook);
	SetCompleteHook(0xE9, 0x0083C7B0, &NI_ItemAtPointHook);
	SetCompleteHook(0xE9, 0x0083CAB0, &NI_ItemAtPointHook);
	SetCompleteHook(0xE9, 0x0083BEC0, &NI_PointedDurabilityHook);
	SetCompleteHook(0xE9, 0x0083BF60, &NI_PointedSlotHook);
}

// ---------------------------------------------------------------------------
// Config

void CNewInventory::SetSlotRect(int slot, int x, int y, int width, int height)
{
	if (slot < 0 || slot >= NEW_INVENTORY_MAX_SLOTS)
	{
		return;
	}

	this->m_SlotRect[slot] = { x, y, width, height };
}

void CNewInventory::SetElementRect(int slot, int x, int y, int width, int height)
{
	if (slot < 0 || slot >= NEW_INVENTORY_MAX_ELEMENTS)
	{
		return;
	}

	this->m_ElementRect[slot] = { x, y, width, height };
}

void CNewInventory::SetSlotName(int slot, const char* name)
{
	if (slot < 0 || slot >= NEW_INVENTORY_MAX_SLOT_NAMES)
	{
		return;
	}

	strncpy_s(this->m_SlotName[slot], (name) ? name : "", _TRUNCATE);
}

void CNewInventory::SetCoin(int index, const char* label, int valueIndex, BYTE r, BYTE g, BYTE b)
{
	if (index < 0 || index >= NEW_INVENTORY_MAX_COINS)
	{
		return;
	}

	strncpy_s(this->m_Coin[index].Label, (label) ? label : "", _TRUNCATE);
	this->m_Coin[index].ValueIndex = valueIndex;
	this->m_Coin[index].Color[0] = r;
	this->m_Coin[index].Color[1] = g;
	this->m_Coin[index].Color[2] = b;
	this->m_Coin[index].Color[3] = 255;
}

void CNewInventory::AddClassicWindow(int window)
{
	if (window < 0)
	{
		this->m_ClassicWindowCount = 0;
		return;
	}

	if (this->m_ClassicWindowCount >= NEW_INVENTORY_MAX_WINDOWS)
	{
		return;
	}

	this->m_ClassicWindows[this->m_ClassicWindowCount++] = window;
}

void CNewInventory::SetPairedWindow(int window, int enabled)
{
	for (int i = 0; i < (int)NI_PAIRED_COUNT; i++)
	{
		if (NewInventoryPaired[i].Window == window)
		{
			this->m_PairedEnabled[i] = enabled;
		}
	}
}

void CNewInventory::SetCoinValue(int index, DWORD value)
{
	if (index < 0 || index >= NEW_INVENTORY_MAX_VALUES)
	{
		return;
	}

	this->m_CoinValue[index] = value;
}

DWORD CNewInventory::GetCoinValue(int index)
{
	if (index == 0)
	{
		return (NI_CharacterAttribute) ? NI_Money : 0;
	}

	if (index < 0 || index >= NEW_INVENTORY_MAX_VALUES)
	{
		return 0;
	}

	return this->m_CoinValue[index];
}

static const char* NI_ExpandCoinName(int coin)
{
	switch (coin)
	{
	case 1: return "Cash";
	case 2: return "Gold";
	case 3: return "JCPoints";
	case 4: return "Horas";
	default: return "Moeda";
	}
}

int CNewInventory::ExpandedSlotAtCursor()
{
	DWORD inventory = (DWORD)pInventoryThis(pWindowThis());

	if (inventory == 0)
	{
		return -1;
	}

	for (int page = 1; page <= NI_EXPAND_SLOT_COUNT; page++)
	{
		DWORD control = NI_ControlForPage(inventory, page);

		if (control == 0)
		{
			continue;
		}

		int local = (int)pInventoryCtrlFindItemptIndex((LPVOID)control, pCursorX, pCursorY);

		if (local != -1)
		{
			return local + 76 + ((page - 1) * 32);
		}
	}

	return -1;
}

int CNewInventory::FindEmptyExpandedSlot(int width, int height)
{
	DWORD inventory = (DWORD)pInventoryThis(pWindowThis());
	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (inventory == 0)
	{
		return -1;
	}

	for (int page = 1; page <= NI_EXPAND_SLOT_COUNT; page++)
	{
		if (!NI_ExpansionSlotOwned(extension, page - 1))
		{
			continue;
		}

		DWORD control = NI_ControlForPage(inventory, page);

		if (control == 0)
		{
			continue;
		}

		int local = pInventoryCtrlFindEmptySlot((LPVOID)control, width, height);

		if (local != -1)
		{
			return local + 76 + ((page - 1) * 32);
		}
	}

	return -1;
}

void CNewInventory::SetExpandPrice(int slot, int coin, DWORD value)
{
	if (slot < 1 || slot > NI_EXPAND_SLOT_COUNT)
	{
		return;
	}

	this->m_ExpandCoin[slot - 1] = coin;
	this->m_ExpandValue[slot - 1] = value;
	this->m_ExpandKnown[slot - 1] = 1;
}

void CNewInventory::UnlockExpansion(int count)
{
	if (count < 0)
	{
		count = 0;
	}

	if (count > NI_EXPAND_SLOT_COUNT)
	{
		count = NI_EXPAND_SLOT_COUNT;
	}

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (extension != 0)
	{
		((void(__thiscall*)(DWORD, int))0x007D6C20)(extension, count);
	}

	NI_RestoreExpandedGrids((DWORD)pInventoryThis(pWindowThis()));
}

void CNewInventory::FinishExpandBuy(int result, int count)
{
	this->m_ExpandBuying = false;
	this->m_ExpandConfirm = -1;

	if (result == 1)
	{
		this->UnlockExpansion(count);
		NI_DrawMessage("Inventario expandido liberado.", 1);
		return;
	}

	if (result == 2)
	{
		NI_DrawMessage("Voce ja possui este inventario expandido.", 1);
		return;
	}

	if (result == 3)
	{
		NI_DrawMessage("Saldo insuficiente.", 1);
		return;
	}

	if (result == 4)
	{
		NI_DrawMessage("Compre o inventario anterior primeiro.", 1);
		return;
	}

	NI_DrawMessage("Nao foi possivel concluir a compra.", 1);
}

void CNewInventory::FormatExpandPrice(int slot, char* buffer, int size)
{
	if (buffer == nullptr || size <= 0)
	{
		return;
	}

	buffer[0] = 0;

	if (slot < 0 || slot >= NI_EXPAND_SLOT_COUNT || this->m_ExpandKnown[slot] == 0)
	{
		strncpy_s(buffer, size, "...", _TRUNCATE);
		return;
	}

	char number[32];
	this->FormatNumber(this->m_ExpandValue[slot], number, sizeof(number));
	sprintf_s(buffer, size, "%s %s", number, NI_ExpandCoinName(this->m_ExpandCoin[slot]));
}

// ---------------------------------------------------------------------------
// Positions

int CNewInventory::GetWidth()
{
	if (!this->m_Wide)
	{
		return NEW_INVENTORY_CLASSIC_WIDTH;
	}

	int left = (this->m_ShowSet != 0) ? this->m_CenterOffset : 0;
	int right = this->m_Width - this->m_CenterOffset - NEW_INVENTORY_CLASSIC_WIDTH;

	if (this->m_ShowAccessories == 0 || right < 0)
	{
		right = 0;
	}

	return left + NEW_INVENTORY_CLASSIC_WIDTH + right;
}

int CNewInventory::GetCenterOffset()
{
	if (!this->m_Wide || this->m_ShowSet == 0)
	{
		return 0;
	}

	return this->m_CenterOffset;
}

int CNewInventory::GetOptionOffsetX()
{
	if (!this->m_Wide)
	{
		return 0;
	}

	// With a column hidden the header is shorter, so the native option text moves under it.
	return (this->GetWidth() < 300) ? 10 : this->m_OptionOffsetX;
}

int CNewInventory::GetOptionOffsetY()
{
	if (!this->m_Wide)
	{
		return 0;
	}

	return (this->GetWidth() < 300) ? 8 : this->m_OptionOffsetY;
}

NEW_INVENTORY_RECT* CNewInventory::GetTabRects()
{
	if (!this->m_Wide)
	{
		return this->m_CompactTabRect;
	}

	int step = (this->GetWidth() < 320) ? 16 : 18;
	int buttons = 2;

	if (this->m_CloseButton)
	{
		buttons++;
	}

	if (this->m_AllowResize && !this->m_Forced)
	{
		buttons++;
	}

	if (this->m_AllowMove && this->m_Floating && this->m_Managed)
	{
		buttons++;
	}

	int tabWidth = (step == 16) ? 40 : 46;
	int tabHeight = (step == 16) ? 14 : 16;
	int tabY = (step == 16) ? 4 : 7;
	int tabsX = this->GetWidth() - 4 - (buttons * step) - 4 - (tabWidth * 2);

	if (tabsX < 18)
	{
		tabsX = 18;
	}

	this->m_TabRect[0] = { tabsX, tabY, tabWidth, tabHeight };
	this->m_TabRect[1] = { tabsX + tabWidth, tabY, tabWidth, tabHeight };

	return this->m_TabRect;
}

void CNewInventory::ResolveSlotRect(int slot, NEW_INVENTORY_RECT* rect)
{
	*rect = this->m_SlotRect[slot];

	if (!this->m_Wide)
	{
		return;
	}

	bool setColumn = (slot >= 2 && slot <= 6);

	if ((setColumn && this->m_ShowSet == 0) || (!setColumn && this->m_ShowAccessories == 0))
	{
		rect->x = 800;
		rect->y = 800;
		return;
	}

	rect->x += this->GetContentShift();
}

void CNewInventory::ResolveElementRect(int slot, NEW_INVENTORY_RECT* rect)
{
	*rect = this->m_ElementRect[slot];

	if (!this->m_Wide)
	{
		return;
	}

	if (this->m_ShowAccessories == 0)
	{
		rect->x = 800;
		rect->y = 800;
		return;
	}

	rect->x += this->GetContentShift();
}

int CNewInventory::GetPosX()
{
	DWORD This = (DWORD)pInventoryThis(pWindowThis());

	return (This) ? *(int*)(This + NI_INVENTORY_POS_X) : 0;
}

int CNewInventory::GetPosY()
{
	DWORD This = (DWORD)pInventoryThis(pWindowThis());

	return (This) ? *(int*)(This + NI_INVENTORY_POS_Y) : 0;
}

int CNewInventory::GetButtonOffsetX(int index)
{
	// Classic row. Index 3 is the native expanded-inventory button.
	static const int classicOffset[4] = { 13, 50, 87, 124 };

	if (index < 0 || index > 3)
	{
		index = 0;
	}

	if (!this->IsSkinned())
	{
		return classicOffset[index];
	}

	// Five equal slots inside the 190 center strip: close, repair, shop, expand, clear.
	return NI_ROW_ORIGIN + (index * NI_ROW_STRIDE);
}

int CNewInventory::GetButtonX(int index)
{
	return this->GetPosX() + this->GetCenterOffset() + this->GetButtonOffsetX(index);
}

int CNewInventory::GetButtonOffsetY()
{
	if (this->m_Wide)
	{
		return this->m_ButtonY;
	}

	return (this->IsCompact()) ? this->m_CompactButtonY : 391;
}

int CNewInventory::GetButtonY()
{
	return this->GetPosY() + this->GetButtonOffsetY();
}

bool CNewInventory::GetVisualTabRect(int index, NEW_INVENTORY_RECT* rect)
{
	if (!this->IsSkinned() || index < 0 || index > 1)
	{
		return false;
	}

	NEW_INVENTORY_RECT* tabs = this->GetTabRects();

	rect->x = this->GetPosX() + tabs[index].x;
	rect->y = this->GetPosY() + tabs[index].y;
	rect->width = tabs[index].width;
	rect->height = tabs[index].height;
	return true;
}

bool CNewInventory::IsWindowOpen(int window)
{
	return CheckWindowOpen(window);
}

NEW_INVENTORY_LAYOUT CNewInventory::ComputeLayout()
{
	NEW_INVENTORY_LAYOUT layout = { false, false, true, 450, 0, -1, 0, -1 };

	if (this->m_Enabled == 0 || NI_GetUISystem() == 0)
	{
		return layout;
	}

	for (int i = 0; i < this->m_ClassicWindowCount; i++)
	{
		if (this->IsWindowOpen(this->m_ClassicWindows[i]))
		{
			return layout;
		}
	}

	bool character = this->IsWindowOpen(ObjWindow::Character);
	bool extension = this->IsWindowOpen(ObjWindow::ExpandInventory);

	// Keep the inventory compact beside the vault so both native item grids remain usable.
	if (this->IsWindowOpen(ObjWindow::Warehouse))
	{
		return layout;
	}

	if (this->IsWindowOpen(ObjWindow::ExpandWarehouse))
	{
		return layout;
	}

	int paired = 0;
	int pairedCount = 0;

	for (int i = 0; i < (int)NI_PAIRED_COUNT; i++)
	{
		if (!this->IsWindowOpen(NewInventoryPaired[i].Window))
		{
			continue;
		}

		if (this->m_PairedEnabled[i] == 0)
		{
			return layout;
		}

		paired = NewInventoryPaired[i].Window;
		pairedCount++;
	}

	if (gTradeX.isVisible() && paired != ObjWindow::Trade)
	{
		paired = (paired == 0) ? -1 : paired;
		pairedCount++;
	}

	if (pairedCount > 1 || (pairedCount == 1 && (character || extension)) || (character && extension))
	{
		return layout;
	}

	layout.Forced = false;

	bool alone = !character && !extension && pairedCount == 0;
	bool floating = this->m_AllowMove && this->m_Floating;
	int floatY = NI_Clamp(this->m_FloatY, 0, NEW_INVENTORY_SCREEN_HEIGHT - NEW_INVENTORY_HEIGHT);

	if (this->m_SizeMode == NEW_INVENTORY_SIZE_COMPACT)
	{
		// With other windows open the compact inventory keeps the native positions, which already handle every combination.
		if (alone)
		{
			layout.Managed = true;
			layout.InventoryX = (floating) ? NI_Clamp(this->m_FloatX, 0, NEW_INVENTORY_SCREEN_WIDTH - NEW_INVENTORY_CLASSIC_WIDTH) : 450;
			layout.InventoryY = (floating) ? floatY : 0;
		}

		return layout;
	}

	layout.Wide = true;
	layout.Managed = true;

	if (!floating)
	{
		if (extension)
		{
			layout.InventoryX = (this->m_ExtensionRight) ? 70 : 260;
			layout.ExtensionX = (this->m_ExtensionRight) ? 450 : 70;
		}
		else if (character)
		{
			layout.InventoryX = 70;
		}
		else
		{
			layout.InventoryX = 260;

			if (paired != 0)
			{
				layout.PairedWindow = paired;
				layout.PairedX = 70;
			}
		}

		layout.InventoryX += this->HiddenSetShift();
		this->KeepCenterOnScreen(&layout);
		return layout;
	}

	int width = this->GetWidth();
	int left = this->m_FloatX + this->HiddenSetShift();

	layout.InventoryY = floatY;

	if (alone)
	{
		layout.InventoryX = NI_Clamp(left, 0, NEW_INVENTORY_SCREEN_WIDTH - width);
	}
	else if (character)
	{
		layout.InventoryX = NI_Clamp(left, 0, 450 - width);
	}
	else
	{
		// The companion window goes to the free side; the inventory snaps so both fit on screen.
		bool companionLeft = (left + (width / 2)) >= (NEW_INVENTORY_SCREEN_WIDTH / 2);
		int companionX;

		if (companionLeft)
		{
			layout.InventoryX = NI_Clamp(left, NEW_INVENTORY_CLASSIC_WIDTH, NEW_INVENTORY_SCREEN_WIDTH - width);
			companionX = layout.InventoryX - NEW_INVENTORY_CLASSIC_WIDTH;
		}
		else
		{
			layout.InventoryX = NI_Clamp(left, 0, NEW_INVENTORY_SCREEN_WIDTH - width - NEW_INVENTORY_CLASSIC_WIDTH);
			companionX = layout.InventoryX + width;
		}

		if (extension)
		{
			layout.ExtensionX = companionX;
		}
		else
		{
			layout.PairedWindow = paired;
			layout.PairedX = companionX;
		}
	}

	this->KeepCenterOnScreen(&layout);
	return layout;
}

int CNewInventory::HiddenSetShift()
{
	if (this->m_ShowSet != 0)
	{
		return 0;
	}

	return this->m_CenterOffset;
}

void CNewInventory::KeepCenterOnScreen(NEW_INVENTORY_LAYOUT* layout)
{
	if (layout == nullptr || !layout->Wide || !layout->Managed)
	{
		return;
	}

	int width = this->GetWidth();
	int maxX = NEW_INVENTORY_SCREEN_WIDTH - width;

	if (maxX < 0)
	{
		maxX = 0;
	}

	layout->InventoryX = NI_Clamp(layout->InventoryX, 0, maxX);
}

void CNewInventory::SetMode(bool wide)
{
	if (this->m_Wide == wide)
	{
		return;
	}

	this->m_Wide = wide;
	this->m_PreviewDragging = false;

	this->PatchWidth(this->GetWidth());
	this->SwapExternalRects(wide);
}

void CNewInventory::PatchWidth(int width)
{
	for (int i = 0; i < 3; i++)
	{
		SetDword(NewInventoryWidthPatch[i], (DWORD)width);
	}
}

void CNewInventory::SwapExternalRects(bool wide)
{
	if (wide)
	{
		if (!this->m_RectsSwapped)
		{
			for (int i = 0; i < 9; i++)
			{
				this->m_SavedVisualRect[i].x = gVisualInventory.m_ItemInventoryEquip[i].x;
				this->m_SavedVisualRect[i].y = gVisualInventory.m_ItemInventoryEquip[i].y;
				this->m_SavedVisualRect[i].width = gVisualInventory.m_ItemInventoryEquip[i].width;
				this->m_SavedVisualRect[i].height = gVisualInventory.m_ItemInventoryEquip[i].height;
			}

			for (int i = 0; i < NEW_INVENTORY_MAX_ELEMENTS; i++)
			{
				this->m_SavedElementRect[i].x = gElementSlots.m_ElementEquiped[i].x;
				this->m_SavedElementRect[i].y = gElementSlots.m_ElementEquiped[i].y;
				this->m_SavedElementRect[i].width = gElementSlots.m_ElementEquiped[i].width;
				this->m_SavedElementRect[i].height = gElementSlots.m_ElementEquiped[i].height;
			}

			this->m_RectsSwapped = true;
		}

		for (int i = 0; i < 9; i++)
		{
			NEW_INVENTORY_RECT slot;

			this->ResolveSlotRect(i, &slot);
			gVisualInventory.m_ItemInventoryEquip[i].x = slot.x;
			gVisualInventory.m_ItemInventoryEquip[i].y = slot.y;
			gVisualInventory.m_ItemInventoryEquip[i].width = slot.width;
			gVisualInventory.m_ItemInventoryEquip[i].height = slot.height;
		}

		for (int i = 0; i < NEW_INVENTORY_MAX_ELEMENTS; i++)
		{
			NEW_INVENTORY_RECT slot;

			this->ResolveElementRect(i, &slot);
			gElementSlots.m_ElementEquiped[i].x = slot.x;
			gElementSlots.m_ElementEquiped[i].y = slot.y;
			gElementSlots.m_ElementEquiped[i].width = slot.width;
			gElementSlots.m_ElementEquiped[i].height = slot.height;
		}
	}
	else if (this->m_RectsSwapped)
	{
		for (int i = 0; i < 9; i++)
		{
			gVisualInventory.m_ItemInventoryEquip[i].x = this->m_SavedVisualRect[i].x;
			gVisualInventory.m_ItemInventoryEquip[i].y = this->m_SavedVisualRect[i].y;
			gVisualInventory.m_ItemInventoryEquip[i].width = this->m_SavedVisualRect[i].width;
			gVisualInventory.m_ItemInventoryEquip[i].height = this->m_SavedVisualRect[i].height;
		}

		for (int i = 0; i < NEW_INVENTORY_MAX_ELEMENTS; i++)
		{
			gElementSlots.m_ElementEquiped[i].x = this->m_SavedElementRect[i].x;
			gElementSlots.m_ElementEquiped[i].y = this->m_SavedElementRect[i].y;
			gElementSlots.m_ElementEquiped[i].width = this->m_SavedElementRect[i].width;
			gElementSlots.m_ElementEquiped[i].height = this->m_SavedElementRect[i].height;
		}

		this->m_RectsSwapped = false;
	}
}

void CNewInventory::SetPos(DWORD This, int x, int y)
{
	NEW_INVENTORY_LAYOUT layout = this->ComputeLayout();

	this->SetMode(layout.Wide);

	if (this->m_Wide)
	{
		this->PatchWidth(this->GetWidth());
		this->SwapExternalRects(true);
	}

	this->m_AppliedShowSet = this->m_ShowSet;
	this->m_AppliedShowAcc = this->m_ShowAccessories;
	this->m_Managed = layout.Managed;
	this->m_Forced = layout.Forced;

	if (layout.Managed)
	{
		x = layout.InventoryX;
		y = layout.InventoryY;
	}

	*(int*)(This + NI_INVENTORY_POS_X) = x;
	*(int*)(This + NI_INVENTORY_POS_Y) = y;

	NI_SetEquipmentSlotInfo(This);

	this->ApplyEquipmentSlots(This);

	int center = x + this->GetCenterOffset();

	DWORD control = *(DWORD*)(This + NI_INVENTORY_CONTROL);

	if (control)
	{
		NI_ControlSetPos(control, center + 15, y + ((this->m_Wide) ? this->m_GridY : 200));
	}

	int buttonY = y + this->GetButtonOffsetY();

	NI_ButtonSetPos(This + NewInventoryButtonOffset[0], center + this->GetButtonOffsetX(0), buttonY);
	NI_ButtonSetPos(This + NewInventoryButtonOffset[1], center + this->GetButtonOffsetX(1), buttonY);
	NI_ButtonSetPos(This + NewInventoryButtonOffset[2], center + this->GetButtonOffsetX(2), buttonY);
	NI_ButtonSetPos(This + NewInventoryButtonOffset[3], center + this->GetButtonOffsetX(3), buttonY);

	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (extension)
	{
		int extensionX = x - NEW_INVENTORY_CLASSIC_WIDTH;

		if (layout.Managed)
		{
			extensionX = (layout.ExtensionX >= 0) ? layout.ExtensionX : ((extensionX < 0) ? 0 : extensionX);
		}

		NI_ExtensionSetPos(extension, extensionX, 0);
		NI_RestoreExpandedGrids(This);
	}
}

void CNewInventory::ApplyEquipmentSlots(DWORD This)
{
	if (!this->m_Wide)
	{
		return;
	}

	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);

	for (int i = 0; i < NEW_INVENTORY_MAX_SLOTS; i++)
	{
		NEW_INVENTORY_RECT resolved;
		int* slot = (int*)(This + NI_INVENTORY_SLOTS + (i * NI_INVENTORY_SLOT_SIZE));

		this->ResolveSlotRect(i, &resolved);
		slot[0] = x + resolved.x;
		slot[1] = y + resolved.y;
		slot[2] = resolved.width;
		slot[3] = resolved.height;
	}
}

int CNewInventory::GetExtensionX()
{
	DWORD extension = NI_GetExtension(NI_GetUISystem());

	return (extension) ? *(int*)(extension + 0x14) : -1;
}

void CNewInventory::MoveExtension(int x)
{
	DWORD extension = NI_GetExtension(NI_GetUISystem());

	if (extension)
	{
		NI_ExtensionSetPos(extension, x, 0);
		NI_RestoreExpandedGrids((DWORD)pInventoryThis(pWindowThis()));
	}
}

int CNewInventory::GetPairedWindowX(int window)
{
	for (int i = 0; i < (int)NI_PAIRED_COUNT; i++)
	{
		if (NewInventoryPaired[i].Window != window)
		{
			continue;
		}

		DWORD object = *(DWORD*)(NI_GetUISystem() + NewInventoryPaired[i].InstanceOffset);

		return (object) ? *(int*)(object + NewInventoryPaired[i].PosOffset) : -1;
	}

	return -1;
}

void CNewInventory::MovePairedWindow(int window, int x)
{
	for (int i = 0; i < (int)NI_PAIRED_COUNT; i++)
	{
		const NEW_INVENTORY_PAIRED* info = &NewInventoryPaired[i];

		if (info->Window != window)
		{
			continue;
		}

		DWORD system = NI_GetUISystem();
		DWORD object = *(DWORD*)(system + info->InstanceOffset);

		if (object == 0)
		{
			return;
		}

		int argument = (info->ExtensionArg) ? (int)NI_GetExtension(system) : info->Window;

		((int(__thiscall*)(DWORD, int, int, int))info->MoveFunc)(object, x, 0, argument);

		for (int n = 0; n < 2; n++)
		{
			if (info->ControlOffset[n] < 0)
			{
				continue;
			}

			DWORD control = *(DWORD*)(object + info->ControlOffset[n]);

			if (control)
			{
				*(int*)(control + 40) = x + 15;
			}
		}

		return;
	}
}

void CNewInventory::RestoreClassicPositions(DWORD This)
{
	bool character = this->IsWindowOpen(ObjWindow::Character);
	bool extension = this->IsWindowOpen(ObjWindow::ExpandInventory);

	this->SetPos(This, (character) ? 260 : 450, 0);

	for (int i = 0; i < (int)NI_PAIRED_COUNT; i++)
	{
		if (this->IsWindowOpen(NewInventoryPaired[i].Window))
		{
			this->MovePairedWindow(NewInventoryPaired[i].Window, (extension) ? 70 : 260);
		}
	}
}

void CNewInventory::UpdateLayout(DWORD This)
{
	NEW_INVENTORY_LAYOUT layout = this->ComputeLayout();

	this->m_Forced = layout.Forced;
	this->m_CompanionX = (layout.ExtensionX >= 0) ? layout.ExtensionX : layout.PairedX;

	if (!layout.Managed)
	{
		if (this->m_Managed)
		{
			this->SetMode(false);
			this->RestoreClassicPositions(This);
		}

		this->m_Managed = false;
		return;
	}

	if (!this->m_Managed || this->m_Wide != layout.Wide
		|| *(int*)(This + NI_INVENTORY_POS_X) != layout.InventoryX
		|| *(int*)(This + NI_INVENTORY_POS_Y) != layout.InventoryY
		|| this->m_AppliedShowSet != this->m_ShowSet
		|| this->m_AppliedShowAcc != this->m_ShowAccessories)
	{
		this->SetPos(This, layout.InventoryX, layout.InventoryY);
	}

	if (layout.ExtensionX >= 0 && this->GetExtensionX() != layout.ExtensionX)
	{
		this->MoveExtension(layout.ExtensionX);
	}

	if (layout.PairedWindow > 0 && (this->GetPairedWindowX(layout.PairedWindow) != layout.PairedX || !this->PairedButtonsInPlace(layout.PairedWindow)))
	{
		this->MovePairedWindow(layout.PairedWindow, layout.PairedX);
	}
}

// The vault buttons keep their own position (+4 of each button). When the native code puts them back on
// the classic spot after the window was moved, the window has to be moved again to bring them along.
bool CNewInventory::PairedButtonsInPlace(int window)
{
	if (window != ObjWindow::Warehouse)
	{
		return true;
	}

	DWORD object = *(DWORD*)(NI_GetUISystem() + 72);

	if (object == 0)
	{
		return true;
	}

	int x = *(int*)(object + 0x10);

	return *(int*)(object + 0x18 + 4) == x + 13 && *(int*)(object + 0x23C + 4) == x + 124;
}

// ---------------------------------------------------------------------------
// Drawing primitives

void CNewInventory::DrawRect(float x, float y, float width, float height, float r, float g, float b, float a)
{
	if (width <= 0.0f || height <= 0.0f)
	{
		return;
	}

	// Objects under the cursor, and the character while walking, leave a texture
	// and the depth test enabled. The client's helpers trust a cache and skip the
	// reset, so these panels were sampling that texture and punching holes.
	glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glAlphaFunc(GL_GREATER, 0.0f);

	BYTE textureCache = *(BYTE*)0x00879325C;
	BYTE textureCache2 = *(BYTE*)0x008793260;
	*(BYTE*)0x00879325C = 0;
	*(BYTE*)0x008793260 = 0;

	glColor4f(r, g, b, a);
	pDrawBarForm(x, y, width, height, 0.0f, 0);
	NI_EndDrawBar();

	*(BYTE*)0x00879325C = textureCache;
	*(BYTE*)0x008793260 = textureCache2;
	glPopAttrib();
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

void CNewInventory::DrawGradient(float x, float y, float width, float height, const float* top, const float* bottom, int bands)
{
	if (bands < 1)
	{
		bands = 1;
	}

	float step = height / (float)bands;

	for (int i = 0; i < bands; i++)
	{
		float t = (bands > 1) ? (float)i / (float)(bands - 1) : 0.0f;

		this->DrawRect(x, y + step * i, width, step + 0.5f,
			top[0] + (bottom[0] - top[0]) * t,
			top[1] + (bottom[1] - top[1]) * t,
			top[2] + (bottom[2] - top[2]) * t,
			top[3] + (bottom[3] - top[3]) * t);
	}
}

void CNewInventory::DrawBorder(float x, float y, float width, float height, float r, float g, float b, float a)
{
	// Corners are left open so boxes read as slightly rounded.
	this->DrawRect(x + 1.0f, y, width - 2.0f, 1.0f, r, g, b, a);
	this->DrawRect(x + 1.0f, y + height - 1.0f, width - 2.0f, 1.0f, r, g, b, a);
	this->DrawRect(x, y + 1.0f, 1.0f, height - 2.0f, r, g, b, a);
	this->DrawRect(x + width - 1.0f, y + 1.0f, 1.0f, height - 2.0f, r, g, b, a);
}

void CNewInventory::DrawAccentBorder(float x, float y, float width, float height, float alpha)
{
	this->DrawBorder(x, y, width, height, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], alpha);
}

int CNewInventory::GetTextWidth(const char* text)
{
	SIZE size = { 0, 0 };

	GetTextExtentPoint32(NI_GetTextDC(pTextThis()), text, strlen(text), &size);

	return (pWinWidthReal > 0.0f) ? (int)((float)size.cx / pWinWidthReal) : size.cx;
}

void CNewInventory::DrawLabel(int x, int y, const char* text, int width, int align, BYTE r, BYTE g, BYTE b, BYTE a, bool bold)
{
	pTextSetFont(pTextThis(), (bold) ? g_hFontBold : g_hFont);
	pSetTextBgColor(pTextThis(), 0, 0, 0, 0);
	pSetTextColor(pTextThis(), r, g, b, a);
	pDrawText(pTextThis(), x, y, text, width, 0, align, 0);
}

bool CNewInventory::DrawButton(int x, int y, int width, int height, const char* text, bool active, bool repeat)
{
	bool hover = CheckMouseIn(x, y, width, height);

	if (active)
	{
		float top[4] = { this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.95f };
		float bottom[4] = { this->m_Accent[0] * 0.65f, this->m_Accent[1] * 0.65f, this->m_Accent[2] * 0.65f, 0.95f };
		this->DrawGradient((float)x, (float)y, (float)width, (float)height, top, bottom, 4);
	}
	else if (hover)
	{
		this->DrawRect((float)x, (float)y, (float)width, (float)height, this->m_Accent[0] * 0.35f, this->m_Accent[1] * 0.35f, this->m_Accent[2] * 0.35f, 0.95f);
	}
	else
	{
		this->DrawRect((float)x, (float)y, (float)width, (float)height, 0.10f, 0.10f, 0.12f, 0.92f);
	}

	this->DrawAccentBorder((float)x, (float)y, (float)width, (float)height, (hover || active) ? 0.9f : 0.45f);

	if (active)
	{
		this->DrawLabel(x, y + (height - 10) / 2, text, width, 3, 25, 20, 10, 255, true);
	}
	else
	{
		this->DrawLabel(x, y + (height - 10) / 2, text, width, 3, (hover) ? 255 : 200, (hover) ? 240 : 200, (hover) ? 210 : 200, 255, false);
	}

	(void)repeat;
	return hover;
}

void CNewInventory::SetPendingTooltip(int centerX, int anchorY, const char* text, bool below)
{
	if (text == nullptr || text[0] == 0)
	{
		return;
	}

	this->m_TooltipPending = true;
	this->m_TooltipBelow = below;
	this->m_TooltipX = centerX;
	this->m_TooltipY = anchorY;
	strncpy_s(this->m_TooltipText, text, _TRUNCATE);
}

void CNewInventory::DrawTooltip(int centerX, int anchorY, const char* text, bool below)
{
	this->DrawTooltipIn(centerX, anchorY, text, below, this->GetPosX(), this->GetPosX() + this->GetWidth());
}

void CNewInventory::DrawTooltipIn(int centerX, int anchorY, const char* text, bool below, int left, int right)
{
	if (text == nullptr || text[0] == 0)
	{
		return;
	}

	pTextSetFont(pTextThis(), g_hFont);

	int width = this->GetTextWidth(text) + 12;
	int height = 14;
	int x = centerX - (width / 2);
	int y = (below) ? anchorY + 3 : anchorY - height - 3;

	int minX = left + 2;
	int maxX = right - width - 2;

	if (x < minX) x = minX;
	if (x > maxX) x = maxX;

	this->DrawRect((float)x, (float)y, (float)width, (float)height, 0.02f, 0.02f, 0.03f, 0.94f);
	this->DrawAccentBorder((float)x, (float)y, (float)width, (float)height, 0.8f);
	this->DrawLabel(x, y + 2, text, width, 3, 255, 255, 255, 255, false);
}

void CNewInventory::FormatNumber(DWORD value, char* buffer, int size)
{
	char temp[64];

	sprintf_s(temp, "%u", value);

	int length = (int)strlen(temp);
	int out = 0;

	for (int i = 0; i < length && out < size - 1; i++)
	{
		if (i > 0 && ((length - i) % 3) == 0 && out < size - 2)
		{
			buffer[out++] = ',';
		}

		buffer[out++] = temp[i];
	}

	buffer[out] = 0;
}

// ---------------------------------------------------------------------------
// Frame

void CNewInventory::DrawFrameTexture(int x, int y)
{
	DWORD bitmap = NI_GetBitmap(NI_BitmapManager, NI_FRAME_IMAGE);
	float textureWidth = (bitmap) ? *(float*)(bitmap + 260) : 0.0f;
	float textureHeight = (bitmap) ? *(float*)(bitmap + 264) : 0.0f;
	int width = this->GetWidth();

	if (textureWidth <= 0.0f || textureHeight <= 0.0f || width < 40)
	{
		this->DrawModernFrame(x, y, width, this->GetHeaderHeight());
		return;
	}

	// Item_Back02 is 190x429. Keep the side borders and the top gem, and stretch only the plain middle.
	const int srcWidth = 190;
	const int border = 10;
	const int gem = 12;
	int gemSrc = (srcWidth - gem) / 2;
	int gemX = this->GetCenterOffset() + ((NEW_INVENTORY_CLASSIC_WIDTH - gem) / 2);

	if (gemX < border)
	{
		gemX = border;
	}

	if (gemX > width - border - gem)
	{
		gemX = width - border - gem;
	}

	int pieces[5][4] =
	{
		{ 0, border, 0, border },
		{ border, gemX - border, border, gemSrc - border },
		{ gemX, gem, gemSrc, gem },
		{ gemX + gem, (width - border) - (gemX + gem), gemSrc + gem, (srcWidth - border) - (gemSrc + gem) },
		{ width - border, border, srcWidth - border, border },
	};

	float vHeight = (float)NEW_INVENTORY_HEIGHT / textureHeight;

	if (vHeight > 1.0f)
	{
		vHeight = 1.0f;
	}

	glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.0f);
	EnableAlphaTest(true);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	for (int i = 0; i < 5; i++)
	{
		if (pieces[i][1] <= 0 || pieces[i][3] <= 0)
		{
			continue;
		}

		RenderImage2(NI_FRAME_IMAGE, (float)(x + pieces[i][0]), (float)y, (float)pieces[i][1], (float)NEW_INVENTORY_HEIGHT,
			(float)pieces[i][2] / textureWidth, 0.0f, (float)pieces[i][3] / textureWidth, vHeight, true, true, 1.0f);
	}

	glPopAttrib();
}

void CNewInventory::DrawModernFrame(int x, int y, int width, int headerHeight)
{
	float fx = (float)x;
	float fy = (float)y;
	float w = (float)width;
	float h = (float)NEW_INVENTORY_HEIGHT;
	float header = (float)headerHeight;

	this->DrawRect(fx + 3.0f, fy + 3.0f, w, h, 0.0f, 0.0f, 0.0f, (this->m_Dragging) ? 0.55f : 0.35f);

	float bodyTop[4] = { 0.085f, 0.088f, 0.100f, 0.97f };
	float bodyBottom[4] = { 0.035f, 0.036f, 0.042f, 0.97f };
	this->DrawGradient(fx, fy, w, h, bodyTop, bodyBottom, 4);

	float headerTop[4] = { 0.17f, 0.15f, 0.11f, 0.96f };
	float headerBottom[4] = { 0.09f, 0.085f, 0.075f, 0.96f };
	this->DrawGradient(fx + 1.0f, fy + 1.0f, w - 2.0f, header, headerTop, headerBottom, 2);

	this->DrawRect(fx + 1.0f, fy + header + 1.0f, w - 2.0f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.25f);
	this->DrawRect(fx + w * 0.2f, fy + header + 1.0f, w * 0.6f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.85f);

	this->DrawRect(fx + 1.0f, fy + h - 2.0f, w - 2.0f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.20f);

	this->DrawBorder(fx + 1.0f, fy + 1.0f, w - 2.0f, h - 2.0f, 0.0f, 0.0f, 0.0f, 0.6f);
	this->DrawAccentBorder(fx, fy, w, h, (this->m_Dragging) ? 1.0f : 0.75f);
}

void CNewInventory::DrawGrip(int x, int y, bool hover)
{
	float alpha = (hover || this->m_Dragging) ? 1.0f : 0.55f;

	for (int row = 0; row < 3; row++)
	{
		for (int column = 0; column < 2; column++)
		{
			this->DrawRect((float)(x + column * 3), (float)(y + row * 3), 2.0f, 2.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], alpha);
		}
	}
}

void CNewInventory::DrawCard(int x, int y, int width, int height, const char* caption)
{
	this->DrawRect((float)x, (float)y, (float)width, (float)height, 1.0f, 1.0f, 1.0f, 0.035f);
	this->DrawBorder((float)x, (float)y, (float)width, (float)height, 1.0f, 1.0f, 1.0f, 0.09f);
	this->DrawRect((float)x + 1.0f, (float)y, (float)width - 2.0f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.45f);

	if (caption && caption[0])
	{
		this->DrawLabel(x, y - 11, caption, width, 3,
			(BYTE)(this->m_Accent[0] * 235.0f), (BYTE)(this->m_Accent[1] * 235.0f), (BYTE)(this->m_Accent[2] * 235.0f), 255, false);
	}
}

void CNewInventory::DrawCoinBox(int x, int y, int width, int height, const char* label, const char* value, BYTE* color)
{
	float top[4] = { 0.10f, 0.10f, 0.12f, 0.92f };
	float bottom[4] = { 0.05f, 0.05f, 0.06f, 0.92f };

	this->DrawGradient((float)x, (float)y, (float)width, (float)height, top, bottom, 1);
	this->DrawBorder((float)x, (float)y, (float)width, (float)height, 1.0f, 1.0f, 1.0f, 0.10f);
	this->DrawRect((float)x + 1.0f, (float)y + 2.0f, 2.0f, (float)height - 4.0f, color[0] / 255.0f, color[1] / 255.0f, color[2] / 255.0f, 0.95f);

	this->DrawLabel(x + 7, y + 2, label, 0, 1, 150, 150, 155, 255, false);

	pTextSetFont(pTextThis(), g_hFontBold);

	int textWidth = this->GetTextWidth(value);

	this->DrawLabel(x + width - 5 - textWidth, y + 2, value, 0, 1, color[0], color[1], color[2], 255, true);
}

// ---------------------------------------------------------------------------
// Clicks are handled while the mouse pulse is still set. The inventory is drawn later, after that pulse is gone.

void CNewInventory::UpdateButtons()
{
	NI_HideExtraGridsWhenClosed();

	if (!this->IsSkinned() || !this->IsWindowOpen(ObjWindow::Inventory))
	{
		this->m_Dragging = false;
		return;
	}

	DWORD This = (DWORD)pInventoryThis(pWindowThis());

	if (This == 0)
	{
		return;
	}

	// The held button would otherwise walk the character toward the cursor while the window moves.
	if (this->m_Dragging)
	{
		gInterface.interfaceLock = 1;
		return;
	}

	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);
	int width = this->GetWidth();
	int size = (this->m_Wide && width < 320) ? 14 : 16;
	int step = size + 2;
	int buttonY = y + ((this->GetHeaderHeight() - size) / 2);
	int buttonX = x + width - 6 - size;
	bool click = (*(BYTE*)0x8793386 != 0);
	int expandX = this->GetButtonX(3);
	int expandY = this->GetButtonY();
	const int expandW = NI_ROW_BUTTON_W;
	const int expandH = NI_ROW_BUTTON_H;

	if (click && this->IsWindowOpen(ObjWindow::ExpandInventory))
	{
		DWORD extension = NI_GetExtension(NI_GetUISystem());

		if (this->m_ExpandConfirm >= 0 && this->m_ExpandConfirm < NI_EXPAND_SLOT_COUNT && extension != 0)
		{
			int slotX = 0;
			int slotY = 0;
			int index = this->m_ExpandConfirm;

			if (NI_ExpansionSlotRect(extension, index, &slotX, &slotY))
			{
				ResetMouseL();
				gInterface.interfaceLock = 1;

				if (CheckMouseIn(slotX + 8, slotY + 50, 70, 18))
				{
					if (!this->m_ExpandBuying)
					{
						this->m_ExpandBuying = true;

						if (!gInterface.m_Lua.Generic_Call("NewInventoryExpandBuy", "i>", index + 1))
						{
							this->m_ExpandBuying = false;
							NI_DrawMessage("Nao foi possivel concluir a compra.", 1);
						}
					}

					return;
				}

				if (CheckMouseIn(slotX + 82, slotY + 50, 70, 18) || !CheckMouseIn(slotX, slotY, NI_EXPAND_SLOT_COLS * NI_EXPAND_CELL, NI_EXPAND_SLOT_ROWS * NI_EXPAND_CELL))
				{
					this->m_ExpandConfirm = -1;
					this->m_ExpandBuying = false;
				}

				return;
			}
		}

		for (int index = 0; index < NI_EXPAND_SLOT_COUNT && extension != 0; index++)
		{
			int slotX = 0;
			int slotY = 0;

			// An owned slot shows its grid here, so the click belongs to the items.
			if (NI_ExpansionSlotOwned(extension, index) || !NI_ExpansionSlotRect(extension, index, &slotX, &slotY) || !CheckMouseIn(slotX + 30, slotY + 22, 100, 18))
			{
				continue;
			}

			ResetMouseL();
			gInterface.interfaceLock = 1;

			if (index > 0 && !NI_ExpansionSlotOwned(extension, index - 1))
			{
				NI_DrawMessage("Compre o inventario anterior primeiro.", 1);
				return;
			}

			if (this->m_ExpandKnown[index] == 0)
			{
				gInterface.m_Lua.Generic_Call("NewInventoryExpandRequest", ">");
				NI_DrawMessage("Aguarde o valor da compra.", 1);
				return;
			}

			this->m_ExpandConfirm = index;
			return;
		}
	}

	// The native button fires on mouse release. Swallow that release after we already toggled on press.
	if (this->m_SuppressExpandClick)
	{
		bool overExpand = CheckMouseIn(expandX, expandY, expandW, expandH);
		bool held = (*(BYTE*)0x8793384 != 0) || IsPressKey(VK_LBUTTON) || IsRepeatKey(VK_LBUTTON);

		if (overExpand && held)
		{
			gInterface.interfaceLock = 1;
			return;
		}

		this->m_SuppressExpandClick = false;

		if (overExpand)
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			return;
		}
	}

	if (this->m_CloseButton)
	{
		if (click && CheckMouseIn(buttonX, buttonY, size, size))
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			this->m_CloseRequested = true;
			return;
		}

		buttonX -= step;
	}

	if (this->m_AllowResize && !this->m_Forced)
	{
		if (click && CheckMouseIn(buttonX, buttonY, size, size))
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			this->m_SizeMode = (this->m_SizeMode == NEW_INVENTORY_SIZE_LARGE) ? NEW_INVENTORY_SIZE_COMPACT : NEW_INVENTORY_SIZE_LARGE;
			this->m_Dragging = false;
			this->SaveUserSettings();
			return;
		}

		buttonX -= step;
	}

	if (this->m_AllowMove && this->m_Floating && this->m_Managed)
	{
		if (click && CheckMouseIn(buttonX, buttonY, size, size))
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			this->m_Floating = 0;
			this->m_Dragging = false;
			this->SaveUserSettings();
			return;
		}

		buttonX -= step;
	}

	if (this->m_Wide)
	{
		if (click && CheckMouseIn(buttonX, buttonY, size, size))
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			this->m_ShowAccessories ^= 1;
			this->SaveUserSettings();
			return;
		}

		buttonX -= step;

		if (click && CheckMouseIn(buttonX, buttonY, size, size))
		{
			ResetMouseL();
			gInterface.interfaceLock = 1;
			this->m_ShowSet ^= 1;
			this->SaveUserSettings();
			return;
		}
	}

	if (click && gVisualInventory.InventoryVisualSwitch != 0)
	{
		NEW_INVENTORY_RECT tab;

		if (this->GetVisualTabRect(0, &tab) && CheckMouseIn(tab.x, tab.y, tab.width, tab.height))
		{
			SetByte(0x0083703A + 3, 0xC);
			gVisualInventory.InventoryVisualOpen = 0;
			ResetMouseL();
			gInterface.interfaceLock = 1;
			return;
		}

		if (this->GetVisualTabRect(1, &tab) && CheckMouseIn(tab.x, tab.y, tab.width, tab.height))
		{
			SetByte(0x0083703A + 3, 0x9);
			gVisualInventory.InventoryVisualOpen = 1;
			ResetMouseL();
			gInterface.interfaceLock = 1;
			return;
		}
	}

	if (click && this->m_AllowMove && this->m_Managed && CheckMouseIn(x, y, width, this->GetHeaderHeight()))
	{
		DWORD pickedManager = NI_GetPickedItemManager();

		if (pickedManager == 0 || NI_GetPickedItem(pickedManager) == nullptr)
		{
			this->m_Dragging = true;
			this->m_Floating = 1;
			this->m_FloatX = x - ((this->m_Wide) ? this->HiddenSetShift() : 0);
			this->m_FloatY = y;
			this->m_DragOffsetX = pCursorX - x;
			this->m_DragOffsetY = pCursorY - y;

			ResetMouseL();
			gInterface.interfaceLock = 1;
			return;
		}
	}

	if (click && CheckMouseIn(expandX, expandY, expandW, expandH))
	{
		DWORD pickedManager = NI_GetPickedItemManager();

		if (pickedManager != 0 && NI_GetPickedItem(pickedManager) != nullptr)
		{
			return;
		}

		ResetMouseL();
		gInterface.interfaceLock = 1;
		this->m_SuppressExpandClick = true;

		bool expanded = (*(int*)(This + NI_INVENTORY_EXPAND_STATE) == 1) || this->IsWindowOpen(ObjWindow::ExpandInventory);

		if (expanded)
		{
			NI_ExpandCloseState(This);
			CloseWindow(ObjWindow::ExpandInventory);
		}
		else
		{
			NI_ExpandOpenState(This);
			OpenWindow(ObjWindow::ExpandInventory);
		}

		return;
	}

	if (!this->m_Wide || this->m_PreviewEnabled == 0)
	{
		return;
	}

	int px = x + this->m_PreviewRect.x + this->GetContentShift();
	int py = y + this->m_PreviewRect.y;
	NEW_INVENTORY_RECT toggle, mount;
	this->GetPreviewControlRects(px, py, &toggle, &mount);
	int rotateRightX = toggle.x - 16;
	int rotateLeftX = rotateRightX - 16;
	int controlY = toggle.y;
	bool held = click || IsRepeatKey(VK_LBUTTON) || IsPressKey(VK_LBUTTON) || (*(BYTE*)0x8793384 != 0);

	if (this->m_PreviewVisible && held && CheckMouseIn(rotateLeftX, controlY, 14, 11))
	{
		this->m_PreviewAngle -= 3.0f;
		gInterface.interfaceLock = 1;

		if (click)
		{
			ResetMouseL();
		}

		return;
	}

	if (this->m_PreviewVisible && held && CheckMouseIn(rotateRightX, controlY, 14, 11))
	{
		this->m_PreviewAngle += 3.0f;
		gInterface.interfaceLock = 1;

		if (click)
		{
			ResetMouseL();
		}

		return;
	}

	if (click && this->m_PreviewVisible && this->m_PreviewHasMount && CheckMouseIn(mount.x, mount.y, mount.width, mount.height))
	{
		this->m_PreviewMounted ^= 1;
		this->m_PreviewDragging = false;
		this->SaveUserSettings();
		ResetMouseL();
		gInterface.interfaceLock = 1;
		return;
	}

	if (click && CheckMouseIn(toggle.x, toggle.y, toggle.width, toggle.height))
	{
		this->m_PreviewVisible ^= 1;
		this->m_PreviewDragging = false;
		this->SaveUserSettings();
		ResetMouseL();
		gInterface.interfaceLock = 1;
	}
}

void CNewInventory::GetPreviewControlRects(int px, int py, NEW_INVENTORY_RECT* toggle, NEW_INVENTORY_RECT* mount)
{
	int pw = this->m_PreviewRect.width;
	int ph = this->m_PreviewRect.height;

	if (this->m_PreviewVisible)
	{
		*toggle = { px + pw - 41, py + ph - 13, 38, 11 };
	}
	else
	{
		*toggle = { px + (pw - 64) / 2, py + 2, 64, 13 };
	}

	*mount = { px + 3, py + 3, 52, 12 };
}

// ---------------------------------------------------------------------------
// Render

void CNewInventory::RenderExpansionSlots(DWORD extension)
{
	if (extension == 0)
	{
		return;
	}

	NI_RestoreExpandedGrids((DWORD)pInventoryThis(pWindowThis()));

	int gridWidth = NI_EXPAND_SLOT_COLS * NI_EXPAND_CELL;
	int gridHeight = NI_EXPAND_SLOT_ROWS * NI_EXPAND_CELL;

	// Same order as 0x7D57A0, which only knows two tables: page items first, then the table art.
	DWORD inventory = (DWORD)pInventoryThis(pWindowThis());

	if (inventory != 0)
	{
		((void(__thiscall*)(DWORD))0x0083C510)(inventory);
	}

	for (int index = 2; index < NI_EXPAND_SLOT_COUNT; index++)
	{
		if (!NI_ExpansionSlotOwned(extension, index))
		{
			continue;
		}

		DWORD control = g_NIExtraControl[index - 2];

		if (control != 0)
		{
			((void(__thiscall*)(DWORD, int))0x007DB230)(control, 0);
		}
	}

	for (int index = 0; index < NI_EXPAND_SLOT_COUNT; index++)
	{
		int slotX = 0;
		int slotY = 0;

		if (!NI_ExpansionSlotRect(extension, index, &slotX, &slotY))
		{
			continue;
		}

		((void(__cdecl*)(DWORD, float, float, float, float))0x00790B50)(NI_EXPAND_TABLE_IMAGE, (float)(slotX - 4), (float)(slotY - 3), NI_EXPAND_TABLE_WIDTH, NI_EXPAND_TABLE_HEIGHT);
	}

	for (int index = 0; index < NI_EXPAND_SLOT_COUNT; index++)
	{
		int slotX = 0;
		int slotY = 0;

		if (NI_ExpansionSlotOwned(extension, index) || !NI_ExpansionSlotRect(extension, index, &slotX, &slotY))
		{
			continue;
		}

		this->DrawRect((float)slotX, (float)slotY, (float)gridWidth, (float)gridHeight, 0.03f, 0.03f, 0.04f, 0.88f);
		this->DrawBorder((float)slotX, (float)slotY, (float)gridWidth, (float)gridHeight, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.55f);

		char price[64];
		this->FormatExpandPrice(index, price, sizeof(price));

		if (this->m_ExpandConfirm == index)
		{
			char title[32];
			sprintf_s(title, "Inventario %d", index + 1);
			this->DrawLabel(slotX, slotY + 8, "Confirmar compra", gridWidth, 3, 219, 176, 89, 255, true);
			this->DrawLabel(slotX, slotY + 24, title, gridWidth, 3, 230, 230, 230, 255, false);
			this->DrawLabel(slotX, slotY + 36, price, gridWidth, 3, 120, 220, 255, 255, true);
			this->DrawButton(slotX + 8, slotY + 50, 70, 18, "Confirmar", false, false);
			this->DrawButton(slotX + 82, slotY + 50, 70, 18, "Cancelar", false, false);
			continue;
		}

		this->DrawButton(slotX + 30, slotY + 22, 100, 18, "Comprar", false, false);
		this->DrawLabel(slotX, slotY + 44, price, gridWidth, 3, 219, 176, 89, 255, true);
	}
}

void CNewInventory::RenderFrame(DWORD This)
{
	if (this->m_CloseRequested)
	{
		this->m_CloseRequested = false;
		CloseWindow(ObjWindow::Inventory);
	}

	this->UpdateLayout(This);

	this->m_TooltipPending = false;

	if (!this->IsSkinned())
	{
		this->m_Dragging = false;
		NI_RenderFrame(This);
		return;
	}

	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);

	// Hovering an NPC switches the blend mode without updating the client's cache,
	// so EnableAlphaTest would skip the reset and the window would draw see-through.
	*(DWORD*)0x008793258 = 0xFFFFFFFF;
	EnableAlphaTest(true);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	if (this->m_Style == 0)
	{
		this->DrawFrameTexture(x, y);
	}
	else if (this->m_Wide)
	{
		this->DrawModernFrame(x, y, this->GetWidth(), NI_HEADER_HEIGHT);
	}
	else
	{
		this->DrawModernFrame(x, y, NEW_INVENTORY_CLASSIC_WIDTH, this->GetHeaderHeight());
	}

	this->RenderHeader(x, y);

	if (this->m_Wide)
	{
		this->RenderSections(This, x, y);
		this->RenderPreview(x, y);
	}
	else
	{
		this->RenderCompactSections(This, x, y);
	}

	*(DWORD*)0x008793258 = 0xFFFFFFFF;
	EnableAlphaTest(true);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

void CNewInventory::LoadImages()
{
	for (int i = 0; i < NI_ICON_COUNT; i++)
	{
		((int(__cdecl*)(char*, int, int, int, int, int))0x00772330)((char*)NI_IconFile[i], NI_ICON_FIRST + i, GL_LINEAR, GL_CLAMP, 1, 0);
	}
}

void CNewInventory::RenderRowButton(int x, int y, int index, int image, bool danger, bool marked, const char* tooltip)
{
	int left = x + this->GetCenterOffset() + NI_ROW_ORIGIN + (index * NI_ROW_STRIDE);
	int top = y + this->GetButtonOffsetY();

	if (this->DrawIconButton(left, top, NI_ROW_BUTTON_W, NI_ROW_BUTTON_H, image, danger, marked, false))
	{
		this->SetPendingTooltip(left + (NI_ROW_BUTTON_W / 2), top, tooltip, false);
	}
}

bool CNewInventory::DrawIconButton(int left, int top, int width, int height, int image, bool danger, bool marked, bool disabled)
{
	bool hover = !disabled && CheckMouseIn(left, top, width, height);
	bool pressed = hover && (*(BYTE*)0x8793384 != 0);
	float bx = (float)left;
	float by = (float)top;
	float bw = (float)width;
	float bh = (float)height;
	float lift = (hover) ? 0.05f : 0.0f;
	float bodyTop[4] = { 0.14f + lift, 0.13f + lift, 0.11f + lift, 0.97f };
	float bodyBottom[4] = { 0.05f, 0.048f, 0.045f, 0.97f };

	this->DrawGradient(bx, by, bw, bh, bodyTop, bodyBottom, 3);

	if (hover && danger)
	{
		this->DrawRect(bx + 1.0f, by + 1.0f, bw - 2.0f, bh - 2.0f, 0.62f, 0.10f, 0.08f, 0.30f);
	}
	else if (hover || marked)
	{
		this->DrawRect(bx + 1.0f, by + 1.0f, bw - 2.0f, bh - 2.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], (marked) ? 0.20f : 0.12f);
	}

	this->DrawRect(bx + 1.0f, by + 1.0f, bw - 2.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.06f);
	this->DrawAccentBorder(bx, by, bw, bh, (disabled) ? 0.25f : ((hover || marked) ? 1.0f : 0.55f));

	float size = (float)NI_ICON_SIZE;
	float ix = bx + ((bw - size) / 2.0f);
	float iy = by + ((bh - size) / 2.0f) + ((pressed) ? 1.0f : 0.0f);

	glPushAttrib(GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	RenderImage2(image, ix, iy, size, size, 0.0f, 0.0f, 1.0f, 1.0f, true, true, (disabled) ? 0.30f : ((hover || marked) ? 1.0f : 0.85f));
	glPopAttrib();

	return hover;
}

bool CNewInventory::RenderShopButton(DWORD button)
{
	if (!this->IsSkinned())
	{
		return false;
	}

	DWORD shop = (DWORD)pMyShopInventoryThis(pWindowThis());

	if (shop == 0 || *(DWORD*)(shop + NI_MYSHOP_BUTTONS) == 0 || button < *(DWORD*)(shop + NI_MYSHOP_BUTTONS))
	{
		return false;
	}

	int index = (int)((button - *(DWORD*)(shop + NI_MYSHOP_BUTTONS)) / NI_MYSHOP_BUTTON_SIZE);

	if (index > 2)
	{
		return false;
	}

	int left = *(int*)(button + 4);
	int top = *(int*)(button + 8);
	int width = *(int*)(button + 0x0C);
	int height = *(int*)(button + 0x10);
	bool open = *(BYTE*)(shop + NI_MYSHOP_OPEN) != 0;

	static const int icons[3] = { 0, NI_ICON_SHOP_OPEN, NI_ICON_SHOP_CLOSE };
	const char* tooltips[3] = { this->m_ButtonLabel[NEW_INVENTORY_LABEL_CLOSE], (open) ? "Atualizar Loja" : "Abrir Loja", "Fechar Loja" };

	bool disabled = (index == 2 && !open);

	if (this->DrawIconButton(left, top, width, height, NI_ICON_FIRST + icons[index], index != 1, index == 1 && open, disabled))
	{
		this->DrawTooltipIn(left + (width / 2), top, tooltips[index], false, 0, NEW_INVENTORY_SCREEN_WIDTH);
	}

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	return true;
}

void CNewInventory::RenderRowButtons(DWORD This)
{
	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);

	// Same rule as 0x837730: repair and personal shop hide while a trade-like window is open.
	static const int commerceBlockers[] = { 0x0C, 0x07, 0x13, 0x14, 0x09, 0x4C, 0x08 };
	// Same rule as LimparInventario.CheckRender.
	static const int trashBlockers[] = { ObjWindow::Warehouse, ObjWindow::Character, ObjWindow::ChaosBox, ObjWindow::Shop, ObjWindow::CashShop, ObjWindow::SkillTree, ObjWindow::FullMap, ObjWindow::Trade };

	bool commerce = true;
	bool trash = true;

	for (int i = 0; i < _countof(commerceBlockers) && commerce; i++)
	{
		commerce = !this->IsWindowOpen(commerceBlockers[i]);
	}

	for (int i = 0; i < _countof(trashBlockers) && trash; i++)
	{
		trash = !this->IsWindowOpen(trashBlockers[i]);
	}

	bool expanded = (*(int*)(This + NI_INVENTORY_EXPAND_STATE) == 1) || this->IsWindowOpen(ObjWindow::ExpandInventory);

	this->RenderRowButton(x, y, 0, NI_ICON_FIRST + 0, true, false, this->m_ButtonLabel[NEW_INVENTORY_LABEL_CLOSE]);

	if (commerce && *(BYTE*)(This + 0x404) == 1)
	{
		this->RenderRowButton(x, y, 1, NI_ICON_FIRST + 1, false, false, "Reparar Itens");
	}

	if (commerce && *(BYTE*)(This + 0x405) == 1)
	{
		this->RenderRowButton(x, y, 2, NI_ICON_FIRST + 2, false, false, "Loja Pessoal");
	}

	this->RenderRowButton(x, y, 3, NI_ICON_FIRST + 3, false, expanded, "Expandido");

	if (trash)
	{
		this->RenderRowButton(x, y, NI_ROW_CLEAR, NI_ICON_FIRST + 4, true, false, "Limpar Inventario");
	}

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

void CNewInventory::RenderHeader(int x, int y)
{
	int width = this->GetWidth();
	int headerHeight = this->GetHeaderHeight();
	int size = (this->m_Wide && width < 320) ? 14 : 16;
	int step = size + 2;
	int buttonY = y + ((headerHeight - size) / 2);
	int buttonX = x + width - 6 - size;
	bool overControls = false;
	bool tabs = gVisualInventory.InventoryVisualSwitch != 0;
	bool roomForTitle = true;

	if (tabs && this->m_Wide && this->GetTabRects()[0].x < 100)
	{
		roomForTitle = false;
	}

	// The compact header, and a shrunk wide header, have no room for the title next to the tabs.
	if (roomForTitle && (this->m_Wide || !tabs))
	{
		this->DrawLabel(x + ((this->m_Wide) ? 18 : 16), y + ((this->m_Wide) ? 10 : 6), GlobalText(223), 0, 1, 255, 255, 255, 255, true);
	}

	if (tabs)
	{
		this->RenderVisualTabs(x, y);

		NEW_INVENTORY_RECT* rects = this->GetTabRects();

		for (int i = 0; i < 2; i++)
		{
			overControls |= CheckMouseIn(x + rects[i].x, y + rects[i].y, rects[i].width, rects[i].height);
		}
	}

	if (this->m_CloseButton)
	{
		overControls |= CheckMouseIn(buttonX, buttonY, size, size);
		this->RenderHeaderButton(buttonX, buttonY, size, 0, true, this->m_ButtonLabel[NEW_INVENTORY_LABEL_CLOSE]);

		buttonX -= step;
	}

	if (this->m_AllowResize && !this->m_Forced)
	{
		bool large = this->m_SizeMode == NEW_INVENTORY_SIZE_LARGE;

		overControls |= CheckMouseIn(buttonX, buttonY, size, size);
		this->RenderHeaderButton(buttonX, buttonY, size, (large) ? 1 : 2, false, this->m_ButtonLabel[(large) ? NEW_INVENTORY_LABEL_SHRINK : NEW_INVENTORY_LABEL_EXPAND]);

		buttonX -= step;
	}

	if (this->m_AllowMove && this->m_Floating && this->m_Managed)
	{
		overControls |= CheckMouseIn(buttonX, buttonY, size, size);
		this->RenderHeaderButton(buttonX, buttonY, size, 3, false, this->m_ButtonLabel[NEW_INVENTORY_LABEL_DOCK]);

		buttonX -= step;
	}

	if (this->m_Wide)
	{
		bool setVisible = this->m_ShowSet != 0;
		bool accessoriesVisible = this->m_ShowAccessories != 0;

		overControls |= CheckMouseIn(buttonX, buttonY, size, size);
		this->RenderHeaderButton(buttonX, buttonY, size, 5, false,
			this->m_ButtonLabel[accessoriesVisible ? NEW_INVENTORY_LABEL_HIDE_ACC : NEW_INVENTORY_LABEL_SHOW_ACC], accessoriesVisible);

		buttonX -= step;
		overControls |= CheckMouseIn(buttonX, buttonY, size, size);
		this->RenderHeaderButton(buttonX, buttonY, size, 4, false,
			this->m_ButtonLabel[setVisible ? NEW_INVENTORY_LABEL_HIDE_SET : NEW_INVENTORY_LABEL_SHOW_SET], setVisible);
	}

	if (this->m_AllowMove && this->m_Managed)
	{
		this->DrawGrip(x + 7, y + (headerHeight / 2) - 3, !overControls && CheckMouseIn(x, y, width, headerHeight));
	}

	this->HandleDrag(x, y, width);
}

bool CNewInventory::RenderHeaderButton(int x, int y, int size, int icon, bool danger, const char* tooltip, bool marked)
{
	bool hover = CheckMouseIn(x, y, size, size);

	if (hover && danger)
	{
		this->DrawRect((float)x, (float)y, (float)size, (float)size, 0.62f, 0.12f, 0.10f, 0.95f);
	}
	else if (marked)
	{
		this->DrawRect((float)x, (float)y, (float)size, (float)size, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.95f);
	}
	else if (hover)
	{
		this->DrawRect((float)x, (float)y, (float)size, (float)size, this->m_Accent[0] * 0.40f, this->m_Accent[1] * 0.40f, this->m_Accent[2] * 0.40f, 0.95f);
	}
	else
	{
		this->DrawRect((float)x, (float)y, (float)size, (float)size, 0.06f, 0.06f, 0.07f, 0.92f);
	}

	this->DrawAccentBorder((float)x, (float)y, (float)size, (float)size, (hover) ? 0.9f : 0.5f);

	float r = (marked) ? 0.15f : ((hover) ? 1.0f : 0.86f);
	float g = (marked) ? 0.12f : ((hover) ? 1.0f : 0.80f);
	float b = (marked) ? 0.05f : ((hover) ? 1.0f : 0.70f);
	float cx = (float)x + (float)size / 2.0f;
	float cy = (float)y + (float)size / 2.0f;

	switch (icon)
	{
	case 0: // close
		this->DrawLabel(x, y + (size - 10) / 2, "X", size, 3, 255, (hover) ? 255 : 220, (hover) ? 255 : 190, 255, true);
		break;
	case 1: // shrink
		this->DrawRect(cx - 4.0f, cy + 1.0f, 8.0f, 2.0f, r, g, b, 1.0f);
		break;
	case 2: // expand
		this->DrawBorder(cx - 4.0f, cy - 4.0f, 9.0f, 8.0f, r, g, b, 1.0f);
		this->DrawRect(cx - 4.0f, cy - 4.0f, 9.0f, 2.0f, r, g, b, 1.0f);
		break;
	case 3: // dock
		this->DrawBorder(cx - 5.0f, cy - 4.0f, 10.0f, 8.0f, r, g, b, 1.0f);
		this->DrawRect(cx - 5.0f, cy - 4.0f, 4.0f, 8.0f, r, g, b, 1.0f);
		break;
	case 4: // set column
		this->DrawRect((float)x + 3.0f, (float)y + 3.0f, 3.0f, (float)size - 6.0f, r, g, b, 1.0f);
		this->DrawRect((float)x + 8.0f, (float)y + 4.0f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		this->DrawRect((float)x + 8.0f, (float)y + 7.5f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		this->DrawRect((float)x + 8.0f, (float)y + 11.0f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		break;
	case 5: // accessories column
		this->DrawRect((float)x + (float)size - 6.0f, (float)y + 3.0f, 3.0f, (float)size - 6.0f, r, g, b, 1.0f);
		this->DrawRect((float)x + 3.0f, (float)y + 4.0f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		this->DrawRect((float)x + 3.0f, (float)y + 7.5f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		this->DrawRect((float)x + 3.0f, (float)y + 11.0f, (float)size - 11.0f, 1.5f, r, g, b, 0.7f);
		break;
	}

	if (!hover)
	{
		return false;
	}

	this->SetPendingTooltip(x + (size / 2), y + size, tooltip, true);
	return false;
}

void CNewInventory::HandleDrag(int x, int y, int width)
{
	if (this->m_AllowMove == 0 || !this->m_Managed)
	{
		this->m_Dragging = false;
		return;
	}

	if (!this->m_Dragging)
	{
		return;
	}

	// The game's key table may not report the button as held on the press frame, so read the hardware state.
	if ((GetAsyncKeyState(VK_LBUTTON) & 0x8000) == 0)
	{
		// Keep the snapped position so the window does not jump when companions close.
		this->m_Dragging = false;
		this->m_FloatX = x - ((this->m_Wide) ? this->HiddenSetShift() : 0);
		this->m_FloatY = y;
		this->SaveUserSettings();
		return;
	}

	this->m_FloatX = NI_Clamp(pCursorX - this->m_DragOffsetX, 0, NEW_INVENTORY_SCREEN_WIDTH - width) - ((this->m_Wide) ? this->HiddenSetShift() : 0);
	this->m_FloatY = NI_Clamp(pCursorY - this->m_DragOffsetY, 0, NEW_INVENTORY_SCREEN_HEIGHT - NEW_INVENTORY_HEIGHT);

	ResetMouseL();
}

void CNewInventory::RenderVisualTabs(int x, int y)
{
	if (gVisualInventory.InventoryVisualSwitch == 0)
	{
		return;
	}

	NEW_INVENTORY_RECT* rects = this->GetTabRects();

	for (int i = 0; i < 2; i++)
	{
		NEW_INVENTORY_RECT* rect = &rects[i];

		bool active = ((gVisualInventory.InventoryVisualOpen != 0) == (i == 1));

		// Clicks are handled by VisualInventory::Update, here it is only drawn.
		bool hover = CheckMouseIn(x + rect->x, y + rect->y, rect->width, rect->height);

		if (active)
		{
			float top[4] = { this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.95f };
			float bottom[4] = { this->m_Accent[0] * 0.65f, this->m_Accent[1] * 0.65f, this->m_Accent[2] * 0.65f, 0.95f };
			this->DrawGradient((float)(x + rect->x), (float)(y + rect->y), (float)rect->width, (float)rect->height, top, bottom, 4);
			this->DrawLabel(x + rect->x, y + rect->y + 3, this->m_TabLabel[i], rect->width, 3, 25, 20, 10, 255, true);
		}
		else
		{
			this->DrawRect((float)(x + rect->x), (float)(y + rect->y), (float)rect->width, (float)rect->height,
				(hover) ? 0.20f : 0.06f, (hover) ? 0.18f : 0.06f, (hover) ? 0.14f : 0.07f, 0.92f);
			this->DrawLabel(x + rect->x, y + rect->y + 3, this->m_TabLabel[i], rect->width, 3, (hover) ? 255 : 170, (hover) ? 240 : 170, (hover) ? 210 : 170, 255, false);
		}
	}

	int left = rects[0].x;
	int right = rects[1].x + rects[1].width;

	this->DrawAccentBorder((float)(x + left), (float)(y + rects[0].y), (float)(right - left), (float)rects[0].height, 0.7f);
}

void CNewInventory::RenderSlotWells(DWORD This, int x, int y)
{
	for (int i = 0; i < NEW_INVENTORY_MAX_SLOTS; i++)
	{
		int* slot = (int*)(This + NI_INVENTORY_SLOTS + (i * NI_INVENTORY_SLOT_SIZE));

		if (slot[0] < 0 || slot[1] < 0 || slot[0] > 700 || slot[1] > 700)
		{
			continue;
		}

		this->DrawRect((float)(slot[0] - 1), (float)(slot[1] - 1), (float)(slot[2] + 2), (float)(slot[3] + 2), 0.0f, 0.0f, 0.0f, 0.45f);
	}

	if (gVisualInventory.CheckVisualOpen())
	{
		return;
	}

	for (int i = 0; i < NEW_INVENTORY_MAX_ELEMENTS; i++)
	{
		if (gElementSlots.m_ElementEquiped[i].Active == 0)
		{
			continue;
		}

		float ex = (float)(x + gElementSlots.m_ElementEquiped[i].x);
		float ey = (float)(y + gElementSlots.m_ElementEquiped[i].y);

		if (ex < 0.0f || ey < 0.0f || ex > 700.0f || ey > 700.0f)
		{
			continue;
		}
		float ew = (float)gElementSlots.m_ElementEquiped[i].width;
		float eh = (float)gElementSlots.m_ElementEquiped[i].height;

		this->DrawRect(ex - 1.0f, ey - 1.0f, ew + 2.0f, eh + 2.0f, 0.0f, 0.0f, 0.0f, 0.45f);
	}
}

void CNewInventory::RenderSections(DWORD This, int x, int y)
{
	int shift = this->GetContentShift();
	int center = x + this->GetCenterOffset();

	if (this->m_Style != 0)
	{
		if (this->m_ShowSet != 0)
		{
			this->DrawCard(x + 6, y + 46, 56, 280, this->m_SectionLabel[0]);
		}

		if (this->m_ShowAccessories != 0)
		{
			this->DrawCard(x + 260 + shift, y + 46, 114, 280, this->m_SectionLabel[2]);
		}

		this->DrawCard(center + 12, y + this->m_GridY - 3, 166, 166, nullptr);
		this->DrawRect((float)(center + 10), (float)(y + this->m_ButtonY - 4), 170.0f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.25f);
		this->RenderSlotWells(This, x, y);
	}
}

void CNewInventory::RenderCompactSections(DWORD This, int x, int y)
{
	if (this->m_Style != 0)
	{
		this->DrawCard(x + 12, y + 197, 166, 166, nullptr);
		this->DrawRect((float)(x + 10), (float)(y + this->m_CompactButtonY - 2), 170.0f, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.25f);
		this->RenderSlotWells(This, x, y);
	}
}

void CNewInventory::RenderTitleAndCoins(DWORD This)
{
	if (!this->IsSkinned())
	{
		NI_RenderTitleAndZen(This);
		return;
	}

	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);

	this->RenderCoins(x, y, (this->m_Wide) ? this->m_CoinRect : this->m_CompactCoinRect);
}

void CNewInventory::RenderCoins(int x, int y, NEW_INVENTORY_RECT* rects)
{
	EnableAlphaTest(true);

	for (int i = 0; i < NEW_INVENTORY_MAX_COINS; i++)
	{
		NEW_INVENTORY_COIN* coin = &this->m_Coin[i];

		if (coin->Label[0] == 0 || coin->ValueIndex < 0)
		{
			continue;
		}

		char value[64] = { 0 };
		BYTE color[4] = { coin->Color[0], coin->Color[1], coin->Color[2], coin->Color[3] };

		DWORD amount = this->GetCoinValue(coin->ValueIndex);

		if (coin->ValueIndex == 0)
		{
			NI_ConvertGold((double)amount, value, 0);

			DWORD gold = NI_GetGoldColor(amount);

			color[0] = (BYTE)(gold & 0xFF);
			color[1] = (BYTE)((gold >> 8) & 0xFF);
			color[2] = (BYTE)((gold >> 16) & 0xFF);
			color[3] = 255;
		}
		else
		{
			this->FormatNumber(amount, value, sizeof(value));
		}

		NEW_INVENTORY_RECT* rect = &rects[i];
		int shift = (rects == this->m_CoinRect) ? this->GetContentShift() : 0;

		this->DrawCoinBox(x + rect->x + shift, y + rect->y, rect->width, rect->height, coin->Label, value, color);
	}

	pTextSetFont(pTextThis(), g_hFont);
	pSetTextColor(pTextThis(), 255, 255, 255, 255);
	pGLSwitch();
}

void CNewInventory::RenderEquipmentOverlay(DWORD This)
{
	if (!this->IsSkinned())
	{
		return;
	}

	EnableAlphaTest(true);

	if (this->m_TooltipPending)
	{
		this->m_TooltipPending = false;
		this->DrawTooltip(this->m_TooltipX, this->m_TooltipY, this->m_TooltipText, this->m_TooltipBelow);
		pGLSwitch();
		return;
	}

	if (this->m_Dragging)
	{
		return;
	}

	int x = *(int*)(This + NI_INVENTORY_POS_X);
	int y = *(int*)(This + NI_INVENTORY_POS_Y);
	bool visual = gVisualInventory.CheckVisualOpen() != 0;

	int hovered = -1;
	NEW_INVENTORY_RECT rect = { 0, 0, 0, 0 };

	for (int i = 0; i < NEW_INVENTORY_MAX_SLOTS && hovered < 0; i++)
	{
		if (visual && i > 8)
		{
			continue;
		}

		int* slot = (int*)(This + NI_INVENTORY_SLOTS + (i * NI_INVENTORY_SLOT_SIZE));

		if (slot[0] < 0 || slot[1] < 0 || slot[0] > 700 || slot[1] > 700)
		{
			continue;
		}

		if (CheckMouseIn(slot[0], slot[1], slot[2], slot[3]))
		{
			hovered = i;
			rect = { slot[0], slot[1], slot[2], slot[3] };
		}
	}

	for (int i = 0; i < NEW_INVENTORY_MAX_ELEMENTS && hovered < 0 && !visual; i++)
	{
		if (gElementSlots.m_ElementEquiped[i].Active == 0)
		{
			continue;
		}

		int ex = x + gElementSlots.m_ElementEquiped[i].x;
		int ey = y + gElementSlots.m_ElementEquiped[i].y;

		if (ex < 0 || ey < 0 || ex > 700 || ey > 700)
		{
			continue;
		}
		int ew = gElementSlots.m_ElementEquiped[i].width;
		int eh = gElementSlots.m_ElementEquiped[i].height;

		if (CheckMouseIn(ex, ey, ew, eh))
		{
			hovered = NEW_INVENTORY_MAX_SLOTS + i;
			rect = { ex, ey, ew, eh };
		}
	}

	if (hovered < 0)
	{
		return;
	}

	this->DrawRect((float)rect.x, (float)rect.y, (float)rect.width, (float)rect.height, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.10f);
	this->DrawAccentBorder((float)(rect.x - 2), (float)(rect.y - 2), (float)(rect.width + 4), (float)(rect.height + 4), 1.0f);

	bool empty = true;

	if (hovered >= NEW_INVENTORY_MAX_SLOTS)
	{
		ITEM* item = gElementSlots.getItemElement(236 + (hovered - NEW_INVENTORY_MAX_SLOTS));
		empty = (item == nullptr || item->Type == -1);
	}
	else if (visual)
	{
		empty = !gVisualInventory.CheckItemExist(240 + hovered);
	}
	else if (NI_CharacterAttribute)
	{
		empty = *(short*)(NI_CharacterAttribute + NI_EQUIPMENT_ITEMS + (NI_ITEM_SIZE * hovered)) == -1;
	}

	if (empty)
	{
		this->DrawTooltip(rect.x + (rect.width / 2), rect.y - 1, this->m_SlotName[hovered], false);
	}

	pGLSwitch();
}

void CNewInventory::RenderPreview(int x, int y)
{
	int px = x + this->m_PreviewRect.x + this->GetContentShift();
	int py = y + this->m_PreviewRect.y;
	int pw = this->m_PreviewRect.width;
	int ph = this->m_PreviewRect.height;

	NEW_INVENTORY_RECT toggle, mount;
	this->GetPreviewControlRects(px, py, &toggle, &mount);

	if (this->m_PreviewEnabled != 0 && !this->m_PreviewVisible)
	{
		char label[48];
		sprintf_s(label, "%s 3D", this->m_PreviewShowLabel);

		this->m_PreviewDragging = false;
		this->DrawButton(toggle.x, toggle.y, toggle.width, toggle.height, label, false, false);
		return;
	}

	this->DrawCard(px - 2, py - 2, pw + 4, ph + 4, this->m_SectionLabel[1]);

	if (this->m_PreviewEnabled == 0)
	{
		return;
	}

	float top[4] = { 0.16f, 0.15f, 0.17f, 0.92f };
	float bottom[4] = { 0.02f, 0.02f, 0.03f, 0.92f };
	this->DrawGradient((float)px, (float)py, (float)pw, (float)ph, top, bottom, 3);

	// Soft floor glow under the character.
	this->DrawRect((float)(px + pw / 2 - 42), (float)(py + ph - 26), 84.0f, 6.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.06f);
	this->DrawRect((float)(px + pw / 2 - 28), (float)(py + ph - 25), 56.0f, 4.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.10f);

	int barHeight = 15;
	int barY = py + ph - barHeight;

	int toggleWidth = 38;
	int toggleX = px + pw - toggleWidth - 3;
	int rotateRightX = toggleX - 16;
	int rotateLeftX = rotateRightX - 16;
	int controlY = barY + 2;
	int controlHeight = 11;

	bool overControls = CheckMouseIn(px, barY, pw, barHeight)
		|| (this->m_PreviewHasMount && CheckMouseIn(mount.x, mount.y, mount.width, mount.height));

	DWORD pickedManager = NI_GetPickedItemManager();
	ITEM* picked = (pickedManager) ? NI_GetPickedItem(pickedManager) : nullptr;

	if (!overControls && picked == nullptr && IsRepeatKey(VK_LBUTTON) && (this->m_PreviewDragging || CheckMouseIn(px, py, pw, ph)))
	{
		if (this->m_PreviewDragging)
		{
			this->m_PreviewAngle += (float)(pCursorX - this->m_PreviewLastMouseX) * this->m_PreviewRotateSpeed;
		}

		this->m_PreviewDragging = true;
		this->m_PreviewLastMouseX = pCursorX;
	}
	else
	{
		this->m_PreviewDragging = false;
	}

	while (this->m_PreviewAngle > 180.0f) this->m_PreviewAngle -= 360.0f;
	while (this->m_PreviewAngle < -180.0f) this->m_PreviewAngle += 360.0f;

	this->RenderCharacterModel(px + 1, py + 1, pw - 2, ph - 2);

	if (CheckMouseIn(px, py, pw, ph) && !overControls && !this->m_PreviewDragging)
	{
		this->DrawLabel(px, py + ph - barHeight - 12, this->m_PreviewHintLabel, pw, 3, 170, 170, 170, 200, false);
	}

	if (this->m_PreviewHasMount)
	{
		this->DrawButton(mount.x, mount.y, mount.width, mount.height, this->m_PreviewMountLabel, this->m_PreviewMounted != 0, false);
	}

	this->DrawRect((float)px, (float)barY, (float)pw, (float)barHeight, 0.0f, 0.0f, 0.0f, 0.6f);
	this->DrawRect((float)px, (float)barY, (float)pw, 1.0f, this->m_Accent[0], this->m_Accent[1], this->m_Accent[2], 0.35f);

	if (NI_CharacterAttribute)
	{
		char name[16] = { 0 };
		char level[16] = { 0 };

		memcpy(name, (char*)NI_CharacterAttribute, 10);
		sprintf_s(level, "Lv %d", *(short*)(NI_CharacterAttribute + 14));

		this->DrawLabel(px + 5, barY + 2, name, 0, 1, 255, 255, 255, 255, true);

		pTextSetFont(pTextThis(), g_hFontBold);
		int nameWidth = this->GetTextWidth(name);

		this->DrawLabel(px + 9 + nameWidth, barY + 2, level, 0, 1,
			(BYTE)(this->m_Accent[0] * 255.0f), (BYTE)(this->m_Accent[1] * 255.0f), (BYTE)(this->m_Accent[2] * 255.0f), 255, false);
	}

	this->DrawButton(rotateLeftX, controlY, 14, controlHeight, "<", false, false);
	this->DrawButton(rotateRightX, controlY, 14, controlHeight, ">", false, false);
	this->DrawButton(toggleX, controlY, toggleWidth, controlHeight, this->m_PreviewHideLabel, false, false);

	this->DrawAccentBorder((float)px, (float)py, (float)pw, (float)ph, 0.55f);
}

void CNewInventory::RenderCharacterModel(int x, int y, int width, int height)
{
	if (*(int*)0x00E609E8 != 5 || oUserPreviewStruct == 0)
	{
		return;
	}

	ObjectPreview* character = (ObjectPreview*)oUserPreviewStruct;
	ObjectModel* object = &character->Object;

	if (!object->Live)
	{
		return;
	}

	BYTE cameraMatrix[48];
	BYTE perspective[20];
	BYTE viewport[16];
	float cameraAngle[3];
	float cameraPosition[3];
	float objectAngle[3];
	float objectLight[3];

	memcpy(cameraMatrix, (void*)NI_CameraMatrix, sizeof(cameraMatrix));
	memcpy(perspective, (void*)NI_PerspectiveInfo, sizeof(perspective));
	memcpy(viewport, (void*)NI_ViewportInfo, sizeof(viewport));
	memcpy(cameraAngle, (void*)NI_CameraAngle, sizeof(cameraAngle));
	memcpy(cameraPosition, (void*)NI_CameraPosition, sizeof(cameraPosition));
	memcpy(objectAngle, object->Angle, sizeof(objectAngle));
	memcpy(objectLight, object->Light, sizeof(objectLight));

	float cameraFov = *(float*)NI_CameraFov;
	BYTE cameraTopView = *(BYTE*)NI_CameraTopView;
	BYTE cameraFog = *(BYTE*)NI_CameraFog;

	int visualPet = -1;

	if (gVisualInventory.CheckItemExist(248))
	{
		ITEM* petItem = gVisualInventory.getItem(248);

		if (petItem != nullptr)
		{
			visualPet = petItem->Type;
		}
	}

	HELPER_VIEW* helper = gHelperManager.GetPreviewHelper(character, visualPet);

	this->m_PreviewHasMount = (helper != nullptr && helper->IsMount());

	bool mounted = this->m_PreviewMounted != 0 && this->m_PreviewHasMount;

	NI_EndBitmap();

	*(BYTE*)NI_CameraTopView = 0;
	*(BYTE*)NI_CameraFog = 0;
	*(float*)NI_CameraFov = this->m_PreviewFov;

	float target[3] = { object->Position[0], object->Position[1], object->Position[2] + this->m_PreviewHeight + ((mounted) ? 25.0f : 0.0f) };
	float offset[3] = { 0.0f, -this->m_PreviewDistance * ((mounted) ? 1.25f : 1.0f), 0.0f };
	float angle[3] = { -90.0f, 0.0f, 0.0f };

	NI_SetCamera(target, offset, angle);
	NI_BeginOpengl(x, y, width, height);

	int windowWidth = pWinWidth;
	int windowHeight = pWinHeight;
	int sx = (x * windowWidth) / 640;
	int sy = (y * windowHeight) / 480;
	int sw = (width * windowWidth) / 640;
	int sh = (height * windowHeight) / 480;

	glEnable(GL_SCISSOR_TEST);
	glScissor(sx, windowHeight - (sy + sh), sw, sh);
	glClear(GL_DEPTH_BUFFER_BIT);

	object->Angle[0] = 0.0f;
	object->Angle[1] = 0.0f;
	object->Angle[2] = this->m_PreviewAngle;
	object->Light[0] = 1.0f;
	object->Light[1] = 1.0f;
	object->Light[2] = 1.0f;

	bool safeZone = character->InSafeZone;
	BYTE stopFlag = *(BYTE*)((DWORD)character + 0x25);
	WORD action = object->CurrentAction;
	WORD priorAction = object->PriorAction;
	float frame = object->AnimationFrame;
	float priorFrame = object->PriorAnimationFrame;

	if (mounted)
	{
		// SetPlayerStop only picks the riding pose outside the safe zone; the flag stays cleared while the character is drawn.
		// Pet mode would also refuse the riding pose, so it is held off for this draw.
		gPetMode.Suspend(true);
		character->InSafeZone = false;
		NI_SetPlayerStop(character);
		this->AnimateMountedPose(object);
	}

	NI_RenderCharacter(character, object, 0);
	gHelperManager.RenderPreview(character, helper, this->m_PreviewAngle - objectAngle[2], mounted);

	if (mounted)
	{
		gPetMode.Suspend(false);
		character->InSafeZone = safeZone;
		*(BYTE*)((DWORD)character + 0x25) = stopFlag;
		object->CurrentAction = action;
		object->PriorAction = priorAction;
		object->AnimationFrame = frame;
		object->PriorAnimationFrame = priorFrame;
	}

	memcpy(object->Angle, objectAngle, sizeof(objectAngle));
	memcpy(object->Light, objectLight, sizeof(objectLight));

	glClear(GL_DEPTH_BUFFER_BIT);
	glDisable(GL_SCISSOR_TEST);

	NI_Viewport(0, 0, windowWidth, windowHeight);
	NI_EndOpengl();

	memcpy((void*)NI_CameraMatrix, cameraMatrix, sizeof(cameraMatrix));
	memcpy((void*)NI_PerspectiveInfo, perspective, sizeof(perspective));
	memcpy((void*)NI_ViewportInfo, viewport, sizeof(viewport));
	memcpy((void*)NI_CameraAngle, cameraAngle, sizeof(cameraAngle));
	memcpy((void*)NI_CameraPosition, cameraPosition, sizeof(cameraPosition));

	*(float*)NI_CameraFov = cameraFov;
	*(BYTE*)NI_CameraTopView = cameraTopView;
	*(BYTE*)NI_CameraFog = cameraFog;

	NI_BeginBitmap();

	*(DWORD*)0x008793258 = 0xFFFFFFFF;
	EnableAlphaTest(true);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

// The real character keeps animating its own (standing) action, so the riding pose runs on frames owned by the preview.
void CNewInventory::AnimateMountedPose(ObjectModel* object)
{
	if (object->CurrentAction != this->m_MountAction)
	{
		this->m_MountAction = object->CurrentAction;
		this->m_MountPriorAction = object->CurrentAction;
		this->m_MountFrame = 0.0f;
		this->m_MountPriorFrame = 0.0f;
	}

	object->PriorAction = this->m_MountPriorAction;
	object->AnimationFrame = this->m_MountFrame;
	object->PriorAnimationFrame = this->m_MountPriorFrame;

	DWORD now = GetTickCount();

	if (now - this->m_MountTick < 40)
	{
		return;
	}

	this->m_MountTick = now;

	DWORD model = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), object->Type);

	if (model != 0)
	{
		*(WORD*)(model + 160) = object->CurrentAction;

		((bool(__thiscall*)(DWORD*, int, int, int, float, vec3_t, vec3_t))0x00545180)
			((DWORD*)model, (int)&object->AnimationFrame, (int)&object->PriorAnimationFrame, (int)&object->PriorAction, 0.25f, object->Position, object->Angle);
	}

	this->m_MountPriorAction = object->PriorAction;
	this->m_MountFrame = object->AnimationFrame;
	this->m_MountPriorFrame = object->PriorAnimationFrame;
}
