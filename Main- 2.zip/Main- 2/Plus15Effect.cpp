#include "stdafx.h"
#include "Plus15Effect.h"
#include "Offset.h"
#include "Util.h"
#include <math.h>

Plus15Effect gPlus15Effect;

namespace
{
	// Névoa fraca: silhouette permanece, textura some
	const float kMinAlpha = 0.26f;
	const float kPeriodMs = 14000.0f;

	float Clamp01(float v)
	{
		if (v < 0.0f) return 0.0f;
		if (v > 1.0f) return 1.0f;
		return v;
	}

	float Smooth(float t)
	{
		t = Clamp01(t);
		return t * t * (3.0f - 2.0f * t);
	}

	float Lerp(float a, float b, float t)
	{
		return a + (b - a) * Clamp01(t);
	}
}

Plus15Effect::Plus15Effect()
{
	this->m_Enabled = true;
	this->m_BodyCaptured = false;
	this->m_LinkCaptured = false;
}

bool Plus15Effect::IsItemLevel(int level)
{
	if (level < 0) {
		return false;
	}

	if ((level & 0xF) == 15) {
		return true;
	}

	if (((level >> 3) & 0xF) == 15) {
		return true;
	}

	return false;
}

int Plus15Effect::ResolveItemLevel(int level, PART_t* part)
{
	if (part != 0 && Plus15Effect::IsItemLevel(part->Level)) {
		return part->Level;
	}

	return level;
}

Plus15Effect::Stage Plus15Effect::Mix(const Stage& a, const Stage& b, float t)
{
	t = Smooth(t);
	Stage out;
	out.Alpha = Lerp(a.Alpha, b.Alpha, t);
	out.LightR = Lerp(a.LightR, b.LightR, t);
	out.LightG = Lerp(a.LightG, b.LightG, t);
	out.LightB = Lerp(a.LightB, b.LightB, t);
	out.Glow = Lerp(a.Glow, b.Glow, t);
	out.Intensity = Lerp(a.Intensity, b.Intensity, t);
	out.Wash = Lerp(a.Wash, b.Wash, t);
	out.Smoke = Lerp(a.Smoke, b.Smoke, t);
	return out;
}

Plus15Effect::Pulse Plus15Effect::Sample()
{
	// normal → névoa laranja → some → névoa rosa → some → névoa ciano → some → normal
	float u = fmodf((float)GetTickCount(), kPeriodMs) / kPeriodMs;
	float drift = (float)GetTickCount() * 0.00008f;

	// Alpha / Wash / Smoke / RGB suave (névoa fraca)
	static const Stage kNormal = { 1.00f, 1.00f, 1.00f, 1.00f, 0.00f, 0.00f, 0.00f, 0.00f };
	static const Stage kOrange = { 0.40f, 1.55f, 0.78f, 0.28f, 0.55f, 1.00f, 0.92f, 0.85f };
	static const Stage kPink = { 0.36f, 1.35f, 0.48f, 1.15f, 0.60f, 1.00f, 0.94f, 0.82f };
	static const Stage kCyan = { 0.30f, 0.42f, 1.05f, 1.45f, 0.68f, 1.00f, 0.96f, 0.78f };
	// Fumaça sumindo entre cores (quase some, sem apagar silhouette)
	static const Stage kGap = { 0.72f, 0.90f, 0.95f, 1.05f, 0.12f, 0.22f, 0.35f, 0.12f };

	Stage stage;
	if (u < 0.12f) {
		// Textura some e vira névoa laranja
		stage = Mix(kNormal, kOrange, u / 0.12f);
	}
	else if (u < 0.22f) {
		stage = kOrange;
	}
	else if (u < 0.32f) {
		// Laranja some
		stage = Mix(kOrange, kGap, (u - 0.22f) / 0.10f);
	}
	else if (u < 0.42f) {
		// Rosa aparece
		stage = Mix(kGap, kPink, (u - 0.32f) / 0.10f);
	}
	else if (u < 0.52f) {
		stage = kPink;
	}
	else if (u < 0.62f) {
		// Rosa some
		stage = Mix(kPink, kGap, (u - 0.52f) / 0.10f);
	}
	else if (u < 0.72f) {
		// Ciano aparece
		stage = Mix(kGap, kCyan, (u - 0.62f) / 0.10f);
	}
	else if (u < 0.82f) {
		stage = kCyan;
	}
	else {
		// Ciano some até a cor/textura padrão
		stage = Mix(kCyan, kNormal, (u - 0.82f) / 0.18f);
	}

	if (stage.Alpha < kMinAlpha) {
		stage.Alpha = kMinAlpha;
	}

	Pulse pulse;
	pulse.Intensity = stage.Intensity;
	pulse.Wash = stage.Wash;
	pulse.Smoke = stage.Smoke;
	pulse.Alpha = stage.Alpha;
	pulse.LightR = stage.LightR;
	pulse.LightG = stage.LightG;
	pulse.LightB = stage.LightB;
	pulse.Glow = stage.Glow * (0.55f + stage.Smoke * 0.45f);
	pulse.ScrollU = sinf(drift) * 0.035f * stage.Smoke;
	pulse.ScrollV = cosf(drift * 0.85f) * 0.028f * stage.Smoke;
	return pulse;
}

void Plus15Effect::TintLight(vec3_t light, const Pulse& pulse)
{
	float intensity = Clamp01(pulse.Intensity);
	float wash = Clamp01(pulse.Wash);

	if (intensity <= 0.001f) {
		return;
	}

	// Substitui a textura por cor de névoa (wash alto = só fumaça colorida)
	float mistR = pulse.LightR * (0.55f + pulse.Smoke * 0.45f);
	float mistG = pulse.LightG * (0.55f + pulse.Smoke * 0.45f);
	float mistB = pulse.LightB * (0.55f + pulse.Smoke * 0.45f);

	float tintedR = light[0] * pulse.LightR;
	float tintedG = light[1] * pulse.LightG;
	float tintedB = light[2] * pulse.LightB;

	float r = Lerp(tintedR, mistR, wash);
	float g = Lerp(tintedG, mistG, wash);
	float b = Lerp(tintedB, mistB, wash);

	light[0] = Lerp(light[0], r, intensity);
	light[1] = Lerp(light[1], g, intensity);
	light[2] = Lerp(light[2], b, intensity);

	if (light[0] > 1.85f) light[0] = 1.85f;
	if (light[1] > 1.85f) light[1] = 1.85f;
	if (light[2] > 1.85f) light[2] = 1.85f;
}

void Plus15Effect::Capture(ObjectModel* object, SavedLook& saved)
{
	saved.AlphaEnable = object->AlphaEnable;
	saved.ContrastEnable = object->ContrastEnable;
	saved.Alpha = object->Alpha;
	saved.AlphaTarget = object->AlphaTarget;
	saved.BlendMeshLight = object->BlendMeshLight;
	saved.BlendMeshTexCoordU = object->BlendMeshTexCoordU;
	saved.BlendMeshTexCoordV = object->BlendMeshTexCoordV;
	saved.BlendMesh = object->BlendMesh;
	saved.Light[0] = object->Light[0];
	saved.Light[1] = object->Light[1];
	saved.Light[2] = object->Light[2];
}

void Plus15Effect::Restore(ObjectModel* object, const SavedLook& saved)
{
	object->AlphaEnable = saved.AlphaEnable;
	object->ContrastEnable = saved.ContrastEnable;
	object->Alpha = saved.Alpha;
	object->AlphaTarget = saved.AlphaTarget;
	object->BlendMeshLight = saved.BlendMeshLight;
	object->BlendMeshTexCoordU = saved.BlendMeshTexCoordU;
	object->BlendMeshTexCoordV = saved.BlendMeshTexCoordV;
	object->BlendMesh = saved.BlendMesh;
	object->Light[0] = saved.Light[0];
	object->Light[1] = saved.Light[1];
	object->Light[2] = saved.Light[2];
}

void Plus15Effect::Apply(ObjectModel* object, const Pulse& pulse, float baseAlpha)
{
	float intensity = Clamp01(pulse.Intensity);
	float smoke = Clamp01(pulse.Smoke);
	float wash = Clamp01(pulse.Wash);

	float mistAlpha = Lerp(baseAlpha, baseAlpha * pulse.Alpha, intensity);
	if (mistAlpha < kMinAlpha) {
		mistAlpha = kMinAlpha;
	}
	if (mistAlpha > 1.0f) {
		mistAlpha = 1.0f;
	}

	if (intensity > 0.001f) {
		object->AlphaEnable = true;
	}

	object->Alpha = mistAlpha;
	object->AlphaTarget = mistAlpha;
	object->ContrastEnable = false;

	vec3_t light;
	light[0] = object->Light[0];
	light[1] = object->Light[1];
	light[2] = object->Light[2];
	Plus15Effect::TintLight(light, pulse);
	object->Light[0] = light[0];
	object->Light[1] = light[1];
	object->Light[2] = light[2];

	// Blend suave tipo névoa (sem ligar/desligar brusco)
	float mistAmount = intensity * (0.35f + smoke * 0.65f) * (0.40f + wash * 0.60f);
	if (mistAmount > 0.08f) {
		object->BlendMesh = -2;
		object->BlendMeshLight = Lerp(object->BlendMeshLight, pulse.Glow * 0.55f, mistAmount);
		object->BlendMeshTexCoordU = pulse.ScrollU;
		object->BlendMeshTexCoordV = pulse.ScrollV;
	}
}

bool Plus15Effect::BodyHasPlus15(ObjectModel* object)
{
	if (object == 0 || object->Kind != 1) {
		return false;
	}

	lpViewObj view = (lpViewObj)((BYTE*)object - 776);

	if (&view->Object != object) {
		return false;
	}

	for (int i = BODYPART_HELM; i <= BODYPART_BOOTS; i++) {
		if (view->BodyPart[i].Type > 0 && Plus15Effect::IsItemLevel(view->BodyPart[i].Level)) {
			return true;
		}
	}

	if (view->WeaponFirstSlot > 0 && Plus15Effect::IsItemLevel(view->WeaponFirstLevel)) {
		return true;
	}

	if (view->WeaponSecondSlot > 0 && Plus15Effect::IsItemLevel(view->WeaponSecondLevel)) {
		return true;
	}

	if (view->WingsSlot > 0 && Plus15Effect::IsItemLevel(view->WingsLevel)) {
		return true;
	}

	if (view->PetSlot > 0 && Plus15Effect::IsItemLevel(view->PetLevel)) {
		return true;
	}

	return false;
}

void Plus15Effect::Init()
{
	SetCompleteHook(0xE8, 0x005666C1, &Plus15Effect::RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x0061041C, &Plus15Effect::RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x00610466, &Plus15Effect::RenderPartObjectEffect);
}

void Plus15Effect::Toggle()
{
	this->m_Enabled = !this->m_Enabled;

	if (this->m_Enabled) {
		pDrawMessage("[F3] Texturas +15 visiveis", 1);
	}
	else {
		pDrawMessage("[F3] Texturas +15 ocultas", 1);
	}
}

bool Plus15Effect::BeginBody(ObjectModel* object, int select)
{
	this->m_BodyCaptured = false;

	if (this->m_Enabled == false || select != 0 || object == 0) {
		return false;
	}

	if (object->Alpha < 0.02f || this->BodyHasPlus15(object) == false) {
		return false;
	}

	Pulse pulse = this->Sample();

	if (pulse.Intensity < 0.001f) {
		return false;
	}

	this->Capture(object, this->m_BodySaved);
	this->Apply(object, pulse, object->Alpha > 0.01f ? object->Alpha : 1.0f);
	this->m_BodyCaptured = true;
	return true;
}

void Plus15Effect::EndBody(ObjectModel* object, bool applied)
{
	if (applied == false || object == 0 || this->m_BodyCaptured == false) {
		return;
	}

	this->Restore(object, this->m_BodySaved);
	this->m_BodyCaptured = false;
}

bool Plus15Effect::BeginLink(ObjectPreview* preview, int level, PART_t* part)
{
	this->m_LinkCaptured = false;

	if (this->m_Enabled == false || preview == 0) {
		return false;
	}

	int itemLevel = this->ResolveItemLevel(level, part);

	if (this->IsItemLevel(itemLevel) == false) {
		return false;
	}

	if (preview->Object.Alpha < 0.02f) {
		return false;
	}

	Pulse pulse = this->Sample();

	if (pulse.Intensity < 0.001f) {
		return false;
	}

	this->Capture(&preview->Object, this->m_LinkSaved);
	this->Apply(&preview->Object, pulse, preview->Object.Alpha > 0.01f ? preview->Object.Alpha : 1.0f);
	this->m_LinkCaptured = true;
	return true;
}

void Plus15Effect::EndLink(ObjectPreview* preview, bool applied)
{
	if (applied == false || preview == 0 || this->m_LinkCaptured == false) {
		return;
	}

	this->Restore(&preview->Object, this->m_LinkSaved);
	this->m_LinkCaptured = false;
}

void Plus15Effect::RenderPartObjectEffect(ObjectModel* object, int type, vec3_t light, float alpha, int itemLevel, int option1, int extOption, int select, int renderType)
{
	vec3_t glow;
	glow[0] = light[0];
	glow[1] = light[1];
	glow[2] = light[2];

	SavedLook saved;
	bool applied = false;

	if (gPlus15Effect.m_Enabled && select == 0 && object != 0 && Plus15Effect::IsItemLevel(itemLevel)) {
		Pulse pulse = Plus15Effect::Sample();

		if (pulse.Intensity >= 0.001f) {
			float base = alpha;

			if (base < 0.01f) {
				base = object->Alpha;
			}

			if (base < 0.01f) {
				base = 1.0f;
			}

			Plus15Effect::Capture(object, saved);
			Plus15Effect::Apply(object, pulse, base);
			Plus15Effect::TintLight(glow, pulse);
			alpha = object->Alpha;
			applied = true;
		}
	}

	((void(*)(ObjectModel*, int, vec3_t, float, int, int, int, int, int))0x609E70)(object, type, glow, alpha, itemLevel, option1, extOption, select, renderType);

	if (applied) {
		Plus15Effect::Restore(object, saved);
	}
}
