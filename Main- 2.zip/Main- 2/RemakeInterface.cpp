#include "stdafx.h"
#include "Interface.h"
#include "RemakeInterface.h"
#include "Util.h"

float TransForX(float num)
{
	return (float) ( pWinWidthReal <= 1.25 ) ? num * pWinWidthReal : num * pWinHeightReal;
}

float TransForY(float num)
{
	return (float) num * pWinHeightReal;
}

float TransFor2X(float num)
{
	return (float) num * pWinWidthReal;
}

float ReturnX(float num)
{
	return (float) ( pWinWidthReal <= 1.25 ) ? num / pWinWidthReal : num / pWinHeightReal;
}

float Return2X(float num)
{
	return (float) num / pWinWidthReal;
}

float ReturnY(float num)
{
	return (float) num / pWinHeightReal;
}

void DowngradeInventoryWindows(DWORD id, float x, float y, float w, float h)
{	
	int This;
	
	//This = GetInventory(GetInstance());
	//
	//*(DWORD *)(This + 224) = Return2X(x + TransForX(223));
	//*(DWORD *)(This + 232) = Return2X(TransForX(28.5)); //-- W
	//*(DWORD *)(This + 236) = ReturnY(TransForY(20)); //-- H
	////
	//*(DWORD *)(This + 252) = Return2X(TransForX(28.5)); //-- W
	//*(DWORD *)(This + 256) = ReturnY(TransForY(24)); //-- H
	////	
	//*(DWORD *)(This + 272) = Return2X(TransForX(28.5)); //-- W
	//*(DWORD *)(This + 276) = ReturnY(TransForY(24)); //-- H

	pDrawGUI(51533, x, y, w, h);
}

void DowngradeLoadWindows(DWORD id, float x, float y, float w, float h)
{
	pDrawGUI(51533, x, y, w, h);
}

void DowngradeStoreLoadWindows(DWORD id, float x, float y, float w, float h)
{
	pDrawGUI(51533, x, y, w, h);
}

void DowngradeLoadWindowsNone(DWORD id, float x, float y, float w, float h)
{
	pDrawGUI(51522, x, y, w, h);
}

//Character
void CClassicUICharacterInfoWindow(int a1)
{
  int v42; // ST24_4@1
  float green; // ST08_4@1
  float red; // ST04_4@1

  v42 = a1;
  green = (double)*(signed int *)(a1 + 20);
  red =   (double)*(signed int *)(a1 + 16);
  pDrawGUI(31352, red, green, 190.0, 429.0);
  if(*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x74) > 0)
  {
  	pDrawGUI(0x700020, 558, 57, 65.0, 11.0);
  }
//
  int DL = ((BYTE(__cdecl*)(BYTE Class)) 0x405230)(*(BYTE *)(oUserPreviewStruct + 19));
  if ( DL == 4 )
  {
	green = (double)*(signed int *)(a1 + 20);
	red = (double)*(signed int *)(a1 + 16);
	pDrawGUI(51291, red, green, 190.0, 429.0);
  	if(*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x74) > 0)
	{
	pDrawGUI(0x700020, 558, 57, 65.0, 11.0);
	}
  }

  int Class = ((BYTE(__cdecl*)(BYTE Class)) 0x405230)(*(BYTE *)(oUserPreviewStruct + 19));
	
  if ( Class == 3 || Class == 5 || Class == 6)
  {
	green = (double)*(signed int *)(a1 + 20);
	red = (double)*(signed int *)(a1 + 16);
	pDrawGUI(51292, red, green, 190.0, 429.0);
	if(*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x74) > 0)
	{
		pDrawGUI(0x700020, 558, 57, 65.0, 11.0);
	}
  }
}

__declspec(naked) void PointColorInventory()
{
	static DWORD BoxColorContinue_buff = 0x0077FD98;

	_asm
	{
	PUSH 255
	PUSH 0
	PUSH 0
	PUSH 0
	JMP [BoxColorContinue_buff]
	}
}

__declspec(naked) void BackPointColorInventory()
{
	static DWORD BoxColorContinue_buff = 0x0077FDAC;

	_asm
	{
	PUSH 255
	PUSH 199
	PUSH 110
	PUSH 30
	JMP [BoxColorContinue_buff]
	}
}

DWORD RenderSlot;
__declspec(naked) void ShadowColorCheck()
{
	static DWORD jmpBack = 0x007DB30F;

	__asm
	{
		mov     eax, [ebp - 0x1C]
		movzx   ecx, byte ptr[eax + 0x60]
		mov		RenderSlot, ecx
		jmp     [jmpBack]
	}
}

void RenderItemBox(DWORD ID, float x, float y, float w, float h)
{
	RenderBitmap(31072, x, y, w, h, 0, 0, 1.0, 1.0, 1, 1, 0.0);

	switch (RenderSlot)
	{
		case 0:
		break;
		case 1:
			glColor4f(1.0, 1.0, 0.0, 0.30000001);//glColor4f(1.0, 1.0, 0.0, 0.60000001);
		break;
		case 2:
			glColor4f(1.0, 0.66000003, 0.0, 0.30000001);//glColor4f(1.0, 0.66000003, 0.0, 0.60000001);
		break;
		case 3:
			glColor4f(0.89000001, 0.10900001, 0.10900001, 0.30000001);//glColor4f(1.0, 0.33000001, 0.0, 0.60000001);
		break;
		case 4:
			glColor4f(1.0, 0.0, 0.0, 0.40000001);
		break;
		case 5:
			glColor4f(1.0, 0.2, 0.1, 0.40000001);
		break;
		default:
			RenderBitmap(31071, x, y, w, h, 0, 0, 1.0, 1.0, 1, 1, 0.0);
		break;
	}

	if(RenderSlot >= 1 && RenderSlot <= 5)
	{
		pSetBlend(true);
		pDrawBarForm(x, y, w, h, 0.0, 0);
		pGLSwitchBlend();
		pGLSwitch();
		glColor3f(1.0, 1.0, 1.0);
	}

	RenderSlot = -1;
}

_declspec(naked) void GuildWarPosition()
{
	static DWORD ReturnAdress = 0x00777026;	
	_asm
	{
		ADD ECX,-230 //POS X
		MOV DWORD PTR SS:[EBP-0x4],ECX
		MOV EDX,DWORD PTR SS:[EBP-0x90]
		MOV EAX,DWORD PTR DS:[EDX+0x14]
		ADD EAX,-354 //POS Y
		MOV DWORD PTR SS:[EBP-0x8C],EAX
		MOV ECX,DWORD PTR DS:[0xE8C58C]
		JMP [ReturnAdress]
	}
}

int SetSlidePosition(DWORD This,int X,int Y) // ok
{
	Y = 429;

	return pSliderSetPosition(This,X,Y);
}

//===========================
//-- SkillRenderizado
//===========================
bool Render_SkillFullMouser(DWORD a1)
{
	bool result; // al@2
	unsigned __int8 v5; // ST4F_1@3
	int v62; // [sp+Ch] [bp-54h]@1
	int v64; // [sp+18h] [bp-48h]@84
	unsigned __int16 v66; // [sp+24h] [bp-3Ch]@53
	signed int v67; // [sp+2Ch] [bp-34h]@40
	signed int v68; // [sp+30h] [bp-30h]@40
	unsigned __int16 v69; // [sp+38h] [bp-28h]@76
	float v70; // [sp+40h] [bp-20h]@5
	float v71; // [sp+40h] [bp-20h]@28
	float v72; // [sp+40h] [bp-20h]@40
	float v73; // [sp+40h] [bp-20h]@73
	float v74; // [sp+40h] [bp-20h]@116
	float v75; // [sp+44h] [bp-1Ch]@5
	float v76; // [sp+44h] [bp-1Ch]@28
	float v77; // [sp+44h] [bp-1Ch]@73
	char v78; // [sp+4Bh] [bp-15h]@73
	float v79; // [sp+4Ch] [bp-14h]@73
	signed int v80; // [sp+50h] [bp-10h]@73
	int v81; // [sp+54h] [bp-Ch]@73
	float v82; // [sp+58h] [bp-8h]@5
	float v83; // [sp+58h] [bp-8h]@28
	float v84; // [sp+58h] [bp-8h]@40
	float v85; // [sp+58h] [bp-8h]@85
	float v86; // [sp+58h] [bp-8h]@116
	float v87; // [sp+5Ch] [bp-4h]@5
	float v88; // [sp+5Ch] [bp-4h]@28
	float v89; // [sp+5Ch] [bp-4h]@40
	float v90; // [sp+5Ch] [bp-4h]@73
	float v91; // [sp+5Ch] [bp-4h]@116*/
	signed int j; // [sp+10h] [bp-50h]@116
	signed int i; // [sp+20h] [bp-40h]@73

	v62 = a1;
	if ( sub_4C8640((DWORD *)(*(DWORD *)0x7BC4F04 + 1260), 98) )
	{
		*(BYTE *)(v62 + 64) = 0;
		result = 1;
	}
	else
	{
		v5 = *(BYTE *)(*(DWORD *)0x8128AC8 + 118);
		*(BYTE *)(v62 + 65) = 0;
		if ( (signed int)v5 > 0 )
		{
			//-- skill en uso
			v82 = 310.0;
			v87 = 445.0f;
			v70 = 25.0f;
			v75 = 32.0f;
			if ( *(DWORD *)(v62 + 80) || *(BYTE *)0x8793384 || pCheckMouseOver(v82, v87, v70, v75) != 1 )
			{
				if ( *(DWORD *)(v62 + 80) != 1 || *(BYTE *)0x8793384 || pCheckMouseOver(v82, v87, v70, v75) )
				{
					if ( *(DWORD *)(v62 + 80) != 1 || *(BYTE *)0x8793384 != 1 && *(BYTE *)0x8793380 != 1 || pCheckMouseOver(v82, v87, v70, v75) != 1 )
					{
						if ( *(DWORD *)(v62 + 80) != 2 || *(BYTE *)0x8793384 || *(BYTE *)0x8793380 )
						{
							if ( *(DWORD *)(v62 + 80) == 1 )
							{
								*(BYTE *)(v62 + 65) = 1;
								*(DWORD *)(v62 + 68) = *(BYTE *)(*(DWORD *)0x7BC4F04 + 50);
								*(DWORD *)(v62 + 72) = v82 - 5.0;
								*(DWORD *)(v62 + 76) = v87;
								result = 0;
							}
							else if ( *(DWORD *)(v62 + 80) == 2 )
							{
								result = 0;
							}
							else
							{
								//-- DrawSkill Bar
								v83 = 330.0;
								v88 = 480.0f;
								v71 = 100.0;
								v76 = 20.0;
								if ( *(DWORD *)(v62 + 80) || *(BYTE *)0x8793384 || pCheckMouseOver(v83, v88, v71, v76) != 1 )
								{
									if ( *(DWORD *)(v62 + 80) != 3 || *(BYTE *)0x8793384 || pCheckMouseOver(v83, v88, v71, v76) )
									{
										if ( *(DWORD *)(v62 + 80) != 3 || *(BYTE *)0x8793384 != 1 || pCheckMouseOver(v83, v88, v71, v76) != 1 )
										{
										//-- DrawSkill Bar Slot 5
											v84 = 315.0;
											v89 = 480.0f;
											v72 = 20.0;
											v68 = 0;
											v67 = *(BYTE *)(v62 + 20) != 1 ? 1 : 6;
											while ( v68 < 5 )
											{
												v84 = v84 + v72;
												if ( v67 == 10 )
													v67 = 0;
												if ( pCheckMouseOver(v84, v89, v72, (float)32.0) == 1 )
												{
													if ( *(DWORD *)(v62 + 4 * v67 + 24) == -1 )
													{
														if ( *(DWORD *)(v62 + 80) == 3 )
														{
															*(BYTE *)(v62 + 65) = 0;
															*(DWORD *)(v62 + 68) = -1;
														}
														if ( *(DWORD *)(v62 + 80) == 4 && !*(BYTE *)0x8793384 )
															*(DWORD *)(v62 + 80) = 0;
													}
													else
													{
														v66 = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * *(DWORD *)(v62 + 4 * v67 + 24) + 120);
														if ( v66 && ((signed int)v66 < 67 || (signed int)v66 > 72) && *(BYTE *)(*(DWORD *)0x8128ABC + 88 * v66 + 55) != 3 )
														{
															if ( *(DWORD *)(v62 + 80) == 3 )
															{
																*(BYTE *)(v62 + 65) = 1;
																*(DWORD *)(v62 + 68) = *(DWORD *)(v62 + 4 * v67 + 24);
																*(DWORD *)(v62 + 72) = v84 - 5.0;
																*(DWORD *)(v62 + 76) = v89;
																return 1;
															}
															if ( *(DWORD *)(v62 + 80) == 4 && !*(BYTE *)0x8793384 )
															{
																if ( *(DWORD *)(v62 + 68) == *(DWORD *)(v62 + 4 * v67 + 24) )
																{
																	*(DWORD *)(v62 + 80) = 0;
																	*(WORD *)(v62 + 84) = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * *(BYTE *)(*(DWORD *)0x7BC4F04 + 50) + 120);
																	*(BYTE *)(*(DWORD *)0x7BC4F04 + 50) = *(BYTE *)(v62 + 4 * v67 + 24);
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
																*(DWORD *)(v62 + 80) = 0;
															}
														}
													}
												}
												++v68;
												++v67;
											}
											if ( *(DWORD *)(v62 + 80) == 4 )
											{
												//-- DrawSkill Bar
												if ( *(BYTE *)0x8793384 || pCheckMouseOver((float)330.0, (float)480.0f, (float)100.0, (float)32.0))
												{
													result = 0;
												}
												else
												{
													*(DWORD *)(v62 + 80) = 0;
													result = 1;
												}
											}
											else if ( *(BYTE *)(v62 + 64) )
											{
												//-- SkillBarSwitch
												v80 = 0;
												v78 = 0;
												v90 = 390.0;//-- y
												v73 = 32.0;//-- w
												v77 = 38.0;//-- h
												v79 = 302.0;//-- x
												v81 = *(DWORD *)(v62 + 80);
												for ( i = 0; i < 150; ++i )
												{
													v69 = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * i + 120);
													if ( v69 && ((signed int)v69 < 67 || (signed int)v69 > 72) && *(BYTE *)(*(DWORD *)0x8128ABC + 88 * v69 + 55) != 3 )
													{
														if ( v80 == 11 )
															v90 = v90 - v77;
														if ( v80 >= 11 )
														{
															if ( v80 < 11 || v80 > 21 )
																v85 = v79 - v73 * 11.0 + (double)(v80 - 21) * v73;
															else
																v85 = v79 - v73 * 6.0 + (double)(v80 - 10) * v73;
														}
														else
														{
															v64 = v80 / 2;
															if ( v80 % 2 )
																v85 = v79 - (double)(v64 + 1) * v73;
															else
																v85 = (double)v64 * v73 + v79;
														}
														++v80;
														if ( pCheckMouseOver(v85, v90, v73, v77) == 1 )
														{
															v78 = 1;
															if ( !*(DWORD *)(v62 + 80) && !*(BYTE *)0x8793384 )
															{
																*(DWORD *)(v62 + 80) = 5;
																break;
															}
														}
														if ( *(DWORD *)(v62 + 80) == 5 && *(BYTE *)0x8793384 == 1 )
														{
															if ( pCheckMouseOver(v85, v90, v73, v77) == 1 )
															{
																*(DWORD *)(v62 + 80) = 6;
																break;
															}
														}
														if ( *(DWORD *)(v62 + 80) == 5 && !*(BYTE *)0x8793384 )
														{
															if ( pCheckMouseOver(v85, v90, v73, v77) == 1 )
															{
																*(BYTE *)(v62 + 65) = 1;
																*(DWORD *)(v62 + 68) = i;
																*(DWORD *)(v62 + 72) = v85;
																*(DWORD *)(v62 + 76) = v90;
															}
														}
														if ( *(DWORD *)(v62 + 80) == 6 && !*(BYTE *)0x8793384 && *(DWORD *)(v62 + 68) == i )
														{
															if ( pCheckMouseOver(v85, v90, v73, v77) == 1 )
															{
																*(DWORD *)(v62 + 80) = 0;
																*(WORD *)(v62 + 84) = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * *(BYTE *)(*(DWORD *)0x7BC4F04 + 50) + 120);
																*(BYTE *)(*(DWORD *)0x7BC4F04 + 50) = i;
																*(BYTE *)(v62 + 64) = 0;
																PlayBuffer(25, 0, 0);
																return 0;
															}
														}
													}
												}
												if ( v81 == *(DWORD *)(v62 + 80) )
												{
													if ( *(DWORD *)(*(DWORD *)0x7BC4F04 + 676) )
													{
														//-- SkillFixRaven
														v86 = 270.0;
														v91 = 350.0;
														v74 = 32.0;
														for ( j = 150; j < 154; ++j )
														{
															if ( pCheckMouseOver(v86, v91, v74, (float)38.0) == 1 )
															{
																v78 = 1;
																if ( !*(DWORD *)(v62 + 80) && !*(BYTE *)0x8793384 )
																{
																	*(DWORD *)(v62 + 80) = 5;
																	return 1;
																}
																if ( *(DWORD *)(v62 + 80) == 5 && *(BYTE *)0x8793384 == 1 )
																{
																	*(DWORD *)(v62 + 80) = 6;
																	return 0;
																}
																if ( *(DWORD *)(v62 + 80) == 5 )
																{
																	*(BYTE *)(v62 + 65) = 1;
																	*(DWORD *)(v62 + 68) = j;
																	*(DWORD *)(v62 + 72) = v86;
																	*(DWORD *)(v62 + 76) = v91;
																}
																if ( *(DWORD *)(v62 + 80) == 6 && !*(BYTE *)0x8793384 && *(DWORD *)(v62 + 68) == j )
																{
																	*(DWORD *)(v62 + 80) = 0;
																	*(WORD *)(v62 + 84) = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * *(BYTE *)(*(DWORD *)0x7BC4F04 + 50) + 120);
																	*(BYTE *)(*(DWORD *)0x7BC4F04 + 50) = j;
																	*(BYTE *)(v62 + 64) = 0;
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
															}
															v86 = v86 + v74;
														}
													}
													if ( v78 || *(DWORD *)(v62 + 80) != 5 )
													{
														if ( v78 || *(BYTE *)0x8793384 || *(DWORD *)(v62 + 80) != 6 )
														{
															if ( *(DWORD *)(v62 + 80) == 6 )
															{
																if ( *(BYTE *)0x8793384 )
																{
																	result = 0;
																}
																else
																{
																	*(DWORD *)(v62 + 80) = 0;
																	result = 1;
																}
															}
															else
															{
																result = 1;
															}
														}
														else
														{
															*(DWORD *)(v62 + 80) = 0;
															result = 0;
														}
													}
													else
													{
														*(DWORD *)(v62 + 80) = 0;
														result = 1;
													}
												}
												else
												{
													result = !*(DWORD *)(v62 + 80) || *(DWORD *)(v62 + 80) == 5;
												}
											}
											else
											{
												result = 1;
											}
										}
										else
										{
											*(DWORD *)(v62 + 80) = 4;
											result = 0;
										}
									}
									else
									{
										*(DWORD *)(v62 + 80) = 0;
										result = 1;
									}
								}
								else
								{
									*(DWORD *)(v62 + 80) = 3;
									result = 1;
								}
							}
						}
						else
						{
							if ( pCheckMouseOver(v82, v87, v70, v75) == 1 )
							{
								*(BYTE *)(v62 + 64) = *(BYTE *)(v62 + 64) == 0;
								PlayBuffer(25, 0, 0);
								*(DWORD *)(v62 + 80) = 0;
								result = 0;
							}
							else
							{
								*(DWORD *)(v62 + 80) = 0;
								result = 1;
							}
						}
					}
					else
					{
						*(DWORD *)(v62 + 80) = 2;
						result = 0;
					}
				}
				else
				{
					*(DWORD *)(v62 + 80) = 0;
					result = 1;
				}
			}
			else
			{
				*(DWORD *)(v62 + 80) = 1;
				result = 1;
			}
		}
		else
		{
			result = 1;
		}
	}
	return result;
}

void RenderSkill_Raven(DWORD *a1)
{
	float v4; // ST18_4@7
	float v5; // ST14_4@7
	int v6; // [sp+18h] [bp-18h]@1
	signed int i; // [sp+1Ch] [bp-14h]@2
	float v8; // [sp+20h] [bp-10h]@2
	float v9; // [sp+24h] [bp-Ch]@2
	float v10; // [sp+28h] [bp-8h]@2
	float v11; // [sp+2Ch] [bp-4h]@2

	v6 = *(DWORD *)a1;
	if ( *(DWORD *)(*(DWORD *)0x7BC4F04 + 676) )
	{
		v10 = 270.0;//X
		v11 = 350.0;//Y
		v8 = 32.0;
		v9 = 38.0;
		for ( i = 150; i < 154; ++i )
		{
			if ( i == *(BYTE *)(*(DWORD *)0x7BC4F04 + 50) )
				pDrawGUI(31313, v10, v11, v8, v9);
			else
				pDrawGUI(31312, v10, v11, v8, v9);
			v4 = v11 + 6.0;
			v5 = v10 + 6.0;
			sub_813DC0(a1, i, v5, v4, 20.0, 28.0);
			v10 = v10 + v8;
		}
	}
}


int	func_5977E0()
{
	HGDIOBJ font;
	signed int i;

	if (!pCheckWindow(pWindowThis(), 65)) //hide when xShop open, add custom window here!
	{
		pSetBlend(1);
		font = (DWORD*)0xE8C58C;
		pSetTextColor(pTextThis(), 0xFFu, 0xFFu, 0xFFu, 0xFFu);
		glColor3f(1.0, 1.0, 1.0);
		for (i = 0; i < 6; ++i)
		{
			switch (*((BYTE*)0x813DDD0 + 264 * i + 260))
			{
			case 1:
				pSetTextColor(pTextThis(), 0x64u, 0xFFu, 0xC8u, 0xFFu);
				pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0x80u);
				break;
			case 2:
				pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0x80u);
				if (*(DWORD*)0x81C0418 % 10 >= 5)
				{
					pSetTextColor(pTextThis(), 0x50u, 0xFFu, 0x50u, 0xFFu);
				}
				else
				{
					pSetTextColor(pTextThis(), 0x50u, 0xFFu, 0x50u, 0xFFu);
				}
				break;
			case 3:
				pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0x80u);
				if (*(DWORD*)0x81C0418 % 10 >= 5)
				{
					pSetTextColor(pTextThis(), 0xFFu, 0x50u, 0xC8u, 0xFFu);
				}
				else
				{
					pSetTextColor(pTextThis(), 0xFFu, 0x50u, 0xC8u, 0xFFu);
				}
				break;
			default:pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0x80u);
				if (*(DWORD*)0x81C0418 % 10 >= 5)
				{
					pSetTextColor(pTextThis(), 0xFFu, 0xC8u, 0x50u, 0xFFu);
				}
				else
				{
					pSetTextColor(pTextThis(), 0xFFu, 0xC8u, 0x50u, 0xFFu);
				}
				break;
			}
			pDrawText(pTextThis(), 320, 13 * i + 300, (LPCTSTR)(0x813DDD0 + 264 * i), 0, 0, 8, 0);
		}

		*(DWORD*)0x81C0418 = *(DWORD*)0x81C0418 + 1;
		return *(DWORD*)0x81C0418 + 1;
	}
	return false;
}

void Render_Funcion_772EA0(int ThisR)
{
	static DWORD Addr1 = 0x00815040;
	static DWORD Addr2_Call = 0x00772EA0;
	static DWORD This = 0x00772EA0;

	This = ThisR;

	_asm
	{
		PUSH 0                              ; /Arg5 = 00000000
		PUSH 0                              ; |Arg4 = 00000000
		MOV ECX,This                        ; |
		PUSH ECX                            ; |Arg3
		PUSH Addr1                          ; |Arg2 = 00815040
		PUSH ECX                            ; |Arg1
		FLD DWORD PTR DS:[0xD2CA40]         ; |
		FSTP DWORD PTR SS:[ESP]             ; |
		MOV EDX,This                        ; |
		MOV ECX,DWORD PTR DS:[EDX + 0x10]   ; |
		CALL Addr2_Call                     ; \main1.00772EA0
	}
}

char Render_SkillBarSwitch(int This)
{
	float v4; // ST18_4@26
	float v5; // ST14_4@26
	int v7; // [sp+28h] [bp-34h]@1
	int v8; // [sp+30h] [bp-2Ch]@15
	char v9; // [sp+37h] [bp-25h]@9
	float v10; // [sp+38h] [bp-24h]@3
	signed int v11; // [sp+3Ch] [bp-20h]@3
	signed int v12; // [sp+40h] [bp-1Ch]@6
	float v13; // [sp+44h] [bp-18h]@3
	float v14; // [sp+48h] [bp-14h]@3
	signed int i; // [sp+50h] [bp-Ch]@3
	float v16; // [sp+54h] [bp-8h]@16
	float v17; // [sp+58h] [bp-4h]@3

	v7 = This;

	if ( (signed int)*(BYTE *)(*(DWORD *)0x8128AC8 + 118) > 0 && *(BYTE *)(v7 + 64) == 1 )
	{
		v17 = 390.0;//Y
		v13 = 32.0;
		v14 = 38.0;
		v10 = 302.0;//X
		v11 = 0;

		for ( i = 0; i < 150; ++i )
		{
			v12 = *(WORD *)(*(DWORD *)0x8128AC8 + 2 * i + 120);

			if ( *(WORD *)(*(DWORD *)0x8128AC8 + 2 * i + 120) && (v12 < 67 || v12 > 72) )
			{
				v9 = *(BYTE *)(*(DWORD *)0x8128ABC + 88 * v12 + 55);
				if ( v9 != 1 && v9 != 3 )
				{
					if ( v11 == 11 )
					{
						v17 = v17 - v14;
					}
					if ( v11 >= 11 )
					{
						if ( v11 < 11 || v11 > 21 )
						{
							v16 = v10 - v13 * 11.0 + (double)(v11 - 21) * v13;
						}
						else
						{
							v16 = v10 - v13 * 6 + (double)(v11 - 10) * v13;
						}
					}
					else
					{
						v8 = v11 / 2;
						if ( v11 % 2 )
						{
							v16 = v10 - (double)(v8 + 1) * v13;
						}
						else
						{
							v16 = (double)v8 * v13 + v10;
						}
					}
					
					++v11;

					if ( i == *(BYTE *)(*(DWORD *)0x7BC4F04 + 50) )//-- Seleccionado
					{
						pDrawGUI(31313, v16, v17, v13, v14);
					}
					else
					{
						pDrawGUI(31312, v16, v17, v13, v14);
					}
					v4 = v17 + 6.0;
					v5 = v16 + 6.0;
					sub_813DC0((DWORD *)This, i, v5, v4, 20.0, 28.0);
				}
			}
		}
		RenderSkill_Raven((DWORD *)This);
	}

	if ( *(BYTE *)(This + 65) == 1 && *(DWORD *)(This + 16) )
	{
		Render_Funcion_772EA0(This);
		*(BYTE *)(This + 65) = 0;
	}
	return 1;
}


__declspec(naked) void DrawAGPosition()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static float AGPositionW = 14.0f;
	static float AGPositionH = 38.0f;
	static float AGPositionX = 551.5f;
	static float AGPositionY = 435.7f;
	static DWORD AGPosition_buff = 0x008102AD;
	_asm
	{	
	FLD DWORD PTR DS:[AGPositionW]
	FSTP DWORD PTR SS:[EBP-0x18]
	FLD DWORD PTR DS:[AGPositionH]
	FSTP DWORD PTR SS:[EBP-0x14]
	FLD DWORD PTR DS:[AGPositionX]
	FSTP DWORD PTR SS:[EBP-0x10]
	FLD DWORD PTR DS:[AGPositionY]
	FSTP DWORD PTR SS:[EBP-0x0C]
	jmp [AGPosition_buff]
	}
}
__declspec(naked) void DrawSDPosition()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static float SDPositionW = 14.0f;
	static float SDPositionH = 38.0f;
	static float SDPositionX = 73.0f;
	static float SDPositionY = 435.7f;
	static DWORD SDPosition_buff = 0x0081057D;
	_asm
	{	
	FLD DWORD PTR DS:[SDPositionW]
	FSTP DWORD PTR SS:[EBP-0x20]
	FLD DWORD PTR DS:[SDPositionH]
	FSTP DWORD PTR SS:[EBP-0x1C]
	FLD DWORD PTR DS:[SDPositionX]
	FSTP DWORD PTR SS:[EBP-0x10]
	FLD DWORD PTR DS:[SDPositionY]
	FSTP DWORD PTR SS:[EBP-0x0C] 
	jmp [SDPosition_buff]
	}
}
//--------------------------------------------
__declspec(naked) void DrawMANAPosition()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static float MANAPositionW = 52.5f;
	static float MANAPositionX = 488.0f;
	static float MANAPositionH = 51.0f;
	static float MANAPositionY = 428.5f;
	static DWORD MANAPosition_buff = 0x0080FFD0;
	_asm
	{	
	FLD DWORD PTR DS:[MANAPositionW]
	FSTP DWORD PTR SS:[EBP-0x20]
	FLD DWORD PTR DS:[MANAPositionX]
	FSTP DWORD PTR SS:[EBP-0x0C]
	FLD DWORD PTR DS:[MANAPositionH]
	FSTP DWORD PTR SS:[EBP-0x1C]
	FLD DWORD PTR DS:[MANAPositionY]
	FSTP DWORD PTR SS:[EBP-0x8]
	jmp [MANAPosition_buff]
	}
}
__declspec(naked) void DrawHPPosition()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static float HPPositionW = 52.5f;
	static float HPPositionH = 51.0f;
	static float HPPositionX = 98.0f;
	static float HPPositionY = 428.5f;
	static DWORD HPPosition_buff = 0x0080FD7C;
	_asm
	{             
	FLD DWORD PTR DS:[HPPositionW]
	FSTP DWORD PTR SS:[EBP-0x20]
	FLD DWORD PTR DS:[HPPositionX]
	FSTP DWORD PTR SS:[EBP-0x0C]
	FLD DWORD PTR DS:[HPPositionH]
	FSTP DWORD PTR SS:[EBP-0x1C]
	FLD DWORD PTR DS:[HPPositionY]
	FSTP DWORD PTR SS:[EBP-0x8]
	jmp [HPPosition_buff]
	}
}

//--------------------------------------------
__declspec(naked) void DrawQPosition1()
{
	static float BarNumberY = 445.0f;
	static DWORD QPosition1_buff = 0x00895A4F;
	_asm
	{
	FLD DWORD PTR DS:[BarNumberY]
	FSTP DWORD PTR SS:[ESP]
	jmp [QPosition1_buff]
	}
}
__declspec(naked) void DrawQPosition2()
{
	static float QPosition2X = 227.0f;
	static DWORD QPosition2_buff = 0x00895A59;
	_asm
	{
	FLD DWORD PTR DS:[QPosition2X]
	FSTP DWORD PTR SS:[ESP]
	jmp [QPosition2_buff]
	}
}
__declspec(naked) void DrawQPosition3()
{
	static float BarPotionY = 453.0f;
	static DWORD QPosition3_buff = 0x00895A63;
	_asm
	{
	FLD DWORD PTR DS:[BarPotionY]
	FSTP DWORD PTR SS:[ESP]
	jmp [QPosition3_buff]
	}
}
__declspec(naked) void DrawQPosition4()
{
	static float QPosition4X = 210.0f;
	static DWORD QPosition4_buff = 0x00895A6D;
	_asm
	{
	FLD DWORD PTR DS:[QPosition4X]
	FSTP DWORD PTR SS:[ESP]
	jmp [QPosition4_buff]
	}
}
__declspec(naked) void DrawWPosition1()
{
	static float BarNumberY = 445.0f;
	static DWORD WPosition1_buff = 0x00895AC4;
	_asm
	{
	FLD DWORD PTR DS:[BarNumberY]
	FSTP DWORD PTR SS:[ESP]
	jmp [WPosition1_buff]
	}
}
__declspec(naked) void DrawWPosition2()
{
	static float WPosition2X = 257.0f;
	static DWORD WPosition2_buff = 0x00895ACE;
	_asm
	{
	FLD DWORD PTR DS:[WPosition2X]
	FSTP DWORD PTR SS:[ESP]
	jmp [WPosition2_buff]
	}
}
__declspec(naked) void DrawWPosition3()
{
	static float BarPotionY = 453.0f;
	static DWORD WPosition3_buff = 0x00895AD8;
	_asm
	{
	FLD DWORD PTR DS:[BarPotionY]
	FSTP DWORD PTR SS:[ESP]
	jmp [WPosition3_buff]
	}
}
__declspec(naked) void DrawWPosition4()
{
	static float WPosition4X = 240.0f;
	static DWORD WPosition4_buff = 0x00895AE2;
	_asm
	{
	FLD DWORD PTR DS:[WPosition4X]
	FSTP DWORD PTR SS:[ESP]
	jmp [WPosition4_buff]
	}
}
__declspec(naked) void DrawEPosition1()
{
	static float BarNumberY = 445.0f;
	static DWORD EPosition1_buff = 0x00895B39;
	_asm
	{
	FLD DWORD PTR DS:[BarNumberY]
	FSTP DWORD PTR SS:[ESP]
	jmp [EPosition1_buff]
	}
}
__declspec(naked) void DrawEPosition2()
{
	static float EPosition2X = 287.0f;
	static DWORD EPosition2_buff = 0x00895B43;
	_asm
	{
	FLD DWORD PTR DS:[EPosition2X]
	FSTP DWORD PTR SS:[ESP]
	jmp [EPosition2_buff]
	}
}
__declspec(naked) void DrawEPosition3()
{
	static float BarPotionY = 453.0f;
	static DWORD EPosition3_buff = 0x00895B4D;
	_asm
	{
	FLD DWORD PTR DS:[BarPotionY]
	FSTP DWORD PTR SS:[ESP]
	jmp [EPosition3_buff]
	}
}
__declspec(naked) void DrawEPosition4()
{
	static float EPosition4X = 270.0f;
	static DWORD EPosition4_buff = 0x00895B57;
	_asm
	{
	FLD DWORD PTR DS:[EPosition4X]
	FSTP DWORD PTR SS:[ESP]
	jmp [EPosition4_buff]
	}
}
__declspec(naked) void DrawNopRShortKey()
{
	static DWORD RButtonAddress = 0x00895C0C;
	_asm{jmp RButtonAddress}
}

__declspec(naked) void DrawHPNumberPosition()
{
	gInterface.DrawCoord();

	static float HPNumberPositionX = 45.0f;
	static DWORD HPNumberPosition_buff = 0x0080FF1E;
	_asm
	{
	FADD DWORD PTR DS:[HPNumberPositionX]
	FSTP DWORD PTR SS:[EBP-0x19C]
	FLD DWORD PTR SS:[EBP-0x19C]
	jmp [HPNumberPosition_buff]
	}
}
__declspec(naked) void DrawMasterButton()
{
	static DWORD MasterButtonAddress1 = 0x0077ED20;
	_asm
	{
		jmp [MasterButtonAddress1]
	}
}
__declspec(naked) void DrawHelperAll()
{
	static DWORD HelperStopAddress1 = 0x007D28B4;
	_asm
	{
		jmp [HelperStopAddress1]
	}
}

//---------------------------------------------
//EXP
__declspec(naked) void DrawEXP1()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP1_buff = 0x00811408;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD DWORD PTR SS:[EBP-0x1B0]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXP1_buff]
	}
}

__declspec(naked) void DrawEXP2()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP2_buff = 0x00811552;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD DWORD PTR SS:[EBP-0x1C4]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXP2_buff]
	}
}

__declspec(naked) void DrawEXP3()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP3_buff = 0x00811719;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD DWORD PTR SS:[EBP-0x1B0]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXP3_buff]
	}
}

__declspec(naked) void DrawEXP4()
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP4_buff = 0x0081181F;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	FLD QWORD PTR SS:[EBP-0x20]
	jmp [EXP4_buff]
	}
}

//EXP MASTER
__declspec(naked) void DrawEXPMASTER1()
{
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AltoTex = 5.8f;
	static double AnchoTex = 198.0f;
	static DWORD EXPMASTER1_buff = 0x00810B6E;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD QWORD PTR SS:[EBP-0x58]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXPMASTER1_buff]
	}
}

__declspec(naked) void DrawEXPMASTER2()
{
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER2_buff = 0x00810CB5;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD QWORD PTR SS:[EBP-0x88]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXPMASTER2_buff]
	}
}

__declspec(naked) void DrawEXPMASTER3()
{
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER3_buff = 0x00810E79;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD QWORD PTR SS:[EBP-0x58]
	FMUL QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXPMASTER3_buff]
	}
}

__declspec(naked) void DrawEXPMASTER4()
{
	static double Ancho = 221.0f;
	static double Alto = 435.0f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER4_buff = 0x00810F73;
	_asm
	{
	FLD QWORD PTR DS:[Ancho]
	FSTP QWORD PTR SS:[EBP-0x10]
	FLD QWORD PTR DS:[Alto]
	FSTP QWORD PTR SS:[EBP-0x8]
	FLD QWORD PTR DS:[AnchoTex]
	FSTP QWORD PTR SS:[EBP-0x28]
	FLD QWORD PTR DS:[AltoTex]
	FSTP QWORD PTR SS:[EBP-0x20]
	jmp [EXPMASTER4_buff]
	}
}


__declspec(naked) void DrawUsingSkillPosition()
{
	static float UsingSkillPositionX = 310.0f;
	static float UsingSkillPositionY = 447.0f;
	static float UsingSkillPositionW = 20.0f;
	static float UsingSkillPositionH = 28.0f;
	static DWORD UsingSkillPosition_buff = 0x00813900;

	_asm
	{
		FLD DWORD PTR DS:[UsingSkillPositionX]
		FSTP DWORD PTR SS:[EBP-0x8]
		FLD DWORD PTR DS:[UsingSkillPositionY]
		FSTP DWORD PTR SS:[EBP-0x4]
		FLD DWORD PTR DS:[UsingSkillPositionW]
		FSTP DWORD PTR SS:[EBP-0x18]
		FLD DWORD PTR DS:[UsingSkillPositionH]
		FSTP DWORD PTR SS:[EBP-0x14]
		jmp [UsingSkillPosition_buff]
	}
}

__declspec(naked) void DrawSkillBarDrawPosition()
{
	static float SkillBarDrawPositionX = 222.0f;
	static float SkillBarDrawPositionY = 480.0f;
	static float SkillBarDrawPositionW = 160.0f;
	static float SkillBarDrawPositionH = 38.0f;
	static DWORD SkillBarDrawPosition_buff = 0x00812968;

	_asm
	{	
		FLD DWORD PTR DS:[SkillBarDrawPositionX]
		FSTP DWORD PTR SS:[EBP-0x8]
		FLD DWORD PTR DS:[SkillBarDrawPositionY]
		FSTP DWORD PTR SS:[EBP-0x4]
		FLD DWORD PTR DS:[SkillBarDrawPositionW]
		FSTP DWORD PTR SS:[EBP-0x20]
		FLD DWORD PTR DS:[SkillBarDrawPositionH]
		FSTP DWORD PTR SS:[EBP-0x1C]
		jmp [SkillBarDrawPosition_buff]
	}
}

__declspec(naked) void OffButtonOpenStore()
{
	static DWORD ButtonAddress = 0x008369B4;
	_asm {jmp ButtonAddress}
}

__declspec(naked) void OffButtonQuestInStats()
{
	static DWORD ButtonAddress = 0x0077EBB5;
	_asm {jmp ButtonAddress}
}

__declspec(naked) void OffButtonPetsInStats()
{
	static DWORD ButtonAddress = 0x0077EC5E;
	_asm {jmp ButtonAddress}
}

__declspec(naked) void DrawInterfaceS2DisableR()
{
	static DWORD RButtonAddress = 0x00895C0C;
	_asm{jmp RButtonAddress}
}

void ColorText(PVOID This, BYTE r, BYTE g, BYTE b, BYTE h)
{
	pSetTextColor(pTextThis(), 191, 191, 146, 255);
}

int OptionBuffer;
int CtrlAtivo;
int EffectAtivo;
int FlagAtivo;
DWORD TimerEventVK;
DWORD TimerEventVK2;
DWORD TimerEventVK3;

void RenderOptionPanelOrigin(int a1)
{
	float v4; // ST08_4@2
	float v5; // ST04_4@2
	float v6; // ST08_4@3
	float v7; // ST04_4@3
	float v8; // ST08_4@5
	float v9; // ST04_4@5
	float v10; // ST08_4@6
	float v11; // ST04_4@6
	float v12; // ST08_4@8
	float v13; // ST04_4@8
	float v14; // ST08_4@9
	float v15; // ST04_4@9
	float v16; // ST10_4@10
	float v17; // ST0C_4@10
	float v18; // ST3C_4@11
	float v19; // ST10_4@11
	float v20; // ST0C_4@11
	float v21; // ST10_4@12
	float v22; // ST0C_4@12
	float v23; // ST24_4@13
	float v24; // ST10_4@13
	float v25; // ST0C_4@13
	int v26; // [sp+74h] [bp-4h]@1
	//
	float v122; // ST08_4@8
	float v132; // ST04_4@8
	float v142; // ST08_4@9
	float v152; // ST04_4@9
	float v162; // ST08_4@9
	float v172; // ST04_4@9
	float PosY;

	PosY -= 0;

	v26 = a1;
	sub_7798F0(a1 + 24, 0);
	float X = 0.0;
	if (*(BYTE *)(v26 + 196))
	{
		v4 = (double)(*(DWORD *)(v26 + 20) + 43 + PosY);
		v5 = (double)(*(DWORD *)(v26 + 16) + 150 + X);
		pDrawButton(31593, v5, v4, 15.0, 15.0, 0.0, 0.0);  //click attack
	}
	else
	{
		v6 = (double)(*(DWORD *)(v26 + 20) + 43 + PosY);
		v7 = (double)(*(DWORD *)(v26 + 16) + 150 + X);
		pDrawButton(31593, v7, v6, 15.0, 15.0, 0.0, 15.0);  //click attack
	}
	if (*(BYTE *)(v26 + 197))
	{
		v8 = (double)(*(DWORD *)(v26 + 20) + 65 + PosY);
		v9 = (double)(*(DWORD *)(v26 + 16) + 150) + X;
		pDrawButton(31593, v9, v8, 15.0, 15.0, 0.0, 0.0);  //click som
	}
	else
	{
		v10 = (double)(*(DWORD *)(v26 + 20) + 65 + PosY);
		v11 = (double)(*(DWORD *)(v26 + 16) + 150 + X);
		pDrawButton(31593, v11, v10, 15.0, 15.0, 0.0, 15.0);  //click som
	}

	if (*(BYTE *)(v26 + 198)) //slide helper
	{
		v12 = (double)(*(DWORD *)(v26 + 20) + 127 + PosY);
		v13 = (double)(*(DWORD *)(v26 + 16) + 150);
		pDrawButton(31593, v13, v12, 15.0, 15.0, 0.0, 0.0);
	}
	else
	{
		v14 = (double)(*(DWORD *)(v26 + 20) + 127 + PosY);
		v15 = (double)(*(DWORD *)(v26 + 16) + 150);
		pDrawButton(31593, v15, v14, 15.0, 15.0, 0.0, 15.0);
	}

//Novos
	v122 = (double)(*(DWORD *)(v26 + 20) + 205 + PosY);
	v132 = (double)(*(DWORD *)(v26 + 16) + 150);

	if(pCheckMouseOver( v132, v122, 15, 15 ) && (*(BYTE*)0x8793386) && GetTickCount() >= TimerEventVK + 250 )
	{
		if(CtrlAtivo !=0)
		{	
			gInterface.DrawMessage(1, "Auto PVP [OFF]");
			SetByte(0x0059AF53+2,1);
			SetByte(0x0059B248+2,1);
			CtrlAtivo = 0;
		}
		else
		{
			gInterface.DrawMessage(1, "Auto PVP [ON]");
			SetByte(0x0059AF53+2,0);
			SetByte(0x0059B248+2,0);			
			CtrlAtivo = 1;
		}
		TimerEventVK = GetTickCount();
	}

	if(CtrlAtivo == 0)
	{
		pDrawButton(31593, v132, v122, 15.0, 15.0, 0.0, 15.0);
	}
	if(CtrlAtivo == 1)
	{
		pDrawButton(31593, v132, v122, 15.0, 15.0, 0.0, 0.0);
	}
//	---------------------------------
	v142 = (double)(*(DWORD *)(v26 + 20) + 227 + PosY);
	v152 = (double)(*(DWORD *)(v26 + 16) + 150);

	if(pCheckMouseOver( v152, v142, 15, 15 ) && (*(BYTE*)0x8793386) && GetTickCount() >= TimerEventVK2 + 250 )
	{
		if(EffectAtivo !=0)
		{	
			//gInterface.DrawMessage(1, "Teste [OFF]");
			//DelectEffectDynamicOff_Hook();
			SetByte(0x00608FB0, 0xC3); //Disable Skill Effects
			//DelectEffectStaticOff_Hook();
			EffectAtivo = 0;
		}
		else
		{
			//gInterface.DrawMessage(1, "Teste [ON]");
			//DelectEffectDynamicOn_Hook();
			SetByte(0x00608FB0, 0x55); //Disable Skill Effects	
			//DelectEffectStaticOn_Hook();
			EffectAtivo = 1;
		}
		TimerEventVK2 = GetTickCount();
	}

	if(EffectAtivo == 0)
	{
		pDrawButton(31593, v152, v142, 15.0, 15.0, 0.0, 15.0);
	}
	if(EffectAtivo == 1)
	{
		pDrawButton(31593, v152, v142, 15.0, 15.0, 0.0, 0.0);
	}
//
//	---------------------------------
	v162 = (double)(*(DWORD *)(v26 + 20) + 249 + PosY);
	v172 = (double)(*(DWORD *)(v26 + 16) + 150);

	if(pCheckMouseOver( v172, v162, 15, 15 ) && (*(BYTE*)0x8793386) && GetTickCount() >= TimerEventVK3 + 250 )
	{
		if(FlagAtivo !=0)
		{	
			gInterface.DrawMessage(1, "Remove Wings [OFF]");
			SetCompleteHook(0xE8, 0x00588661, 0x005655C0);
			SetByte(0x0051EC90, 0x55);
			SetByte(0x0051EE20, 0x55); //Disable Cloaks
			FlagAtivo = 0;
		}
		else
		{
			gInterface.DrawMessage(1, "Remove Wings [ON]");
			MemorySet(0x588661, 0x90, 0x5);
			SetByte(0x0051EC90, 0xC3);
			SetByte(0x0051EE20, 0xC3); //Disable Cloaks
			FlagAtivo = 1;
		}
		TimerEventVK3 = GetTickCount();
	}

	if(FlagAtivo == 0)
	{
		pDrawButton(31593, v172, v162, 15.0, 15.0, 0.0, 15.0);
	}
	if(FlagAtivo == 1)
	{
		pDrawButton(31593, v172, v162, 15.0, 15.0, 0.0, 0.0);
	}
//

	//volume click and image
	v16 = (double)(*(DWORD *)(v26 + 20) + 104 + PosY);
	v17 = (double)(*(DWORD *)(v26 + 16) + 33);
	pDrawGUI(31596, v17, v16, 124.0, 16.0);

	if (*(DWORD *)(v26 + 200) > 0)
	{
		//volume click and image
		v18 = (double)*(signed int *)(v26 + 200) * 12.40000057220459;
		v19 = (double)(*(DWORD *)(v26 + 20) + 104 + PosY);
		v20 = (double)(*(DWORD *)(v26 + 16) + 33);
		pDrawGUI(31597, v20, v19, v18, 16.0);
	}

	//effect limitation
	v21 = (double)(*(DWORD *)(v26 + 20) + 168 + PosY);
	v22 = (double)(*(DWORD *)(v26 + 16) + 25);
	pDrawGUI(31594, v22, v21, 141.0, 29.0);
	if (*(DWORD *)(v26 + 204) >= 0)
	{	
		//effect limitation
		v23 = (double)(*(DWORD *)(v26 + 204) + 1) * 28.20000076293945;
		v24 = (double)(*(DWORD *)(v26 + 20) + 168 + PosY);
		v25 = (double)(*(DWORD *)(v26 + 16) + 25);
		pDrawGUI(31595, v25, v24, v23, 29.0);
	}
}

int RenderOptionTextOrigin(int a1)
{
	int v4; // ST1C_4@1
	float v5; // ST20_4@1
	float v6; // ST24_4@1
	float v7; // ST24_4@1
	float v8; // ST24_4@1
	float v9; // ST24_4@1
	float v10; // ST24_4@1
	HGDIOBJ v11; // ST18_4@1
	void *v12; // eax@1
	void *v13; // eax@1
	void *v14; // eax@1
	int v15; // ST08_4@1
	int v16; // ST04_4@1
	int v17; // ST00_4@1
	void *v18; // eax@1
	int v19; // ST08_4@1
	int v20; // ST04_4@1
	int v21; // ST00_4@1
	void *v22; // eax@1
	int v23; // ST08_4@1
	int v24; // ST04_4@1
	int v25; // ST00_4@1
	void *v26; // eax@1
	int v27; // ST08_4@1
	int v28; // ST04_4@1
	int v29; // ST00_4@1
	void *v30; // eax@1
	int v31; // ST08_4@1
	int v32; // ST04_4@1
	int v33; // ST00_4@1
	void *v34; // eax@1
	int v35; // ST04_4@1
	int v36; // ST00_4@1
	float prox;
	float prox1;
	float prox2;
	float PosY;

	v4 = *(DWORD *)(GetInstance() + 160);
	PosY -= 28;

	v5 = (double)*(signed int *)(v4 + 16) + 20.0;
	v6 = (double)*(signed int *)(v4 + 20) + 46.0 + PosY;
	pDrawGUI(31592, v5, v6, 10.0, 10.0);
	v7 = v6 + 22.0;
	pDrawGUI(31592, v5, v7, 10.0, 10.0);
	v8 = v7 + 22.0;
	pDrawGUI(31592, v5, v8, 10.0, 10.0);
	v9 = v8 + 40.0;
	pDrawGUI(31592, v5, v9, 10.0, 10.0);
	v10 = v9 + 22.0;
	pDrawGUI(31592, v5, v10, 10.0, 10.0);
	prox = v10 + 58.0;
	pDrawGUI(31592, v5, prox, 10.0, 10.0);
	prox1 = prox + 22.0;
	pDrawGUI(31592, v5, prox1, 10.0, 10.0);
	prox2 = prox1 + 22.0;
	pDrawGUI(31592, v5, prox2, 10.0, 10.0);

	pSetFont(pTextThis(), (int)pFontNormal);
	pSetTextColor(pTextThis(), 0xFFu, 0xFFu, 0xFFu, 0xFFu);
	sub_4200F0_Addr(pTextThis(), 0);
		
	v16 = *(DWORD *)(v4 + 20) + 48 + PosY;
	v17 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v17, v16, pGetTextLine(pTextLineThis, 386), 0, 0, 1, 0); //-- Attack Automatic

	v20 = *(DWORD *)(v4 + 20) + 70 + PosY;
	v21 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v21, v20, pGetTextLine(pTextLineThis, 387), 0, 0, 1, 0); //-- Beep Sound

	v24 = *(DWORD *)(v4 + 20) + 92 + PosY;
	v25 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v25, v24, pGetTextLine(pTextLineThis, 389), 0, 0, 1, 0); //-- Volumen

	v28 = *(DWORD *)(v4 + 20) + 132 + PosY;
	v29 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v29, v28, pGetTextLine(pTextLineThis, 919), 0, 0, 1, 0); //-- Slide Help
	
	v35 = *(DWORD *)(v4 + 20) + 211 + PosY;
	v36 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v36, v35, "Ctrl Ativo", 0, 0, 1, 0); //-- Ctrl Ativo
	
	v35 = *(DWORD *)(v4 + 20) + 233 + PosY;
	v36 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v36, v35, "Remove Effects", 0, 0, 1, 0); //-- Effects
	
	v35 = *(DWORD *)(v4 + 20) + 255 + PosY;
	v36 = *(DWORD *)(v4 + 16) + 40;
	pDrawText(pTextThis(), v36, v35, "Remove Wings/Capes", 0, 0, 1, 0); //-- Wings

	v32 = *(DWORD *)(v4 + 20) + 154 + PosY;
	v33 = *(DWORD *)(v4 + 16) + 40;
	return pDrawText(pTextThis(), v33, v32, pGetTextLine(pTextLineThis, 1840), 0, 0, 1, 0); //-- Effect Limit
}

void RenderWindowsOptionOrigin(int a1)
{
	float v1; 
	float v2; 
	float v3; 
	float v4; 
	float v5; 
	float v6; 
	float v7; 
	float v8; 
	float v9; 
	float v10; 
	float v11; 
	float v12; 
	float v13; 
	int v14; 
	signed int i; 
	float v16;
	float v17;

	v14 = *(DWORD *)(GetInstance() + 160);

	//v16 = (double)*(signed int *)(v14 + 16);
	//v4 = (double)*(signed int *)(v14 + 20);
	
	v1 = (double)60;	//Posi��o Y das Janelas
	v2 = (double)220;	//Largura das Janelase
	v4 = (double)210;	//Posi��o X das Janelas

	v3 = (double)(12); //Y barra de cima
	RenderBitmap(79325, v4, v3 + v1, v2, 5.0, 0, 0, 0.83203125, 0.625, 1, 1, 0.0);

	for (i = 0; i < 6; ++i)
	{
		v5 = (double)12 + (double)(40 * i + 5); //Y do fundo
		RenderBitmap(79324, v4, v5 + v1, v2, 40.0, 0, 0, 0.83203125, 0.625, 1, 1, 0.0);
	}

	v6 = (double)(12) + 240.0; //Y barra de baixo
	RenderBitmap(79325, v4, v6 + v1, v2, 5.0, 0, 0, 0.83203125, 0.625, 1, 1, 0.0);
}


bool CheckAttackMouseOver(int x, int y, int w, int h) //-- ataque automatico
{
	int This; // [sp+74h] [bp-4h]@1

	This = *(DWORD *)(GetInstance() + 160);

	y = (double)(*(DWORD *)(This + 20) + 43 - 28);
	x = (double)(*(DWORD *)(This + 16) + 150);

	return pCheckMouseOver(x, y, 15, 15);
}

bool CheckBeepMouseOver(int x, int y, int w, int h) //-- ataque automatico
{
	int This; // [sp+74h] [bp-4h]@1

	This = *(DWORD *)(GetInstance() + 160);

	y = (double)(*(DWORD *)(This + 20) + 65 - 28);
	x = (double)(*(DWORD *)(This + 16) + 150);

	return pCheckMouseOver( x, y, 15, 15);
}

bool CheckSlideMouseOver(int x, int y, int w, int h) //-- ataque automatico
{
	int This; // [sp+74h] [bp-4h]@1

	This = *(DWORD *)(GetInstance() + 160);

	y = (double)(*(DWORD *)(This + 20) + 127 - 28);
	x = (double)(*(DWORD *)(This + 16) + 150);

	return pCheckMouseOver(x, y, 15, 15);
}

bool CheckSoundMouseOver(int x, int y, int w, int h) //-- ataque automatico
{
	int This; // [sp+74h] [bp-4h]@1

	This = getWindowConfig_35((int)pWindowThis());

	y = *(DWORD *)(This + 20) + 104 - 28;

	return pCheckMouseOver(x, y, w, h);
}

bool CheckEffectMouseOver(int x, int y, int w, int h) //-- ataque automatico
{
	int This; // [sp+74h] [bp-4h]@1

	This = getWindowConfig_35((int)pWindowThis());

	y = *(DWORD *)(This + 20) + 168 - 28;

	return pCheckMouseOver( x, y, w, h);
}

void RenderFrame()
{
	void* v3; // eax@1
	int v4; // eax@1
	float v5; // [sp+20h] [bp-4h]@1

	v5 = 480.0 - (float)51.0;
	pDrawGUI(31292, 0.0, v5 + 0.75, 256.0, 51.0);
	pDrawGUI(31293, 256.0, v5, 128.0, 51.0);
	pDrawGUI(31294, 384.0, v5, 256.0, 51.0);

	//RenderBitmap(31292, 0.0, 432.0, 256.0, 48.0, 0, 0, 1.0, 0.75, 1, 1, 0);
	//RenderBitmap(31293, 256.0, 432.0, 128.0, 48.0, 0, 0, 1.0, 0.75, 1, 1, 0);
	//RenderBitmap(31294, 384.0, 432.0, 256.0, 48.0, 0, 0, 1.0, 0.75, 1, 1, 0);

	v4 = sub_861200(g_pNewUISystem());
	if (sub_815000(v4) == 1)
	{
		pDrawGUI(31295, 222.0, v5, 160.0, 40.0);
	}

	glColor3f(0.91000003, 0.81, 0.60000002);

	//gInterface.DrawInterface97Menu();
	//
	//gInterface.DrawInterfaceDragonLS3();
	//
	//gInterface.DrawInterfaceDragonRS3();
}

void SDBarNew(int a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9, char a10, char a11, float a12)
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	if(*(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x2A) > 0 && *(WORD*)(*(DWORD*)(MAIN_CHARACTER_STRUCT)+0x2C) > 0)
	{
		RenderBitmap(31300, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12);
	}
	else
	{
		RenderBitmap(75125, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12);
	}
	glColor3f(0.91000003, 0.81, 0.60000002);
}

void MoveCharacterListName(int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{
	pSetFont(pTextThis(), (int)pFontBold);
	pRender_rendertext(g_Fontthis(), iPos_x, iPos_y + 12, pszText, iBoxWidth, iBoxHeight, iSort, lpTextSize);
}

void ColorCharacterListLevel(LPVOID a1, int color)
{
	pSetFont(pTextThis(), (int)pFontNormal2);
	SetTextColorByHDC(pTextThis(), pMakeColor(0xFFu, 0xFFu, 0xFFu, 0xFFu));
}

double RenderNumberRemake(float a1, float a2, int a3, float a4, float a5)
{
	float v10; // [sp+38h] [bp+8h]@1
	EnableAlphaTest(1);

	char strText[32];
	_itoa(a3, strText, 10);
	int iLength = (int)strlen(strText);

	v10 = a1 - (double)iLength * a4 / 2.0;

	for (int i = 0; i < iLength; ++i)
	{
		float fU = (float)(strText[i] - 48) * 16.f / 256.f;
		RenderBitmap(542028, v10, a2, a4, a5, fU, 0, 0.0625, 0.5, 1, 1, 0.0);
		v10 = a4 * 0.69999999 + v10;
	}

	return v10;
}


void DrawHp(float a1, float a2, int Value, float a4)
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	RenderNumberRemake(140.0, 467.0, Value, 9.0, 10.0);
	glColor3f(0.91000003, 0.81, 0.60000002);
}

void DrawMp(float a1, float a2, int Value, float a4)
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	RenderNumberRemake(520.0, 467.0, Value, 9.0, 10.0);
	glColor3f(0.91000003, 0.81, 0.60000002);
}

void DrawSd(float a1, float a2, int Value, float a4)
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	RenderNumberRemake(93.0, 467.0, Value, 9.0, 10.0);
	glColor3f(0.91000003, 0.81, 0.60000002);
}

void DrawAg(float a1, float a2, int Value, float a4)
{
	glColor3f(0.91000003, 0.81, 0.60000002);
	RenderNumberRemake(571.0, 467.0, Value, 9.0, 10.0);
	glColor3f(0.91000003, 0.81, 0.60000002);
}

__declspec(naked) void DrawInterfaceS2DisableR1()
{
	static DWORD RButtonAddress = 0x00895C0C;
	_asm {jmp RButtonAddress}
}

__declspec(naked) void DrawAGPosition1()
{
	static float AGPositionW = 14.0f;
	static float AGPositionH = 43.0f;
	static float AGPositionX = 485.5f;
	static float AGPositionY = 433.7f;
	static DWORD AGPosition_buff = 0x008102AD;
	_asm
	{
		FLD DWORD PTR DS : [AGPositionW]
		FSTP DWORD PTR SS : [EBP - 0x18]
		FLD DWORD PTR DS : [AGPositionH]
		FSTP DWORD PTR SS : [EBP - 0x14]
		FLD DWORD PTR DS : [AGPositionX]
		FSTP DWORD PTR SS : [EBP - 0x10]
		FLD DWORD PTR DS : [AGPositionY]
		FSTP DWORD PTR SS : [EBP - 0x0C]
		jmp[AGPosition_buff]
	}
}
__declspec(naked) void DrawSDPosition1()
{
	static float SDPositionW = 14.0f;
	static float SDPositionH = 43.0f;
	static float SDPositionX = 142.0f;
	static float SDPositionY = 433.7f;
	static DWORD SDPosition_buff = 0x0081057D;
	_asm
	{
		FLD DWORD PTR DS : [SDPositionW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [SDPositionH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		FLD DWORD PTR DS : [SDPositionX]
		FSTP DWORD PTR SS : [EBP - 0x10]
		FLD DWORD PTR DS : [SDPositionY]
		FSTP DWORD PTR SS : [EBP - 0x0C]
		jmp[SDPosition_buff]
	}
}
//--------------------------------------------
__declspec(naked) void DrawMANAPosition1()
{
	static float MANAPositionW = 52.0f;
	static float MANAPositionH = 60.0f;
	static float MANAPositionX = 430.7f;
	static float MANAPositionY = 417.0f;
	static DWORD MANAPosition_buff = 0x0080FFD0;
	_asm
	{
		FLD DWORD PTR DS : [MANAPositionW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [MANAPositionX]
		FSTP DWORD PTR SS : [EBP - 0x0C]
		FLD DWORD PTR DS : [MANAPositionH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		FLD DWORD PTR DS : [MANAPositionY]
		FSTP DWORD PTR SS : [EBP - 0x8]
		jmp[MANAPosition_buff]
	}
}
__declspec(naked) void DrawHPPosition1()
{
	static float HPPositionW = 52.0f;
	static float HPPositionH = 51.0f;
	static float HPPositionX = 163.0f;
	static float HPPositionY = 428.0f;
	static DWORD HPPosition_buff = 0x0080FD7C;
	_asm
	{
		FLD DWORD PTR DS : [HPPositionW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [HPPositionX]
		FSTP DWORD PTR SS : [EBP - 0x0C]
		FLD DWORD PTR DS : [HPPositionH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		FLD DWORD PTR DS : [HPPositionY]
		FSTP DWORD PTR SS : [EBP - 0x8]
		jmp[HPPosition_buff]
	}
}
__declspec(naked) void DrawHPNumberPosition11()
{
	gInterface.DrawCoord();
	static float HPNumberPositionX = 38.0f;
	static DWORD HPNumberPosition_buff = 0x0080FF1E;
	_asm
	{
		FADD DWORD PTR DS : [HPNumberPositionX]
		FSTP DWORD PTR SS : [EBP - 0x19C]
		FLD DWORD PTR SS : [EBP - 0x19C]
		jmp[HPNumberPosition_buff]
	}
}


signed int JCGetScreenWidth()
{
	signed int v52; // [sp+0h] [bp-4h]@11

	v52 = ((signed int(*)()) 0x005C6E80)();

	return v52;
}

signed int JCWinIngame()
{
	return 640;
}

signed int JCFrustumWidth()
{
	if (pWinWidth <= 0 || pWinHeight <= 0)
	{
		return 640;
	}

	int width = (pWinWidth * 480) / pWinHeight;

	return (width > 640) ? width : 640;
}

void Master_back(DWORD a1, float a2, float a3, float a4, float a5) {
	pDrawGUI(a1, a2, a3, a4, 428);
}

bool CheckMouseWindow(int x, int y, int w, int h)
{
	if (pCheckWindow(pWindowThis(), 78))
	{
		x = 70;
		w = 380;
	}
	return pCheckMouseOver(x, y, w, h);
}

__declspec(naked) void DrawQPosition11()
{
	static float BarNumberY = 443.0f;
	static DWORD QPosition1_buff = 0x00895A4F;
	_asm
	{
		FLD DWORD PTR DS : [BarNumberY]
		FSTP DWORD PTR SS : [ESP]
		jmp[QPosition1_buff]
	}
}
__declspec(naked) void DrawQPosition21()
{
	static float QPosition2X = 230.0f;
	static DWORD QPosition2_buff = 0x00895A59;
	_asm
	{
		FLD DWORD PTR DS : [QPosition2X]
		FSTP DWORD PTR SS : [ESP]
		jmp[QPosition2_buff]
	}
}
__declspec(naked) void DrawQPosition31()
{
	static float BarPotionY = 453.0f;
	static DWORD QPosition3_buff = 0x00895A63;

	_asm
	{
		FLD DWORD PTR DS : [BarPotionY]
		FSTP DWORD PTR SS : [ESP]
		jmp[QPosition3_buff]
	}
}
__declspec(naked) void DrawQPosition41()
{
	static float QPosition4X = 222.0f;
	static DWORD QPosition4_buff = 0x00895A6D;

	_asm
	{
		FLD DWORD PTR DS : [QPosition4X]
		FSTP DWORD PTR SS : [ESP]
		jmp[QPosition4_buff]
	}
}
__declspec(naked) void DrawWPosition11()
{
	static float BarNumberY = 443.0f;
	static DWORD WPosition1_buff = 0x00895AC4;
	_asm
	{
		FLD DWORD PTR DS : [BarNumberY]
		FSTP DWORD PTR SS : [ESP]
		jmp[WPosition1_buff]
	}
}
__declspec(naked) void DrawWPosition21()
{
	static float WPosition2X = 261.0f;
	static DWORD WPosition2_buff = 0x00895ACE;
	_asm
	{
		FLD DWORD PTR DS : [WPosition2X]
		FSTP DWORD PTR SS : [ESP]
		jmp[WPosition2_buff]
	}
}
__declspec(naked) void DrawWPosition31()
{
	static float BarPotionY = 453.0f;
	static DWORD WPosition3_buff = 0x00895AD8;

	_asm
	{
		FLD DWORD PTR DS : [BarPotionY]
		FSTP DWORD PTR SS : [ESP]
		jmp[WPosition3_buff]
	}
}
__declspec(naked) void DrawWPosition41()
{
	static float WPosition4X = 250.0f;
	static DWORD WPosition4_buff = 0x00895AE2;

	_asm
	{
		FLD DWORD PTR DS : [WPosition4X]
		FSTP DWORD PTR SS : [ESP]
		jmp[WPosition4_buff]
	}
}
__declspec(naked) void DrawEPosition11()
{
	static float BarNumberY = 443.0f;
	static DWORD EPosition1_buff = 0x00895B39;
	_asm
	{
		FLD DWORD PTR DS : [BarNumberY]
		FSTP DWORD PTR SS : [ESP]
		jmp[EPosition1_buff]
	}
}
__declspec(naked) void DrawEPosition21()
{
	static float EPosition2X = 287.0f;
	static DWORD EPosition2_buff = 0x00895B43;
	_asm
	{
		FLD DWORD PTR DS : [EPosition2X]
		FSTP DWORD PTR SS : [ESP]
		jmp[EPosition2_buff]
	}
}
__declspec(naked) void DrawEPosition31()
{
	static float BarPotionY = 453.0f;
	static DWORD EPosition3_buff = 0x00895B4D;

	_asm
	{
		FLD DWORD PTR DS : [BarPotionY]
		FSTP DWORD PTR SS : [ESP]
		jmp[EPosition3_buff]
	}
}
__declspec(naked) void DrawEPosition41()
{
	static float EPosition4X = 278.0f;
	static DWORD EPosition4_buff = 0x00895B57;
	_asm
	{
		FLD DWORD PTR DS : [EPosition4X]
		FSTP DWORD PTR SS : [ESP]
		jmp[EPosition4_buff]
	}
}

__declspec(naked) void DrawEXP11()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP1_buff = 0x00811408;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR SS : [EBP - 0x1B0]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXP1_buff]
	}
}

__declspec(naked) void DrawEXP21()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP2_buff = 0x00811552;
	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR SS : [EBP - 0x1C4]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXP2_buff]
	}
}

__declspec(naked) void DrawEXP31()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP3_buff = 0x00811719;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR SS : [EBP - 0x1B0]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXP3_buff]
	}
}

__declspec(naked) void DrawEXP41()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXP4_buff = 0x0081181F;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		FLD QWORD PTR SS : [EBP - 0x20]
		jmp[EXP4_buff]
	}
}

//EXP MASTER
__declspec(naked) void DrawEXPMASTER11()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AltoTex = 5.8f;
	static double AnchoTex = 198.0f;
	static DWORD EXPMASTER1_buff = 0x00810B6E;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD QWORD PTR SS : [EBP - 0x58]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXPMASTER1_buff]
	}
}

__declspec(naked) void DrawEXPMASTER21()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER2_buff = 0x00810CB5;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD QWORD PTR SS : [EBP - 0x88]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXPMASTER2_buff]
	}
}

__declspec(naked) void DrawEXPMASTER31()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER3_buff = 0x00810E79;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD QWORD PTR SS : [EBP - 0x58]
		FMUL QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXPMASTER3_buff]
	}
}

__declspec(naked) void DrawEXPMASTER41()
{
	static double Ancho = 221.0f;
	static double Alto = 432.5f;
	static double AnchoTex = 198.0f;
	static double AltoTex = 5.8f;
	static DWORD EXPMASTER4_buff = 0x00810F73;

	_asm
	{
		FLD QWORD PTR DS : [Ancho]
		FSTP QWORD PTR SS : [EBP - 0x10]
		FLD QWORD PTR DS : [Alto]
		FSTP QWORD PTR SS : [EBP - 0x8]
		FLD QWORD PTR DS : [AnchoTex]
		FSTP QWORD PTR SS : [EBP - 0x28]
		FLD QWORD PTR DS : [AltoTex]
		FSTP QWORD PTR SS : [EBP - 0x20]
		jmp[EXPMASTER4_buff]
	}
}
__declspec(naked) void ToolTipSkill()
{
	static DWORD SkillRavenClicDraw_buff = 0x00813C25;

	_asm
	{
		PUSH ECX
		MOV EDX, DWORD PTR SS : [EBP - 0x04]
		MOV EAX, DWORD PTR DS : [EDX + 0x4C]
		SUB EAX, 0x1B
		PUSH EAX
		MOV ECX, DWORD PTR SS : [EBP - 0x04]
		MOV EDX, DWORD PTR DS : [ECX + 0x48]
		ADD EDX, 0x0F
		jmp[SkillRavenClicDraw_buff]
	}
}

int StackNumberPotion(float x, float y, int number)
{
	return ((float(__cdecl*)(float x, float y, int iNum, float fScale)) 0x00791000)(x, y, number, 0.9);
}
bool Render_SkillFullMouser1(DWORD a1)
{
	bool result; // al@2
	unsigned __int8 v5; // ST4F_1@3
	int v62; // [sp+Ch] [bp-54h]@1
	int v64; // [sp+18h] [bp-48h]@84
	unsigned __int16 v66; // [sp+24h] [bp-3Ch]@53
	signed int v67; // [sp+2Ch] [bp-34h]@40
	signed int v68; // [sp+30h] [bp-30h]@40
	unsigned __int16 v69; // [sp+38h] [bp-28h]@76
	float v70; // [sp+40h] [bp-20h]@5
	float v71; // [sp+40h] [bp-20h]@28
	float v72; // [sp+40h] [bp-20h]@40
	float v73; // [sp+40h] [bp-20h]@73
	float v74; // [sp+40h] [bp-20h]@116
	float v75; // [sp+44h] [bp-1Ch]@5
	float v76; // [sp+44h] [bp-1Ch]@28
	float v77; // [sp+44h] [bp-1Ch]@73
	char v78; // [sp+4Bh] [bp-15h]@73
	float v79; // [sp+4Ch] [bp-14h]@73
	signed int v80; // [sp+50h] [bp-10h]@73
	int v81; // [sp+54h] [bp-Ch]@73
	float v82; // [sp+58h] [bp-8h]@5
	float v83; // [sp+58h] [bp-8h]@28
	float v84; // [sp+58h] [bp-8h]@40
	float v85; // [sp+58h] [bp-8h]@85
	float v86; // [sp+58h] [bp-8h]@116
	float v87; // [sp+5Ch] [bp-4h]@5
	float v88; // [sp+5Ch] [bp-4h]@28
	float v89; // [sp+5Ch] [bp-4h]@40
	float v90; // [sp+5Ch] [bp-4h]@73
	float v91; // [sp+5Ch] [bp-4h]@116*/
	signed int j; // [sp+10h] [bp-50h]@116
	signed int i; // [sp+20h] [bp-40h]@73

	v62 = a1;
	if (pCheckEffectPlayer((DWORD*)(*(DWORD*)0x7BC4F04 + 1260), 98))
	{
		*(BYTE*)(v62 + 64) = 0;
		result = 1;
	}
	else
	{
		v5 = *(BYTE*)(*(DWORD*)0x8128AC8 + 118);
		*(BYTE*)(v62 + 65) = 0;
		if ((signed int)v5 > 0)
		{
			//-- skill en uso
			v82 = 310.0;
			v87 = 445.0f;
			v70 = 25.0f;
			v75 = 32.0f;
			if (*(DWORD*)(v62 + 80) || *(BYTE*)0x8793384 || pCheckMouseOver(v82, v87, v70, v75) != 1)
			{
				if (*(DWORD*)(v62 + 80) != 1 || *(BYTE*)0x8793384 || pCheckMouseOver(v82, v87, v70, v75))
				{
					if (*(DWORD*)(v62 + 80) != 1 || *(BYTE*)0x8793384 != 1 && *(BYTE*)0x8793380 != 1 || pCheckMouseOver(v82, v87, v70, v75) != 1)
					{
						if (*(DWORD*)(v62 + 80) != 2 || *(BYTE*)0x8793384 || *(BYTE*)0x8793380)
						{
							if (*(DWORD*)(v62 + 80) == 1)
							{
								*(BYTE*)(v62 + 65) = 1;
								*(DWORD*)(v62 + 68) = *(BYTE*)(*(DWORD*)0x7BC4F04 + 50);
								*(DWORD*)(v62 + 72) = v82 - 5.0;
								*(DWORD*)(v62 + 76) = v87;
								result = 0;
							}
							else if (*(DWORD*)(v62 + 80) == 2)
							{
								result = 0;
							}
							else
							{
								//-- DrawSkill Bar
								v83 = 330.0;
								v88 = 480.0f;
								v71 = 100.0;
								v76 = 20.0;
								if (*(DWORD*)(v62 + 80) || *(BYTE*)0x8793384 || pCheckMouseOver(v83, v88, v71, v76) != 1)
								{
									if (*(DWORD*)(v62 + 80) != 3 || *(BYTE*)0x8793384 || pCheckMouseOver(v83, v88, v71, v76))
									{
										if (*(DWORD*)(v62 + 80) != 3 || *(BYTE*)0x8793384 != 1 || pCheckMouseOver(v83, v88, v71, v76) != 1)
										{
											//-- DrawSkill Bar Slot 5
											v84 = 315.0;
											v89 = 480.0f;
											v72 = 20.0;
											v68 = 0;
											v67 = *(BYTE*)(v62 + 20) != 1 ? 1 : 6;
											while (v68 < 5)
											{
												v84 = v84 + v72;
												if (v67 == 10)
													v67 = 0;
												if (pCheckMouseOver(v84, v89, v72, (float)32.0) == 1)
												{
													if (*(DWORD*)(v62 + 4 * v67 + 24) == -1)
													{
														if (*(DWORD*)(v62 + 80) == 3)
														{
															*(BYTE*)(v62 + 65) = 0;
															*(DWORD*)(v62 + 68) = -1;
														}
														if (*(DWORD*)(v62 + 80) == 4 && !*(BYTE*)0x8793384)
															*(DWORD*)(v62 + 80) = 0;
													}
													else
													{
														v66 = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * *(DWORD*)(v62 + 4 * v67 + 24) + 120);
														if (v66 && ((signed int)v66 < 67 || (signed int)v66 > 72) && *(BYTE*)(*(DWORD*)0x8128ABC + 88 * v66 + 55) != 3)
														{
															if (*(DWORD*)(v62 + 80) == 3)
															{
																*(BYTE*)(v62 + 65) = 1;
																*(DWORD*)(v62 + 68) = *(DWORD*)(v62 + 4 * v67 + 24);
																*(DWORD*)(v62 + 72) = v84 - 5.0;
																*(DWORD*)(v62 + 76) = v89;
																return 1;
															}
															if (*(DWORD*)(v62 + 80) == 4 && !*(BYTE*)0x8793384)
															{
																if (*(DWORD*)(v62 + 68) == *(DWORD*)(v62 + 4 * v67 + 24))
																{
																	*(DWORD*)(v62 + 80) = 0;
																	*(WORD*)(v62 + 84) = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * *(BYTE*)(*(DWORD*)0x7BC4F04 + 50) + 120);
																	*(BYTE*)(*(DWORD*)0x7BC4F04 + 50) = *(BYTE*)(v62 + 4 * v67 + 24);
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
																*(DWORD*)(v62 + 80) = 0;
															}
														}
													}
												}
												++v68;
												++v67;
											}
											if (*(DWORD*)(v62 + 80) == 4)
											{
												//-- DrawSkill Bar
												if (*(BYTE*)0x8793384 || pCheckMouseOver((float)330.0, (float)480.0f, (float)100.0, (float)32.0))
												{
													result = 0;
												}
												else
												{
													*(DWORD*)(v62 + 80) = 0;
													result = 1;
												}
											}
											else if (*(BYTE*)(v62 + 64))
											{
												//-- SkillBarSwitch
												v80 = 0;
												v78 = 0;
												v90 = 390.0;//-- y
												v73 = 32.0;//-- w
												v77 = 38.0;//-- h
												v79 = 302.0;//-- x
												v81 = *(DWORD*)(v62 + 80);
												for (i = 0; i < 150; ++i)
												{
													v69 = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * i + 120);
													if (v69 && ((signed int)v69 < 67 || (signed int)v69 > 72) && *(BYTE*)(*(DWORD*)0x8128ABC + 88 * v69 + 55) != 3)
													{
														if (v80 == 11)
															v90 = v90 - v77;
														if (v80 >= 11)
														{
															if (v80 < 11 || v80 > 21)
																v85 = v79 - v73 * 11.0 + (double)(v80 - 21) * v73;
															else
																v85 = v79 - v73 * 6.0 + (double)(v80 - 10) * v73;
														}
														else
														{
															v64 = v80 / 2;
															if (v80 % 2)
																v85 = v79 - (double)(v64 + 1) * v73;
															else
																v85 = (double)v64 * v73 + v79;
														}
														++v80;
														if (pCheckMouseOver(v85, v90, v73, v77) == 1)
														{
															v78 = 1;
															if (!*(DWORD*)(v62 + 80) && !*(BYTE*)0x8793384)
															{
																*(DWORD*)(v62 + 80) = 5;
																break;
															}
														}
														if (*(DWORD*)(v62 + 80) == 5 && *(BYTE*)0x8793384 == 1)
														{
															if (pCheckMouseOver(v85, v90, v73, v77) == 1)
															{
																*(DWORD*)(v62 + 80) = 6;
																break;
															}
														}
														if (*(DWORD*)(v62 + 80) == 5 && !*(BYTE*)0x8793384)
														{
															if (pCheckMouseOver(v85, v90, v73, v77) == 1)
															{
																*(BYTE*)(v62 + 65) = 1;
																*(DWORD*)(v62 + 68) = i;
																*(DWORD*)(v62 + 72) = v85;
																*(DWORD*)(v62 + 76) = v90;
															}
														}
														if (*(DWORD*)(v62 + 80) == 6 && !*(BYTE*)0x8793384 && *(DWORD*)(v62 + 68) == i)
														{
															if (pCheckMouseOver(v85, v90, v73, v77) == 1)
															{
																*(DWORD*)(v62 + 80) = 0;
																*(WORD*)(v62 + 84) = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * *(BYTE*)(*(DWORD*)0x7BC4F04 + 50) + 120);
																*(BYTE*)(*(DWORD*)0x7BC4F04 + 50) = i;
																*(BYTE*)(v62 + 64) = 0;
																PlayBuffer(25, 0, 0);
																return 0;
															}
														}
													}
												}
												if (v81 == *(DWORD*)(v62 + 80))
												{
													if (*(DWORD*)(*(DWORD*)0x7BC4F04 + 676))
													{
														//-- SkillFixRaven
														v86 = 270.0;
														v91 = 350.0;
														v74 = 32.0;
														for (j = 150; j < 154; ++j)
														{
															if (pCheckMouseOver(v86, v91, v74, (float)38.0) == 1)
															{
																v78 = 1;
																if (!*(DWORD*)(v62 + 80) && !*(BYTE*)0x8793384)
																{
																	*(DWORD*)(v62 + 80) = 5;
																	return 1;
																}
																if (*(DWORD*)(v62 + 80) == 5 && *(BYTE*)0x8793384 == 1)
																{
																	*(DWORD*)(v62 + 80) = 6;
																	return 0;
																}
																if (*(DWORD*)(v62 + 80) == 5)
																{
																	*(BYTE*)(v62 + 65) = 1;
																	*(DWORD*)(v62 + 68) = j;
																	*(DWORD*)(v62 + 72) = v86;
																	*(DWORD*)(v62 + 76) = v91;
																}
																if (*(DWORD*)(v62 + 80) == 6 && !*(BYTE*)0x8793384 && *(DWORD*)(v62 + 68) == j)
																{
																	*(DWORD*)(v62 + 80) = 0;
																	*(WORD*)(v62 + 84) = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * *(BYTE*)(*(DWORD*)0x7BC4F04 + 50) + 120);
																	*(BYTE*)(*(DWORD*)0x7BC4F04 + 50) = j;
																	*(BYTE*)(v62 + 64) = 0;
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
															}
															v86 = v86 + v74;
														}
													}
													if (v78 || *(DWORD*)(v62 + 80) != 5)
													{
														if (v78 || *(BYTE*)0x8793384 || *(DWORD*)(v62 + 80) != 6)
														{
															if (*(DWORD*)(v62 + 80) == 6)
															{
																if (*(BYTE*)0x8793384)
																{
																	result = 0;
																}
																else
																{
																	*(DWORD*)(v62 + 80) = 0;
																	result = 1;
																}
															}
															else
															{
																result = 1;
															}
														}
														else
														{
															*(DWORD*)(v62 + 80) = 0;
															result = 0;
														}
													}
													else
													{
														*(DWORD*)(v62 + 80) = 0;
														result = 1;
													}
												}
												else
												{
													result = !*(DWORD*)(v62 + 80) || *(DWORD*)(v62 + 80) == 5;
												}
											}
											else
											{
												result = 1;
											}
										}
										else
										{
											*(DWORD*)(v62 + 80) = 4;
											result = 0;
										}
									}
									else
									{
										*(DWORD*)(v62 + 80) = 0;
										result = 1;
									}
								}
								else
								{
									*(DWORD*)(v62 + 80) = 3;
									result = 1;
								}
							}
						}
						else
						{
							if (pCheckMouseOver(v82, v87, v70, v75) == 1)
							{
								*(BYTE*)(v62 + 64) = *(BYTE*)(v62 + 64) == 0;
								PlayBuffer(25, 0, 0);
								*(DWORD*)(v62 + 80) = 0;
								result = 0;
							}
							else
							{
								*(DWORD*)(v62 + 80) = 0;
								result = 1;
							}
						}
					}
					else
					{
						*(DWORD*)(v62 + 80) = 2;
						result = 0;
					}
				}
				else
				{
					*(DWORD*)(v62 + 80) = 0;
					result = 1;
				}
			}
			else
			{
				*(DWORD*)(v62 + 80) = 1;
				result = 1;
			}
		}
		else
		{
			result = 1;
		}
	}
	return result;
}

void RenderSkill_Raven1(DWORD* a1)
{
	float v4; // ST18_4@7
	float v5; // ST14_4@7
	int v6; // [sp+18h] [bp-18h]@1
	signed int i; // [sp+1Ch] [bp-14h]@2
	float v8; // [sp+20h] [bp-10h]@2
	float v9; // [sp+24h] [bp-Ch]@2
	float v10; // [sp+28h] [bp-8h]@2
	float v11; // [sp+2Ch] [bp-4h]@2

	v6 = *(DWORD*)a1;
	if (*(DWORD*)(*(DWORD*)0x7BC4F04 + 676))
	{
		v10 = 270.0;//X
		v11 = 350.0;//Y
		v8 = 32.0;
		v9 = 38.0;
		for (i = 150; i < 154; ++i)
		{
			if (i == *(BYTE*)(*(DWORD*)0x7BC4F04 + 50))
				pDrawGUI(31313, v10, v11, v8, v9);
			else
				pDrawGUI(31312, v10, v11, v8, v9);
			v4 = v11 + 6.0;
			v5 = v10 + 6.0;
			((int(__thiscall*)(DWORD * This, int Skill, float X, float Y, float W, float H)) 0x00813DC0)(a1, i, v5, v4, 20.0, 28.0);
			v10 = v10 + v8;
		}
	}
}

void Render_Funcion_772EA01(int ThisR1)
{
	static DWORD Addr1 = 0x00815040;
	static DWORD Addr2_Call = 0x00772EA0;
	static DWORD This = 0x00772EA0;

	This = ThisR1;

	_asm
	{
		PUSH 0; / Arg5 = 00000000
		PUSH 0; | Arg4 = 00000000
		MOV ECX, This; |
		PUSH ECX; | Arg3
		PUSH Addr1; | Arg2 = 00815040
		PUSH ECX; | Arg1
		FLD DWORD PTR DS : [0xD2CA40] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		MOV EDX, This; |
		MOV ECX, DWORD PTR DS : [EDX + 0x10] ; |
		CALL Addr2_Call; \main1.00772EA0
	}
}



char Render_SkillBarSwitch1(int This)
{
	float v4; // ST18_4@26
	float v5; // ST14_4@26
	int v7; // [sp+28h] [bp-34h]@1
	int v8; // [sp+30h] [bp-2Ch]@15
	char v9; // [sp+37h] [bp-25h]@9
	float v10; // [sp+38h] [bp-24h]@3
	signed int v11; // [sp+3Ch] [bp-20h]@3
	signed int v12; // [sp+40h] [bp-1Ch]@6
	float v13; // [sp+44h] [bp-18h]@3
	float v14; // [sp+48h] [bp-14h]@3
	signed int i; // [sp+50h] [bp-Ch]@3
	float v16; // [sp+54h] [bp-8h]@16
	float v17; // [sp+58h] [bp-4h]@3

	v7 = This;

	if ((signed int)*(BYTE*)(*(DWORD*)0x8128AC8 + 118) > 0 && *(BYTE*)(v7 + 64) == 1)
	{
		v17 = 390.0;//Y
		v13 = 32.0;
		v14 = 38.0;
		v10 = 302.0;//X
		v11 = 0;

		for (i = 0; i < 150; ++i)
		{
			v12 = *(WORD*)(*(DWORD*)0x8128AC8 + 2 * i + 120);

			if (*(WORD*)(*(DWORD*)0x8128AC8 + 2 * i + 120) && (v12 < 67 || v12 > 72))
			{
				v9 = *(BYTE*)(*(DWORD*)0x8128ABC + 88 * v12 + 55);
				if (v9 != 1 && v9 != 3)
				{
					if (v11 == 11)
					{
						v17 = v17 - v14;
					}
					if (v11 >= 11)
					{
						if (v11 < 11 || v11 > 21)
						{
							v16 = v10 - v13 * 11.0 + (double)(v11 - 21) * v13;
						}
						else
						{
							v16 = v10 - v13 * 6 + (double)(v11 - 10) * v13;
						}
					}
					else
					{
						v8 = v11 / 2;
						if (v11 % 2)
						{
							v16 = v10 - (double)(v8 + 1) * v13;
						}
						else
						{
							v16 = (double)v8 * v13 + v10;
						}
					}

					++v11;

					if (i == *(BYTE*)(*(DWORD*)0x7BC4F04 + 50))//-- Seleccionado
					{
						pDrawGUI(31313, v16, v17, v13, v14);
					}
					else
					{
						pDrawGUI(31312, v16, v17, v13, v14);
					}
					v4 = v17 + 6.0;
					v5 = v16 + 6.0;
					((int(__thiscall*)(DWORD * This, int Skill, float X, float Y, float W, float H)) 0x00813DC0)((DWORD*)This, i, v5, v4, 20.0, 28.0);
				}
			}
		}
		RenderSkill_Raven1((DWORD*)This);
	}

	if (*(BYTE*)(This + 65) == 1 && *(DWORD*)(This + 16))
	{
		Render_Funcion_772EA01(This);
		*(BYTE*)(This + 65) = 0;
	}
	return 1;
}
//--------------------------------------------
__declspec(naked) void DrawUsingSkillPosition1()
{
	static float UsingSkillPositionX = 311.0f;
	static float UsingSkillPositionY = 447.0f;
	static float UsingSkillPositionW = 20.0f;
	static float UsingSkillPositionH = 28.0f;
	static DWORD UsingSkillPosition_buff = 0x00813900;
	_asm
	{
		FLD DWORD PTR DS : [UsingSkillPositionX]
		FSTP DWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR DS : [UsingSkillPositionY]
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR DS : [UsingSkillPositionW]
		FSTP DWORD PTR SS : [EBP - 0x18]
		FLD DWORD PTR DS : [UsingSkillPositionH]
		FSTP DWORD PTR SS : [EBP - 0x14]
		jmp[UsingSkillPosition_buff]
	}
}
__declspec(naked) void DrawSkillClickPosition1()
{
	static float SkillClickPositionX = 310.0f;
	static float SkillClickPositionY = 445.0f;
	static float SkillClickPositionW = 25.0f;
	static float SkillClickPositionH = 32.0f;
	static DWORD SkillClickPosition_buff = 0x00812734;
	_asm
	{
		FLD DWORD PTR DS : [SkillClickPositionX]
		FSTP DWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR DS : [SkillClickPositionY]
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR DS : [SkillClickPositionW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [SkillClickPositionH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		jmp[SkillClickPosition_buff]
	}
}
//--------------------------------------------
__declspec(naked) void DrawSkillBarDrawPosition1()
{
	static float SkillBarDrawPositionX = 222.0f;
	static float SkillBarDrawPositionY = 480.0f;
	static float SkillBarDrawPositionW = 160.0f;
	static float SkillBarDrawPositionH = 38.0f;
	static DWORD SkillBarDrawPosition_buff = 0x00812968;
	_asm
	{
		FLD DWORD PTR DS : [SkillBarDrawPositionX]
		FSTP DWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR DS : [SkillBarDrawPositionY]
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR DS : [SkillBarDrawPositionW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [SkillBarDrawPositionH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		jmp[SkillBarDrawPosition_buff]
	}
}
//--------------------------------------------
__declspec(naked) void DrawSkillSwitchDraw1()
{

	static float SkillSwitchDrawX = 385.0f;
	static float SkillSwitchDrawY = 350.0f;
	static float SkillSwitchDrawW = 32.0f;
	static float SkillSwitchDrawH = 38.0f;
	static float SkillSwitchDrawMW = 385.0f;
	static DWORD SkillSwitchDraw_buff = 0x008139CA;

	_asm
	{
		FLD DWORD PTR DS : [SkillSwitchDrawX]
		FSTP DWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR DS : [SkillSwitchDrawY]
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR DS : [SkillSwitchDrawW]
		FSTP DWORD PTR SS : [EBP - 0x18]
		FLD DWORD PTR DS : [SkillSwitchDrawH]
		FSTP DWORD PTR SS : [EBP - 0x14]
		FLD DWORD PTR DS : [SkillSwitchDrawMW]
		FSTP DWORD PTR SS : [EBP - 0x24]
		jmp[SkillSwitchDraw_buff]

	}
}
__declspec(naked) void DrawSkillSwitchClick1()
{
	static float SkillSwitchDrawX = 385.0f;
	static float SkillSwitchDrawY = 350.0f;
	static float SkillSwitchDrawW = 32.0f;
	static float SkillSwitchDrawH = 38.0f;
	static float SkillSwitchDrawMW = 385.0f;
	static DWORD SkillSwitchClick_buff = 0x00812D69;

	_asm
	{
		FLD DWORD PTR DS : [SkillSwitchDrawX]
		FSTP DWORD PTR SS : [EBP - 0x8]
		FLD DWORD PTR DS : [SkillSwitchDrawY]
		FSTP DWORD PTR SS : [EBP - 0x4]
		FLD DWORD PTR DS : [SkillSwitchDrawW]
		FSTP DWORD PTR SS : [EBP - 0x20]
		FLD DWORD PTR DS : [SkillSwitchDrawH]
		FSTP DWORD PTR SS : [EBP - 0x1C]
		FLD DWORD PTR DS : [SkillSwitchDrawMW]
		FSTP DWORD PTR SS : [EBP - 0x14]
		jmp[SkillSwitchClick_buff]
	}
}

__declspec(naked) void OffButtonSkillMasterInStats()
{
	static DWORD ButtonAddress = 0x0077ECE7;
	_asm {jmp ButtonAddress}
}

void InterfaceRemakeLoad()
{
	SetCompleteHook(0xE8, 0x007818D4, &ColorText);
	SetCompleteHook(0xE8, 0x007801A8, &ColorText);
	SetCompleteHook(0xE8, 0x00782CE4, &ColorText);
	SetCompleteHook(0xE8, 0x007830BE, &ColorText);
	SetCompleteHook(0xE8, 0x00784B4A, &ColorText);
	SetCompleteHook(0xE8, 0x0077FCAD, &ColorText);

	//-------------------------------------------------------------------	
	SetCompleteHook(0xE9, 0x008126C0, &Render_SkillFullMouser1);
	SetCompleteHook(0xE9, 0x00813970, &Render_SkillBarSwitch1);

	SetRange((LPVOID)0x008138DF, 0x24, 0x90);
	SetOp(0x008138DF, (LPVOID)DrawUsingSkillPosition1, 0xE9);
	//-------------------------------------------------------------------	
	SetRange((LPVOID)0x00812713, 0x24, 0x90);
	SetOp(0x00812713, (LPVOID)DrawSkillClickPosition1, 0xE9);
	//------------//-------------------------------------------------------	
	SetRange((LPVOID)0x00812947, 0x24, 0x90);
	SetOp(0x00812947, (LPVOID)DrawSkillBarDrawPosition1, 0xE9);
	//-------------------------------------------------------------------	
	SetRange((LPVOID)0x008139A0, 0x2D, 0x90);
	SetOp(0x008139A0, (LPVOID)DrawSkillSwitchDraw1, 0xE9);
	//-------------------------------------------------------------------	
	SetRange((LPVOID)0x00812D3F, 0x2D, 0x90);
	SetOp(0x00812D3F, (LPVOID)DrawSkillSwitchClick1, 0xE9);
	SetRange((LPVOID)0x00D46C8C, 5, 0x90);		//-> Remove Interface [Socket Option]
	SetRange((LPVOID)0x00D46C84, 5, 0x90);		//-> Remove Interface [Set Option]
	//-------------------------------------------------------------------	
	MemorySet(0x00895B8D, 0x90, 0x7E); //Disable R option
	SetCompleteHook(0xE9, 0x00895B8D, &DrawInterfaceS2DisableR1);
	//-------------------------------------------------------------------	
	SetRange((LPVOID)0x0080F270, 0x4D1, 0x90);//-> Interface -> Draw Button
	//-------------------------------------------------------------------	
	SetByte((0x008137AF + 3), 0);
	SetByte((0x008119A7), 0xEB);
	SetRange((LPVOID)0x00811AC0, 0xAC, 0x90);
	//--------------------------DrawMANAPosition-----------------------------------------	
	SetRange((LPVOID)0x0080FFAF, 0x24, 0x90);
	SetOp(0x0080FFAF, (LPVOID)DrawMANAPosition1, 0xE9);
	//------------------------------DrawHPPosition-------------------------------------	
	SetRange((LPVOID)0x0080FD5B, 0x24, 0x90);
	SetOp(0x0080FD5B, (LPVOID)DrawHPPosition1, 0xE9);
	//---------------------------------DrawAGPosition----------------------------------	
	SetRange((LPVOID)0x0081028C, 0x24, 0x90);
	SetOp(0x0081028C, (LPVOID)DrawAGPosition1, 0xE9);
	//----------------------------------DrawSDPosition---------------------------------		
	SetRange((LPVOID)0x0081055C, 0x24, 0x90);
	SetOp(0x0081055C, (LPVOID)DrawSDPosition1, 0xE9);
	//------------------------------DrawHPNumberPosition-------------------------------------	
	SetRange((LPVOID)0x0080FF12, 0x12, 0x90);
	SetOp(0x0080FF12, (LPVOID)DrawHPNumberPosition11, 0xE9);

	SetDouble(0x00D461C8, 198);					//-> Experience Bar Max Size
	SetDouble(0x00D461C0, 425);					//-> Exp Number Position X
	SetDouble(0x00D461B8, 431);					//-> Exp Number Position Y

	SetFloat(0x00D43220, 0x00);					//-> Top buff icons Size X
	SetFloat(0x00D43224, 0x00);					//-> Top buff icons Size Y
	SetDword(0x004D9746 + 3, 480);				//deshabilita el background

	//->Q
	SetRange((LPVOID)0x00895A49, 0x9, 0x90);
	SetOp(0x00895A49, (LPVOID)DrawQPosition11, 0xE9);
	//-
	SetRange((LPVOID)0x00895A53, 0x9, 0x90);
	SetOp(0x00895A53, (LPVOID)DrawQPosition21, 0xE9);
	//-
	SetRange((LPVOID)0x00895A5D, 0x9, 0x90);
	SetOp(0x00895A5D, (LPVOID)DrawQPosition31, 0xE9);
	//-
	SetRange((LPVOID)0x00895A67, 0x9, 0x90);
	SetOp(0x00895A67, (LPVOID)DrawQPosition41, 0xE9);
	//->W
	SetRange((LPVOID)0x00895ABE, 0x9, 0x90);
	SetOp(0x00895ABE, (LPVOID)DrawWPosition11, 0xE9);
	//-
	SetRange((LPVOID)0x00895AC8, 0x9, 0x90);
	SetOp(0x00895AC8, (LPVOID)DrawWPosition21, 0xE9);
	//-
	SetRange((LPVOID)0x00895AD2, 0x9, 0x90);
	SetOp(0x00895AD2, (LPVOID)DrawWPosition31, 0xE9);
	//-
	SetRange((LPVOID)0x00895ADC, 0x9, 0x90);
	SetOp(0x00895ADC, (LPVOID)DrawWPosition41, 0xE9);
	//->E
	SetRange((LPVOID)0x00895B33, 0x9, 0x90);
	SetOp(0x00895B33, (LPVOID)DrawEPosition11, 0xE9);
	//-
	SetRange((LPVOID)0x00895B3D, 0x9, 0x90);
	SetOp(0x00895B3D, (LPVOID)DrawEPosition21, 0xE9);
	//-
	SetRange((LPVOID)0x00895B47, 0x9, 0x90);
	SetOp(0x00895B47, (LPVOID)DrawEPosition31, 0xE9);
	//-
	SetRange((LPVOID)0x00895B51, 0x9, 0x90);
	SetOp(0x00895B51, (LPVOID)DrawEPosition41, 0xE9);
	//----------------------------------
	//EXP
	SetRange((LPVOID)0x008113DE, 5, 0x90);
	SetOp(0x008113DE, (LPVOID)DrawEXP11, 0xE9);
	SetRange((LPVOID)0x00811528, 5, 0x90);
	SetOp(0x00811528, (LPVOID)DrawEXP21, 0xE9);
	SetRange((LPVOID)0x008116EF, 5, 0x90);
	SetOp(0x008116EF, (LPVOID)DrawEXP31, 0xE9);
	SetRange((LPVOID)0x008117F8, 5, 0x90);
	SetOp(0x008117F8, (LPVOID)DrawEXP41, 0xE9);
	//------------------------------------------------------------------------------
	//EXPMASTER
	SetRange((LPVOID)0x00810B47, 5, 0x90);
	SetOp(0x00810B47, (LPVOID)DrawEXPMASTER11, 0xE9);
	SetRange((LPVOID)0x00810C8B, 5, 0x90);
	SetOp(0x00810C8B, (LPVOID)DrawEXPMASTER21, 0xE9);
	SetRange((LPVOID)0x00810E52, 5, 0x90);
	SetOp(0x00810E52, (LPVOID)DrawEXPMASTER31, 0xE9);
	SetRange((LPVOID)0x00810F4F, 5, 0x90);
	SetOp(0x00810F4F, (LPVOID)DrawEXPMASTER41, 0xE9);
	SetRange((LPVOID)0x00810B7F, 5, 0x90);

	//===========================================================
	//===========================================================
	SetRange((LPVOID)0x006E899D, 5, 0x90);
	SetRange((LPVOID)0x007126FA, 5, 0x90);
	SetRange((LPVOID)0x005B768F, 5, 0x90);
	SetRange((LPVOID)0x005B770C, 5, 0x90);

	SetDouble((0x00D27AF8), 0.5);
	SetFloat((0x00D461A4), 471);
	//===========================================================
	//===========================================================
	SetCompleteHook(0xE8, 0x00857746, &CheckMouseWindow); //-- baul check
	//--
	SetCompleteHook(0xE8, 0x005B6180, &JCGetScreenWidth);
	//--
	SetCompleteHook(0xE8, 0x0040F2E9, &JCWinIngame); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D714E, &JCWinIngame); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D79E7, &JCWinIngame); //-- Camara General Renderizado
	SetCompleteHook(0xE8, 0x004D9756, &JCWinIngame); //-- Camara General Renderizado
	//--
	//-- Frustum 2D do terreno: largura proporcional ao aspecto real da tela
	SetCompleteHook(0xE8, 0x005DB4D5, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB1AA, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB22F, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB322, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB3A7, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB46D, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB4AD, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB534, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB5C4, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB628, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB68C, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x005DB6ED, &JCFrustumWidth);
	SetCompleteHook(0xE8, 0x008605BF, &JCWinIngame); //-- load character
	//-
	SetCompleteHook(0xE8, 0x005B8344, &JCGetScreenWidth); //-- check cursor attack
	SetCompleteHook(0xE8, 0x0047FFF4, &JCGetScreenWidth); //-- Load MapName In-game
	SetCompleteHook(0xE8, 0x0048007C, &JCGetScreenWidth); //-- Load MapName In-game
	SetCompleteHook(0xE8, 0x004F2A6C, &JCGetScreenWidth); //-- algo del raven
	SetCompleteHook(0xE8, 0x004F2B55, &JCGetScreenWidth); //-- algo del raven
	SetCompleteHook(0xE8, 0x005B4956, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x005B9E22, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x005BAFE5, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007D453E, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007DF2D9, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007DFD4B, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007DFD54, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007DFD68, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007F3F87, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007F4A63, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x007FAC46, &JCGetScreenWidth);
	SetCompleteHook(0xE8, 0x008346F6, &JCGetScreenWidth);

	SetCompleteHook(0xE8, 0x0085F90C, &JCGetScreenWidth);
	SetOp(0x0081A146, (LPVOID)Master_back, 0xE8); //0081A146 1.04e	//00819FF6 1.04d
	SetOp(0x0081A199, (LPVOID)Master_back, 0xE8); //0081A199 1.04e //0081A049 1.04d

	//	//newui_item_box
	SetDword(0x007D991A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_box.tga");
	//newui_item_boots
	SetDword(0x00836B7A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_boots.tga");
	////newui_item_cap
	SetDword(0x00836B9A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_cap.tga");
	////newui_item_fairy
	SetDword(0x00836BBA + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_fairy.tga");
	//	

	//	//newui_item_gloves
	SetDword(0x00836C5A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_gloves.tga");
	//newui_item_lower
	SetDword(0x00836C7A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_lower.tga");
	//newui_item_ring
	SetDword(0x00836C9A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_ring.tga");
	//newui_item_necklace
	SetDword(0x00836CBA + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_necklace.tga");
	////newui_item_wing
	//SetDword(0x00836BDA+1,(DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_wing.tga");
	//newui_item_weapon(L)
	SetDword(0x00836BFA + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_weapon(L).tga");
	//newui_item_weapon(R)
	SetDword(0x00836C1A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_weapon(R).tga");
	////newui_item_upper
	SetDword(0x00836C3A + 1, (DWORD)"Custom\\Interface\\Gfx\\Menu\\newui_item_upper.tga");

	SetCompleteHook(0xE8, 0x4D5EC3, &func_5977E0);
	SetDword(0x00784DAA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D993A+1,(DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x0084B33A+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E79A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879C0A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008804EA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882D2A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784DCA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D995A+1,(DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x0084B35A+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E7BA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879C2A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088050A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882D4A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784DEA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D997A+1,(DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x0084B37A+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E7DA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879C4A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088052A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882D6A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784E0A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D999A+1,(DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x0084B39A+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E7FA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879C6A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088054A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882D8A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784E4A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x007CDE0A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D99DA+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084B3DA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E83A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879CAA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088058A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882DCA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008842CA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784E6A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x007CDE2A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D99FA+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084B3FA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E85A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879CCA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008805AA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882DEA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008842EA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784E8A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x007CDE4A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D9A1A+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084B41A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E87A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879CEA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008805CA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882E0A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088430A + 1, (DWORD)"Custom\\Interface\\none.tga");
	//--
	SetDword(0x00784E2A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x007CDDEA + 1, (DWORD)"Custom\\Interface\\none.tga");
	//SetDword(0x007D99BA+1,(DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084B3BA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0084E81A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00879C8A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x0088056A + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x00882DAA + 1, (DWORD)"Custom\\Interface\\none.tga");
	SetDword(0x008842AA + 1, (DWORD)"Custom\\Interface\\none.tga");

	//-> Fix Skill Tooltip Position
	SetCompleteHook(0xE9, 0x00813C11, &ToolTipSkill);

	//-> Size of Potions Number
	SetCompleteHook(0xE9, 0x00895600, &StackNumberPotion);

	SetCompleteHook(0xE9, 0x0077FDA4, &BackPointColorInventory);
	SetCompleteHook(0xE9, 0x0077FD87, &PointColorInventory);
	SetCompleteHook(0xE8, 0x0077F7EE, &CClassicUICharacterInfoWindow);
	SetDword((0x0077E935 + 1), 51290);
	SetByte((0x0077E94A + 1), 24);
	SetByte((0x0077E94C + 1), 24);
	SetByte((0x0077E957 + 2), 117);
	SetByte((0x0077E964 + 1), 130);
	SetDword((0x0077E97E + 1), 51290);
	SetByte((0x0077E996 + 1), 24);
	SetByte((0x0077E998 + 1), 24);
	SetByte((0x0077E9A3 + 2), 172);
	SetByte((0x0077E9B3 + 2), 130);
	SetDword((0x0077E9D1 + 1), 51290);
	SetByte((0x0077E9E9 + 1), 24);
	SetByte((0x0077E9EB + 1), 24);
	SetByte((0x0077E9F6 + 1), 237);
	SetByte((0x0077EA05 + 2), 130);
	SetDword((0x0077EA23 + 1), 51290);
	SetByte((0x0077EA3B + 1), 24);
	SetByte((0x0077EA3D + 1), 24);
	SetByte((0x0077EA48 + 2), 292);
	SetByte((0x0077EA58 + 1), 130);
	SetDword((0x0077EA75 + 1), 51290);
	SetByte((0x0077EA8D + 1), 24);
	SetByte((0x0077EA8F + 1), 24);
	SetByte((0x0077EA9A + 2), 347);
	SetByte((0x0077EAAA + 2), 130);
	SetByte((0x007801D9 + 1), 4);
	SetByte((0x007801DD + 1), 42);
	SetByte((0x00780217 + 1), 2);
	SetByte((0x0078023A + 2), 56);
	SetByte((0x0078190D + 1), 4);
	SetByte((0x00781911 + 1), 42);
	SetByte((0x0078194E + 1), 2);
	SetByte((0x00781973 + 2), 56);
	SetByte((0x007830EF + 1), 4);
	SetByte((0x007830F3 + 1), 42);
	SetByte((0x00783130 + 1), 2);
	SetByte((0x00783155 + 2), 56);
	SetByte((0x00782D15 + 1), 4);
	SetByte((0x00782D19 + 1), 42);
	SetByte((0x00782D56 + 1), 2);
	SetByte((0x00782D7C + 2), 56);
	SetByte((0x00782D15 + 1), 4);
	SetByte((0x00782D19 + 1), 42);
	SetByte((0x00782D56 + 1), 2);
	SetByte((0x00782D7C + 2), 56);
	SetByte((0x00784B6D + 1), 4);
	SetByte((0x00784B71 + 1), 42);
	SetByte((0x00784BAE + 1), 2);
	SetByte((0x00784BD4 + 2), 56);
	//--
	//-- Windows Command
	SetCompleteHook(0xE8, 0x0078E6D6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0078E70A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0078E74A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0078E79C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0078E7E2, &DowngradeLoadWindowsNone);

	//-- Windows Helper
	SetCompleteHook(0xE8, 0x007F65A6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007F65E6, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007F6638, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007F66A2, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007F66FA, &DowngradeLoadWindowsNone);
	//-- Windows MuHelper2
	SetCompleteHook(0xE8, 0x0080C848, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0080C87C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0080C8BC, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0080C90E, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0080C954, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido1
	SetCompleteHook(0xE8, 0x00845956, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0084598A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008459C7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00845A10, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00845A4F, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido2
	SetCompleteHook(0xE8, 0x007C6BCC, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007C6C06, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C6C49, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C6C98, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C6CDD, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido3
	SetCompleteHook(0xE8, 0x007C7D0C, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007C7D46, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C7D89, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C7DD8, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007C7E1D, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido4
	SetCompleteHook(0xE8, 0x00850966, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0085099A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008509D7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00850A20, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00850A5F, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido5
	SetCompleteHook(0xE8, 0x00852476, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008524AA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008524E7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00852530, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0085256F, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido6
	SetCompleteHook(0xE8, 0x008540B6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008540EA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00854127, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00854170, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008541AF, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido7
	SetCompleteHook(0xE8, 0x00868052, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0086808C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008680D5, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00868130, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0086817B, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido8
	SetCompleteHook(0xE8, 0x0087F886, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0087F8BA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0087F8F7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0087F940, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0087F97F, &DowngradeLoadWindowsNone);
	//-- Windows Desconocido9 NPC CASTLE SIEGE
	SetCompleteHook(0xE8, 0x00882F52, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x00882F8C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00882FD5, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00883030, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0088307B, &DowngradeLoadWindowsNone);
	//-- Windows NPC Lugar
	SetCompleteHook(0xE8, 0x00893102, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0089313C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00893185, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008931E0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0089322B, &DowngradeLoadWindowsNone);
	//-- Windows Guard NPC
	SetCompleteHook(0xE8, 0x008812A2, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008812DC, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00881325, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00881380, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008813CB, &DowngradeLoadWindowsNone);
	//-- Windows NPC Senior
	SetCompleteHook(0xE8, 0x00879EE2, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x00879F1C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00879F65, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00879FC0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0087A00B, &DowngradeLoadWindowsNone);
	//-- Windows BloodCastle
	SetCompleteHook(0xE8, 0x008747B6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008747F0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0087483C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008748A0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008748F2, &DowngradeLoadWindowsNone);
	//-- Windows DevilSquare
	SetCompleteHook(0xE8, 0x008781BC, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008781F0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00878230, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00878282, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008782C8, &DowngradeLoadWindowsNone);
	//-- Windows Pet
	SetCompleteHook(0xE8, 0x0084D01A, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0084D05A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084D0AC, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084D116, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084D16E, &DowngradeLoadWindowsNone);
	//-- Windows Party
	SetCompleteHook(0xE8, 0x0084A546, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0084A57A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084A5BA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084A60C, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084A652, &DowngradeLoadWindowsNone);

	//-- Windows ChaosMachine
	SetCompleteHook(0xE8, 0x0082CA22, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0082CB4B, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0082CB00, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0082CAA5, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0082CA5C, &DowngradeLoadWindowsNone);
	//-- Windows Store
	SetCompleteHook(0xE8, 0x00841E49, &DowngradeStoreLoadWindows);
	SetCompleteHook(0xE8, 0x00841E7D, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00841EBA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00841F03, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00841F42, &DowngradeLoadWindowsNone);
	//-- Windows Store Other PJ
	SetCompleteHook(0xE8, 0x0084F406, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0084F43A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084F477, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084F4C0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084F4FF, &DowngradeLoadWindowsNone);
	//-- Windows Baul
	SetCompleteHook(0xE8, 0x00857946, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0085797A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008579B7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00857A00, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00857A3F, &DowngradeLoadWindowsNone);
	//-- Windows Baul Ext.
	SetCompleteHook(0xE8, 0x008567E6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0085681A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00856857, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008568A0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008568DF, &DowngradeLoadWindowsNone);
	//-- Windows Inventory
	SetCompleteHook(0xE8, 0x00836EF6, &DowngradeInventoryWindows);
	SetCompleteHook(0xE8, 0x00836F2A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00836F67, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00836FB0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00836FEF, &DowngradeLoadWindowsNone);
	//-- Windows Inventory Ext.
	SetCompleteHook(0xE8, 0x007D55A6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007D55DA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D5617, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D5660, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D569F, &DowngradeLoadWindowsNone);
	//-- Windows Shop.
	SetCompleteHook(0xE8, 0x008470A6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008470DA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00847117, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00847160, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084719F, &DowngradeLoadWindowsNone);
	//-- Windows GuildMarker
	SetCompleteHook(0xE8, 0x007D1786, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007D17BA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D17F7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D1840, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007D187F, &DowngradeLoadWindowsNone);
	//-- Windows Guild User
	SetCompleteHook(0xE8, 0x007CB6F6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x007CB72A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007CB767, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007CB7B0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x007CB7EF, &DowngradeLoadWindowsNone);

	//-- Windows Gens-Quest
	SetCompleteHook(0xE8, 0x00843826, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0084385A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00843897, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008438E0, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0084391F, &DowngradeLoadWindowsNone);
	//-- Windows Quest (T)
	SetCompleteHook(0xE8, 0x0083EA46, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x0083EA7A, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0083EAB7, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0083EB00, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x0083EB3F, &DowngradeLoadWindowsNone);
	//-- Windows Trade
	SetCompleteHook(0xE8, 0x008643B6, &DowngradeLoadWindows);
	SetCompleteHook(0xE8, 0x008643EA, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00864427, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x00864470, &DowngradeLoadWindowsNone);
	SetCompleteHook(0xE8, 0x008644AF, &DowngradeLoadWindowsNone);

	SetDword((0x007D0EF6 + 1), 350);			//POSI��O Y GUILD MASTER BUTTONS PART1
	SetDword((0x007D0F5D + 1), 350);			//POSI��O Y GUILD MASTER BUTTONS PART1
	SetByte((0x007D0F05 + 2), 43);				//POSI��O X GUILD MASTER BUTTONS PART1
	SetByte((0x007D0F6C + 2), 88);				//POSI��O X GUILD MASTER BUTTONS PART1
	SetDword((0x007D11DE + 2), 350);			//POSI��O Y GUILD MASTER BUTTONS PART2
	SetDword((0x007D1249 + 2), 350);			//POSI��O Y GUILD MASTER BUTTONS PART2
	SetByte((0x007D11EE + 2), 43);				//POSI��O X GUILD MASTER BUTTONS PART2
	SetByte((0x007D1259 + 2), 88);				//POSI��O X GUILD MASTER BUTTONS PART2
	MemorySet(0x007A8330, 0x90, 0x198);		//MENU ESC TRANSPARENTE
	//
	SetCompleteHook(0xE9, 0x00777008, &GuildWarPosition);
	MemorySet(0x00776FE4, 0x90, 0x5); //RETIRA IMAGEM GUILD WAR

	RenderSlot = -1;
	SetCompleteHook(0xE9, 0x007DB308, &ShadowColorCheck); //Get Slot Type
	SetCompleteHook(0xE8, 0x007DB5D0, &RenderItemBox);

	//SetByte((0x00834D93+1),0x52);			//KEY REPAIR (R)
	SetByte((0x0078DDFF + 2), 48);	//X
	SetByte((0x0078DDF1 + 3), 60);	//Y
	MemorySet(0x0085B6AC, 0x90, 0x05); 	//-- Remove Helper Top Screen
	MemorySet(0x0085CC50, 0x90, 0x05); 	//-- Disable Helper (Key Z)
	MemorySet(0x007D40A2, 0x90, 0x05); 	//-- Disable Helper (Key Home)
	//Remove border Inventory
	MemorySet(0x007DB7B0, 0x90, 0x05);
	MemorySet(0x007DB812, 0x90, 0x05);
	MemorySet(0x007DB874, 0x90, 0x05);
	MemorySet(0x007DB8E0, 0x90, 0x05);
	MemorySet(0x007DB959, 0x90, 0x05);
	MemorySet(0x007DB9A2, 0x90, 0x05);
	MemorySet(0x007DBA20, 0x90, 0x05);
	MemorySet(0x007DBA69, 0x90, 0x05);
	SetByte((0x007D4000 + 1), 0xFF); //REMOVE HOME KEY
	SetByte((0x007D410F + 1), 0xFF); //REMOVE Z KEY
	MemorySet(0x008684F0, 0x90, 0x52);				// Disable FastMenu (Key U)
	MemorySet(0x007C5A68, 0x90, 0x25);
	MemorySet(0x007C4430, 0x90, 0x159);				// Disable Gems
	MemorySet(0x007C5AD2, 0x90, 0x05);				// Disable Gens (Key B)

	//if (gProtect.m_MainInfo.RemoveClickSystem == 1)
	//{
	MemorySet(0x006E899D, 0x90, 5);		//CLICK EFFECT CURSOR
	MemorySet(0x007126FA, 0x90, 5);		//CLICK EFFECT CURSOR
	MemorySet(0x005B768F, 0x90, 5);		//CLICK EFFECT CURSOR
	MemorySet(0x005B770C, 0x90, 5);		//CLICK EFFECT CURSOR
	//}

	MemorySet(0x008193F0, 0x90, 0xC8);				//REMOVE JANELA MASTER SKILL TREE
	SetByte((0x007D3A4A + 1), 0xFF);			//REMOVE TECLA MASTER SKILL TREE
	SetByte(0x004030D1 + 3, 4); //Remove Sum e DL
	SetDword(0x005BB774 + 1, 31239); //Downgrade MENU D
	SetDword(0x005BB800 + 1, 31239); //Downgrade MENU D

	MemorySet(0x007AA3BA, 0x90, 0x5);
	MemorySet(0x007AA39C, 0x90, 0x5);
	MemorySet(0x007AA9B3, 0x90, 0x5);

	SetOp(0x0077EC59, (LPVOID)OffButtonPetsInStats, 0xE8);

	SetCompleteHook(0xE9, 0x00856FAA, 0x00856FD2);	//Remove (H) Ba� Aberto
	SetCompleteHook(0xE9, 0x007D371E, 0x007D3725);	//Remove bot�o (H)	
	SetCompleteHook(0xE9, 0x008369FA, 0x00836A23);	//Remove bot�o (K)
	SetCompleteHook(0xE9, 0x007D36B8, 0x007D36BF);	//Fun��o (K) Invent�rio aberto
	SetCompleteHook(0xE9, 0x007D3F9C, 0x007D3FA3);	//Fun��o (K) Ba� Aberto

	SetDword((0x004D568C + 1), (DWORD)"Custom\\InterfaceS2\\none.tga");
	SetByte((0x007D3C6B + 1), 0xFF); //DESATIVA O M MOVE

	SetByte((0x007D399F + 1), 0xFF); // Disable Key T
	SetOp(0x0077EBB0, (LPVOID)OffButtonQuestInStats, 0xE8);

	SetByte((0x007D3D56 + 1), 0xFF);	//-> Remove Key X CASH SHOP

	SetByte((0x007D37A1 + 1), 0xFF); //DESATIVA O F TECLA

	//SetByte((0x007D3AF1 + 1), 0xFF); //DESATIVA O D TELA

	//SetByte((0x00834E12 + 1), 0xFF); //DESATIVA O S STORE
	//SetOp(0x008369AF, (LPVOID)OffButtonOpenStore, 0xE8);
	MemorySet(0x008193F0, 0x90, 0xC8);

	SetCompleteHook(0xE9, 0x0077ECE2, &OffButtonSkillMasterInStats);
	SetOp(0x0077ECE2, (LPVOID)OffButtonSkillMasterInStats, 0xE8);
}



//void InterfaceRemakeLoad()
//{
//	SetRange(0x00D46C8C, 5, 0x90);      //-> Remove Interface [Socket Option]
//	SetRange(0x00D46C84, 5, 0x90);      //-> Remove Interface [Set Option]
//
//	SetCompleteHook(0xE8, 0x0080FF28, &DrawHp);
//	//
//	SetCompleteHook(0xE8, 0x008100BB, &DrawMp);
//	//
//	SetCompleteHook(0xE8, 0x00810389, &DrawAg);
//	//
//	SetCompleteHook(0xE8, 0x00810659, &DrawSd);
//	SetCompleteHook(0xE8, 0x00401F67, &ColorCharacterListLevel);			//Modifica��o da cor do nome do personagem
//	SetCompleteHook(0xE8, 0x00401EF1, &MoveCharacterListName);				//Deslocamento em Y do nome do Personagem
//	MemorySet(0x00401F56, 0x90, 0x5);										//Remo��o dos status do personagem
//	SetCompleteHook(0xE8,0x00810624,&SDBarNew);
//	//SetCompleteHook(0xE9,0x80F8E0,&RenderFrame);
//
//	SetCompleteHook(0xE8,0x007818D4,&ColorText);
//	SetCompleteHook(0xE8,0x007801A8,&ColorText);
//	SetCompleteHook(0xE8,0x00782CE4,&ColorText);
//	SetCompleteHook(0xE8,0x007830BE,&ColorText);
//	SetCompleteHook(0xE8,0x00784B4A,&ColorText);
//	SetCompleteHook(0xE8,0x0077FCAD,&ColorText);
//	
//	MemorySet(0x0080FA02,0x90,0x5);
//	
//	SetByte((0x007D3D56 + 1), 0xFF);	//-> Remove Key X CASH SHOP
//
//	SetByte((0x007D37A1 + 1), 0xFF); //DESATIVA O F TECLA
//
//	//SetByte((0x007D3AF1 + 1), 0xFF); //DESATIVA O D TELA
//
//	//SetByte((0x00834E12 + 1), 0xFF); //DESATIVA O S STORE
//	//SetOp(0x008369AF, (LPVOID)OffButtonOpenStore, 0xE8);
//
//	SetByte((0x007D3C6B + 1), 0xFF); //DESATIVA O M MOVE
//
//	SetByte((0x007D399F + 1), 0xFF); // Disable Key T
//	SetOp(0x0077EBB0, (LPVOID)OffButtonQuestInStats, 0xE8);
//	
//
//	MemorySet(0x007D582D, 0x90, 0x05);
//
//	SetCompleteHook(0xE9, 0x00856FAA, 0x00856FD2);	//Remove (H) Ba� Aberto
//	SetCompleteHook(0xE9, 0x007D371E, 0x007D3725);	//Remove bot�o (H)	
//	SetCompleteHook(0xE9, 0x008369FA, 0x00836A23);	//Remove bot�o (K)
//	SetCompleteHook(0xE9, 0x007D36B8, 0x007D36BF);	//Fun��o (K) Invent�rio aberto
//	SetCompleteHook(0xE9, 0x007D3F9C, 0x007D3FA3);	//Fun��o (K) Ba� Aberto
//
//	SetDword((0x004D568C+1),(DWORD)"Custom\\InterfaceS2\\none.tga");
//
//
//	MemorySet(0x00895B8D,0x90,0x7E); //Disable R option
//	SetCompleteHook(0xE9,0x00895B8D,&DrawInterfaceS2DisableR);
//
//	SetOp(0x0077EC59, (LPVOID)OffButtonPetsInStats, 0xE8);
//
//
//	//if (gProtect.m_MainInfo.MoveWindowSystem == 1)
//	//{
//	//	/*			NEW MOVE DOWNGRADE SYSTEM			*/
//	//	SetCompleteHook(0xE9, 0x00832862, 0x00832897);	//DISABLE GENS BATTLE (BATTLE ZONE MOVE (M))
//	//	MemorySet(0x00832CF2, 0x90, 0x5);
//	//	SetByte((0x00832C44 + 2), 5);				//BARRA AMARELA REDIMENSIONADA
//	//	//TELA M EM RESOLU��O 800
//	//	SetByte((0x00830C77 + 2), 34);
//	//	SetByte((0x00830C86 + 2), 94);
//	//	SetByte((0x00830C98 + 2), 139);
//	//	SetByte((0x00830C6A + 3), 148);				//LARGURA
//	//	//TELA M EM RESOLU��O 1024
//	//	SetByte((0x00830CB6 + 2), 29);
//	//	SetByte((0x00830CC5 + 2), 84);
//	//	SetByte((0x00830CD4 + 2), 124);
//	//	SetByte((0x00830CA9 + 3), 128);				//LARGURA
//	//	SetByte((0x00830C31 + 2), 30);
//	//	//TELA M EM RESOLU��O 1280 OK
//	//	SetByte((0x00830CF2 + 2), 25);
//	//	SetByte((0x00830D01 + 2), 69);
//	//	SetByte((0x00830D10 + 1), 104);
//	//	SetByte((0x00830CE5 + 3), 108);				//LARGURA
//	//	SetDword((0x00830D49), 500);				//DIMENSIONAMENTO DO MOVE
//	//	SetDword((0x00832443 + 2), 220);			//COMPRIMENTO DO MOVE
//	//	//TAMANHO DO MOVE - OTIMIZA��O DE TAMANHO
//	//	SetByte((0x00830D64 + 2), 33);
//	//	SetByte((0x00830D67 + 2), 55);						//REGULA O TAMANHO DO MOVE
//	//	SetByte((0x00830E55 + 2), 33);
//	//	SetByte((0x0083245B + 2), 33);
//	//	SetByte((0x00830ED3 + 2), 33);
//	//	SetByte((0X00830FD6 + 2), 33);
//	//	//RETIRA IMAGENS DO MOVE
//	//	MemorySet(0x008325D4, 0x90, 0x05);
//	//	MemorySet(0x00832639, 0x90, 0x05);
//	//	MemorySet(0x0083268F, 0x90, 0x05);
//	//	MemorySet(0x008326D7, 0x90, 0x05);
//	//	MemorySet(0x00832757, 0x90, 0x05);
//	//	MemorySet(0x00832794, 0x90, 0x05);
//	//}
//	/*			NEW MOVE DOWNGRADE SYSTEM			*/
//
//	SetByte((0x007D4000+1),0xFF); //REMOVE HOME KEY
//	SetByte((0x007D410F+1),0xFF); //REMOVE Z KEY
//	MemorySet(0x008684F0, 0x90, 0x52);				// Disable FastMenu (Key U)
//	MemorySet(0x007C5A68, 0x90, 0x25);
//	MemorySet(0x007C4430, 0x90,0x159);				// Disable Gems
//	MemorySet(0x007C5AD2, 0x90, 0x05);				// Disable Gens (Key B)
//
//	//if (gProtect.m_MainInfo.RemoveClickSystem == 1)
//	//{
//		MemorySet(0x006E899D, 0x90, 5);		//CLICK EFFECT CURSOR
//		MemorySet(0x007126FA, 0x90, 5);		//CLICK EFFECT CURSOR
//		MemorySet(0x005B768F, 0x90, 5);		//CLICK EFFECT CURSOR
//		MemorySet(0x005B770C, 0x90, 5);		//CLICK EFFECT CURSOR
//	//}
//
//	MemorySet(0x008193F0,0x90,0xC8);				//REMOVE JANELA MASTER SKILL TREE
//	SetByte((0x007D3A4A+1),0xFF);			//REMOVE TECLA MASTER SKILL TREE
//	SetByte(0x004030D1+3,4); //Remove Sum e DL
//	SetDword(0x005BB774+1,31239); //Downgrade MENU D
//	SetDword(0x005BB800+1,31239); //Downgrade MENU D
//
//	MemorySet(0x007AA3BA,0x90,0x5);
//	MemorySet(0x007AA39C,0x90,0x5);
//	MemorySet(0x007AA9B3,0x90,0x5);
//
//	SetDword((0x007AA2F4+2),190);//  BOT�O CHAOS WEAPON POSITION Y
//	SetByte((0x007AA292+2),120); //BOT�O REGULAR COMBINATION POSITION Y
//	SetByte((0x007AA669+2),50); //TEXTS CM POSITION Y
//	//-
//	SetRange((LPVOID)0x0081028C, 0x24, 0x90);
//	SetOp(0x0081028C, (LPVOID)DrawAGPosition, 0xE9);
//	//-
//	//if (gProtect.m_MainInfo.IsSD == 1)
//	//{
//		SetRange((LPVOID)0x0081055C, 0x24, 0x90);
//		SetOp(0x0081055C, (LPVOID)DrawSDPosition, 0xE9);
//	//}
//	//-
//	SetRange((LPVOID)0x0080FFAF, 0x24, 0x90);
//	SetOp(0x0080FFAF, (LPVOID)DrawMANAPosition, 0xE9);
//	//-
//	SetRange((LPVOID)0x0080FD5B, 0x24, 0x90);
//	SetOp(0x0080FD5B, (LPVOID)DrawHPPosition, 0xE9);
//	//--
//	SetRange((LPVOID)0x008138DF, 0x24, 0x90);
//	SetOp(0x008138DF, (LPVOID)DrawUsingSkillPosition, 0xE9);
//	SetRange((LPVOID)0x00812947, 0x24, 0x90);
//	SetOp(0x00812947, (LPVOID)DrawSkillBarDrawPosition, 0xE9);
//	//-
//	SetRange((LPVOID)0x0080FF12, 0x12, 0x90);
//	SetOp(0x0080FF12, (LPVOID)DrawHPNumberPosition, 0xE9);
//	//-
//	SetRange((LPVOID)0x0077EC97, 0x88, 0x90);
//	SetOp(0x0077EC97, (LPVOID)DrawMasterButton, 0xE9);
//	//->Q
//	SetRange((LPVOID)0x00895A49, 0x9, 0x90);
//	SetOp(0x00895A49, (LPVOID)DrawQPosition1, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895A53, 0x9, 0x90);
//	SetOp(0x00895A53, (LPVOID)DrawQPosition2, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895A5D, 0x9, 0x90);
//	SetOp(0x00895A5D, (LPVOID)DrawQPosition3, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895A67, 0x9, 0x90);
//	SetOp(0x00895A67, (LPVOID)DrawQPosition4, 0xE9);
//	//->W
//	SetRange((LPVOID)0x00895ABE, 0x9, 0x90);
//	SetOp(0x00895ABE, (LPVOID)DrawWPosition1, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895AC8, 0x9, 0x90);
//	SetOp(0x00895AC8, (LPVOID)DrawWPosition2, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895AD2, 0x9, 0x90);
//	SetOp(0x00895AD2, (LPVOID)DrawWPosition3, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895ADC, 0x9, 0x90);
//	SetOp(0x00895ADC, (LPVOID)DrawWPosition4, 0xE9);
//	//->E
//	SetRange((LPVOID)0x00895B33, 0x9, 0x90);
//	SetOp(0x00895B33, (LPVOID)DrawEPosition1, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895B3D, 0x9, 0x90);
//	SetOp(0x00895B3D, (LPVOID)DrawEPosition2, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895B47, 0x9, 0x90);
//	SetOp(0x00895B47, (LPVOID)DrawEPosition3, 0xE9);
//	//-
//	SetRange((LPVOID)0x00895B51, 0x9, 0x90);
//	SetOp(0x00895B51, (LPVOID)DrawEPosition4, 0xE9);
//	//EXP
//	SetRange((LPVOID)0x008113DE, 5, 0x90);
//	SetOp(0x008113DE, (LPVOID)DrawEXP1, 0xE9);
//	SetRange((LPVOID)0x00811528, 5, 0x90);
//	SetOp(0x00811528, (LPVOID)DrawEXP2, 0xE9);
//	SetRange((LPVOID)0x008116EF, 5, 0x90);
//	SetOp(0x008116EF, (LPVOID)DrawEXP3, 0xE9);
//	SetRange((LPVOID)0x008117F8, 5, 0x90);
//	SetOp(0x008117F8, (LPVOID)DrawEXP4, 0xE9);
//	//------------------------------------------------------------------------------
//	//EXPMASTER
//	SetRange((LPVOID)0x00810B47, 5, 0x90);
//	SetOp(0x00810B47, (LPVOID)DrawEXPMASTER1, 0xE9);
//	SetRange((LPVOID)0x00810C8B, 5, 0x90);
//	SetOp(0x00810C8B, (LPVOID)DrawEXPMASTER2, 0xE9);
//	SetRange((LPVOID)0x00810E52, 5, 0x90);
//	SetOp(0x00810E52, (LPVOID)DrawEXPMASTER3, 0xE9);
//	SetRange((LPVOID)0x00810F4F, 5, 0x90);
//	SetOp(0x00810F4F, (LPVOID)DrawEXPMASTER4, 0xE9);
//	SetRange((LPVOID)0x00810B7F, 5, 0x90);
//
//	//-> Interface -> Draw Button
//	MemorySet(0x0080F270,0x90,0x4D1);
//	//-
//	SetByte((0x008137AF + 3), 0);
//	SetByte((0x008119A7), 0xEB);
//	MemorySet(0x00811AC0,0x90,0xAC);
//
//	//--
//	SetCompleteHook(0xE9, 0x008126C0, &Render_SkillFullMouser);
//	SetCompleteHook(0xE9, 0x00813970, &Render_SkillBarSwitch); //aqui aonde arruma posi��o e quantidade de magias numa linha
//	SetDouble(0x00D461C8, 198);				//-> Experience Bar Max Size
//	SetDouble(0x00D461C0, 425);				//-> Exp Number Position X
//	SetDouble(0x00D461B8, 431.5);			//-> Exp Number Position Y
//	//if (gProtect.m_MainInfo.IsSD == 0)
//	//{
//	//	MemorySet(0x00810624, 0x90, 5);			// remove SD Img completamente
//	//	MemorySet(0x00810659, 0x90, 5);			// remove SD Value completamente
//	//	MemorySet(0x008106EA, 0x90, 5);			// remove SD Value completamente
//	//}
//
//	//SetOp(0x00425472,(LPVOID)SetSlidePosition,0xE8);
//	//SetOp(0x00425484,(LPVOID)SetSlidePosition,0xE8);
//
//	SetDword((0x007D0EF6+1),350);			//POSI��O Y GUILD MASTER BUTTONS PART1
//	SetDword((0x007D0F5D+1),350);			//POSI��O Y GUILD MASTER BUTTONS PART1
//	SetByte((0x007D0F05+2),43);				//POSI��O X GUILD MASTER BUTTONS PART1
//	SetByte((0x007D0F6C+2),88);				//POSI��O X GUILD MASTER BUTTONS PART1
//	SetDword((0x007D11DE+2),350);			//POSI��O Y GUILD MASTER BUTTONS PART2
//	SetDword((0x007D1249+2),350);			//POSI��O Y GUILD MASTER BUTTONS PART2
//	SetByte((0x007D11EE+2),43);				//POSI��O X GUILD MASTER BUTTONS PART2
//	SetByte((0x007D1259+2),88);				//POSI��O X GUILD MASTER BUTTONS PART2
//	MemorySet(0x007A8330,0x90,0x198);		//MENU ESC TRANSPARENTE
//	//
//	SetCompleteHook(0xE9, 0x00777008, &GuildWarPosition);
//	MemorySet(0x00776FE4,0x90,0x5); //RETIRA IMAGEM GUILD WAR
//
//	RenderSlot = -1;
//	SetCompleteHook(0xE9, 0x007DB308, &ShadowColorCheck); //Get Slot Type
//	SetCompleteHook(0xE8, 0x007DB5D0, &RenderItemBox);
//		
//	//SetByte((0x00834D93+1),0x52);			//KEY REPAIR (R)
//	SetByte((0x0078DDFF+2),48);	//X
//	SetByte((0x0078DDF1+3),60);	//Y
//	MemorySet(0x0085B6AC, 0x90, 0x05); 	//-- Remove Helper Top Screen
//	MemorySet(0x0085CC50, 0x90, 0x05); 	//-- Disable Helper (Key Z)
//	MemorySet(0x007D40A2, 0x90, 0x05); 	//-- Disable Helper (Key Home)
//	//Remove border Inventory
//	MemorySet(0x007DB7B0, 0x90, 0x05);
//	MemorySet(0x007DB812, 0x90, 0x05);
//	MemorySet(0x007DB874, 0x90, 0x05);
//	MemorySet(0x007DB8E0, 0x90, 0x05);
//	MemorySet(0x007DB959, 0x90, 0x05);
//	MemorySet(0x007DB9A2, 0x90, 0x05);
//	MemorySet(0x007DBA20, 0x90, 0x05);
//	MemorySet(0x007DBA69, 0x90, 0x05);
//	//
//	SetCompleteHook(0xE9, 0x0077FDA4, &BackPointColorInventory);
//	SetCompleteHook(0xE9, 0x0077FD87, &PointColorInventory);
//	SetCompleteHook(0xE8, 0x0077F7EE, &CClassicUICharacterInfoWindow);
//	SetDword((0x0077E935 + 1), 51290);
//	SetByte((0x0077E94A + 1), 24);
//	SetByte((0x0077E94C + 1), 24);
//	SetByte((0x0077E957 + 2), 117);
//	SetByte((0x0077E964 + 1), 130);
//	SetDword((0x0077E97E + 1), 51290);
//	SetByte((0x0077E996 + 1), 24);
//	SetByte((0x0077E998 + 1), 24);
//	SetByte((0x0077E9A3 + 2), 172);
//	SetByte((0x0077E9B3 + 2), 130);
//	SetDword((0x0077E9D1 + 1), 51290);
//	SetByte((0x0077E9E9 + 1), 24);
//	SetByte((0x0077E9EB + 1), 24);
//	SetByte((0x0077E9F6 + 1), 237);
//	SetByte((0x0077EA05 + 2), 130);
//	SetDword((0x0077EA23 + 1), 51290);
//	SetByte((0x0077EA3B + 1), 24);
//	SetByte((0x0077EA3D + 1), 24);
//	SetByte((0x0077EA48 + 2), 292);
//	SetByte((0x0077EA58 + 1), 130);
//	SetDword((0x0077EA75 + 1), 51290);
//	SetByte((0x0077EA8D + 1), 24);
//	SetByte((0x0077EA8F + 1), 24);
//	SetByte((0x0077EA9A + 2), 347);
//	SetByte((0x0077EAAA + 2), 130);
//	SetByte((0x007801D9 + 1), 4);
//	SetByte((0x007801DD + 1), 42);
//	SetByte((0x00780217 + 1), 2);
//	SetByte((0x0078023A + 2), 56);
//	SetByte((0x0078190D + 1), 4);
//	SetByte((0x00781911 + 1), 42);
//	SetByte((0x0078194E + 1), 2);
//	SetByte((0x00781973 + 2), 56);
//	SetByte((0x007830EF + 1), 4);
//	SetByte((0x007830F3 + 1), 42);
//	SetByte((0x00783130 + 1), 2);
//	SetByte((0x00783155 + 2), 56);
//	SetByte((0x00782D15 + 1), 4);
//	SetByte((0x00782D19 + 1), 42);
//	SetByte((0x00782D56 + 1), 2);
//	SetByte((0x00782D7C + 2), 56);
//	SetByte((0x00782D15 + 1), 4);
//	SetByte((0x00782D19 + 1), 42);
//	SetByte((0x00782D56 + 1), 2);
//	SetByte((0x00782D7C + 2), 56);
//	SetByte((0x00784B6D + 1), 4);
//	SetByte((0x00784B71 + 1), 42);
//	SetByte((0x00784BAE + 1), 2);
//	SetByte((0x00784BD4 + 2), 56);
//	//--
//	//-- Windows Command
//	SetCompleteHook(0xE8, 0x0078E6D6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0078E70A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0078E74A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0078E79C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0078E7E2, &DowngradeLoadWindowsNone);
//
//	//-- Windows Helper
//	SetCompleteHook(0xE8, 0x007F65A6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007F65E6, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007F6638, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007F66A2, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007F66FA, &DowngradeLoadWindowsNone);
//	//-- Windows MuHelper2
//	SetCompleteHook(0xE8, 0x0080C848, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0080C87C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0080C8BC, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0080C90E, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0080C954, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido1
//	SetCompleteHook(0xE8, 0x00845956, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0084598A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008459C7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00845A10, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00845A4F, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido2
//	SetCompleteHook(0xE8, 0x007C6BCC, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007C6C06, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C6C49, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C6C98, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C6CDD, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido3
//	SetCompleteHook(0xE8, 0x007C7D0C, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007C7D46, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C7D89, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C7DD8, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007C7E1D, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido4
//	SetCompleteHook(0xE8, 0x00850966, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0085099A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008509D7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00850A20, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00850A5F, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido5
//	SetCompleteHook(0xE8, 0x00852476, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008524AA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008524E7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00852530, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0085256F, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido6
//	SetCompleteHook(0xE8, 0x008540B6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008540EA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00854127, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00854170, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008541AF, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido7
//	SetCompleteHook(0xE8, 0x00868052, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0086808C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008680D5, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00868130, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0086817B, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido8
//	SetCompleteHook(0xE8, 0x0087F886, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0087F8BA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0087F8F7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0087F940, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0087F97F, &DowngradeLoadWindowsNone);
//	//-- Windows Desconocido9 NPC CASTLE SIEGE
//	SetCompleteHook(0xE8, 0x00882F52, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x00882F8C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00882FD5, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00883030, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0088307B, &DowngradeLoadWindowsNone);
//	//-- Windows NPC Lugar
//	SetCompleteHook(0xE8, 0x00893102, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0089313C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00893185, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008931E0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0089322B, &DowngradeLoadWindowsNone);
//	//-- Windows Guard NPC
//	SetCompleteHook(0xE8, 0x008812A2, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008812DC, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00881325, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00881380, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008813CB, &DowngradeLoadWindowsNone);
//	//-- Windows NPC Senior
//	SetCompleteHook(0xE8, 0x00879EE2, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x00879F1C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00879F65, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00879FC0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0087A00B, &DowngradeLoadWindowsNone);
//	//-- Windows BloodCastle
//	SetCompleteHook(0xE8, 0x008747B6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008747F0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0087483C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008748A0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008748F2, &DowngradeLoadWindowsNone);
//	//-- Windows DevilSquare
//	SetCompleteHook(0xE8, 0x008781BC, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008781F0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00878230, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00878282, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008782C8, &DowngradeLoadWindowsNone);
//	//-- Windows Pet
//	SetCompleteHook(0xE8, 0x0084D01A, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0084D05A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084D0AC, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084D116, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084D16E, &DowngradeLoadWindowsNone);
//	//-- Windows Party
//	SetCompleteHook(0xE8, 0x0084A546, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0084A57A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084A5BA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084A60C, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084A652, &DowngradeLoadWindowsNone);
//	//-- Windows ChaosMachine
//	SetCompleteHook(0xE8, 0x0082CA22, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0082CB4B, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0082CB00, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0082CAA5, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0082CA5C, &DowngradeLoadWindowsNone);
//	//-- Windows Store
//	SetCompleteHook(0xE8, 0x00841E49, &DowngradeStoreLoadWindows);
//	SetCompleteHook(0xE8, 0x00841E7D, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00841EBA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00841F03, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00841F42, &DowngradeLoadWindowsNone);
//	//-- Windows Store Other PJ
//	SetCompleteHook(0xE8, 0x0084F406, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0084F43A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084F477, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084F4C0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084F4FF, &DowngradeLoadWindowsNone);
//	//-- Windows Baul
//	SetCompleteHook(0xE8, 0x00857946, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0085797A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008579B7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00857A00, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00857A3F, &DowngradeLoadWindowsNone);
//	//-- Windows Baul Ext.
//	SetCompleteHook(0xE8, 0x008567E6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0085681A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00856857, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008568A0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008568DF, &DowngradeLoadWindowsNone);
//	//-- Windows Inventory
//	SetCompleteHook(0xE8, 0x00836EF6, &DowngradeInventoryWindows);
//	SetCompleteHook(0xE8, 0x00836F2A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00836F67, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00836FB0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00836FEF, &DowngradeLoadWindowsNone);
//	//-- Windows Inventory Ext.
//	SetCompleteHook(0xE8, 0x007D55A6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007D55DA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D5617, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D5660, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D569F, &DowngradeLoadWindowsNone);
//	//-- Windows Shop.
//	SetCompleteHook(0xE8, 0x008470A6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008470DA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00847117, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00847160, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084719F, &DowngradeLoadWindowsNone);
//	//-- Windows GuildMarker
//	SetCompleteHook(0xE8, 0x007D1786, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007D17BA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D17F7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D1840, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007D187F, &DowngradeLoadWindowsNone);
//	//-- Windows Guild User
//	SetCompleteHook(0xE8, 0x007CB6F6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x007CB72A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007CB767, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007CB7B0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x007CB7EF, &DowngradeLoadWindowsNone);
//	
//	//-- Windows Gens-Quest
//	SetCompleteHook(0xE8, 0x00843826, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0084385A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00843897, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008438E0, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0084391F, &DowngradeLoadWindowsNone);
//	//-- Windows Quest (T)
//	SetCompleteHook(0xE8, 0x0083EA46, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x0083EA7A, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0083EAB7, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0083EB00, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x0083EB3F, &DowngradeLoadWindowsNone);
//	//-- Windows Trade
//	SetCompleteHook(0xE8, 0x008643B6, &DowngradeLoadWindows);
//	SetCompleteHook(0xE8, 0x008643EA, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00864427, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x00864470, &DowngradeLoadWindowsNone);
//	SetCompleteHook(0xE8, 0x008644AF, &DowngradeLoadWindowsNone);
//
//	//if (gProtect.m_MainInfo.MenuOption == 1)
//	//{
//	//	SetCompleteHook(0xE9, 0x008499E0, &RenderOptionPanelOrigin); //op��es do painel
//	//	SetCompleteHook(0xE9, 0x00849730, &RenderOptionTextOrigin);  //textos do painel
//	//	SetCompleteHook(0xE9, 0x008494B0, &RenderWindowsOptionOrigin); //fundo do painel
//	//	MemorySet(0x00848CB6, 0x90, 0x5); //REMOVE CLOSE BUTTON
//	//	//Movendo Bot�es
//	//	SetCompleteHook(0xE8, 0x00848E5D, &CheckAttackMouseOver);	// - attack
//	//	SetCompleteHook(0xE8, 0x00848EB2, &CheckBeepMouseOver);		// - sound
//	//	SetCompleteHook(0xE8, 0x00848F07, &CheckSlideMouseOver);	// - slide
//	//	SetCompleteHook(0xE8, 0x00848F4B, &CheckSoundMouseOver);	// - sound slide
//	//	SetCompleteHook(0xE8, 0x00849087, &CheckEffectMouseOver);	// - effect*/
//	//}
//}