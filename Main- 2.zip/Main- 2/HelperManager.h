#pragma once

#include <map>
#include <vector>
#include "HelperView.h"

class CHelperManager
{
public:
	CHelperManager();
	virtual ~CHelperManager();

	void Relese();
	void Init();
	static void RenderPetMain();
	static void UpdatePetMain();
	bool CreateHelper(int Index, int ModelIndex, vec3_t Position, ObjectPreview* m_Owner, int SubType = 0);
	void DeleteHelper(ObjectPreview *Owner, int itemType = -1, bool allDelete = false);
	void Register(BoostSmart_Ptr(HELPER_VIEW) info);
	void UnRegister(ObjectPreview *Owner, int itemType, bool isUnregistAll = false);
	bool CheckExistsHelper(ObjectPreview *Owner);

	void RenderHelpers();
	HELPER_VIEW* GetPreviewHelper(ObjectPreview* owner, int visualItemType = -1);
	void RenderPreview(ObjectPreview* owner, HELPER_VIEW* helper, float angleDelta, bool mounted);
	void UpdateHelpers();

private:
	bool ApplyHelperInfo(BoostSmart_Ptr(HELPER_VIEW) element, int ModelIndex);
	HELPER_VIEW* GetVisualPreview(ObjectPreview* owner, int visualItemType);
	void ReleaseVisualPreview();

	std::vector<BoostSmart_Ptr(HELPER_VIEW)> m_HelperList;
	BoostSmart_Ptr(HELPER_VIEW) m_PreviewHelper;
};

extern CHelperManager gHelperManager;