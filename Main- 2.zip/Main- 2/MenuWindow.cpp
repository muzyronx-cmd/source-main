#include "stdafx.h"
#include "MenuWindow.h"
#include "Util.h"
#include "Interface.h"
#include "CreateFont.h"

extern void WriteClientLog(const char* line);
extern volatile long g_CrashWatch;

#pragma comment (lib, "Gdi32.lib")
#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "Advapi32.lib")

CMenuWindow gMenuWindow;

CMenuWindow::CMenuWindow()
{
	this->m_HealthBarDisabled = 0;
	this->m_ShadowDisabled = 0;
	this->m_WingDisabled = 0;
	this->m_Windowed = 1;
	this->m_ApplyPending = 0;
	this->m_PendingWindowed = 1;
	this->m_Applying = 0;
}

CMenuWindow::~CMenuWindow()
{

}

__declspec(naked) void ChangeViewItem() {
	static DWORD m_ReturnFunc = 0x00772954;

	static int WindowWidth = *(int*)MAIN_RESOLUTION_X;
	static int WindowHeight = *(int*)MAIN_RESOLUTION_Y;

	_asm {
		MOV EAX, WindowWidth;

		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV DWORD PTR DS : [ECX + 0x48], EAX;

		MOV EAX, WindowHeight;

		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV DWORD PTR DS : [ECX + 0x4C], EAX;


		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV EDX, DWORD PTR DS : [ECX + 0x4C];

		JMP[m_ReturnFunc]
	}
}

void CMenuWindow::Init() {
	HKEY key;
	DWORD mode = 1;
	DWORD type = REG_DWORD;
	DWORD size = sizeof(mode);

	if (RegOpenKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_READ, &key) == ERROR_SUCCESS)
	{
		RegQueryValueExA(key, "WindowMode", 0, &type, (LPBYTE)&mode, &size);
		RegCloseKey(key);
	}

	if (mode == 0)
	{
		this->m_Windowed = 0;
		this->m_PendingWindowed = 0;
		this->m_ApplyPending = 1;
	}
}

DWORD g_dwCharSet[8] = { HANGUL_CHARSET, DEFAULT_CHARSET, CHINESEBIG5_CHARSET, GB2312_CHARSET, SHIFTJIS_CHARSET, THAI_CHARSET, DEFAULT_CHARSET, VIETNAMESE_CHARSET };

void CMenuWindow::ChangeFontSize(int fontSize, bool resolution)
{
	if (resolution == 0) {
		/*if (fontSize == *(int*)MAIN_FONT_SIZE) {
			return;
		}*/
	}

	if (g_hFont) {
		DeleteObject((HGDIOBJ)g_hFont);
	}

	if (g_hFontBold) {
		DeleteObject((HGDIOBJ)g_hFontBold);
	}

	if (g_hFontBig) {
		DeleteObject((HGDIOBJ)g_hFontBig);
	}

	if (g_hFontFix) {
		DeleteObject((HGDIOBJ)g_hFontFix);
	}

	SetDword(MAIN_FONT_SIZE, fontSize);

	int newfontSize = fontSize - 1;

	g_hFont = CreateFont(newfontSize + gCreateFont.m_fontInfo[0].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[0].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[0].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[0].Name.c_str());

	g_hFontBold = CreateFont(newfontSize + gCreateFont.m_fontInfo[1].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[1].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[1].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[1].Name.c_str());

	g_hFontBig = CreateFont((newfontSize * 2) + gCreateFont.m_fontInfo[2].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[2].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[2].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[2].Name.c_str());

	g_hFontFix = CreateFont(12 + gCreateFont.m_fontInfo[3].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[3].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[3].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[3].Name.c_str());
}

void LoadTexture(char * text) {
	static DWORD m_CallGlobal = 0x006346A0;

	_asm {
		PUSH 0x80000001;
		MOV EAX, text;
		PUSH EAX;
		MOV ECX, 0x08128ADC;
		CALL[m_CallGlobal];
	}
}

void CMenuWindow::ChangeLanguage(char * lang)
{
	char buffer[256];

	sprintf_s(buffer, "Data\\Local\\%s\\Dialog_%s.bmd", lang, lang);
	((void(*)(char*))0x58A940)(buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Item_%s.bmd", lang, lang);
	((void(*)(char*))0x58B200)(buffer);

	//((void(__thiscall*)(LPVOID))0x51ACE0)(((LPVOID(*)())0x51ABB0)());

	//sprintf_s(buffer, "Data\\Local\\%s\\movereq_%s.bmd", lang, lang);
	//((void(*)(char*))0x51AD60)(buffer);

	//((void(*)(HDC))0x6316C0)(gInterface.hdc);

	//sprintf_s(buffer, "Data\\Local\\%s\\movereq_%s.bmd", lang, lang);
	//((void(__thiscall*)(DWORD))0x51AC20)((DWORD)buffer);

	/*sprintf_s(buffer, "Data\\Local\\%s\\NpcName(%s)%s.bmd", lang, lang);
	((void(*)(char*))0x590D00)(buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Quest_%s.bmd", lang, lang);
	((void(*)(DWORD, char*))0x4F33F0)(((DWORD(*)())0x5BE390)(), buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Skill_%s.bmd", lang, lang);
	((void(*)(char*))0x58A3F0)(buffer);*/

	//((void(__thiscall*)(LPVOID))0x596980)(((LPVOID(__thiscall*)()0x596910)());

	((void(*)())0x00D20470)();

	((void(*)())0x6345A0)();

	//Itemtooltip
	((void(__thiscall*)(LPVOID, bool))0x7E7940)(((LPVOID(__thiscall*)(LPVOID))0x861AA0)(pWindowThis()), 0);

	((void(__thiscall*)(LPVOID))0x7E3000)(((LPVOID(__thiscall*)(LPVOID))0x861AA0)(pWindowThis()));


	//((void(*)())0x7E3000)();

}

static void SelectResolutionIndex(int width, int height)
{
	if (width == 1024 && height == 600) *(int*)MAIN_RESOLUTION = 1;
	else if (width == 1366 && height == 768) *(int*)MAIN_RESOLUTION = 4;
	else if (width == 1440 && height == 900) *(int*)MAIN_RESOLUTION = 5;
	else if (width == 1600 && height == 900) *(int*)MAIN_RESOLUTION = 6;
	else if (width == 1680 && height == 1050) *(int*)MAIN_RESOLUTION = 7;
	else if (width == 1920 && height == 1080) *(int*)MAIN_RESOLUTION = 8;
	else if (width >= 1920 && height >= 1080) *(int*)MAIN_RESOLUTION = 8;
	else if (width >= 1680 && height >= 1050) *(int*)MAIN_RESOLUTION = 7;
	else if (width >= 1600 && height >= 900) *(int*)MAIN_RESOLUTION = 6;
	else if (width >= 1440 && height >= 900) *(int*)MAIN_RESOLUTION = 5;
	else if (width >= 1366 && height >= 768) *(int*)MAIN_RESOLUTION = 4;
	else *(int*)MAIN_RESOLUTION = 1;
}

static void MonitorSize(int* x, int* y, int* w, int* h)
{
	POINT pt = { 0, 0 };
	HMONITOR monitor = NULL;

	if (MAIN_WINDOW != NULL && IsWindow(MAIN_WINDOW))
	{
		monitor = MonitorFromWindow(MAIN_WINDOW, MONITOR_DEFAULTTONEAREST);
	}
	else
	{
		monitor = MonitorFromPoint(pt, MONITOR_DEFAULTTOPRIMARY);
	}

	MONITORINFO info;
	info.cbSize = sizeof(info);

	if (monitor != NULL && GetMonitorInfo(monitor, &info))
	{
		*x = info.rcMonitor.left;
		*y = info.rcMonitor.top;
		*w = info.rcMonitor.right - info.rcMonitor.left;
		*h = info.rcMonitor.bottom - info.rcMonitor.top;
		return;
	}

	*x = 0;
	*y = 0;
	*w = GetSystemMetrics(SM_CXSCREEN);
	*h = GetSystemMetrics(SM_CYSCREEN);
}

extern "C" void ForceNativeResolution()
{
	HKEY key;
	DWORD mode = 1;
	DWORD type = REG_DWORD;
	DWORD size = sizeof(mode);

	if (RegOpenKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_READ, &key) == ERROR_SUCCESS)
	{
		RegQueryValueExA(key, "WindowMode", 0, &type, (LPBYTE)&mode, &size);
		RegCloseKey(key);
	}

	if (mode != 0)
	{
		return;
	}

	int x = 0;
	int y = 0;
	int w = 0;
	int h = 0;

	MonitorSize(&x, &y, &w, &h);

	if (w < 640 || h < 480)
	{
		return;
	}

	*(int*)MAIN_RESOLUTION_X = w;
	*(int*)MAIN_RESOLUTION_Y = h;
	SelectResolutionIndex(w, h);
}

static void WriteRenderSize(int width, int height)
{
	*(int*)MAIN_RESOLUTION_X = width;
	*(int*)MAIN_RESOLUTION_Y = height;
	*(int*)0x87933EC = width;
	*(int*)0x87933E8 = height;
	*(int*)0x87933F4 = 0;
	*(int*)0x87933F0 = 0;
	*(float*)0xE7C3D4 = (float)width / 640.0f;
	*(float*)0xE7C3D8 = (float)height / 480.0f;
}

void CMenuWindow::ApplySize(int width, int height)
{
	bool windowed = (this->m_Windowed != 0);

	if (windowed)
	{
		width = 1024;
		height = 600;
	}

	if (MAIN_WINDOW == NULL || IsWindow(MAIN_WINDOW) == FALSE)
	{
		WriteClientLog("fullscreen: janela invalida");
		return;
	}

	WriteClientLog(windowed ? "modo janela: resize" : "fullscreen: resize");

	if (windowed)
	{
		DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_BORDER | WS_CLIPCHILDREN;
		RECT rc = { 0, 0, width, height };

		AdjustWindowRect(&rc, style, FALSE);

		int frameW = rc.right - rc.left;
		int frameH = rc.bottom - rc.top;
		int posX = (GetSystemMetrics(SM_CXSCREEN) - frameW) / 2;
		int posY = (GetSystemMetrics(SM_CYSCREEN) - frameH) / 2;

		SetWindowLong(MAIN_WINDOW, GWL_STYLE, style);
		SetWindowPos(MAIN_WINDOW, HWND_NOTOPMOST, posX, posY, frameW, frameH, SWP_SHOWWINDOW | SWP_FRAMECHANGED);

		RECT client;
		GetClientRect(MAIN_WINDOW, &client);

		int extraW = width - (client.right - client.left);
		int extraH = height - (client.bottom - client.top);

		if (extraW != 0 || extraH != 0)
		{
			SetWindowPos(MAIN_WINDOW, HWND_NOTOPMOST, posX, posY, frameW + extraW, frameH + extraH, SWP_SHOWWINDOW | SWP_FRAMECHANGED);
		}
	}
	else
	{
		int x = 0;
		int y = 0;
		int w = 0;
		int h = 0;

		MonitorSize(&x, &y, &w, &h);
		width = w;
		height = h;

		SetWindowLong(MAIN_WINDOW, GWL_STYLE, WS_POPUP | WS_CLIPCHILDREN | WS_VISIBLE);
		SetWindowPos(MAIN_WINDOW, HWND_TOP, x, y, w, h, SWP_SHOWWINDOW | SWP_FRAMECHANGED | SWP_NOCOPYBITS);
	}

	*(int*)MAIN_FONT_SIZE = (width >= 1280) ? 15 : 14;
	SelectResolutionIndex(width, height);
	WriteRenderSize(width, height);

	LPVOID scene = ((LPVOID(*)())0x407B20)();

	if (scene != NULL)
	{
		*(DWORD*)((DWORD)scene + 40) = width;
		*(DWORD*)((DWORD)scene + 44) = height;
	}

	this->ChangeFontSize(*(int*)MAIN_FONT_SIZE, 1);

	LPVOID textThis = pTextThis();

	if (textThis != NULL)
	{
		((void(__thiscall*)(LPVOID))0x41FF20)(textThis);
		((void(__thiscall*)(LPVOID, int, HDC))0x41FE80)(textThis, 0, MAIN_HDC);
	}

	WriteClientLog("fullscreen: resolucao");

	RECT client;

	if (GetClientRect(MAIN_WINDOW, &client))
	{
		int cw = client.right - client.left;
		int ch = client.bottom - client.top;

		int deltaW = cw - width;
		int deltaH = ch - height;

		if (deltaW < 0)
		{
			deltaW = -deltaW;
		}

		if (deltaH < 0)
		{
			deltaH = -deltaH;
		}

		if (cw > 0 && ch > 0 && deltaW <= 8 && deltaH <= 8)
		{
			width = cw;
			height = ch;
			WriteRenderSize(width, height);
		}
	}

	WriteRenderSize(width, height);
}

void CMenuWindow::UpdateWideCamera()
{
}

void CMenuWindow::SetWindowMode(int windowed)
{
	this->m_PendingWindowed = windowed ? 1 : 0;
	this->m_ApplyPending = 1;
}

void CMenuWindow::ApplyPendingMode()
{
	if (this->m_ApplyPending == 0 || this->m_Applying != 0)
	{
		return;
	}

	this->m_ApplyPending = 0;
	this->m_Applying = 1;
	g_CrashWatch = 120;
	WriteClientLog("fullscreen: inicio");

	int windowed = this->m_PendingWindowed;
	int width = 1024;
	int height = 600;

	if (windowed == 0)
	{
		int x = 0;
		int y = 0;
		MonitorSize(&x, &y, &width, &height);
	}

	*(DWORD*)0xE60974 = 1;

	if (MAIN_WINDOW != NULL && this->m_Windowed == windowed && *(int*)MAIN_RESOLUTION_X == width && *(int*)MAIN_RESOLUTION_Y == height)
	{
		this->m_Applying = 0;
		return;
	}

	this->m_Windowed = windowed;
	this->ApplySize(width, height);
	this->m_Applying = 0;
}

void CMenuWindow::ChangeResolution(int value)
{
	if (this->m_Windowed == 0)
	{
		int x = 0;
		int y = 0;
		int width = 0;
		int height = 0;

		MonitorSize(&x, &y, &width, &height);
		this->ApplySize(width, height);
		return;
	}

	this->ApplySize(1024, 600);
}
