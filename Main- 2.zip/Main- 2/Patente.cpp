#include "stdafx.h"
#include "Patente.h"
#include "PrintPlayer.h"
#include "LuaStack.hpp"
#include "Util.h"
#include "LuaBMD.h"
#include "LuaObject.h"

using namespace luaaa;

CPatente gPatente;

CPatente::CPatente() : m_Lua(true)
{
	this->m_PlayerInfo.clear();
	this->m_PatentModelInfo.clear();
}

CPatente::~CPatente()
{
	this->m_PlayerInfo.clear();
	this->m_PatentModelInfo.clear();
}

void CreatePartsFactory(ObjectPreview* character) {

	if (character->Object.Kind != KIND_PLAYER) {
		if (character->m_pParts != 0) {
			((void(*)(ObjectPreview*)) 0x004EFF70)(character);
		}
		goto CALLFUNC;
	}

	auto lpInfo = gPatente.GetPlayer(character->aIndex);

	if (lpInfo != nullptr) {
		if (lpInfo->Type != 1 || lpInfo->Patente < 1) {
			if (character->EtcPart >= 20) {
				character->EtcPart = 0;
			}
			if (character->m_pParts != 0) {
				((void(*)(ObjectPreview*)) 0x004EFF70)(character);
			}
			goto CALLFUNC;
		}

		if (character->Object.Teleport == 1 || character->Object.Teleport == 2) {
			if (character->m_pParts != 0) {
				((void(*)(ObjectPreview*)) 0x004EFF70)(character);
			}
			return;
		}

		if (character->m_pParts != 0 && character->EtcPart != (lpInfo->Patente + 19))
		{
			((void(*)(ObjectPreview*)) 0x004EFF70)(character);
		}

		if (character->m_pParts != 0 && character->EtcPart == (lpInfo->Patente + 19))
		{
			return;
		}

		gPatente.m_Lua.Generic_Call("SetPlayerPatente", "ii>", ((int(*)(int))0x57D9A0)(character->aIndex), lpInfo->Patente);

		if (character->m_pParts != 0)
		{
			return;
		}
	}

CALLFUNC:

	((void(*)(ObjectPreview*))0x4EF9A0)(character);
}

void CreatePartsModel(int arrayPlayer, int PatentIndex, int32_t Type, int32_t BoneNumber, int bBillBoard, float x, float y, float z, float ax, float ay, float az) {
	DWORD PreviewStruct = ((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayPlayer);

	LPVOID CreateClass = pGetThisEffect(668);

	if (CreateClass) {
		*(BYTE*)(PreviewStruct + 23) = (PatentIndex + 19);
		*(LPVOID*)(PreviewStruct + 672) = pAddEventEffect(CreateClass, Type, BoneNumber, bBillBoard, x, y, z, ax, ay, az);
	}
}

void CreatePartsImage(int arrayPlayer, int PatentIndex, int Wing, int Pet, int Safezone, int32_t Type, int32_t BoneNumber, int bBillBoard, float x, float y, float z) {
	DWORD PreviewStruct = ((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), arrayPlayer);

	LPVOID CreateClass = pGetThisEffect(668);

	if (CreateClass) {
		*(BYTE*)(PreviewStruct + 23) = (PatentIndex, Wing, Pet, Safezone + 19);
		*(LPVOID*)(PreviewStruct + 672) = pAddEventEffect2(CreateClass, Type, BoneNumber, bBillBoard, x, y, z);
	}
}

__declspec(naked) void CheckNewPatents() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x004EFF10;
	static DWORD m_HookFunc = 0x004EFF46;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8]
		MOVZX EDX, BYTE PTR DS : [ECX + 0x17]
		MOV m_Index, EDX;
	}

	if (m_Index >= 20) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8]
			MOVZX EDX, BYTE PTR DS : [ECX + 0x17]
			CMP EDX, 0x5
			JMP[m_ReturnFunc];
		}
	}
}

int GetResolutionPatent() {
	return *(int*)MAIN_RESOLUTION;
}

int GetZoom() {
	return *(int*)MAIN_RESOLUTION;
}

void SetPatentModel(int PatentIndex, char* Folder, char* ModelName) {
	PATENT_MODEL_INFO info;

	info.PatentIndex = PatentIndex;

	strcpy_s(info.ModelFolder, Folder);

	strcpy_s(info.ModelName, ModelName);

	gPatente.m_PatentModelInfo.insert(std::make_pair(info.PatentIndex, info));
}

void CPatente::RestartLua()
{
	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	this->m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("SetPatentModel", &SetPatentModel);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//PatentSystem.lua");

	this->m_Lua.Generic_Call("StartPatentLoadModel", "");

	LuaModule(this->m_Lua.GetState()).fun("CreatePartsModel", &CreatePartsModel);

	SetCompleteHook(0xE8, 0x00588511, &CreatePartsFactory);

	SetCompleteHook(0xE9, 0x004EFF09, &CheckNewPatents);
}

void CPatente::Init()
{
	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	this->m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("SetPatentModel", &SetPatentModel);

	LuaModule(this->m_Lua.GetState()).fun("GetResolutionPatent", &GetResolutionPatent);

	LuaModule(this->m_Lua.GetState()).fun("GetZoom", &GetZoom);


	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//PatentSystem.lua");

	this->m_Lua.Generic_Call("StartPatentLoadModel", "");

	LuaModule(this->m_Lua.GetState()).fun("CreatePartsModel", &CreatePartsModel);

	SetCompleteHook(0xE8, 0x00588511, &CreatePartsFactory);

	SetCompleteHook(0xE9, 0x004EFF09, &CheckNewPatents);
}


void CPatente::Clear()
{
	this->m_PlayerInfo.clear();
}

void CPatente::StartLoadImage()
{
	this->m_Lua.Generic_Call("StartPatentLoadImage", ">");
}

void CPatente::GCPatentePlayerRecv(PMSG_VIEWPORT_RECV* lpMsg)
{
	if (lpMsg->count == 1)
	{
		auto lpInfo = (PMSG_VIEWPORT_PATENT*)(((BYTE*)lpMsg) + sizeof(PMSG_VIEWPORT_RECV) + (sizeof(PMSG_VIEWPORT_PATENT) * 0));

		int aIndex = MAKE_NUMBERW(lpInfo->index[0], lpInfo->index[1]);

		if (this->IsPlayer(aIndex, lpInfo->patent, lpInfo->type) != 0) {
			return;
		}

		PATENTE_PLAYER_INFO info;

		info.aIndex = aIndex;

		info.Patente = lpInfo->patent;

		info.Type = lpInfo->type;

		this->m_PlayerInfo.push_back(info);
	}
	else
	{
		for (int n = 0; n < lpMsg->count; n++)
		{
			auto lpInfo = (PMSG_VIEWPORT_PATENT*)(((BYTE*)lpMsg) + sizeof(PMSG_VIEWPORT_RECV) + (sizeof(PMSG_VIEWPORT_PATENT) * n));

			int aIndex = MAKE_NUMBERW(lpInfo->index[0], lpInfo->index[1]);

			if (this->IsPlayer(aIndex, lpInfo->patent, lpInfo->type) != 0) {
				continue;
			}

			PATENTE_PLAYER_INFO info;

			info.aIndex = aIndex;

			info.Patente = lpInfo->patent;

			info.Type = lpInfo->type;

			this->m_PlayerInfo.push_back(info);
		}
	}
}

void CPatente::PatentModelSetIndex(int PatentIndex, int ModelIndex)
{
	this->m_Lua.Generic_Call("PatentModelSetIndex", "ii>", PatentIndex, ModelIndex);
}

PATENTE_PLAYER_INFO* CPatente::GetPlayer(int aIndex)
{
	for (auto& Player : this->m_PlayerInfo) {
		if (Player.aIndex == aIndex) {
			return &Player;
		}
	}

	return 0;
}

bool CPatente::IsPlayer(int aindex, int patent, BYTE type)
{
	for (auto& Player : this->m_PlayerInfo) {
		if (Player.aIndex == aindex) {
			Player.Patente = patent;
			Player.Type = type;
			return 1;
		}
	}

	return 0;
}

void CPatente::DeletePlayer(int aIndex)
{
	std::vector<PATENTE_PLAYER_INFO>::iterator it = this->m_PlayerInfo.begin();

	for (; it != this->m_PlayerInfo.end(); it++) {
		if (it->aIndex == aIndex) {
			this->m_PlayerInfo.erase(it);
			return;
		}
	}
}

void CPatente::MainProc()
{
	for (int n = 0; n < MAX_MAIN_VIEWPORT; n++)
	{
		lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), n);

		if (!lpObj)
		{
			continue;
		}

		if (lpObj->Object.Live == 0)
		{
			continue;
		}

		if (lpObj->aIndex == 0) {
			continue;
		}

		auto lpPlayer = this->GetPlayer(lpObj->aIndex);

		if (lpPlayer) {
			if (lpPlayer->Type == 0) {
				this->m_Lua.Generic_Call("RenderPatentImage", "ii>", n, lpPlayer->Patente);
			}
		}
	}
}

int CPatente::PatentModelRender(DWORD BMDStruct, DWORD ObjectStruct, DWORD ItemIndex)
{
	int result = 0;

	if (BMDStruct == 0 || ObjectStruct == 0) {
		return 0;
	}

	this->m_Lua.Generic_Call("PatentModelRender", "jji>i", BMDStruct, ObjectStruct, ItemIndex, &result);

	return result;
}
