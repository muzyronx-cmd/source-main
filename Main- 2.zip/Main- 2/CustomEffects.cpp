#include "stdafx.h"
#include "CustomEffects.h"
#include "ItemVisualEffect.h"
#include "CustomCape.h"
#include "CustomWing.h"
#include "Util.h"
#include "Protocol.h"
#include "Item.h"
#include "AntiHack.h"
#include "MenuWindow.h"

CCustomEffects gCustomEffects;

CCustomEffects::CCustomEffects() : m_Lua(false)
{

}

CCustomEffects::~CCustomEffects()
{

}


void CCustomEffects::Init()
{
	this->m_Lua.DoFile("Data//Files//Lua//EffectSystem//CharacterEffectItens.lua");

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());

	SetCompleteHook(0xE8, 0x005711AB, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x0057126F, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x005713D6, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00576DDB, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00588357, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x005883F4, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00588505, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00588617, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00588661, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x0058876E, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x005887AD, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00609D1E, &this->RenderLinkObject);
	SetCompleteHook(0xE8, 0x00610691, &this->RenderLinkObject);

	/*SetCompleteHook(0xE8, 0x005666C1, &this->RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x0061041C, &this->RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x00610466, &this->RenderPartObjectEffect);*/
}

void CCustomEffects::RestartLua()
{
	this->m_Lua.DoFile("Data//Files//Lua//EffectSystem//CharacterEffectItens.lua");

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());
	 
     SetCompleteHook(0xE8, 0x005711AB, &this->RenderLinkObject);
     SetCompleteHook(0xE8, 0x0057126F, &this->RenderLinkObject);
     SetCompleteHook(0xE8, 0x005713D6, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00576DDB, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00588357, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x005883F4, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00588505, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00588617, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00588661, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x0058876E, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x005887AD, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00609D1E, &this->RenderLinkObject);
    //SetCompleteHook(0xE8, 0x00610691, &this->RenderLinkObject);

	/*SetCompleteHook(0xE8, 0x005666C1, &this->RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x0061041C, &this->RenderPartObjectEffect);
	SetCompleteHook(0xE8, 0x00610466, &this->RenderPartObjectEffect);*/


}

void CCustomEffects::RenderLinkObject(float x, float y, float z, ObjectPreview * c, PART_t* f, int Type, int Level, int Option1, bool Link, bool Translate, int RenderType, bool bRightHandItem)
{
	if (gMenuWindow.m_WingDisabled) {
		if (Type >= GET_ITEM_MODEL(12, 0) && Type <= GET_ITEM_MODEL(12, 6)
			|| Type >= GET_ITEM_MODEL(12, 36) && Type <= GET_ITEM_MODEL(12, 51)
			|| gCustomWing.CheckCustomWingByItem(Type-ITEM_BASE_MODEL)) {

			return;
		}

	}

	if (gAntiHack.LicenseChecked) {
		if (gCustomWing.CheckCustomWingIsCape(Type)) {
			int LinkBone = 0;

			gCustomCape.m_Lua.Generic_Call("CharacterCapeBone", "i>i", Type, &LinkBone);

			if (LinkBone == 1520) {
				return;
			}
			else if (LinkBone != 0) {
				f->LinkBone = LinkBone;
				Link = true;
			}
		}
	}

	((void(*)(float, float, float, ObjectPreview*, PART_t*, int, int, int, bool, bool, int, bool))0x5655C0)(x, y, z, c, f, Type, Level, Option1, Link, Translate, RenderType, bRightHandItem);

	if (gAntiHack.LicenseChecked) {
		DWORD BMDStruct = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), Type);

		if (BMDStruct) {
			DWORD ObjectStruct = (DWORD)(&c->Object);
			gCustomEffects.m_Lua.Generic_Call("CharacterItensEffect", "jjj>", ObjectStruct, BMDStruct, Type);
		}

		gItemVisualEffect.OnLinkObject(c, f, Type);
	}
}

void CCustomEffects::RenderPartObjectEffect(ObjectModel * o, int Type, vec3_t Light, float_t Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType)
{
	if (gAntiHack.LicenseChecked) {
		DWORD BMDStruct = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), Type);

		if (BMDStruct) {
			gCustomEffects.m_Lua.Generic_Call("CharacterItensEffect", "iii>", (DWORD)(o), BMDStruct, Type);
		}
	}

	((void(*)(ObjectModel*, int, vec3_t, float_t, int, int, int, int, int))0x609E70)(o, Type, Light, Alpha, ItemLevel, Option1, ExtOption, Select, RenderType);
}
