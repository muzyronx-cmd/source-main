#pragma once

#include "Structs.h"

class Plus15Effect
{
public:
	Plus15Effect();

	void Init();
	void Toggle();

	bool BeginBody(ObjectModel* object, int select);
	void EndBody(ObjectModel* object, bool applied);

	bool BeginLink(ObjectPreview* preview, int level, PART_t* part);
	void EndLink(ObjectPreview* preview, bool applied);

	static bool IsItemLevel(int level);
	static void RenderPartObjectEffect(ObjectModel* object, int type, vec3_t light, float alpha, int itemLevel, int option1, int extOption, int select, int renderType);

public:
	bool m_Enabled;

private:
	struct SavedLook
	{
		bool AlphaEnable;
		bool ContrastEnable;
		float Alpha;
		float AlphaTarget;
		float BlendMeshLight;
		float BlendMeshTexCoordU;
		float BlendMeshTexCoordV;
		int BlendMesh;
		float Light[3];
	};

	struct Pulse
	{
		float Intensity;
		float Wash;
		float Smoke;
		float Alpha;
		float LightR;
		float LightG;
		float LightB;
		float Glow;
		float ScrollU;
		float ScrollV;
	};

	struct Stage
	{
		float Alpha;
		float LightR;
		float LightG;
		float LightB;
		float Glow;
		float Intensity;
		float Wash;
		float Smoke;
	};

	static Pulse Sample();
	static Stage Mix(const Stage& a, const Stage& b, float t);
	static void Capture(ObjectModel* object, SavedLook& saved);
	static void Restore(ObjectModel* object, const SavedLook& saved);
	static void Apply(ObjectModel* object, const Pulse& pulse, float baseAlpha);
	static void TintLight(vec3_t light, const Pulse& pulse);
	static bool BodyHasPlus15(ObjectModel* object);
	static int ResolveItemLevel(int level, PART_t* part);

	SavedLook m_BodySaved;
	SavedLook m_LinkSaved;
	bool m_BodyCaptured;
	bool m_LinkCaptured;
};

extern Plus15Effect gPlus15Effect;
