#include "stdafx.h"
#include "Graphic.h"
#include "Util.h"

#define GL_TEXTURE_MAX_ANISOTROPY_EXT 0x84FE
#define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT 0x84FF

CGraphic gGraphic;

CGraphic::CGraphic()
{
}

CGraphic::~CGraphic()
{
}

static int g_AnisotropyLevel = -1;

static void InitGraphicOptions()
{
	int enabled = GetPrivateProfileInt("Graphics", "Anisotropy", 1, ".\\Settings.ini");
	int requested = GetPrivateProfileInt("Graphics", "MaxAnisotropy", 4, ".\\Settings.ini");

	if (enabled == 0 || requested <= 1)
	{
		g_AnisotropyLevel = 1;
		return;
	}

	if (requested > 8)
	{
		requested = 8;
	}

	GLfloat gpuMax = 1.0f;
	glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &gpuMax);

	if (gpuMax < 1.0f)
	{
		gpuMax = 1.0f;
	}

	if ((int)gpuMax < requested)
	{
		requested = (int)gpuMax;
	}

	g_AnisotropyLevel = requested;
}

void SetAnisotropy() {
	if (g_AnisotropyLevel < 0)
	{
		InitGraphicOptions();
	}

	if (g_AnisotropyLevel > 1)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, g_AnisotropyLevel);
	}

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

__declspec(naked) void JpgAnisotropy() {
	static DWORD m_ReturnFunc = 0x004FCB5E;

	_asm {
		CALL[SetAnisotropy];
		ADD ESP, 0x4;
		LEA EDX, DWORD PTR SS : [EBP - 0x2A4] ;
		JMP[m_ReturnFunc];
	}
}

__declspec(naked) void TgaAnisotropy() {
	static DWORD m_ReturnFunc = 0x004FD0C0;

	_asm {
		CALL[SetAnisotropy];
		ADD ESP, 0x4;
		MOV BYTE PTR SS : [EBP - 0xB9] , 0x1;
		JMP[m_ReturnFunc];
	}
}

void CGraphic::Init()
{
	SetCompleteHook(0xE9, 0x004FCB58, &JpgAnisotropy);

	SetCompleteHook(0xE9, 0x004FD0B9, &TgaAnisotropy);
}
