#include "stdafx.h"
#include "ItemVisualEffect.h"
#include "Item.h"
#include "LuaStack.hpp"
#include <math.h>
#include <stdarg.h>

using namespace luaaa;

#define ITEM_VISUAL_CONFIG "Data//Files//Lua//EffectSystem//ItemVisualEffect.lua"
#define ITEM_VISUAL_LOG "Data\\Files\\Lua\\EffectSystem\\ItemVisualEffect.log"

CItemVisualEffect gItemVisualEffect;

static float ClampRange(float value, float minValue, float maxValue)
{
	if (value < minValue)
		return minValue;
	if (value > maxValue)
		return maxValue;
	return value;
}

static DWORD ItemModelBmd(int modelType)
{
	return ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), modelType);
}

static void ItemVisualReset()
{
	gItemVisualEffect.Reset();
}

static void ItemVisualSettings(int enabled, int maxEmits, float maxDistance, int showPreview, int quality)
{
	gItemVisualEffect.ApplySettings(enabled, maxEmits, maxDistance, showPreview, quality);
}

static void ItemVisualDefine(int id, const char* name, int kind, float r, float g, float b, float r2, float g2, float b2, float intensity, float scale, float speed, int particles, int bone, float offsetX, float offsetY, float offsetZ, int spriteId, int particleId, int particleSub, int enabled)
{
	gItemVisualEffect.Define(id, name, kind, r, g, b, r2, g2, b2, intensity, scale, speed, particles, bone, offsetX, offsetY, offsetZ, spriteId, particleId, particleSub, enabled);
}

static void ItemVisualBind(int section, int index, int effectId, int enabled)
{
	gItemVisualEffect.Bind(section, index, effectId, enabled);
}

static void ItemVisualSet(int setId, int effectId, int needCount)
{
	gItemVisualEffect.DefineSet(setId, effectId, needCount);
}

static void ItemVisualSetPiece(int setId, int section, int index)
{
	gItemVisualEffect.AddSetPiece(setId, section, index);
}

CItemVisualEffect::CItemVisualEffect() : m_Lua(false)
{
	this->m_Registered = false;
	this->m_Enabled = false;
	this->m_MaxEmits = 120;
	this->m_MaxDistance = 1500.0f;
	this->m_ShowPreview = 1;
	this->m_Quality = 100;
	this->m_ErrorCount = 0;
	this->m_CheckTick = 0;
	this->m_WindowTick = 0;
	this->m_WindowCount = 0;
	this->m_RecentCursor = 0;
	memset(&this->m_FileTime, 0, sizeof(this->m_FileTime));
	memset(this->m_Recent, 0, sizeof(this->m_Recent));
}

CItemVisualEffect::~CItemVisualEffect()
{
}

void CItemVisualEffect::Init()
{
	this->RegisterFunctions();
	this->Load();
}

void CItemVisualEffect::RestartLua()
{
	this->RegisterFunctions();
	this->Load();
}

void CItemVisualEffect::RegisterFunctions()
{
	if (this->m_Registered || this->m_Lua.GetState() == NULL)
		return;

	LuaModule(this->m_Lua.GetState()).fun("ItemVisualReset", &ItemVisualReset);
	LuaModule(this->m_Lua.GetState()).fun("ItemVisualSettings", &ItemVisualSettings);
	LuaModule(this->m_Lua.GetState()).fun("ItemVisualDefine", &ItemVisualDefine);
	LuaModule(this->m_Lua.GetState()).fun("ItemVisualBind", &ItemVisualBind);
	LuaModule(this->m_Lua.GetState()).fun("ItemVisualSet", &ItemVisualSet);
	LuaModule(this->m_Lua.GetState()).fun("ItemVisualSetPiece", &ItemVisualSetPiece);
	this->m_Registered = true;
}

void CItemVisualEffect::ClearLog()
{
	FILE* file = NULL;

	if (fopen_s(&file, ITEM_VISUAL_LOG, "w") != 0 || file == NULL)
		return;

	fputs("ItemVisualEffect\n", file);
	fclose(file);
}

void CItemVisualEffect::Log(const char* format, ...)
{
	char message[512];
	va_list args;

	va_start(args, format);
	_vsnprintf_s(message, sizeof(message), _TRUNCATE, format, args);
	va_end(args);

	OutputDebugStringA(message);
	OutputDebugStringA("\n");

	FILE* file = NULL;

	if (fopen_s(&file, ITEM_VISUAL_LOG, "a") != 0 || file == NULL)
		return;

	fputs(message, file);
	fputs("\n", file);
	fclose(file);
}

void CItemVisualEffect::Reset()
{
	this->m_Definitions.clear();
	this->m_Binds.clear();
	this->m_BindIndex.clear();
	this->m_Sets.clear();
	this->m_Enabled = true;
	this->m_MaxEmits = 120;
	this->m_MaxDistance = 1500.0f;
	this->m_ShowPreview = 1;
	this->m_Quality = 100;
}

void CItemVisualEffect::ApplySettings(int enabled, int maxEmits, float maxDistance, int showPreview, int quality)
{
	this->m_Enabled = (enabled != 0);
	this->m_MaxEmits = (int)ClampRange((float)maxEmits, 1.0f, 400.0f);
	this->m_MaxDistance = ClampRange(maxDistance, 0.0f, 10000.0f);
	this->m_ShowPreview = (showPreview != 0);
	this->m_Quality = (int)ClampRange((float)quality, 0.0f, 100.0f);
}

void CItemVisualEffect::Define(int id, const char* name, int kind, float r, float g, float b, float r2, float g2, float b2, float intensity, float scale, float speed, int particles, int bone, float offsetX, float offsetY, float offsetZ, int spriteId, int particleId, int particleSub, int enabled)
{
	if (id <= 0)
	{
		this->m_ErrorCount++;
		this->Log("efeito ignorado: id %d invalido", id);
		return;
	}

	if (this->FindDefinition(id) != NULL)
	{
		this->m_ErrorCount++;
		this->Log("efeito ignorado: id %d duplicado", id);
		return;
	}

	if (kind < 0 || kind >= ITEM_VISUAL_KIND_COUNT)
	{
		this->m_ErrorCount++;
		this->Log("efeito %d ignorado: tipo %d invalido", id, kind);
		return;
	}

	ITEM_VISUAL_DEFINITION effect;
	memset(&effect, 0, sizeof(effect));
	effect.Id = id;
	strncpy_s(effect.Name, (name != NULL && name[0] != 0) ? name : "Sem nome", _TRUNCATE);
	effect.Kind = kind;
	effect.Color[0] = ClampRange(r, 0.0f, 1.0f);
	effect.Color[1] = ClampRange(g, 0.0f, 1.0f);
	effect.Color[2] = ClampRange(b, 0.0f, 1.0f);
	effect.Color2[0] = ClampRange(r2, 0.0f, 1.0f);
	effect.Color2[1] = ClampRange(g2, 0.0f, 1.0f);
	effect.Color2[2] = ClampRange(b2, 0.0f, 1.0f);
	effect.Intensity = ClampRange(intensity, 0.05f, 3.0f);
	effect.Scale = ClampRange(scale, 0.05f, 4.0f);
	effect.Speed = ClampRange(speed, 0.0f, 5.0f);
	effect.Particles = (int)ClampRange((float)particles, 0.0f, 8.0f);
	effect.Bone = (int)ClampRange((float)bone, -1.0f, 80.0f);
	effect.Offset[0] = ClampRange(offsetX, -200.0f, 200.0f);
	effect.Offset[1] = ClampRange(offsetY, -200.0f, 200.0f);
	effect.Offset[2] = ClampRange(offsetZ, -200.0f, 200.0f);
	effect.SpriteId = spriteId;
	effect.ParticleId = particleId;
	effect.ParticleSub = particleSub;
	effect.Enabled = (enabled != 0);

	if (effect.SpriteId <= 0)
		effect.SpriteId = (kind == ITEM_VISUAL_FLAME || kind == ITEM_VISUAL_ARCANE || kind == ITEM_VISUAL_MAGIC) ? 32114 : 32002;

	if (kind == ITEM_VISUAL_GLOW)
	{
		effect.ParticleId = 0;
		effect.Particles = 0;
	}
	else if (effect.ParticleId <= 0)
	{
		if (kind == ITEM_VISUAL_ARCANE || kind == ITEM_VISUAL_MAGIC)
		{
			effect.ParticleId = 32287;
			if (effect.ParticleSub == 0)
				effect.ParticleSub = 2;
		}
		else
		{
			effect.ParticleId = 32146;
			if (effect.ParticleSub == 0)
				effect.ParticleSub = 20;
		}
	}

	this->m_Definitions.push_back(effect);
}

void CItemVisualEffect::Bind(int section, int index, int effectId, int enabled)
{
	if (section < 0 || section >= MAX_ITEM_SECTION || index < 0 || index >= MAX_ITEM_TYPE)
	{
		this->m_ErrorCount++;
		this->Log("bind ignorado: item %d,%d fora da faixa 0-15 / 0-511", section, index);
		return;
	}

	if (this->FindDefinition(effectId) == NULL)
	{
		this->m_ErrorCount++;
		this->Log("bind ignorado: efeito %d nao existe para o item %d,%d", effectId, section, index);
		return;
	}

	int model = GET_ITEM_MODEL(section, index);

	for (size_t i = 0; i < this->m_Binds.size(); i++)
	{
		if (this->m_Binds[i].Model == model && this->m_Binds[i].EffectId == effectId)
		{
			this->m_ErrorCount++;
			this->Log("bind ignorado: item %d,%d ja usa o efeito %d", section, index, effectId);
			return;
		}
	}

	DWORD table = *(DWORD*)0x8128AC0;

	if (table != 0)
	{
		ITEM_ATTRIBUTE* attribute = (ITEM_ATTRIBUTE*)(table + (sizeof(ITEM_ATTRIBUTE) * GET_ITEM(section, index)));

		if (attribute->Name[0] == 0 && attribute->Width == 0 && attribute->Height == 0)
			this->Log("aviso: item %d,%d sem cadastro no Item.bmd. O bind foi mantido.", section, index);
	}

	ITEM_VISUAL_BIND bind;
	bind.Section = section;
	bind.Index = index;
	bind.Model = model;
	bind.EffectId = effectId;
	bind.Enabled = (enabled != 0);
	this->m_Binds.push_back(bind);
}

void CItemVisualEffect::DefineSet(int setId, int effectId, int needCount)
{
	if (setId <= 0 || needCount <= 0)
	{
		this->m_ErrorCount++;
		this->Log("conjunto ignorado: id %d quantidade %d", setId, needCount);
		return;
	}

	if (this->FindDefinition(effectId) == NULL)
	{
		this->m_ErrorCount++;
		this->Log("conjunto %d ignorado: efeito %d nao existe", setId, effectId);
		return;
	}

	for (size_t i = 0; i < this->m_Sets.size(); i++)
	{
		if (this->m_Sets[i].SetId == setId)
		{
			this->m_ErrorCount++;
			this->Log("conjunto ignorado: id %d duplicado", setId);
			return;
		}
	}

	ITEM_VISUAL_SET set;
	set.SetId = setId;
	set.EffectId = effectId;
	set.NeedCount = needCount;
	this->m_Sets.push_back(set);
}

void CItemVisualEffect::AddSetPiece(int setId, int section, int index)
{
	if (section < 0 || section >= MAX_ITEM_SECTION || index < 0 || index >= MAX_ITEM_TYPE)
	{
		this->m_ErrorCount++;
		this->Log("peca ignorada: item %d,%d fora da faixa", section, index);
		return;
	}

	for (size_t i = 0; i < this->m_Sets.size(); i++)
	{
		if (this->m_Sets[i].SetId != setId)
			continue;

		int model = GET_ITEM_MODEL(section, index);

		for (size_t piece = 0; piece < this->m_Sets[i].Models.size(); piece++)
		{
			if (this->m_Sets[i].Models[piece] == model)
			{
				this->m_ErrorCount++;
				this->Log("peca ignorada: item %d,%d duplicado no conjunto %d", section, index, setId);
				return;
			}
		}

		this->m_Sets[i].Models.push_back(model);
		return;
	}

	this->m_ErrorCount++;
	this->Log("peca ignorada: conjunto %d nao existe", setId);
}

const ITEM_VISUAL_DEFINITION* CItemVisualEffect::FindDefinition(int id) const
{
	for (size_t i = 0; i < this->m_Definitions.size(); i++)
	{
		if (this->m_Definitions[i].Id == id)
			return &this->m_Definitions[i];
	}

	return NULL;
}

void CItemVisualEffect::BuildIndex()
{
	this->m_BindIndex.clear();

	for (size_t i = 0; i < this->m_Binds.size(); i++)
	{
		if (this->m_Binds[i].Enabled == 0)
			continue;

		this->m_BindIndex[this->m_Binds[i].Model].push_back((int)i);
	}
}

void CItemVisualEffect::Load()
{
	this->ClearLog();
	this->m_ErrorCount = 0;
	this->Reset();
	this->m_Lua.DoFile(ITEM_VISUAL_CONFIG);
	this->BuildIndex();

	WIN32_FILE_ATTRIBUTE_DATA info;
	memset(&info, 0, sizeof(info));

	if (GetFileAttributesExA("Data\\Files\\Lua\\EffectSystem\\ItemVisualEffect.lua", GetFileExInfoStandard, &info))
		this->m_FileTime = info.ftLastWriteTime;

	this->Log("carregado: %d efeitos, %d binds ativos, %d conjuntos, %d avisos", this->DefinitionCount(), this->ActiveBindCount(), (int)this->m_Sets.size(), this->m_ErrorCount);
}

void CItemVisualEffect::ReloadIfNeeded()
{
	DWORD now = GetTickCount();

	if ((now - this->m_CheckTick) < 1000)
		return;

	this->m_CheckTick = now;

	WIN32_FILE_ATTRIBUTE_DATA info;

	if (!GetFileAttributesExA("Data\\Files\\Lua\\EffectSystem\\ItemVisualEffect.lua", GetFileExInfoStandard, &info))
		return;

	if (CompareFileTime(&info.ftLastWriteTime, &this->m_FileTime) == 0)
		return;

	this->Load();
}

int CItemVisualEffect::DefinitionCount() const
{
	return (int)this->m_Definitions.size();
}

int CItemVisualEffect::ActiveBindCount() const
{
	int count = 0;

	for (size_t i = 0; i < this->m_Binds.size(); i++)
	{
		if (this->m_Binds[i].Enabled != 0)
			count++;
	}

	return count;
}

int CItemVisualEffect::ErrorCount() const
{
	return this->m_ErrorCount;
}

bool CItemVisualEffect::IsWorldCharacter(ObjectPreview* preview) const
{
	if (preview == NULL || oUserPreviewStruct == 0)
		return false;

	DWORD base = (DWORD)oUserPreviewStruct;
	DWORD ptr = (DWORD)preview;

	if (ptr < base)
		return false;

	DWORD delta = ptr - base;

	if ((delta % ITEM_VISUAL_WORLD_STRIDE) != 0)
		return false;

	return (delta / ITEM_VISUAL_WORLD_STRIDE) < ITEM_VISUAL_WORLD_LIMIT;
}

bool CItemVisualEffect::Reserve(DWORD object, int key)
{
	DWORD now = GetTickCount();

	if ((now - this->m_WindowTick) > 16)
	{
		this->m_WindowTick = now;
		this->m_WindowCount = 0;
	}

	for (int i = 0; i < ITEM_VISUAL_RECENT; i++)
	{
		if (this->m_Recent[i].Object == object && this->m_Recent[i].Key == key && (now - this->m_Recent[i].Tick) < 16)
			return false;
	}

	if (this->m_WindowCount >= this->m_MaxEmits)
		return false;

	this->m_Recent[this->m_RecentCursor].Object = object;
	this->m_Recent[this->m_RecentCursor].Key = key;
	this->m_Recent[this->m_RecentCursor].Tick = now;
	this->m_RecentCursor = (this->m_RecentCursor + 1) % ITEM_VISUAL_RECENT;
	this->m_WindowCount++;
	return true;
}

int CItemVisualEffect::CountWorn(ObjectPreview* preview, const ITEM_VISUAL_SET& set) const
{
	int count = 0;

	for (size_t i = 0; i < set.Models.size(); i++)
	{
		int model = set.Models[i];
		bool worn = false;

		for (int part = 0; part < MAX_BODYPART; part++)
		{
			if (preview->BodyPart[part].Type == (short)model)
				worn = true;
		}

		if (preview->WeaponFirstSlot == (short)model || preview->WeaponSecondSlot == (short)model || preview->WingsSlot == (short)model || preview->PetSlot == (short)model)
			worn = true;

		if (worn)
			count++;
	}

	return count;
}

void CItemVisualEffect::Emit(ObjectPreview* preview, PART_t* part, int modelType, const ITEM_VISUAL_DEFINITION& effect, int key)
{
	DWORD objectStruct = (DWORD)(&preview->Object);

	if (!this->Reserve(objectStruct, key))
		return;

	int bone = effect.Bone;

	if (bone < 0)
		bone = (part != NULL) ? part->LinkBone : 0;

	if (bone < 0 || bone > 80)
		bone = 0;

	DWORD boneMatrix = ((DWORD(__thiscall*)(DWORD, int))0x4CD7F0)(objectStruct, bone);

	if (boneMatrix == 0)
		return;

	DWORD bmd = ItemModelBmd(modelType);

	if (bmd == 0)
		bmd = ItemModelBmd((int)preview->Object.Type);

	if (bmd == 0)
		return;

	vec34_t* boneTransform = (vec34_t*)boneMatrix;
	vec3_t local;
	vec3_t world;
	Vector(effect.Offset[0], effect.Offset[1], effect.Offset[2], local);
	((void(__thiscall*)(void*, float(*)[4], vec3_t, vec3_t, bool))0x545030)((void*)bmd, boneTransform[0], local, world, 1);

	float wave = 1.0f;

	if (effect.Speed > 0.0f)
	{
		float time = ((float)GetTickCount() * 0.001f) * effect.Speed;
		wave = 0.82f + (0.18f * sinf(time * 6.2831853f));
	}

	float scale = effect.Scale * effect.Intensity * wave;

	if (effect.Kind == ITEM_VISUAL_AURA)
		scale *= 1.35f;

	float lightScale = effect.Intensity;

	if (lightScale > 1.0f)
		lightScale = 1.0f;

	vec3_t spriteColor;
	vec3_t particleColor;
	Vector(effect.Color[0] * lightScale, effect.Color[1] * lightScale, effect.Color[2] * lightScale, spriteColor);
	Vector(effect.Color2[0] * lightScale, effect.Color2[1] * lightScale, effect.Color2[2] * lightScale, particleColor);

	((void(*)(int, vec3_t, float, vec3_t, DWORD, float, int))0x771310)(effect.SpriteId, world, scale, spriteColor, objectStruct, 0.0f, 0);

	int count = effect.Particles;

	if (this->m_Quality < 100)
		count = (count * this->m_Quality) / 100;

	if (count > 8)
		count = 8;

	if (effect.ParticleId <= 0 || count <= 0)
		return;

	for (int i = 0; i < count; i++)
	{
		vec3_t particlePos;
		Vector(world[0], world[1], world[2] + ((float)i * 0.35f), particlePos);
		((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(effect.ParticleId, particlePos, preview->Object.Angle, particleColor, effect.ParticleSub, scale * 0.65f, objectStruct);
	}
}

void CItemVisualEffect::OnLinkObject(ObjectPreview* preview, PART_t* part, int modelType)
{
	this->ReloadIfNeeded();

	if (!this->m_Enabled || this->m_Quality <= 0 || preview == NULL || !preview->Object.Live)
		return;

	bool world = this->IsWorldCharacter(preview);

	if (!world && this->m_ShowPreview == 0)
		return;

	if (world && this->m_MaxDistance > 0.0f && oUserPreviewStruct != 0)
	{
		ObjectPreview* hero = (ObjectPreview*)oUserPreviewStruct;
		float dx = preview->Object.Position[0] - hero->Object.Position[0];
		float dy = preview->Object.Position[1] - hero->Object.Position[1];
		float dz = preview->Object.Position[2] - hero->Object.Position[2];

		if ((dx * dx) + (dy * dy) + (dz * dz) > (this->m_MaxDistance * this->m_MaxDistance))
			return;
	}

	std::map<int, std::vector<int>>::iterator found = this->m_BindIndex.find(modelType);

	if (found != this->m_BindIndex.end())
	{
		for (size_t i = 0; i < found->second.size(); i++)
		{
			const ITEM_VISUAL_BIND& bind = this->m_Binds[found->second[i]];
			const ITEM_VISUAL_DEFINITION* effect = this->FindDefinition(bind.EffectId);

			if (effect == NULL || effect->Enabled == 0)
				continue;

			this->Emit(preview, part, modelType, *effect, (modelType << 4) ^ effect->Id);
		}
	}

	for (size_t i = 0; i < this->m_Sets.size(); i++)
	{
		const ITEM_VISUAL_SET& set = this->m_Sets[i];
		bool piece = false;

		for (size_t model = 0; model < set.Models.size(); model++)
		{
			if (set.Models[model] == modelType)
				piece = true;
		}

		if (!piece || this->CountWorn(preview, set) < set.NeedCount)
			continue;

		const ITEM_VISUAL_DEFINITION* effect = this->FindDefinition(set.EffectId);

		if (effect == NULL || effect->Enabled == 0)
			continue;

		this->Emit(preview, part, modelType, *effect, 0x40000000 | set.SetId);
	}
}
