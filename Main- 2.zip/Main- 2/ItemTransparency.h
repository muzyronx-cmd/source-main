#pragma once

#define ITEM_TRANSPARENCY_CONFIG_PATH ".\\Data\\Files\\ItemTransparency.ini"

#define ITEM_TRANSPARENCY_LOOK_COUNT 3

struct ITEM_TRANSPARENCY_LOOK
{
	float Opacity;
	float Saturation;
	// 1 = corpo com textura. 0 = so o brilho, sem a malha transparente.
	float Texture;
	vec3_t Tint;
	vec3_t GlowColor;
	vec3_t OutlineColor;
	float Glow;
	float Outline;
};

struct ITEM_TRANSPARENCY_CONFIG
{
	int Enable;
	int MinLevel;
	int DepthPrepass;
	int Desaturate;

	float Speed;
	float HoldSeconds;
	float PulseSeconds;
	float Smoothness;

	float OpacityNormal;
	float OpacityGhost;
	float OpacityPulse;
	float PulseColorFade;

	float NormalSaturation;
	float NormalSmoke;
	vec3_t NormalColor;
	vec3_t NormalSmokeColor;
	vec3_t NormalOutlineColor;

	float BodyBrightness;
	float GlowIntensity;
	float ChromeIntensity;

	vec3_t BlueColor;
	vec3_t BlueGlowColor;
	vec3_t VioletColor;
	vec3_t VioletGlowColor;

	int Outline;
	int OutlineWings;
	float OutlineWidth;
	float OutlineIntensity;
	float OutlinePulse;
};

class CItemTransparency
{
public:
	CItemTransparency();
	~CItemTransparency();

	void Init();
	void LoadConfig();
	void Toggle();

	bool GetLightScale(float* scale) const;

	static void RenderPartObjectEffect(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType);

private:
	int InstallHooks();
	void CheckConfigReload();
	bool CheckItem(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel) const;
	void Update();
	void Render(ObjectModel* o, int Type, float* Light, float Alpha, int ItemLevel, int Option1, int ExtOption, int Select, int RenderType);
	void RenderGlow(ObjectModel* o, int Type, float Alpha);
	void RenderOutline(ObjectModel* o, int Type, float Alpha);

	ITEM_TRANSPARENCY_CONFIG m_Config;
	ITEM_TRANSPARENCY_LOOK m_Looks[ITEM_TRANSPARENCY_LOOK_COUNT];

	bool m_Enabled;
	bool m_Rendering;

	LARGE_INTEGER m_Frequency;
	LARGE_INTEGER m_StartCounter;
	LONGLONG m_LastUpdateCounter;

	DWORD m_LastConfigCheck;
	FILETIME m_ConfigWriteTime;

	ITEM_TRANSPARENCY_LOOK m_Current;
};

extern CItemTransparency gItemTransparency;
