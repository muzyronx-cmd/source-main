#include "stdafx.h"
#include "LoginRemake.h"
#include "Util.h"
#include "Interface.h"
#include "Offset.h"
#include "Protocol.h"

struct PMSG_LOGIN_KEEPALIVE
{
	PBMSG_HEAD header;
	DWORD TickCount;
	WORD PhysiSpeed;
	WORD MagicSpeed;
};

static void SendLoginKeepAlive()
{
	static DWORD lastSend = 0;
	DWORD now = GetTickCount();

	if (lastSend != 0 && (now - lastSend) < 10000)
	{
		return;
	}

	lastSend = now;

	PMSG_LOGIN_KEEPALIVE pMsg;
	pMsg.header.setE(0x0E, sizeof(pMsg));
	pMsg.TickCount = now;
	pMsg.PhysiSpeed = 0;
	pMsg.MagicSpeed = 0;
	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

int PointSY1 = 220;

static const int LOGIN_SLIDE_MAX = 220;

static int s_LastLoginFieldX = -9999;
static int s_LastLoginFieldY = -9999;
static int s_LastPasswordFieldX = -9999;
static int s_LastPasswordFieldY = -9999;
static DWORD s_LastLoginClick = 0;
static bool s_LoginExitAnim = false;

static void MoveLoginField(DWORD field, int x, int y, int* lastX, int* lastY)
{
	if (field == 0 || x == *lastX && y == *lastY)
	{
		return;
	}

	SetBoundInputField(field, x, y);
	*lastX = x;
	*lastY = y;
}

static int LoginSlideStep(int distance)
{
	int step = distance / 4;

	if (step < 6)
	{
		step = 6;
	}

	if (step > distance)
	{
		step = distance;
	}

	return step;
}

static void LoginSlideIn()
{
	if (PointSY1 > 0)
	{
		PointSY1 -= LoginSlideStep(PointSY1);
	}
}

static void LoginSlideOut()
{
	if (PointSY1 < LOGIN_SLIDE_MAX)
	{
		PointSY1 += LoginSlideStep(LOGIN_SLIDE_MAX - PointSY1);
	}
}

void LoginRequestWithExitAnim()
{
	if (s_LoginExitAnim)
	{
		return;
	}

	if ((GetTickCount() - s_LastLoginClick) <= 800)
	{
		return;
	}

	s_LastLoginClick = GetTickCount();
	s_LoginExitAnim = true;
	PlayBuffer(27, 0, 0);
}

float getX2(float x)
{
	return x / g_fScreenRate_x;
}
float getY2(float y)
{
	if (pWinWidth == 1024 && pWinHeight == 600)
	{
		return y / g_fScreenRate_x;
	}

	float fixResu = ((float)pWinWidth) / (((float)pWinHeight) * (640.0f / 480.0f)); //fix custom res
	return y / g_fScreenRate_x * fixResu;
}

void LoginBoxRemake()
{	
	int Baixar = 53;
	int Struct = _Instance() + 16968;

	// State 2 is the login form. State 0x13 is "connecting".
	int loginState = *(int*)0x87935A4;
	bool onLoginForm = (loginState == 2);
	bool connecting = (loginState == 0x13);
	bool showLoginUi = onLoginForm || s_LoginExitAnim;

	if (s_LoginExitAnim)
	{
		LoginSlideOut();

		if (PointSY1 >= LOGIN_SLIDE_MAX)
		{
			PointSY1 = LOGIN_SLIDE_MAX;
			s_LoginExitAnim = false;
			RequestLogin(Struct);
		}
	}
	else if (onLoginForm)
	{
		SendLoginKeepAlive();

		int connectX = 324;
		int connectY = 295 + Baixar + PointSY1;
		int exitX = 285;
		int exitY = 380 + Baixar;

		if (SEASON3B_CheckMouseIn(connectX, connectY, 70, 19))
		{
			if (IsPress(1))
			{
				LoginRequestWithExitAnim();
			}
		}

		if (SEASON3B_CheckMouseIn(exitX, exitY, 70, 20))
		{
			if (IsPress(1))
			{
				PlayBuffer(27, 0, 0);
				CancelLogin(Struct);
			}
		}

		LoginSlideIn();
	}
	else if (!connecting)
	{
		s_LastLoginFieldX = -9999;
		s_LastLoginFieldY = -9999;
		s_LastPasswordFieldX = -9999;
		s_LastPasswordFieldY = -9999;
		LoginSlideOut();
	}

	EnableAlphaTest(1);
	((void(*)()) 0x637770)();
	glColor4f(1.0, 1.0, 1.0, 1.0);
	RenderBitmap(531020, 195.0, 200.5 + Baixar + PointSY1, 250.0, 216.0, 0, 0, 0.9765625, 0.84375, 1, 1, 0.0);

	if (showLoginUi && !s_LoginExitAnim)
	{
		if (SEASON3B_CheckMouseIn(324, 295 + Baixar + PointSY1, 70, 19))
		{
			RenderBitmap(531021, 324.0, 295.0 + Baixar + PointSY1, 70.0, 19.0, 0, 0, 0.546875, 0.59375, 1, 1, 0.0);
		}

		if (SEASON3B_CheckMouseIn(285, 380 + Baixar, 70, 20))
		{
			RenderBitmap(531022, 285.0, 380.5 + Baixar, 70.0, 20.0, 0, 0, 0.546875, 0.625, 1, 1, 0.0);
		}
	}

	DisableAlphaBlend();

	glColor4f(1.0, 1.0, 1.0, 1.0);
	((void(*)()) 0x637870)();

	float boxX = 195.0f;
	float boxY = 200.5f + Baixar + PointSY1;
	int fieldX = (int)(boxX + 114.0f);
	int loginY = (int)(boxY + 48.0f);
	int passwordY = (int)(boxY + 72.0f);

	if (*(DWORD*)0xE60960 == 1 && showLoginUi)
	{
		MoveLoginField(*(DWORD*)(Struct + 848), fieldX, loginY, &s_LastLoginFieldX, &s_LastLoginFieldY);
		MoveLoginField(*(DWORD*)(Struct + 852), fieldX, passwordY, &s_LastPasswordFieldX, &s_LastPasswordFieldY);
	}

	if (showLoginUi)
	{
		pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0);
		pSetFont(pTextThis(), (int)pFontBold);
		pSetTextColor(pTextThis(), 250, 219, 168, 0xFF);
		pDrawText(pTextThis(), (int)(boxX + 8), loginY, GlobalText(450), 96, 0, 4, 0);
		pDrawText(pTextThis(), (int)(boxX + 8), passwordY, GlobalText(451), 96, 0, 4, 0);
		pDrawText(pTextThis(), 324, 295 + Baixar + PointSY1 + 3, GlobalText(452), 70, 0, 3, 0);
		pDrawText(pTextThis(), 285, 380 + Baixar + 3, GlobalText(453), 70, 0, 3, 0);
		pSetTextColor(pTextThis(), 255, 255, 255, 0xFFu);
	}
}

int __fastcall LoginBoxText(int a1, int a2, signed int a3, signed int a4, char a5)
{
	return DisplayInfoBarCharacter(a1, a2, a3, a4 - 56 + PointSY1, a5);
}

int __fastcall PasswordBoxText(int a1, int a2, signed int a3, signed int a4, char a5)
{
	return DisplayInfoBarCharacter(a1, a2, a3, a4 - 45 + PointSY1, a5);
}

void CentralTextLoginBox(int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{	
	pRender_rendertext(g_Fontthis(), iPos_x - 25, iPos_y - 32, "", iBoxWidth, iBoxHeight, iSort, lpTextSize);
}

void RemakeLoginLoad()
{
	SetDword(0x006311B6+1, (DWORD)"Custom\\InterfaceS2\\none.tga");		//Remo��o Interface LoginBox
	SetDword(0x006311D6+1, (DWORD)"Custom\\InterfaceS2\\none.tga");		//Remo��o Interface LoginBox

	SetCompleteHook(0xE8, 0x004D7D13, &LoginBoxRemake);					//Adi��o de nova Login_back.tga
	SetCompleteHook(0xE8, 0x0040B1EF, &LoginBoxText);					//Deslocamento do campo de Login
	SetCompleteHook(0xE8, 0x0040B210, &PasswordBoxText);				//Deslocamento do campo de Senha
	SetCompleteHook(0xE8, 0x0040B6A7, &CentralTextLoginBox);			//Deslocamento do texto de Login e Senha - Fazendo sua remo��o
	SetCompleteHook(0xE8, 0x0040B635, &CentralTextLoginBox);			//Deslocamento do texto de Login e Senha - Fazendo sua remo��o
	
	MemorySet(0x0040B7A2,0x90,0x5);										//Remo��o Room Name
	MemorySet(0x0040B2E2,0x90,0x5);										//Remo��o Bot�o OK e Cancelar
	MemorySet(0x0040B306,0x90,0x5);										//Remo��o Bot�o OK e Cancelar
	MemorySet(0x0040B380,0x90,0x5);										//Remo��o Bot�o OK e Cancelar

	MemorySet(0x00401F56,0x90,0x5);
}