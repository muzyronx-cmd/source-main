#include "stdafx.h"
#include "CharacterList.h"
#include "Console.h"
#include "MakePreview.h"
#include "LuaStack.hpp"
#include "LoadFiles.h"
#include "AutoLoginWin.h"

using namespace luaaa;

CCharacterList gCharacterList;

CCharacterList::CCharacterList() : m_Lua(true)
{

}

CCharacterList::~CCharacterList()
{

}

int CheckCreateCharacterWindow() {
	return *(BYTE *)((int)((int(*)()) 0x00482B70)() + 33948);
}

void SetMaxCharacter(int value) {
	SetByte(0x004057E2 + 3, value);
	SetByte(0x0040587E + 3, value);
	SetByte(0x004D6F60 + 6, value);
	SetByte(0x004D706F + 6, value - 1);
	SetByte(0x00405548 + 3, value);
	SetByte(0x004D70AA + 6, value - 1);
	SetByte(0x004D71DD + 3, value);

	SetDword(0x004029C7 + 1, (value * 368 + 4));
	SetByte(0x004029E7 + 2, value);
	SetByte(0x004029F7 + 1, value);
	SetByte(0x00402A44 + 3, value);
	SetByte(0x00402AA6 + 3, value);
	SetByte(0x00402AF6 + 3, value);
}

void SetPetSize(float MountSize, float FlyingSize, float FlyingHeight) {
	gCharacterList.MountAddSize = MountSize;
	gCharacterList.FlyingAddSize = FlyingSize;
	gCharacterList.FlyingAddHeight = FlyingHeight;
}

void CCharacterList::Init()
{
	if (gLoadFiles.m_LoadFiles.m_CharListSeason13) {
		LuaModule(this->m_Lua.GetState()).fun("SetPetSize", &SetPetSize);

		LuaModule(this->m_Lua.GetState()).fun("SetMaxCharacter", &SetMaxCharacter);

		LuaModule(this->m_Lua.GetState()).fun("CheckCreateCharacterWindow", &CheckCreateCharacterWindow);

		this->m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

		this->m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

		this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

		this->m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

		this->m_LuaMemory.RegisterLua(this->m_Lua.GetState());

		this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterList.lua");

		SetCompleteHook(0xE8, 0x004D6C3E, this->OpenCharacterSceneData);

		SetCompleteHook(0xE8, 0x00663E8C, this->CGCharacterListRecv);

		SetCompleteHook(0xE8, 0x004D9E23, this->MoveCharacterList);

		SetCompleteHook(0xE8, 0x004D75CB, this->RenderCharacterList);

		SetCompleteHook(0xE8, 0x00663E9D, this->CGCharacterCreateRecv);

		SetDword(0x004D6C73, 0);
		SetByte(0x00402106, 0);
	}
}

void CCharacterList::RestartLua()
{
	this->m_Lua.CloseLua();

	this->m_Lua.RegisterLua();

	this->m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

	this->m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	this->m_LuaMemory.RegisterLua(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("SetMaxCharacter", &SetMaxCharacter);

	LuaModule(this->m_Lua.GetState()).fun("CheckCreateCharacterWindow", &CheckCreateCharacterWindow);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterList.lua");

}

void CCharacterList::OpenCharacterSceneData()
{
	gCharacterList.m_Lua.Generic_Call("StartLoadImages", ">");

	((void(__cdecl*)())0x006312E0)();
}

void CCharacterList::CGCharacterListRecv(PMSG_CHARACTER_LIST_RECV * lpMsg)
{
	for (int i = 0; i < 10; i++) {
		lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), i);

		if (lpObj) {
			lpObj->Object.Visible = 0;
		}
	}

	((void(*)()) 0x0063CB40)();

	((void(*)(BYTE)) 0x004D5130)(lpMsg->ClassCode);

	if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
		pMapNumber = 73;
	}

	float posX;
	float posY;
	float posZ;

	for (int n = 0; n < lpMsg->count; n++) {
		auto lpInfo = (PMSG_CHARACTER_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_CHARACTER_LIST_RECV) + (sizeof(PMSG_CHARACTER_LIST)*n));

		switch (lpInfo->slot)
		{
		case 0:
			posX = 8008.0;
			posY = 18885.0;
			posZ = 115.0;
			break;
		case 1:
			posX = 7986.0;
			posY = 19145.0;
			posZ = 90.0;
			break;
		case 2:
			posX = 8046.0;
			posY = 19400.0;
			posZ = 75.0;
			break;
		case 3:
			posX = 8133.0;
			posY = 19645.0;
			posZ = 60.0;
			break;
		case 4:
			posX = 8282.0;
			posY = 19845.0;
			posZ = 35.0;
			break;
		default:
			posX = 0.0;
			posY = 0.0;
			posZ = 0.0;
			break;
		}

		auto Character = ((ObjectPreview*(__cdecl*)(int, int, BYTE, float, float, float)) 0x586DA0)(lpInfo->slot, ((int(*)(BYTE))0x587380)(lpInfo->CharSet[0]), 0, posX, posY, posZ);

		if (Character) {
			if (gLoadFiles.m_LoadFiles.m_CharListSeason13) {
				gCharacterList.m_Lua.Generic_Call("SetCharacterPosition", "i>", lpInfo->slot);
			}

			Character->Level = lpInfo->Level;
			Character->CtlCode = lpInfo->CtlCode;
			std::memcpy(Character->Name, lpInfo->Name, sizeof(Character->Name));
			Character->Name[10] = 0;
			Character->GuildStatus = lpInfo->GuildStatus;

			gMakePreview.ChangeCharacterExt(lpInfo->slot, &lpInfo->CharSet[1], 0, 0);
		}
	}

	SetDword(0x87935A4, 51);
	((void(__thiscall*)(int Pointer, BYTE Status)) 0x00856BD0)(((int(__thiscall*)(LPVOID This)) 0x00861A80)(pWindowThis()), lpMsg->ExtWarehouse);
	SetDword(0xE8CB30, GetTickCount());

	gCharacterList.MaxCharactersAccount = lpMsg->MaxCharacter;
}

void CCharacterList::CGCharacterCreateRecv(PMSG_CHARACTER_CREATE_RECV * lpMsg)
{
	((void(*)(PMSG_CHARACTER_CREATE_RECV*))0x63D3D0)(lpMsg);

	if (lpMsg->result == 1) {
		gCharacterList.m_Lua.Generic_Call("SetCharacterPosition", "i>", lpMsg->slot);
	}
}

void CCharacterList::MoveCharacterList()
{
	gCharacterList.m_Lua.Generic_Call("UpdateProc", "i>", gCharacterList.MaxCharactersAccount);

	#if USE_CONSOLE == TRUE
	if (GetKeyState(VK_F9) & 0x8000) {
		gCharacterList.RestartLua();
	}
	#endif

	((void(*)())0x4D6E70)();
}

void CCharacterList::RenderCharacterList()
{
	gCharacterList.m_Lua.Generic_Call("RenderProc", "i>", gCharacterList.MaxCharactersAccount);

	((void(*)())0x4D5EC0)();
}

