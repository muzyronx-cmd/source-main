#include "StdAfx.h"
#include "HelperManager.h"
#include "HelperSystem.h"
#include "Item.h"
#include "Util.h"
#include "CharacterList.h"
#include "ElementPet.h"
#include "Console.h"

CHelperManager gHelperManager;

CHelperManager::CHelperManager()
{
	this->m_HelperList.clear();
}

CHelperManager::~CHelperManager()
{
	//this->Relese();
}

void CHelperManager::Relese()
{
	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end();) {
		std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(HELPER_VIEW) element = *tempIT;

		if (element.expired() == false) {
			element.lock()->Relese();
		}

		//m_HelperList.erase(tempIT);
	}

	m_HelperList.clear();
}

void CHelperManager::Init()
{
	SetCompleteHook(0xE8, 0x004D7348, &this->RenderPetMain);
	SetCompleteHook(0xE8, 0x004D7A98, &this->RenderPetMain);
	SetCompleteHook(0xE8, 0x004D9A65, &this->RenderPetMain);

	SetCompleteHook(0xE8, 0x004D6EA5, &this->UpdatePetMain);
	SetCompleteHook(0xE8, 0x004D7787, &this->UpdatePetMain);
	SetCompleteHook(0xE8, 0x004D9568, &this->UpdatePetMain);
}

void CHelperManager::RenderPetMain()
{
	((void(*)())0x503950)();

	gHelperManager.RenderHelpers();
}

void CHelperManager::UpdatePetMain()
{
	((void(*)())0x503720)();

	gHelperManager.UpdateHelpers();
}

bool CHelperManager::CreateHelper(int Index, int ModelIndex, vec3_t Position, ObjectPreview * m_Owner, int SubType)
{
	if (m_Owner == nullptr) {
		return 0;
	}

	if (CheckExistsHelper(m_Owner)) {
		return 1;
	}

	HELPER_VIEWPtr element = HELPER_VIEW::Make();

	if (element == nullptr) {
		return 0;
	}

	if (element->Create(Index, ModelIndex, Position, m_Owner, SubType)) {
		if (this->ApplyHelperInfo(element, ModelIndex) == 0) {
			return 0;
		}

		this->Register(element);
		return 1;
	}

	return 0;
}

bool CHelperManager::ApplyHelperInfo(BoostSmart_Ptr(HELPER_VIEW) element, int ModelIndex)
{
	auto elementInfo = gHelperSystem.GetHelper(ModelIndex);

	if (elementInfo == 0) {
		return 0;
	}

	element->m_Type = elementInfo->Type;

	element->m_HeightFloor = elementInfo->HeightFloor;

	element->m_Movement = elementInfo->Movement;

	if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
		element->SetScale(elementInfo->SizeCharList);
	}
	else {
		element->SetScale(elementInfo->Size);
	}

	element->SetMiniature(elementInfo->Miniature, elementInfo->SizeMiniature, elementInfo->VelocityMiniature);

	return 1;
}

void CHelperManager::DeleteHelper(ObjectPreview * Owner, int itemType, bool allDelete)
{
	if (Owner == nullptr) {
		return;
	}

	UnRegister(Owner, itemType, allDelete);
}

void CHelperManager::Register(BoostSmart_Ptr(HELPER_VIEW) info)
{
	this->m_HelperList.push_back(info);
}

void CHelperManager::UnRegister(ObjectPreview* Owner, int itemType, bool isUnregistAll)
{
	if (Owner == nullptr) {
		return;
	}

	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end();) {
		std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(HELPER_VIEW) element = *tempIT;

		if (Hero == Owner) {
			if (element.lock()->IsSameOwner(&Owner->Object)) {
				element.lock()->Relese();
				m_HelperList.erase(tempIT);
				break;
			}
		}
		else {
			if ((-1 == itemType && element.lock()->IsSameOwner(&Owner->Object))
				|| element.lock()->IsSameObject(&Owner->Object, itemType))
			{
				element.lock()->Relese();

				m_HelperList.erase(tempIT);

				if (-1 == itemType || !isUnregistAll) {
					return;
				}
			}
		}
	}
}

bool CHelperManager::CheckExistsHelper(ObjectPreview * Owner)
{
	if (Owner == nullptr) {
		return 0;
	}

	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end();) {

		std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(HELPER_VIEW) element = *tempIT;

		if (element.expired() == false) {
			if (element.lock()->IsSameOwner(&Owner->Object) && element.lock()->IsSameObject(&Owner->Object, Owner->PetSlot))
			{
				return 1;
			}
		}
	}

	return 0;
}

void CHelperManager::RenderHelpers()
{
	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end();) {

		std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(HELPER_VIEW) element = *tempIT;

		if (element.expired() == false) {
			element.lock()->Render();
		}
	}

	gElementPetFirst.RenderElement();
	gElementPetSecond.RenderElement();
}

HELPER_VIEW* CHelperManager::GetPreviewHelper(ObjectPreview* owner, int visualItemType)
{
	ObjectModel* ownerObject = &owner->Object;

	int visualModel = -1;

	if (visualItemType >= 0 && gHelperSystem.CheckIsHelper(visualItemType + ITEM_BASE_MODEL)) {
		visualModel = visualItemType + ITEM_BASE_MODEL;
	}

	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end(); ++it) {
		BoostWeak_Ptr(HELPER_VIEW) element = *it;

		if (element.expired() == false && element.lock()->IsSameOwner(ownerObject)) {
			if (visualModel != -1 && element.lock()->m_itemType != visualModel) {
				continue;
			}

			this->ReleaseVisualPreview();
			return element.lock().get();
		}
	}

	if (visualModel == -1) {
		this->ReleaseVisualPreview();
		return nullptr;
	}

	return this->GetVisualPreview(owner, visualItemType);
}

void CHelperManager::RenderPreview(ObjectPreview* owner, HELPER_VIEW* helper, float angleDelta, bool mounted)
{
	ObjectModel* ownerObject = &owner->Object;

	if (helper != nullptr) {
		if (mounted && helper->IsMount()) {
			helper->RenderPreviewMounted();
		}
		else {
			helper->RenderPreview(angleDelta);
		}
	}

	gElementPetFirst.RenderPreview(ownerObject, angleDelta);
	gElementPetSecond.RenderPreview(ownerObject, angleDelta);
}

// Never registered: the world keeps rendering the real pet while only the preview shows the visual one.
HELPER_VIEW* CHelperManager::GetVisualPreview(ObjectPreview* owner, int visualItemType)
{
	int visualModel = visualItemType + ITEM_BASE_MODEL;

	if (!m_PreviewHelper
		|| m_PreviewHelper->m_Obj == nullptr
		|| !m_PreviewHelper->m_Obj->Live
		|| m_PreviewHelper->m_itemType != visualModel
		|| m_PreviewHelper->m_pOwner != owner)
	{
		this->ReleaseVisualPreview();

		HELPER_VIEWPtr element = HELPER_VIEW::Make();

		if (element == nullptr) {
			return nullptr;
		}

		int modelIndex = gHelperSystem.GetHelperModel(visualModel);

		if (!element->Create(visualItemType, modelIndex, owner->Object.Position, owner, 0) || !this->ApplyHelperInfo(element, modelIndex)) {
			element->Relese();
			return nullptr;
		}

		element->m_Obj->Alpha = 1.0f;

		m_PreviewHelper = element;
	}

	m_PreviewHelper->Update();

	if (m_PreviewHelper->m_Obj == nullptr || !m_PreviewHelper->m_Obj->Live) {
		return nullptr;
	}

	return m_PreviewHelper.get();
}

void CHelperManager::ReleaseVisualPreview()
{
	if (m_PreviewHelper) {
		m_PreviewHelper->Relese();
		m_PreviewHelper.reset();
	}
}

void CHelperManager::UpdateHelpers()
{
	for (std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator it = m_HelperList.begin(); it != m_HelperList.end();) {

		std::vector<BoostSmart_Ptr(HELPER_VIEW)>::iterator tempIT = it;

		++it;

		BoostWeak_Ptr(HELPER_VIEW) element = *tempIT;

		if (element.expired() == false) {
			element.lock()->Update();
		}
	}

	gElementPetFirst.UpdateElement();
	gElementPetSecond.UpdateElement();
}