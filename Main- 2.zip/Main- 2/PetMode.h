#pragma once

#include "Protocol.h"

#define PM_FLAG_PET		0x01
#define PM_FLAG_CITY	0x02
#define PM_FLAG_MASK	(PM_FLAG_PET | PM_FLAG_CITY)

// Right-edge column, top to bottom. The Runas slot is drawn by RuneShop.lua.
enum
{
	PM_DOCK_RUNES = 0,
	PM_DOCK_PET = 1,
	PM_DOCK_CITY = 2,
	PM_DOCK_COUNT = 3,
};

struct PMSG_PET_MODE_SEND
{
	PSBMSG_HEAD header; // C1:F3:D8
	BYTE state;
};

struct PMSG_PET_MODE_LIST_RECV
{
	PSWMSG_HEAD header; // C2:F3:D8
	BYTE count;
};

struct PMSG_PET_MODE_INFO
{
	BYTE index[2];
	BYTE state;
};

class CPetMode
{
public:
	CPetMode();

	void Init();
	void LoadImages();
	void Render();
	void UpdateMouse();
	void UpdateKey();
	void EnterWorld();
	void GCPetModeRecv(BYTE* lpMsg, int size);
	bool IsActive(ObjectPreview* character);
	bool IsCityRiding(ObjectPreview* character);
	bool InSafeTile(ObjectPreview* character);
	bool IsCovered();
	void Suspend(bool suspend) { this->m_Suspended = suspend; };

	static int GetDockX();
	static int GetDockY(int slot);
	static int GetDockWidth();
	static int GetDockHeight();

private:
	bool InGame();
	bool HasMount(ObjectPreview* character);
	BYTE GetFlags(ObjectPreview* character);
	bool CanToggle(BYTE flag);
	void RenderButton(int slot, int image, bool disabled, const char* tooltip);
	void Toggle(BYTE flag);
	void TryToggle(BYTE flag);
	void SendState();
	void SetState(int aIndex, BYTE state);
	void Refresh(ObjectPreview* character);

	BYTE m_Flags;
	bool m_Suspended;
	bool m_PetKeyDown;
	bool m_CityKeyDown;
	DWORD m_LastToggle;
	BYTE m_State[0x10000];
};

extern CPetMode gPetMode;
