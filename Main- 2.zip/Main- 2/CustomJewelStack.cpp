#include "stdafx.h"
#include "CustomJewelStack.h"
#include "Item.h"
#include "Util.h"
#include "Interface.h"
#include "LuaStack.hpp"
#include "CustomMessage.h"
#include "Descriptions.h"
#include "NewInventory.h"

using namespace luaaa;

CCustomJewelStack gCustomJewelStack;

CCustomJewelStack::CCustomJewelStack() : m_Lua(false)
{
	this->m_VisibleSplitStack = 0;
	this->m_ValueGetStack = 0;

	this->m_EventKey = 0;
	this->m_EventKey2 = 0;

	this->m_x = (640 / 2) - ((230 / 2));
	this->m_y = 95;

	this->m_CustomJewelStackInfo.clear();
}

CCustomJewelStack::~CCustomJewelStack()
{
	this->m_CustomJewelStackInfo.clear();
}

BOOL CheckIsJewel(DWORD Index) {
	if (gCustomJewelStack.CheckCustomJewelStack(Index)) {
		return 1;
	}

	return 0;
}

__declspec(naked) void SetItensStack() {
	static DWORD m_ReturnFunc = 0x007DC96A;
	static DWORD m_ExitFunc = 0x007DCEF1;
	static DWORD m_CallFunc = 0x00791000;
	static DWORD m_IndexItem = 0x0;
	static DWORD m_Durability = 0x0;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0x18];
		MOVSX EAX, WORD PTR DS : [EDX];
		MOV m_IndexItem, EAX;
		MOV EAX, DWORD PTR SS : [EBP - 0x18];
		MOVZX ECX, BYTE PTR DS : [EAX + 0x16];
		MOV m_Durability, ECX;
	}

	if (CheckIsJewel(m_IndexItem) && m_Durability > 1) {
		_asm {
			PUSH ECX;
			FLD DWORD PTR DS : [0xD23788];
			FSTP DWORD PTR SS : [ESP];
			PUSH ECX;
			FLD DWORD PTR DS : [0xD2881C];
			FSTP DWORD PTR SS : [ESP];
			PUSH ECX;
			FLD1;
			FSTP DWORD PTR SS : [ESP];
			CALL DWORD PTR DS : [glColor3f];
			PUSH ECX;
			FLD1;
			FSTP DWORD PTR SS : [ESP];
			MOV EDX, DWORD PTR SS : [EBP - 0x18];
			MOVZX EAX, BYTE PTR DS : [EDX + 0x16];
			PUSH EAX;
			FLD DWORD PTR SS : [EBP - 0x10];
			FADD QWORD PTR DS : [0xD23500];
			FSTP DWORD PTR SS : [EBP - 0x44];
			FLD DWORD PTR SS : [EBP - 0x44];
			PUSH ECX;
			FSTP DWORD PTR SS : [ESP];
			FLD DWORD PTR SS : [EBP - 0x14];
			FADD DWORD PTR SS : [EBP - 0x1C];
			FSUB QWORD PTR DS : [0xD235D0];
			FSTP DWORD PTR SS : [EBP - 0x48];
			FLD DWORD PTR SS : [EBP - 0x48];
			PUSH ECX;
			FSTP DWORD PTR SS : [ESP];
			CALL[m_CallFunc]
			FSTP ST
			ADD ESP, 0x10
			JMP[m_ExitFunc]
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP - 0x18];
			MOVSX EAX, WORD PTR DS : [EDX];
			JMP[m_ReturnFunc];
		}
	}
}

BOOL CheckAllowJewelSplit(DWORD ItemIndex, DWORD TargetIndex) {
	if (ItemIndex == TargetIndex) {
		if (gCustomJewelStack.CheckCustomJewelStack(ItemIndex)) {
			return 1;
		}
	}

	return 0;
}

__declspec(naked) void AllowJewelSplit() {
	static DWORD m_ReturnFunc = 0x007DD63A;
	static DWORD m_HookFunc = 0x007DDA8B;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x14];
		PUSH EAX;
		MOV EAX, DWORD PTR SS : [EBP - 0x10];
		PUSH EAX;
		CALL[CheckAllowJewelSplit];
		Test Eax, Eax;
		JE EXIT;

		MOV AL, 0x1;
		JMP[m_HookFunc];

	EXIT:
		MOV EAX, DWORD PTR SS : [EBP - 0x14];
		CMP EAX, DWORD PTR SS : [EBP - 0x10];
		JMP[m_ReturnFunc];
	}
}

void SetJewelStack(int ItemIndex) {
	CUSTOM_JEWEL_STACK_INFO info;

	info.ItemIndex = ItemIndex;

	info.MaxStack = 0;

	gCustomJewelStack.m_CustomJewelStackInfo.insert(std::make_pair(info.ItemIndex, info));
}

void CCustomJewelStack::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetJewelStack", &SetJewelStack);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomJewelStack.lua");

	this->m_Lua.Generic_Call("StartLoadJewelStack", "");

	MemorySet(0x007DC964, 0x90, 6);
	SetCompleteHook(0xE9, 0x007DC964, &SetItensStack);

	MemorySet(0x007DD634, 0x90, 6);
	SetCompleteHook(0xE9, 0x007DD634, &AllowJewelSplit);
}

bool CCustomJewelStack::CheckCustomJewelStack(int ItemIndex)
{
	std::map<int, CUSTOM_JEWEL_STACK_INFO>::iterator it = this->m_CustomJewelStackInfo.find(ItemIndex);

	if (it == this->m_CustomJewelStackInfo.end()) {
		return 0;
	}

	return 1;
}

CUSTOM_JEWEL_STACK_INFO * CCustomJewelStack::GetInfo(int ItemIndex)
{
	return nullptr;
}

BOOL CCustomJewelStack::CheckSplitJewel(int ItemIndex, int TargetItemIndex)
{
	if (ItemIndex == TargetItemIndex) {
		if (this->CheckCustomJewelStack(ItemIndex)) {
			return 1;
		}
	}

	return 0;
}

void CCustomJewelStack::RenderDescriptionStack(DWORD* Line, WORD ItemIndex, BYTE durability)
{
	if (this->CheckCustomJewelStack(ItemIndex) && durability > 1) {
		memcpy(textLine[*Line], "\n", 100);
		textColor[*Line] = 1;
		textBold[*Line] = 0;

		(*Line)++;

		char buffer[60];
		sprintf(buffer, gCustomMessage.GetMessage(45), durability);

		memcpy(textLine[*Line], buffer, 100);
		textColor[*Line] = 1;
		textBold[*Line] = 0;

		(*Line)++;
	}
}

void CCustomJewelStack::ProcessUnSplit(int ItemSlot, int Stack)
{
	if (Stack <= 0) {
		return;
	}

	CUSTOM_JEWEL_STACK_INFO_SEND pMsg;

	pMsg.header.set(0x4C, 0x81, sizeof(pMsg));

	pMsg.slot = ItemSlot;

	pMsg.stack = Stack;

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CCustomJewelStack::Open(int ItemIndex, int ItemSlot, int Durability)
{
	this->m_VisibleSplitStack = 1;
	this->m_EventKey = 0;
	this->m_EventKey2 = 0;
	this->m_ValueGetStack = 1;

	this->m_ItemIndex = ItemIndex;
	this->m_ItemSlot = ItemSlot;
	this->m_Durability = Durability;
}

void CCustomJewelStack::Close()
{
	this->m_VisibleSplitStack = 0;
}

void CCustomJewelStack::Update()
{
	if (CheckWindowOpen(ObjWindow::Inventory) == 0
		|| CheckWindowOpen(ObjWindow::Warehouse) == 1
		|| CheckWindowOpen(ObjWindow::ChaosBox) == 1
		|| CheckWindowOpen(ObjWindow::Trade) == 1
		|| CheckWindowOpen(ObjWindow::Shop) == 1
		|| CheckWindowOpen(ObjWindow::Store) == 1
		|| CheckWindowOpen(ObjWindow::OtherStore) == 1
		|| CheckWindowOpen(ObjWindow::ExpandWarehouse) == 1) {
		return;
	}

	if (this->m_VisibleSplitStack) {
		if (CheckMouseIn(this->m_x + (((230 / 2) - 54) / 2), this->m_y + 180 - 50, 54, 30)) {
			if (IsPressKey(VK_LBUTTON)) {
				this->ProcessUnSplit(this->m_ItemSlot, this->m_ValueGetStack);
				this->Close();
			}
			else {
				m_EventKey = 1;
			}
		}
		else {
			m_EventKey = 0;
		}

		if (CheckMouseIn(this->m_x + (230 / 2) + (((230 / 2) - 54) / 2), this->m_y + 180 - 50, 54, 30)) {
			if (IsPressKey(VK_LBUTTON)) {
				this->Close();
				m_EventKey2 = 2;
			}
			else {
				m_EventKey2 = 1;
			}
		}
		else {
			m_EventKey2 = 0;
		}

		if (CheckMouseIn(this->m_x + (230 / 2) - (50 / 2) - 18, this->m_y + (180 / 2) - 18, 12, 12)) {
			if (IsPressKey(VK_LBUTTON)) {
				if (this->m_ValueGetStack > 1) {
					this->m_ValueGetStack--;
				}
			}
		}

		if (CheckMouseIn(this->m_x + (230 / 2) + 30, this->m_y + (180 / 2) - 18, 12, 12)) {
			if (IsPressKey(VK_LBUTTON)) {
				if (this->m_ValueGetStack < this->m_Durability) {
					this->m_ValueGetStack++;
				}
			}
		}

		*(BYTE*)0x8793386 = 0;
		*(BYTE*)0x8793384 = 0;
		gInterface.interfaceLock = 1;
	}

	if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9), *((DWORD *)pInventoryThis(pWindowThis()) + 10), gNewInventory.GetWidth(), 429)) {
		if (((int(*)(int))0x791090)(VK_SHIFT) == 1) {
			if (IsPressKey(VK_RBUTTON)) {
				DWORD index = pInventoryGetPointedItemIndex(pInventoryThis(pWindowThis()));

				if (index != -1) {
					auto item = pInventoryCtrlFindItem(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0), pCursorX, pCursorY);

					if (item) {
						if (this->CheckCustomJewelStack(item->Type) && item->Durability > 1) {
							this->Open(item->Type, (item->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + item->x) + 12, item->Durability);
						}
					}
				}
			}
		}
	}
}

void CCustomJewelStack::RenderItem(float x , float y)
{
	glMatrixMode(0x1701);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(int, int, int, int))0x6363D0)(0, 0, *(GLsizei*)MAIN_RESOLUTION_X, *(GLsizei*)MAIN_RESOLUTION_Y);

	((void(*)(float, float, float, float))0x6358A0)(1.f, (float)(*(DWORD*)MAIN_RESOLUTION_X) / (float)(*(DWORD*)MAIN_RESOLUTION_Y), *(float*)0xE61E38, *(float*)0xE61E3C);

	glMatrixMode(0x1700);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(vec34_t))0x635830)(*(vec34_t*)0x87933A0);

	((void(*)())0x635DE0)();

	((void(*)())0x635E40)();

	((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)(x, y, 25.0, 25.0, this->m_ItemIndex, 0, 0, 0, 0);

	glMatrixMode(0x1700);
	glPopMatrix();
	glMatrixMode(0x1701);
	glPopMatrix();

	glColor3f(1, 1, 1);
	pSetBlend(false);
}

void CCustomJewelStack::Render()
{
	if (CheckWindowOpen(ObjWindow::Inventory) == 0
		|| CheckWindowOpen(ObjWindow::Warehouse) == 1
		|| CheckWindowOpen(ObjWindow::ChaosBox) == 1
		|| CheckWindowOpen(ObjWindow::Trade) == 1
		|| CheckWindowOpen(ObjWindow::Shop) == 1
		|| CheckWindowOpen(ObjWindow::Store) == 1
		|| CheckWindowOpen(ObjWindow::OtherStore) == 1
		|| CheckWindowOpen(ObjWindow::ExpandWarehouse) == 1) {
		return;
	}

	if (this->m_VisibleSplitStack == 0) {
		return;
	}

	EnableAlphaTest(1);

	float x = (640 / 2) - ((230 / 2));
	float y = 95;

	RenderImage(0x7A5A, x, y + 2.0, 222.0, 180);

	RenderImage(0x7A63, x, y, 230.0, 45.f);

	y += 45.f;

	for (int i = 0; i < 6; ++i) {
		RenderImage(0x7A58, x, y, 230.0, 15.f);
		y += 15.f;
	}

	RenderImage(0x7A58, x, y, 230.0, 5.f);
	y += 5.f;

	RenderImage(0x7A59, x, y, 230.0, 45.f);

	y = 95;

	DWORD StructImage = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, 0x7A5B);

	int m_fButtonWidth = 54;
	int m_fButtonHeight = 30;

	if (StructImage != 0) {
		RenderImage2(0x7A5B, x + (((230 / 2) - 54) / 2), y + 180 - 50, 54, 30,
			(0.5f / (float)*(float*)(StructImage + 260)), ((this->m_EventKey * m_fButtonHeight + 0.5f) / (float)*(float*)(StructImage + 264)),
			(m_fButtonWidth - 0.5f) / (float)*(float*)(StructImage + 260) - (0.5f / (float)*(float*)(StructImage + 260)),
			(m_fButtonHeight - 0.5f) / (float)*(float*)(StructImage + 264) - (0.5f / (float)*(float*)(StructImage + 264)), 1, 1, 0);
	}

	DWORD StructImage2 = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, 0x7A5C);

	if (StructImage2 != 0) {
		RenderImage2(0x7A5C, x + (230 / 2) + (((230 / 2) - 54) / 2), y + 180 - 50, 54, 30,
			(0.5f / (float)*(float*)(StructImage2 + 260)), ((this->m_EventKey2 * m_fButtonHeight + 0.5f) / (float)*(float*)(StructImage2 + 264)),
			(m_fButtonWidth - 0.5f) / (float)*(float*)(StructImage2 + 260) - (0.5f / (float)*(float*)(StructImage2 + 260)),
			(m_fButtonHeight - 0.5f) / (float)*(float*)(StructImage2 + 264) - (0.5f / (float)*(float*)(StructImage2 + 264)), 1, 1, 0);
	}

	if (CheckMouseIn(this->m_x + (230 / 2) - (50 / 2) - 18, this->m_y + (180 / 2) - 18, 12, 12)) {
		glColor3f(0.6f, 0.6f, 0.6f);
	}

	//-
	if (IsPressKey(VK_LBUTTON) && CheckMouseIn(this->m_x + (230 / 2) - (50 / 2) - 18, this->m_y + (180 / 2) - 18, 12, 12)) {
		RenderImage2(this->m_IndexMinusCliked, x + (230 / 2) - (50 / 2) - 18, y + (180 / 2) - 18, 12, 12, 0, 0, 1.0, 0.919724525, 1, 1, 1);
	}
	else {
		RenderImage2(this->m_IndexMinus, x + (230 / 2) - (50 / 2) - 18, y + (180 / 2) - 18, 12, 12, 0, 0, 1.0, 0.919724525, 1, 1, 1);
	}

	glColor3f(1.0f, 1.0f, 1.0f);

	if (CheckMouseIn(this->m_x + (230 / 2) + 30, this->m_y + (180 / 2) - 18, 12, 12)) {
		glColor3f(0.6f, 0.6f, 0.6f);
	}

	//+
	if (IsPressKey(VK_LBUTTON) && CheckMouseIn(this->m_x + (230 / 2) + 30, this->m_y + (180 / 2) - 18, 12, 12)) {
		RenderImage2(this->m_IndexAddCliked, x + (230 / 2) + 30, y + (180 / 2) - 18, 12, 12, 0, 0, 1.0, 0.919724525, 1, 1, 1);
	}
	else {
		RenderImage2(this->m_IndexAdd, x + (230 / 2) + 30, y + (180 / 2) - 18, 12, 12, 0, 0, 1.0, 0.919724525, 1, 1, 1);
	}

	glColor3f(1.0f, 1.0f, 1.0f);

	this->RenderItem(x + (230 / 2) - (30 / 2), y + (180 / 2) - 55);

	EnableAlphaTest(1);

	glColor4f(0.f, 0.f, 0.f, 1.f);

	pDrawBarForm(x + (230 /2) - (50 /2), y + (180/2) - 20, 50, 15, 0.0, 0);

	((void(*)())0x637A30)();

	pSetTextBgColor2(pTextThis(), 0);

	pSetTextColor(pTextThis(), 255, 189, 25, 255);

	pTextSetFont(pTextThis(), g_hFontBold);

	char buffer[15];
	sprintf(buffer, "%d", this->m_ValueGetStack);

	pDrawText(pTextThis(), x + (230 / 2) - (50 / 2), y + (180 / 2) - 15, buffer, 50, 0, 3, 0);

	auto itemAttribute = pGetItemAttr(this->m_ItemIndex);

	if (itemAttribute) {
		pDrawText(pTextThis(), x, y + 10, itemAttribute->Name, 230, 0, 3, 0);
	}

	DisableAlphaBlend();
}
